@file:OptIn(ExperimentalMaterial3ExpressiveApi::class)

package com.example.ui.rhythm

import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ExperimentalMaterial3ExpressiveApi
import androidx.compose.material3.MaterialShapes
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.remember
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Matrix
import androidx.compose.ui.graphics.Outline
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.asComposePath
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.graphics.shapes.RoundedPolygon
import androidx.graphics.shapes.toPath

/**
 * Authentic Material 3 Expressive shapes ported from Rhythm's `MaterialShapesUtils.kt`
 * and `ExpressiveShapeProvider.kt`, backed by `androidx.compose.material3.MaterialShapes`
 * and `androidx.graphics.shapes.RoundedPolygon`.
 */
enum class ExpressiveMaterialShape(
  val displayName: String,
) {
  CIRCLE("Circle"),
  SQUARE("Square"),
  OVAL("Oval"),
  PILL("Pill"),
  DIAMOND("Diamond"),
  TRIANGLE("Triangle"),
  PENTAGON("Pentagon"),
  FLOWER("Flower"),
  CLOVER_4_LEAF("4-Leaf Clover"),
  CLOVER_8_LEAF("8-Leaf Clover"),
  HEART("Heart"),
  BOOM("Boom"),
  SOFT_BOOM("Soft Boom"),
  BURST("Burst"),
  SOFT_BURST("Soft Burst"),
  SUNNY("Sunny"),
  VERY_SUNNY("Very Sunny"),
  COOKIE_4("Cookie 4"),
  COOKIE_6("Cookie 6"),
  COOKIE_7("Cookie 7"),
  COOKIE_9("Cookie 9"),
  COOKIE_12("Cookie 12"),
  GHOSTISH("Ghostish"),
  PUFFY("Puffy"),
  PUFFY_DIAMOND("Puffy Diamond"),
  BUN("Bun"),
  FAN("Fan"),
  ARROW("Arrow"),
  ARCH("Arch"),
  CLAM_SHELL("Clam Shell"),
  GEM("Gem"),
  SEMI_CIRCLE("Semi Circle"),
  SLANTED("Slanted"),
  PIXEL_CIRCLE("Pixel Circle"),
  PIXEL_TRIANGLE("Pixel Triangle");

  fun getRoundedPolygon(): RoundedPolygon = when (this) {
    CIRCLE -> MaterialShapes.Circle
    SQUARE -> MaterialShapes.Square
    OVAL -> MaterialShapes.Oval
    PILL -> MaterialShapes.Pill
    DIAMOND -> MaterialShapes.Diamond
    TRIANGLE -> MaterialShapes.Triangle
    PENTAGON -> MaterialShapes.Pentagon
    FLOWER -> MaterialShapes.Flower
    CLOVER_4_LEAF -> MaterialShapes.Clover4Leaf
    CLOVER_8_LEAF -> MaterialShapes.Clover8Leaf
    HEART -> MaterialShapes.Heart
    BOOM -> MaterialShapes.Boom
    SOFT_BOOM -> MaterialShapes.SoftBoom
    BURST -> MaterialShapes.Burst
    SOFT_BURST -> MaterialShapes.SoftBurst
    SUNNY -> MaterialShapes.Sunny
    VERY_SUNNY -> MaterialShapes.VerySunny
    COOKIE_4 -> MaterialShapes.Cookie4Sided
    COOKIE_6 -> MaterialShapes.Cookie6Sided
    COOKIE_7 -> MaterialShapes.Cookie7Sided
    COOKIE_9 -> MaterialShapes.Cookie9Sided
    COOKIE_12 -> MaterialShapes.Cookie12Sided
    GHOSTISH -> MaterialShapes.Ghostish
    PUFFY -> MaterialShapes.Puffy
    PUFFY_DIAMOND -> MaterialShapes.PuffyDiamond
    BUN -> MaterialShapes.Bun
    FAN -> MaterialShapes.Fan
    ARROW -> MaterialShapes.Arrow
    ARCH -> MaterialShapes.Arch
    CLAM_SHELL -> MaterialShapes.ClamShell
    GEM -> MaterialShapes.Gem
    SEMI_CIRCLE -> MaterialShapes.SemiCircle
    SLANTED -> MaterialShapes.Slanted
    PIXEL_CIRCLE -> MaterialShapes.PixelCircle
    PIXEL_TRIANGLE -> MaterialShapes.PixelTriangle
  }
}

enum class ExpressiveShapeTarget {
  ALBUM_ART,
  PLAYER_ART,
  SONG_ART,
  PLAYLIST_ART,
  ARTIST_ART,
  PLAYER_CONTROLS,
  MINI_PLAYER,
}

@Immutable
data class RhythmShapeConfig(
  val albumArtShapeId: String = "GHOSTISH",
  val songArtShapeId: String = "CLOVER_8_LEAF",
  val playlistArtShapeId: String = "CLOVER_4_LEAF",
  val miniPlayerShapeId: String = "COOKIE_4",
)

val LocalRhythmShapeConfig = staticCompositionLocalOf { RhythmShapeConfig() }

fun resolveExpressiveShapeEnum(shapeId: String, fallback: ExpressiveMaterialShape): ExpressiveMaterialShape {
  return ExpressiveMaterialShape.entries.firstOrNull { it.name == shapeId } ?: fallback
}

/**
 * Exact Rhythm `RoundedPolygon.toComposeShape()` scaling bounds into target Composable slot.
 * Caches the base Compose Path once per polygon and caches the scaled Outline per measured Size.
 */
fun RoundedPolygon.toComposeShape(): Shape {
  val basePath: Path by lazy(LazyThreadSafetyMode.NONE) {
    this.toPath().asComposePath()
  }
  val baseBounds by lazy(LazyThreadSafetyMode.NONE) {
    basePath.getBounds()
  }
  return object : Shape {
    private var lastSize: Size? = null
    private var cachedOutline: Outline? = null

    override fun createOutline(
      size: Size,
      layoutDirection: LayoutDirection,
      density: Density,
    ): Outline {
      if (size == lastSize && cachedOutline != null) {
        return cachedOutline!!
      }
      val bounds = baseBounds
      val matrix = Matrix()
      val scaleX = size.width / (bounds.width.takeIf { it > 0f } ?: 1f)
      val scaleY = size.height / (bounds.height.takeIf { it > 0f } ?: 1f)
      val scaledWidth = bounds.width * scaleX
      val scaledHeight = bounds.height * scaleY
      val translateX = (size.width - scaledWidth) / 2f - bounds.left * scaleX
      val translateY = (size.height - scaledHeight) / 2f - bounds.top * scaleY

      matrix.scale(scaleX, scaleY)
      matrix.translate(translateX / scaleX, translateY / scaleY)

      val scaledPath = Path()
      scaledPath.addPath(basePath)
      scaledPath.transform(matrix)

      val outline = Outline.Generic(scaledPath)
      lastSize = size
      cachedOutline = outline
      return outline
    }
  }
}

private object ExpressiveShapeCache {
  private val shapesByEnum = java.util.EnumMap<ExpressiveMaterialShape, Shape>(ExpressiveMaterialShape::class.java)

  fun get(shape: ExpressiveMaterialShape): Shape {
    return shapesByEnum.getOrPut(shape) {
      shape.getRoundedPolygon().toComposeShape()
    }
  }
}

@Composable
fun rememberExpressiveShape(shape: ExpressiveMaterialShape): Shape {
  return remember(shape) { ExpressiveShapeCache.get(shape) }
}

@Composable
fun rememberExpressiveShape(shapeId: String): Shape {
  val enumShape = remember(shapeId) {
    ExpressiveMaterialShape.entries.firstOrNull { it.name == shapeId }
      ?: ExpressiveMaterialShape.CIRCLE
  }
  return rememberExpressiveShape(enumShape)
}

@Composable
fun rememberExpressiveShapeFor(
  target: ExpressiveShapeTarget,
  fallbackShape: Shape = RoundedCornerShape(16.dp),
): Shape {
  val config = LocalRhythmShapeConfig.current
  return remember(target, config, fallbackShape) {
    when (target) {
      ExpressiveShapeTarget.PLAYER_ART -> CircleShape
      ExpressiveShapeTarget.PLAYER_CONTROLS -> ExpressiveShapeCache.get(ExpressiveMaterialShape.SUNNY)
      ExpressiveShapeTarget.MINI_PLAYER -> ExpressiveShapeCache.get(
        resolveExpressiveShapeEnum(config.miniPlayerShapeId, ExpressiveMaterialShape.COOKIE_4),
      )
      ExpressiveShapeTarget.ARTIST_ART -> CircleShape
      ExpressiveShapeTarget.ALBUM_ART -> ExpressiveShapeCache.get(
        resolveExpressiveShapeEnum(config.albumArtShapeId, ExpressiveMaterialShape.GHOSTISH),
      )
      ExpressiveShapeTarget.PLAYLIST_ART -> ExpressiveShapeCache.get(
        resolveExpressiveShapeEnum(config.playlistArtShapeId, ExpressiveMaterialShape.CLOVER_4_LEAF),
      )
      ExpressiveShapeTarget.SONG_ART -> ExpressiveShapeCache.get(
        resolveExpressiveShapeEnum(config.songArtShapeId, ExpressiveMaterialShape.CLOVER_8_LEAF),
      )
    }
  }
}
