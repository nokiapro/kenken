package com.example.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.model.SleepTimerUiState
import com.example.model.Song
import com.example.ui.AppearanceSettings
import com.example.ui.AuthUiState
import com.example.ui.FormatUtils
import com.example.ui.PersonalizationSection
import com.example.ui.PersonalizationSettings
import com.example.ui.RhythmColorPreset
import com.example.ui.ThemeMode
import com.example.ui.components.Material3SettingsGroup
import com.example.ui.components.Material3SettingsItem
import com.example.ui.components.RhythmCollapsibleHeaderScreen
import com.example.ui.components.RhythmHeaderAction
import com.example.ui.components.SettingsPalettes
import com.example.ui.rhythm.RhythmIcons
import com.example.ui.rhythm.RhythmSymbolIcon
import java.text.NumberFormat
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfileScreen(
  authState: AuthUiState,
  sleepTimerState: SleepTimerUiState,
  bottomOverlayPadding: PaddingValues,
  onLogin: (email: String, password: String) -> Unit,
  onRegister: (email: String, password: String, displayName: String) -> Unit = { _, _, _ -> },
  onRefreshProfile: () -> Unit,
  onLogout: () -> Unit,
  onClearAuthError: () -> Unit = {},
  onPlayPurchasedSong: (String) -> Unit,
  onStartSleepTimer: (Int) -> Unit = {},
  onStartSleepAfterCurrentTrack: () -> Unit = {},
  onCancelSleepTimer: () -> Unit = {},
  appearanceSettings: AppearanceSettings = AppearanceSettings(),
  personalizationSettings: PersonalizationSettings = PersonalizationSettings(),
  onThemeModeChange: (ThemeMode) -> Unit = {},
  onDynamicColorChange: (Boolean) -> Unit = {},
  onColorPresetChange: (RhythmColorPreset) -> Unit = {},
  onAmoledModeChange: (Boolean) -> Unit = {},
  onOpenPersonalization: (PersonalizationSection) -> Unit = {},
  blockedSongIds: Set<String> = emptySet(),
  allKnownSongs: List<Song> = emptyList(),
  onUpdateDisplayName: (String) -> Unit = {},
  onUnblockSong: (String) -> Unit = {},
) {
  val session = authState.session
  val currencyFormatter = remember { NumberFormat.getNumberInstance(Locale.forLanguageTag("vi-VN")) }

  var email by remember { mutableStateOf("") }
  var password by remember { mutableStateOf("") }
  var showEditNameDialog by remember { mutableStateOf(false) }
  var showPurchasesSheet by remember { mutableStateOf(false) }

  val songsById = remember(allKnownSongs) { allKnownSongs.associateBy { it.id } }
  val validPurchases = remember(authState.purchases, songsById) {
    authState.purchases
      .distinctBy { it.songId }
      .filter { record ->
        if (songsById.isNotEmpty()) {
          record.songId in songsById
        } else {
          !record.songTitle.startsWith("Bài hát #")
        }
      }
  }

  RhythmCollapsibleHeaderScreen(
    title = "Cá nhân & Cài đặt",
    headerActions = if (session != null) {
      listOf(
        RhythmHeaderAction(
          icon = RhythmIcons.Refresh,
          contentDescription = "Đồng bộ tài khoản",
          onClick = onRefreshProfile,
        ),
      )
    } else emptyList(),
  ) { scaffoldModifier ->
    LazyColumn(
      modifier = scaffoldModifier
        .fillMaxSize()
        .testTag("profile_list"),
      contentPadding = PaddingValues(
        start = 16.dp,
        end = 16.dp,
        top = 8.dp,
        bottom = bottomOverlayPadding.calculateBottomPadding() + 28.dp,
      ),
      verticalArrangement = Arrangement.spacedBy(6.dp),
    ) {
      // 1. Account Section — Rhythm Material3SettingsGroup Stack
      item(key = "account_group") {
        if (session == null) {
          Card(
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer),
            elevation = CardDefaults.cardElevation(defaultElevation = 0.dp),
            modifier = Modifier
              .fillMaxWidth()
              .padding(top = 6.dp),
          ) {
            Column(
              modifier = Modifier.padding(18.dp),
              verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
              Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp),
              ) {
                Surface(
                  shape = CircleShape,
                  color = SettingsPalettes.Indigo.container,
                  modifier = Modifier.size(44.dp),
                ) {
                  Box(contentAlignment = Alignment.Center) {
                    RhythmSymbolIcon(
                      icon = RhythmIcons.AccountCircle,
                      contentDescription = null,
                      tint = SettingsPalettes.Indigo.tint,
                      size = 24.dp,
                      modifier = Modifier.size(24.dp),
                    )
                  }
                }
                Text(
                  text = "Đăng nhập",
                  style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                  modifier = Modifier.weight(1f),
                )
              }

              OutlinedTextField(
                value = email,
                onValueChange = { email = it },
                label = { Text("Email") },
                singleLine = true,
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                  .fillMaxWidth()
                  .testTag("auth_email_input"),
              )

              OutlinedTextField(
                value = password,
                onValueChange = { password = it },
                label = { Text("Mật khẩu") },
                singleLine = true,
                visualTransformation = PasswordVisualTransformation(),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                  .fillMaxWidth()
                  .testTag("auth_password_input"),
              )

              if (!authState.errorMessage.isNullOrBlank()) {
                Text(
                  text = authState.errorMessage,
                  style = MaterialTheme.typography.bodySmall,
                  color = MaterialTheme.colorScheme.error,
                )
              }

              Button(
                onClick = { onLogin(email.trim(), password) },
                enabled = email.isNotBlank() && password.isNotBlank() && !authState.isLoading,
                shape = CircleShape,
                modifier = Modifier
                  .fillMaxWidth()
                  .height(48.dp)
                  .testTag("auth_submit_button"),
              ) {
                if (authState.isLoading) {
                  CircularProgressIndicator(
                    modifier = Modifier.size(18.dp),
                    strokeWidth = 2.dp,
                    color = MaterialTheme.colorScheme.onPrimary,
                  )
                } else {
                  RhythmSymbolIcon(
                    icon = RhythmIcons.Login,
                    contentDescription = null,
                    size = 18.dp,
                    modifier = Modifier.size(18.dp),
                  )
                  Spacer(Modifier.width(8.dp))
                  Text("Đăng nhập")
                }
              }
            }
          }
        } else {
          val balanceText = "${currencyFormatter.format(session.user.balance)}đ"
          Material3SettingsGroup(
            title = "Tài khoản XK Music",
            items = listOf(
              Material3SettingsItem(
                icon = RhythmIcons.AccountCircle,
                title = session.user.displayName.ifBlank { session.user.email },
                subtitle = session.user.email,
                palette = SettingsPalettes.Indigo,
                trailingText = session.user.role?.uppercase(),
              ),
              Material3SettingsItem(
                icon = RhythmIcons.Edit,
                title = "Đổi tên hiển thị",
                subtitle = "Cập nhật hồ sơ tài khoản đồng bộ web",
                palette = SettingsPalettes.SkyBlue,
                showChevron = true,
                onClick = { showEditNameDialog = true },
                testTag = "edit_display_name_button",
              ),
              Material3SettingsItem(
                icon = RhythmIcons.Wallet,
                title = "Số dư tài khoản",
                subtitle = "Đồng bộ trực tiếp với xkmu.xuanken.name.vn",
                palette = SettingsPalettes.Emerald,
                trailingText = balanceText,
              ),
              Material3SettingsItem(
                icon = RhythmIcons.Logout,
                title = "Đăng xuất",
                subtitle = "Thoát phiên đăng nhập trên thiết bị này",
                palette = SettingsPalettes.Coral,
                onClick = onLogout,
                testTag = "logout_button",
              ),
            ),
          )
        }
      }

      // 2. Cá nhân hóa — chỉ hiển thị với thành viên đã đăng nhập
      if (session != null) {
        item(key = "personalization_group") {
        val sleepSubtitle = when {
          !sleepTimerState.isActive -> "Đang tắt"
          sleepTimerState.stopAfterCurrentSong -> "Tắt khi hết bài hiện tại"
          else -> "Còn ${FormatUtils.formatDurationMs(sleepTimerState.remainingSeconds * 1000L)}"
        }
        val speedText = String.format(Locale.US, "%.2fx", personalizationSettings.playbackSpeed)
          .replace(".00x", ".0x")

        val personalizationItems = listOf(
          Material3SettingsItem(
            icon = RhythmIcons.DarkMode,
            title = "Chọn chế độ chủ đề",
            subtitle = "Hệ thống - Ánh sáng - Bóng tối",
            palette = SettingsPalettes.Purple,
            testTag = "personalization_theme_mode",
            customContent = {
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
              ) {
                ThemeMode.entries.forEach { mode ->
                  FilterChip(
                    selected = appearanceSettings.themeMode == mode,
                    onClick = { onThemeModeChange(mode) },
                    label = { Text(mode.label, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                    shape = CircleShape,
                    colors = FilterChipDefaults.filterChipColors(
                      selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                      selectedLabelColor = MaterialTheme.colorScheme.onPrimaryContainer,
                    ),
                    modifier = Modifier
                      .weight(1f)
                      .testTag("theme_mode_${mode.name.lowercase()}"),
                  )
                }
              }
            },
          ),
          Material3SettingsItem(
            icon = RhythmIcons.SleepTimer,
            title = PersonalizationSection.SLEEP_TIMER.title,
            subtitle = sleepSubtitle,
            palette = SettingsPalettes.Orange,
            trailingText = if (sleepTimerState.isActive) "BẬT" else null,
            showChevron = true,
            onClick = { onOpenPersonalization(PersonalizationSection.SLEEP_TIMER) },
            testTag = "personalization_sleep_timer",
          ),
          Material3SettingsItem(
            icon = RhythmIcons.Speed,
            title = PersonalizationSection.PLAYER_CONTROLS.title,
            subtitle = "Tốc độ $speedText • ${if (personalizationSettings.useWavySeekbar) "Thanh tua sóng" else "Thanh tua chuẩn"}",
            palette = SettingsPalettes.SkyBlue,
            showChevron = true,
            onClick = { onOpenPersonalization(PersonalizationSection.PLAYER_CONTROLS) },
            testTag = "personalization_player_controls",
          ),
          Material3SettingsItem(
            icon = RhythmIcons.Palette,
            title = PersonalizationSection.COLOR_CUSTOMIZATION.title,
            subtitle = "${appearanceSettings.colorPreset.label} • ${personalizationSettings.paletteStyle.label}",
            palette = SettingsPalettes.Rose,
            showChevron = true,
            onClick = { onOpenPersonalization(PersonalizationSection.COLOR_CUSTOMIZATION) },
            testTag = "personalization_color_customization",
          ),
          Material3SettingsItem(
            icon = RhythmIcons.Content.Category,
            title = PersonalizationSection.SHAPE_CUSTOMIZATION.title,
            subtitle = "Album, bài hát, playlist & Mini Player",
            palette = SettingsPalettes.Teal,
            showChevron = true,
            onClick = { onOpenPersonalization(PersonalizationSection.SHAPE_CUSTOMIZATION) },
            testTag = "personalization_shape_customization",
          ),
          Material3SettingsItem(
            icon = RhythmIcons.TextFields,
            title = PersonalizationSection.FONT_CUSTOMIZATION.title,
            subtitle = "${personalizationSettings.fontOption.label} • Cỡ ${personalizationSettings.fontScale.label}",
            palette = SettingsPalettes.Indigo,
            showChevron = true,
            onClick = { onOpenPersonalization(PersonalizationSection.FONT_CUSTOMIZATION) },
            testTag = "personalization_font_customization",
          ),
          Material3SettingsItem(
            icon = RhythmIcons.Smartphone,
            title = PersonalizationSection.FLOATING_NAV_BAR.title,
            subtitle = if (personalizationSettings.floatingNavBarEnabled) {
              "Thanh nổi viên thuốc • ${personalizationSettings.navBarLabelBehavior.label}"
            } else {
              "Thanh điều hướng gắn đáy"
            },
            palette = SettingsPalettes.Cyan,
            showChevron = true,
            onClick = { onOpenPersonalization(PersonalizationSection.FLOATING_NAV_BAR) },
            testTag = "personalization_floating_nav_bar",
          ),
          Material3SettingsItem(
            icon = RhythmIcons.Celebration,
            title = PersonalizationSection.FESTIVE_THEME.title,
            subtitle = personalizationSettings.festiveThemeMode.label,
            palette = SettingsPalettes.Amber,
            showChevron = true,
            onClick = { onOpenPersonalization(PersonalizationSection.FESTIVE_THEME) },
            testTag = "personalization_festive_theme",
          ),
          Material3SettingsItem(
            icon = RhythmIcons.TouchApp,
            title = PersonalizationSection.GESTURES.title,
            subtitle = if (personalizationSettings.swipeArtworkToSkip || personalizationSettings.swipeDownToDismissPlayer) {
              "Cử chỉ vuốt trình phát & Mini Player"
            } else {
              "Đã tắt thao tác vuốt"
            },
            palette = SettingsPalettes.Teal,
            showChevron = true,
            onClick = { onOpenPersonalization(PersonalizationSection.GESTURES) },
            testTag = "personalization_gestures",
          ),
          Material3SettingsItem(
            icon = RhythmIcons.Equalizer,
            title = PersonalizationSection.EQUALIZER.title,
            subtitle = if (personalizationSettings.equalizerEnabled) {
              "Đang bật • ${personalizationSettings.equalizerPreset.label}"
            } else {
              "Đang tắt • Bass Boost & 5 dải tần"
            },
            palette = SettingsPalettes.Emerald,
            showChevron = true,
            onClick = { onOpenPersonalization(PersonalizationSection.EQUALIZER) },
            testTag = "personalization_equalizer",
          ),
          Material3SettingsItem(
            icon = RhythmIcons.Lyrics,
            title = PersonalizationSection.LYRICS.title,
            subtitle = "${personalizationSettings.lyricsAlignment.label} • Cỡ ${personalizationSettings.lyricsFontSize.label}",
            palette = SettingsPalettes.Yellow,
            showChevron = true,
            onClick = { onOpenPersonalization(PersonalizationSection.LYRICS) },
            testTag = "personalization_lyrics",
          ),
        )

        Material3SettingsGroup(
          title = "Cá nhân hóa",
          items = personalizationItems,
        )
        }
      }

      // 3. Purchased Songs History (gom gọn 1 mục, bấm để mở danh sách)
      if (session != null) {
        item(key = "purchases_group") {
          Material3SettingsGroup(
            title = "Kho nhạc đã mở khóa",
            items = listOf(
              Material3SettingsItem(
                icon = RhythmIcons.ShoppingBag,
                title = "Bài hát đã mua & mở khóa",
                subtitle = if (validPurchases.isEmpty()) {
                  "Chưa có bài hát trả phí nào trong lịch sử"
                } else {
                  "Chạm để xem toàn bộ ${validPurchases.size} bài hát"
                },
                palette = SettingsPalettes.Emerald,
                trailingText = "${validPurchases.size} bài",
                showChevron = validPurchases.isNotEmpty(),
                onClick = if (validPurchases.isNotEmpty()) ({ showPurchasesSheet = true }) else null,
                testTag = "open_purchased_songs_button",
              ),
            ),
          )
        }
      }

      // 4. Blocked Songs Management
      if (blockedSongIds.isNotEmpty()) {
        item(key = "blocked_songs_group") {
          val blockedItems = blockedSongIds.map { sid ->
            val matched = songsById[sid]
            Material3SettingsItem(
              icon = RhythmIcons.Block,
              title = matched?.title ?: "Bài hát #$sid",
              subtitle = matched?.artistName ?: "Chạm để bỏ chặn bài hát này",
              palette = SettingsPalettes.Coral,
              trailingText = "Bỏ chặn",
              onClick = { onUnblockSong(sid) },
            )
          }
          Material3SettingsGroup(
            title = "Bài hát đã chặn (${blockedSongIds.size})",
            items = blockedItems,
          )
        }
      }
    }
  }

  if (showPurchasesSheet && session != null) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    ModalBottomSheet(
      onDismissRequest = { showPurchasesSheet = false },
      sheetState = sheetState,
      containerColor = MaterialTheme.colorScheme.surfaceContainerLow,
    ) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .heightIn(max = 540.dp)
          .padding(horizontal = 20.dp)
          .padding(bottom = 28.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
      ) {
        Text(
          text = "Kho nhạc đã mở khóa (${validPurchases.size})",
          style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
        )
        LazyColumn(
          modifier = Modifier.testTag("purchased_songs_sheet_list"),
          verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
          items(validPurchases, key = { "purchased_${it.songId}" }) { record ->
            val matchedSong = songsById[record.songId]
            val title = matchedSong?.title?.takeIf { it.isNotBlank() } ?: record.songTitle.ifBlank { record.songId }
            val meta = buildString {
              matchedSong?.artistName?.takeIf { it.isNotBlank() }?.let {
                append(it)
                append(" • ")
              }
              append("Đã mở khóa • ${currencyFormatter.format(record.price)}đ")
            }
            Surface(
              onClick = {
                showPurchasesSheet = false
                onPlayPurchasedSong(record.songId)
              },
              shape = RoundedCornerShape(18.dp),
              color = MaterialTheme.colorScheme.surfaceContainer,
              modifier = Modifier.testTag("purchased_song_${record.songId}"),
            ) {
              Row(
                modifier = Modifier
                  .fillMaxWidth()
                  .padding(horizontal = 14.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp),
              ) {
                Surface(
                  shape = CircleShape,
                  color = SettingsPalettes.Emerald.container,
                  modifier = Modifier.size(40.dp),
                ) {
                  Box(contentAlignment = Alignment.Center) {
                    RhythmSymbolIcon(
                      icon = RhythmIcons.MusicNote,
                      contentDescription = null,
                      tint = SettingsPalettes.Emerald.tint,
                      size = 20.dp,
                      modifier = Modifier.size(20.dp),
                    )
                  }
                }
                Column(modifier = Modifier.weight(1f)) {
                  Text(
                    text = title,
                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.SemiBold),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                  )
                  Text(
                    text = meta,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                  )
                }
                Text(
                  text = "Nghe",
                  style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold),
                  color = MaterialTheme.colorScheme.primary,
                )
              }
            }
          }
        }
      }
    }
  }

  if (showEditNameDialog && session != null) {
    var nextName by remember(session.user.displayName) { mutableStateOf(session.user.displayName) }
    AlertDialog(
      onDismissRequest = { showEditNameDialog = false },
      title = { Text("Đổi tên hiển thị", style = MaterialTheme.typography.titleLarge) },
      text = {
        OutlinedTextField(
          value = nextName,
          onValueChange = { nextName = it },
          label = { Text("Tên hiển thị mới") },
          singleLine = true,
          modifier = Modifier.fillMaxWidth(),
        )
      },
      confirmButton = {
        Button(
          onClick = {
            onUpdateDisplayName(nextName.trim())
            showEditNameDialog = false
          },
          enabled = nextName.isNotBlank() && !authState.isUpdatingProfile,
        ) {
          Text("Lưu")
        }
      },
      dismissButton = {
        TextButton(onClick = { showEditNameDialog = false }) {
          Text("Hủy")
        }
      },
    )
  }
}
