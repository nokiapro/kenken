package com.example.data.network

import com.example.model.Playlist
import com.example.model.Song
import com.example.model.UserProfile
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject

/**
 * Lightweight Firestore REST fallback for project `newmusic-5625b` so that
 * playlists, member profiles, and song_masters stored in Firestore are also
 * seamlessly synced alongside Firebase RTDB.
 */
object XkFirestoreHelper {
  private const val PROJECT_BASE =
    "https://firestore.googleapis.com/v1/projects/newmusic-5625b/databases/(default)/documents"
  private val jsonType = "application/json; charset=utf-8".toMediaType()

  fun fetchUserPlaylists(
    uid: String,
    idToken: String,
    isAdmin: Boolean,
    songsLookup: Map<String, Song>,
  ): List<Playlist> {
    if (idToken.isBlank()) return emptyList()
    val structuredQuery = JSONObject().apply {
      put(
        "from",
        JSONArray().put(JSONObject().put("collectionId", "playlists")),
      )
      if (!isAdmin && uid.isNotBlank()) {
        put(
          "where",
          JSONObject().put(
            "fieldFilter",
            JSONObject().apply {
              put("field", JSONObject().put("fieldPath", "userId"))
              put("op", "EQUAL")
              put("value", JSONObject().put("stringValue", uid))
            },
          ),
        )
      }
    }
    val payload = JSONObject().put("structuredQuery", structuredQuery).toString()
    val req = Request.Builder()
      .url("$PROJECT_BASE:runQuery")
      .header("Authorization", "Bearer $idToken")
      .post(payload.toRequestBody(jsonType))
      .build()

    val bodyStr = runCatching {
      ApiClient.okHttpClient.newCall(req).execute().use { res ->
        if (res.isSuccessful) res.body?.string().orEmpty() else ""
      }
    }.getOrDefault("")

    if (!bodyStr.trim().startsWith("[")) return emptyList()

    val result = mutableListOf<Playlist>()
    val arr = runCatching { JSONArray(bodyStr) }.getOrNull() ?: return emptyList()
    for (i in 0 until arr.length()) {
      val doc = arr.optJSONObject(i)?.optJSONObject("document") ?: continue
      val fields = doc.optJSONObject("fields") ?: continue
      val docId = doc.optString("name").substringAfterLast("/")
      val id = fields.fsString("id") ?: docId
      val title = fields.fsString("title") ?: fields.fsString("name") ?: "Playlist"
      val desc = fields.fsString("description")
      val songIds = fields.fsStringArray("songIds")
      val matchedSongs = songIds.mapNotNull { songsLookup[it] }
      val cover = fields.fsString("coverImage") ?: fields.fsString("coverUrl")
        ?: matchedSongs.firstOrNull { !it.coverUrl.isNullOrBlank() }?.coverUrl
      val userId = fields.fsString("userId") ?: fields.fsString("ownerId") ?: fields.fsString("uid")
      val curator = fields.fsString("curator") ?: fields.fsString("userName") ?: "XuanKen Music"
      result.add(
        Playlist(
          id = id,
          title = title,
          description = desc,
          coverUrl = cover,
          curator = curator,
          curatorId = userId,
          songCount = maxOf(songIds.size, matchedSongs.size),
          songs = matchedSongs,
        ),
      )
    }
    return result
  }

  fun fetchUserPurchases(
    uid: String,
    idToken: String,
  ): List<String> {
    if (uid.isBlank() || idToken.isBlank()) return emptyList()
    val structuredQuery = JSONObject().apply {
      put("from", JSONArray().put(JSONObject().put("collectionId", "purchases")))
      put(
        "where",
        JSONObject().put(
          "fieldFilter",
          JSONObject().apply {
            put("field", JSONObject().put("fieldPath", "userId"))
            put("op", "EQUAL")
            put("value", JSONObject().put("stringValue", uid))
          },
        ),
      )
    }
    val payload = JSONObject().put("structuredQuery", structuredQuery).toString()
    val req = Request.Builder()
      .url("$PROJECT_BASE:runQuery")
      .header("Authorization", "Bearer $idToken")
      .post(payload.toRequestBody(jsonType))
      .build()
    val bodyStr = runCatching {
      ApiClient.okHttpClient.newCall(req).execute().use { res ->
        if (res.isSuccessful) res.body?.string().orEmpty() else ""
      }
    }.getOrDefault("")
    if (!bodyStr.trim().startsWith("[")) return emptyList()
    val ids = linkedSetOf<String>()
    val arr = runCatching { JSONArray(bodyStr) }.getOrNull() ?: return emptyList()
    for (i in 0 until arr.length()) {
      val fields = arr.optJSONObject(i)?.optJSONObject("document")?.optJSONObject("fields") ?: continue
      fields.fsString("songId")?.let { ids.add(it) }
    }
    return ids.toList()
  }

  fun fetchMemberProfile(
    uid: String,
    idToken: String,
    fallbackEmail: String,
    fallbackName: String,
  ): UserProfile? {
    if (uid.isBlank() || idToken.isBlank()) return null
    val req = Request.Builder()
      .url("$PROJECT_BASE/members/$uid")
      .header("Authorization", "Bearer $idToken")
      .get()
      .build()
    val bodyStr = runCatching {
      ApiClient.okHttpClient.newCall(req).execute().use { res ->
        if (res.isSuccessful) res.body?.string().orEmpty() else ""
      }
    }.getOrDefault("")
    val doc = runCatching { JSONObject(bodyStr) }.getOrNull() ?: return null
    val fields = doc.optJSONObject("fields") ?: return null
    return UserProfile(
      uid = fields.fsString("uid") ?: uid,
      email = fields.fsString("email") ?: fallbackEmail,
      displayName = fields.fsString("displayName") ?: fallbackName,
      avatarUrl = fields.fsString("avatarUrl"),
      balance = fields.fsLong("balance"),
      role = fields.fsString("role"),
      purchasedSongIds = fields.fsStringArray("purchasedSongIds"),
      likedSongIds = fields.fsStringArray("likedSongIds"),
    )
  }

  fun fetchSongMasterUrl(songId: String, idToken: String): String? {
    if (songId.isBlank() || idToken.isBlank()) return null
    val req = Request.Builder()
      .url("$PROJECT_BASE/song_masters/$songId")
      .header("Authorization", "Bearer $idToken")
      .get()
      .build()
    val bodyStr = runCatching {
      ApiClient.okHttpClient.newCall(req).execute().use { res ->
        if (res.isSuccessful) res.body?.string().orEmpty() else ""
      }
    }.getOrDefault("")
    val doc = runCatching { JSONObject(bodyStr) }.getOrNull() ?: return null
    val fields = doc.optJSONObject("fields") ?: return null
    val keys = listOf(
      "mp3Url", "mp3_url", "masterUrl", "fullUrl",
      "wavUrl", "wav_url", "flacUrl", "streamUrl", "audioUrl", "url",
    )
    for (key in keys) {
      val v = fields.fsString(key)?.takeIf { it.isNotBlank() }
      if (v != null) return v
    }
    return null
  }

  private fun JSONObject.fsString(key: String): String? {
    val valObj = optJSONObject(key) ?: return null
    val s = valObj.optString("stringValue", "")
    return s.takeIf { it.isNotBlank() && it != "null" }
  }

  private fun JSONObject.fsLong(key: String): Long {
    val valObj = optJSONObject(key) ?: return 0L
    if (valObj.has("integerValue")) return valObj.optString("integerValue").toLongOrNull() ?: 0L
    if (valObj.has("doubleValue")) return valObj.optDouble("doubleValue", 0.0).toLong()
    return 0L
  }

  private fun JSONObject.fsStringArray(key: String): List<String> {
    val arr = optJSONObject(key)?.optJSONObject("arrayValue")?.optJSONArray("values") ?: return emptyList()
    return buildList {
      for (i in 0 until arr.length()) {
        val item = arr.optJSONObject(i)?.optString("stringValue", "")
        if (!item.isNullOrBlank()) add(item)
      }
    }
  }
}
