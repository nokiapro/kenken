package com.example.data.network

import okhttp3.RequestBody
import okhttp3.ResponseBody
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.DELETE
import retrofit2.http.Field
import retrofit2.http.FormUrlEncoded
import retrofit2.http.GET
import retrofit2.http.PATCH
import retrofit2.http.POST
import retrofit2.http.PUT
import retrofit2.http.Path
import retrofit2.http.Query
import retrofit2.http.Url

interface XkMusicApiService {

  // Auth endpoints
  @POST("api/v1/auth/login")
  suspend fun login(@Body body: RequestBody): Response<ResponseBody>

  @POST("api/v1/auth/register")
  suspend fun register(@Body body: RequestBody): Response<ResponseBody>

  @POST("api/v1/auth/refresh")
  suspend fun refreshToken(@Body body: RequestBody): Response<ResponseBody>

  // Home & Search
  @GET("api/v1/home")
  suspend fun getHome(): Response<ResponseBody>

  @GET("api/v1/search")
  suspend fun search(@Query("q") query: String): Response<ResponseBody>

  // User profile, settings, likes & blocks
  @GET("api/v1/me")
  suspend fun getMe(): Response<ResponseBody>

  @PATCH("api/v1/me")
  suspend fun updateMe(@Body body: RequestBody): Response<ResponseBody>

  @GET("api/v1/me/settings")
  suspend fun getMeSettings(): Response<ResponseBody>

  @PATCH("api/v1/me/settings")
  suspend fun updateMeSettings(@Body body: RequestBody): Response<ResponseBody>

  @POST("api/v1/me/likes")
  suspend fun toggleLike(@Body body: RequestBody): Response<ResponseBody>

  @POST("api/v1/me/album-likes")
  suspend fun toggleAlbumLike(@Body body: RequestBody): Response<ResponseBody>

  @GET("api/v1/me/blocks")
  suspend fun getBlockedSongs(): Response<ResponseBody>

  @POST("api/v1/me/blocks")
  suspend fun blockSong(@Body body: RequestBody): Response<ResponseBody>

  @DELETE("api/v1/me/blocks/{songId}")
  suspend fun unblockSong(@Path("songId") songId: String): Response<ResponseBody>

  // Songs, streaming, download, play count & report
  @GET("api/v1/songs")
  suspend fun getSongs(
    @Query("q") query: String? = null,
    @Query("genre") genre: String? = null,
    @Query("paid") paid: String? = null,
    @Query("sort") sort: String? = "popular",
  ): Response<ResponseBody>

  @GET("api/v1/songs/{id}")
  suspend fun getSongById(@Path("id") id: String): Response<ResponseBody>

  @GET("api/v1/songs/{id}/stream")
  suspend fun getSongStream(@Path("id") id: String): Response<ResponseBody>

  @GET("api/v1/songs/{id}/download")
  suspend fun getSongDownload(@Path("id") id: String): Response<ResponseBody>

  @POST("api/v1/songs/{id}/play")
  suspend fun recordSongPlay(
    @Path("id") id: String,
    @Body body: RequestBody,
  ): Response<ResponseBody>

  @POST("api/v1/songs/{id}/report")
  suspend fun reportSong(
    @Path("id") id: String,
    @Body body: RequestBody,
  ): Response<ResponseBody>

  // Purchases & vouchers
  @POST("api/v1/songs/{id}/purchase")
  suspend fun purchaseSong(
    @Path("id") id: String,
    @Body body: RequestBody,
  ): Response<ResponseBody>

  @GET("api/v1/purchases")
  suspend fun getPurchases(): Response<ResponseBody>

  @POST("api/v1/purchases")
  suspend fun createPurchase(@Body body: RequestBody): Response<ResponseBody>

  @GET("api/v1/vouchers")
  suspend fun getVouchers(): Response<ResponseBody>

  @GET("api/v1/vouchers/validate")
  suspend fun validateVoucher(
    @Query("code") code: String,
    @Query("songId") songId: String? = null,
  ): Response<ResponseBody>

  // Playlists CRUD
  @GET("api/v1/playlists")
  suspend fun getPlaylists(): Response<ResponseBody>

  @POST("api/v1/playlists")
  suspend fun createPlaylist(@Body body: RequestBody): Response<ResponseBody>

  @GET("api/v1/playlists/{id}")
  suspend fun getPlaylistById(@Path("id") id: String): Response<ResponseBody>

  @PATCH("api/v1/playlists/{id}")
  suspend fun updatePlaylist(
    @Path("id") id: String,
    @Body body: RequestBody,
  ): Response<ResponseBody>

  @DELETE("api/v1/playlists/{id}")
  suspend fun deletePlaylist(@Path("id") id: String): Response<ResponseBody>

  // Albums, Artists, Charts, Site
  @GET("api/v1/albums")
  suspend fun getAlbums(): Response<ResponseBody>

  @GET("api/v1/albums/{id}")
  suspend fun getAlbumById(@Path("id") id: String): Response<ResponseBody>

  @GET("api/v1/artists")
  suspend fun getArtists(): Response<ResponseBody>

  @GET("api/v1/artists/{id}")
  suspend fun getArtistById(@Path("id") id: String): Response<ResponseBody>

  @GET("api/v1/charts")
  suspend fun getCharts(): Response<ResponseBody>

  @GET("api/v1/site")
  suspend fun getSiteInfo(): Response<ResponseBody>

  @GET
  suspend fun getTextFromUrl(@Url url: String): Response<ResponseBody>
}

interface XkRtdbApiService {

  @GET("songs.json")
  suspend fun getSongs(): Response<ResponseBody>

  @GET("exclusive_albums.json")
  suspend fun getExclusiveAlbums(): Response<ResponseBody>

  @GET("playlists.json")
  suspend fun getPlaylists(): Response<ResponseBody>

  @GET("playlists.json")
  suspend fun getAllPlaylistsAuthed(
    @Query("auth") authToken: String?,
  ): Response<ResponseBody>

  @GET("playlists.json")
  suspend fun getUserPlaylists(
    @Query("orderBy") orderBy: String = "\"userId\"",
    @Query("equalTo") equalTo: String,
    @Query("auth") authToken: String?,
  ): Response<ResponseBody>

  @PUT("playlists/{id}.json")
  suspend fun upsertPlaylist(
    @Path("id") id: String,
    @Query("auth") authToken: String?,
    @Body body: RequestBody,
  ): Response<ResponseBody>

  @PATCH("playlists/{id}.json")
  suspend fun patchPlaylist(
    @Path("id") id: String,
    @Query("auth") authToken: String?,
    @Body body: RequestBody,
  ): Response<ResponseBody>

  @DELETE("playlists/{id}.json")
  suspend fun deletePlaylist(
    @Path("id") id: String,
    @Query("auth") authToken: String?,
  ): Response<ResponseBody>

  @GET("admins/{uid}.json")
  suspend fun getAdminRecord(
    @Path("uid") uid: String,
    @Query("auth") authToken: String?,
  ): Response<ResponseBody>

  @GET("song_masters/{id}.json")
  suspend fun getSongMaster(
    @Path("id") id: String,
    @Query("auth") authToken: String?,
  ): Response<ResponseBody>

  @GET("song_masters.json")
  suspend fun getAllSongMasters(
    @Query("auth") authToken: String?,
  ): Response<ResponseBody>

  @GET("weekly_plays.json")
  suspend fun getWeeklyPlays(): Response<ResponseBody>

  @GET("site_settings.json")
  suspend fun getSiteSettings(): Response<ResponseBody>

  @GET("artist_bios.json")
  suspend fun getArtistBios(): Response<ResponseBody>

  @GET("vouchers.json")
  suspend fun getVouchers(): Response<ResponseBody>

  @GET("members/{uid}.json")
  suspend fun getMember(
    @Path("uid") uid: String,
    @Query("auth") authToken: String?,
  ): Response<ResponseBody>

  @PATCH("members/{uid}.json")
  suspend fun patchMember(
    @Path("uid") uid: String,
    @Query("auth") authToken: String?,
    @Body body: RequestBody,
  ): Response<ResponseBody>

  @GET("users/{uid}/liked_songs.json")
  suspend fun getUserLikedSongs(
    @Path("uid") uid: String,
    @Query("auth") authToken: String?,
  ): Response<ResponseBody>

  @PUT("users/{uid}/liked_songs.json")
  suspend fun putUserLikedSongs(
    @Path("uid") uid: String,
    @Query("auth") authToken: String?,
    @Body body: RequestBody,
  ): Response<ResponseBody>

  @GET("user_purchases/{uid}.json")
  suspend fun getUserPurchases(
    @Path("uid") uid: String,
    @Query("auth") authToken: String?,
  ): Response<ResponseBody>

  @PUT("user_purchases/{uid}/{songId}.json")
  suspend fun putUserPurchase(
    @Path("uid") uid: String,
    @Path("songId") songId: String,
    @Query("auth") authToken: String?,
    @Body body: RequestBody,
  ): Response<ResponseBody>

  @PUT("purchases/{purchaseId}.json")
  suspend fun putPurchase(
    @Path("purchaseId") purchaseId: String,
    @Query("auth") authToken: String?,
    @Body body: RequestBody,
  ): Response<ResponseBody>
}

interface FirebaseAuthApiService {
  @POST("v1/accounts:signInWithPassword")
  suspend fun signInWithPassword(
    @Query("key") apiKey: String,
    @Body body: RequestBody,
  ): Response<ResponseBody>

  @POST("v1/accounts:signUp")
  suspend fun signUp(
    @Query("key") apiKey: String,
    @Body body: RequestBody,
  ): Response<ResponseBody>

  @POST("v1/accounts:update")
  suspend fun updateProfile(
    @Query("key") apiKey: String,
    @Body body: RequestBody,
  ): Response<ResponseBody>

  @POST("v1/accounts:lookup")
  suspend fun lookupAccount(
    @Query("key") apiKey: String,
    @Body body: RequestBody,
  ): Response<ResponseBody>
}

interface FirebaseTokenApiService {
  @FormUrlEncoded
  @POST("v1/token")
  suspend fun refreshIdToken(
    @Query("key") apiKey: String,
    @Field("grant_type") grantType: String = "refresh_token",
    @Field("refresh_token") refreshToken: String,
  ): Response<ResponseBody>
}
