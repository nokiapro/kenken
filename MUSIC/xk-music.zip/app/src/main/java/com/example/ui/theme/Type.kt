package com.example.ui.theme

import androidx.compose.material3.Typography
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.AppFontOption
import com.example.ui.FontScaleOption

private fun singleFileFontFamily(fontResId: Int): FontFamily = FontFamily(
  Font(fontResId, FontWeight.Normal),
  Font(fontResId, FontWeight.Medium),
  Font(fontResId, FontWeight.SemiBold),
  Font(fontResId, FontWeight.Bold),
  Font(fontResId, FontWeight.ExtraBold),
  Font(fontResId, FontWeight.Black),
)

val RhythmFontFamily = singleFileFontFamily(R.font.plus_jakarta_sans)
val BeVietnamProFontFamily = singleFileFontFamily(R.font.be_vietnam_pro)
val SpaceGroteskFontFamily = singleFileFontFamily(R.font.space_grotesk)
val GeomFontFamily = singleFileFontFamily(R.font.geom)
val PlayfairDisplayFontFamily = singleFileFontFamily(R.font.playfair_display)
val JetBrainsMonoFontFamily = singleFileFontFamily(R.font.jetbrains_mono)

fun fontFamilyForOption(option: AppFontOption): FontFamily = when (option) {
  AppFontOption.PLUS_JAKARTA_SANS -> RhythmFontFamily
  AppFontOption.BE_VIETNAM_PRO -> BeVietnamProFontFamily
  AppFontOption.SPACE_GROTESK -> SpaceGroteskFontFamily
  AppFontOption.GEOM -> GeomFontFamily
  AppFontOption.PLAYFAIR_DISPLAY -> PlayfairDisplayFontFamily
  AppFontOption.JETBRAINS_MONO -> JetBrainsMonoFontFamily
  AppFontOption.SYSTEM -> FontFamily.Default
}

val MonoNumericStyle = TextStyle(
  fontFamily = FontFamily(Font(R.font.jetbrains_mono, FontWeight.Medium)),
  fontWeight = FontWeight.Medium,
  fontSize = 12.sp,
  lineHeight = 16.sp,
  letterSpacing = 0.sp,
  fontFeatureSettings = "tnum",
)

fun buildAppTypography(
  fontOption: AppFontOption = AppFontOption.PLUS_JAKARTA_SANS,
  fontScale: FontScaleOption = FontScaleOption.NORMAL,
): Typography {
  val family = fontFamilyForOption(fontOption)
  val s = fontScale.scale
  return Typography(
    displayLarge = TextStyle(
      fontFamily = family,
      fontWeight = FontWeight.Bold,
      fontSize = (57f * s).sp,
      lineHeight = (64f * s).sp,
      letterSpacing = (-0.25).sp,
    ),
    displayMedium = TextStyle(
      fontFamily = family,
      fontWeight = FontWeight.Bold,
      fontSize = (45f * s).sp,
      lineHeight = (52f * s).sp,
      letterSpacing = 0.sp,
    ),
    displaySmall = TextStyle(
      fontFamily = family,
      fontWeight = FontWeight.Bold,
      fontSize = (36f * s).sp,
      lineHeight = (44f * s).sp,
      letterSpacing = (-0.25).sp,
    ),
    headlineLarge = TextStyle(
      fontFamily = family,
      fontWeight = FontWeight.Bold,
      fontSize = (32f * s).sp,
      lineHeight = (40f * s).sp,
      letterSpacing = (-0.2).sp,
    ),
    headlineMedium = TextStyle(
      fontFamily = family,
      fontWeight = FontWeight.Bold,
      fontSize = (28f * s).sp,
      lineHeight = (36f * s).sp,
      letterSpacing = (-0.1).sp,
    ),
    headlineSmall = TextStyle(
      fontFamily = family,
      fontWeight = FontWeight.SemiBold,
      fontSize = (24f * s).sp,
      lineHeight = (32f * s).sp,
      letterSpacing = 0.sp,
    ),
    titleLarge = TextStyle(
      fontFamily = family,
      fontWeight = FontWeight.SemiBold,
      fontSize = (22f * s).sp,
      lineHeight = (28f * s).sp,
      letterSpacing = 0.sp,
    ),
    titleMedium = TextStyle(
      fontFamily = family,
      fontWeight = FontWeight.Medium,
      fontSize = (16f * s).sp,
      lineHeight = (24f * s).sp,
      letterSpacing = 0.15.sp,
    ),
    titleSmall = TextStyle(
      fontFamily = family,
      fontWeight = FontWeight.Medium,
      fontSize = (14f * s).sp,
      lineHeight = (20f * s).sp,
      letterSpacing = 0.1.sp,
    ),
    bodyLarge = TextStyle(
      fontFamily = family,
      fontWeight = FontWeight.Normal,
      fontSize = (16f * s).sp,
      lineHeight = (24f * s).sp,
      letterSpacing = 0.25.sp,
    ),
    bodyMedium = TextStyle(
      fontFamily = family,
      fontWeight = FontWeight.Normal,
      fontSize = (14f * s).sp,
      lineHeight = (20f * s).sp,
      letterSpacing = 0.2.sp,
    ),
    bodySmall = TextStyle(
      fontFamily = family,
      fontWeight = FontWeight.Normal,
      fontSize = (12f * s).sp,
      lineHeight = (16f * s).sp,
      letterSpacing = 0.3.sp,
    ),
    labelLarge = TextStyle(
      fontFamily = family,
      fontWeight = FontWeight.SemiBold,
      fontSize = (14f * s).sp,
      lineHeight = (20f * s).sp,
      letterSpacing = 0.1.sp,
    ),
    labelMedium = TextStyle(
      fontFamily = family,
      fontWeight = FontWeight.Medium,
      fontSize = (12f * s).sp,
      lineHeight = (16f * s).sp,
      letterSpacing = 0.4.sp,
    ),
    labelSmall = TextStyle(
      fontFamily = family,
      fontWeight = FontWeight.Medium,
      fontSize = (11f * s).sp,
      lineHeight = (16f * s).sp,
      letterSpacing = 0.4.sp,
    ),
  )
}

val AppTypography = buildAppTypography()
