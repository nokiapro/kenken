package com.example.data.repository

import com.example.data.network.ApiClient
import com.example.data.network.XkFirestoreHelper
import com.example.data.network.XkJsonParser
import com.example.data.network.XkMusicApiService
import com.example.data.network.XkRtdbApiService
import com.example.model.Album
import com.example.model.ApiResult
import com.example.model.Artist
import com.example.model.ChartSection
import com.example.model.HomeFeedBundle
import com.example.model.ListeningStats
import com.example.model.Playlist
import com.example.model.SearchBundle
import com.example.model.SiteInfo
import com.example.model.Song
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.ResponseBody
import org.json.JSONObject
import retrofit2.Response

class MusicRepository(
  private val api: XkMusicApiService = ApiClient.apiService,
  private val rtdb: XkRtdbApiService = ApiClient.rtdbService,
  private val localStore: LocalLibraryStore,
) {

  val favoritesFlow: Flow<List<Song>> = localStore.favoritesFlow
  val favoriteAlbumIdsFlow: Flow<Set<String>> = localStore.favoriteAlbumIdsFlow
  val blockedSongIdsFlow: Flow<Set<String>> = localStore.blockedSongIdsFlow
  val recentFlow: Flow<List<Song>> = localStore.recentFlow
  val listeningStatsFlow: Flow<ListeningStats> = localStore.listeningStatsFlow

  private val cacheMutex = Mutex()
  private var cachedRtdbSongs: List<Song> = emptyList()
  private var cachedRtdbAlbums: List<Album> = emptyList()
  private var cachedRtdbArtists: List<Artist> = emptyList()
  private var cachedPublicPlaylists: List<Playlist> = emptyList()
  private var cachedRtdbPlaylists: List<Playlist> = emptyList()
  private var cachedWeeklyRaw: String? = null
  private var rtdbLoadedOnce = false

  suspend fun toggleFavorite(song: Song): Boolean = localStore.toggleFavorite(song)

  suspend fun toggleFavoriteAlbumId(albumId: String): Boolean = localStore.toggleFavoriteAlbumId(albumId)

  suspend fun mergeFavoriteAlbumIds(ids: List<String>) = localStore.mergeFavoriteAlbumIds(ids)

  suspend fun setBlockedSongIds(ids: List<String>) = localStore.setBlockedSongIds(ids)

  suspend fun mergeRemoteFavorites(remoteSongIds: List<String>) {
    if (remoteSongIds.isEmpty()) return
    ensureRtdbLoaded()
    val byId = cachedRtdbSongs.associateBy { it.id }
    val matched = remoteSongIds.mapNotNull { byId[it] }
    localStore.mergeFavorites(matched)
  }

  suspend fun recordPlayed(song: Song) = localStore.recordPlayed(song)

  suspend fun addListeningTime(deltaMs: Long) = localStore.addListeningTime(deltaMs)

  suspend fun getSongsLookupMap(): Map<String, Song> {
    ensureRtdbLoaded(forceRefresh = cachedRtdbSongs.isEmpty())
    val map = LinkedHashMap<String, Song>(cachedRtdbSongs.size)
    cachedRtdbSongs.forEach { map[it.id] = it }
    if (map.isEmpty()) {
      val primarySongs = tryPrimary { api.getSongs(sort = "popular") }
        ?.let { XkJsonParser.parseSongsList(it) }
        .orEmpty()
      primarySongs.forEach { map[it.id] = it }
      fetchHomeBundle()?.let { bundle ->
        (bundle.popularSongs + bundle.latestSongs + bundle.albums.flatMap { it.songs }).forEach { s ->
          if (s.id !in map) map[s.id] = s
        }
      }
    }
    return map
  }

  suspend fun fetchSiteInfo(): ApiResult<SiteInfo> = withContext(Dispatchers.IO) {
    val primary = tryPrimary { api.getSiteInfo() }
    if (primary != null) {
      return@withContext ApiResult.Success(XkJsonParser.parseSiteInfo(primary))
    }

    ensureRtdbLoaded()
    val genres = cachedRtdbSongs
      .flatMap { it.genre.split(",") }
      .map { it.trim() }
      .filter { it.isNotEmpty() }
      .distinct()
    val featured = cachedRtdbSongs.sortedByDescending { it.playCount }.take(5)
    ApiResult.Success(
      SiteInfo(
        siteName = "XuanKen Music",
        tagline = "Nền tảng nghe nhạc trực tuyến chất lượng cao",
        description = "Nghe nhạc trực tuyến từ xkmu.xuanken.name.vn",
        genres = genres,
        featuredSongs = featured,
      ),
    )
  }

  suspend fun fetchHomeBundle(): HomeFeedBundle? = withContext(Dispatchers.IO) {
    val primary = tryPrimary { api.getHome() } ?: return@withContext null
    XkJsonParser.parseHomeBundle(primary)
  }

  suspend fun searchAll(query: String): SearchBundle? = withContext(Dispatchers.IO) {
    val clean = query.trim()
    if (clean.isEmpty()) return@withContext null
    val primary = tryPrimary { api.search(clean) } ?: return@withContext null
    XkJsonParser.parseSearchBundle(primary)
  }

  suspend fun fetchSongs(
    query: String = "",
    genre: String = "",
    paid: Boolean? = null,
    sort: String = "popular",
  ): ApiResult<List<Song>> = withContext(Dispatchers.IO) {
    val cleanQuery = query.trim()
    if (cleanQuery.isNotEmpty() && genre.isBlank() && paid == null) {
      val searchBundle = searchAll(cleanQuery)
      if (searchBundle != null && searchBundle.songs.isNotEmpty()) {
        return@withContext ApiResult.Success(searchBundle.songs)
      }
    }

    val primary = tryPrimary {
      api.getSongs(
        query = cleanQuery.ifEmpty { null },
        genre = genre.trim().ifEmpty { null },
        paid = paid?.toString(),
        sort = sort.ifBlank { "popular" },
      )
    }
    if (primary != null) {
      return@withContext ApiResult.Success(XkJsonParser.parseSongsList(primary))
    }

    return@withContext try {
      ensureRtdbLoaded(forceRefresh = query.isBlank() && genre.isBlank() && paid == null && cachedRtdbSongs.isEmpty())
      val filtered = filterAndSortSongs(cachedRtdbSongs, query, genre, paid, sort)
      ApiResult.Success(filtered)
    } catch (e: Exception) {
      ApiResult.Error(e.localizedMessage ?: "Không thể tải danh sách bài hát.")
    }
  }

  suspend fun fetchSongDetail(id: String): ApiResult<Song?> = withContext(Dispatchers.IO) {
    val primary = tryPrimary { api.getSongById(id) }
    if (primary != null) {
      val parsed = XkJsonParser.parseSongDetail(primary)
      return@withContext ApiResult.Success(hydrateLyricsIfNeeded(parsed))
    }

    ensureRtdbLoaded()
    val matched = cachedRtdbSongs.firstOrNull { it.id == id }
      ?: cachedRtdbAlbums.flatMap { it.songs }.firstOrNull { it.id == id }
    ApiResult.Success(hydrateLyricsIfNeeded(matched))
  }

  suspend fun fetchSongStreamUrl(
    id: String,
    authToken: String? = null,
    preferFullMaster: Boolean = false,
  ): String? = withContext(Dispatchers.IO) {
    val streamJson = tryPrimary { api.getSongStream(id) }
    val streamInfo = streamJson?.let { XkJsonParser.parseStreamInfo(it) }

    if (preferFullMaster) {
      // 1. If /api/v1/songs/:id/stream returned a non-demo full stream URL, use it immediately
      if (streamInfo != null && !streamInfo.isDemo && !streamInfo.url.isNullOrBlank()) {
        return@withContext streamInfo.url
      }
      // 2. Try RTDB / Firestore `song_masters/{id}` with user's fresh Firebase token
      if (!authToken.isNullOrBlank()) {
        fetchMasterUrlForSong(id, authToken)?.let { master ->
          if (!XkJsonParser.looksLikeDemoUrl(master)) return@withContext master
        }
      }
      // 3. Try /api/v1/songs/:id/download which returns the full master file URL
      val downloadJson = tryPrimary { api.getSongDownload(id) }
      val dlUrl = downloadJson?.let { XkJsonParser.parseDownloadUrl(it) }
      if (!dlUrl.isNullOrBlank() && !XkJsonParser.looksLikeDemoUrl(dlUrl)) {
        return@withContext dlUrl
      }
      // 4. Try song detail endpoint (authenticated callers may receive masterUrl/fullUrl)
      val detail = (fetchSongDetail(id) as? ApiResult.Success)?.data
      val detailUrl = detail?.audioUrl?.takeIf { it.isNotBlank() && !XkJsonParser.looksLikeDemoUrl(it) }
      if (detailUrl != null) return@withContext detailUrl

      return@withContext streamInfo?.url
    }

    if (streamInfo != null && !streamInfo.url.isNullOrBlank()) {
      return@withContext streamInfo.url
    }
    if (!authToken.isNullOrBlank()) {
      fetchMasterUrlForSong(id, authToken)?.let { return@withContext it }
    }
    val detail = (fetchSongDetail(id) as? ApiResult.Success)?.data
    detail?.audioUrl
  }

  suspend fun fetchSongDownloadUrl(id: String, authToken: String? = null): String? = withContext(Dispatchers.IO) {
    val downloadJson = tryPrimary { api.getSongDownload(id) }
    if (downloadJson != null) {
      XkJsonParser.parseDownloadUrl(downloadJson)?.let { return@withContext it }
    }
    fetchSongStreamUrl(id, authToken, preferFullMaster = true)
  }

  suspend fun recordSongPlay(songId: String) = withContext(Dispatchers.IO) {
    val mediaType = "application/json; charset=utf-8".toMediaType()
    val body = JSONObject().apply {
      put("songId", songId)
      put("timestamp", System.currentTimeMillis())
    }.toString().toRequestBody(mediaType)
    runCatching { api.recordSongPlay(songId, body) }
  }

  suspend fun reportSong(songId: String, reason: String, detail: String): ApiResult<String> = withContext(Dispatchers.IO) {
    val mediaType = "application/json; charset=utf-8".toMediaType()
    val body = JSONObject().apply {
      put("songId", songId)
      put("reason", reason.trim())
      put("detail", detail.trim())
      put("message", detail.trim())
    }.toString().toRequestBody(mediaType)
    val res = runCatching { api.reportSong(songId, body) }.getOrNull()
    if (res != null && res.isSuccessful) {
      ApiResult.Success("Đã gửi báo cáo bài hát. Cảm ơn bạn đã phản hồi!")
    } else if (res != null && res.code() != 404) {
      val errMsg = XkJsonParser.parseErrorMessage(res.errorBody()?.string())
      ApiResult.Error(errMsg ?: "Không thể gửi báo cáo (${res.code()}).")
    } else {
      ApiResult.Success("Đã ghi nhận phản hồi bài hát.")
    }
  }

  suspend fun fetchAuthorizedMasterUrls(
    songIds: List<String>,
    authToken: String?,
    isAdmin: Boolean = false,
  ): Map<String, String> = withContext(Dispatchers.IO) {
    if (authToken.isNullOrBlank()) return@withContext emptyMap()
    val result = mutableMapOf<String, String>()
    if (isAdmin) {
      val allBody = runCatching { rtdb.getAllSongMasters(authToken) }.getOrNull()
        ?.takeIf { it.isSuccessful }?.body()?.string()?.trim().orEmpty()
      if (allBody.startsWith("{")) {
        runCatching {
          val obj = org.json.JSONObject(allBody)
          val keys = obj.keys()
          while (keys.hasNext()) {
            val k = keys.next()
            val item = obj.optJSONObject(k) ?: continue
            val url = XkJsonParser.parseStreamInfo(item.toString())
              ?.takeIf { !it.isDemo }?.url
              ?: item.optString("mp3Url").takeIf { it.isNotBlank() }
              ?: item.optString("wavUrl").takeIf { it.isNotBlank() }
            if (!url.isNullOrBlank()) result[k] = url
          }
        }
        if (result.isNotEmpty()) return@withContext result
      }
    }
    coroutineScope {
      songIds.distinct().filter { it.isNotBlank() }.map { sid ->
        async {
          val directMaster = fetchMasterUrlForSong(sid, authToken)
          val resolved = directMaster ?: fetchSongStreamUrl(sid, authToken, preferFullMaster = true)
          sid to resolved
        }
      }.forEach { deferred ->
        val (sid, url) = deferred.await()
        if (!url.isNullOrBlank() && !XkJsonParser.looksLikeDemoUrl(url)) {
          result[sid] = url
        }
      }
    }
    result
  }

  private suspend fun fetchMasterUrlForSong(songId: String, authToken: String): String? {
    val rtdbBody = runCatching { rtdb.getSongMaster(songId, authToken) }.getOrNull()
      ?.takeIf { it.isSuccessful }?.body()?.string()?.trim().orEmpty()
    if (rtdbBody.startsWith("{")) {
      val info = XkJsonParser.parseStreamInfo(rtdbBody)
      if (!info?.url.isNullOrBlank()) return info?.url
    }
    return XkFirestoreHelper.fetchSongMasterUrl(songId, authToken)
  }

  suspend fun fetchAlbums(): ApiResult<List<Album>> = withContext(Dispatchers.IO) {
    val primary = tryPrimary { api.getAlbums() }
    if (primary != null) {
      return@withContext ApiResult.Success(XkJsonParser.parseAlbumsList(primary))
    }

    return@withContext try {
      ensureRtdbLoaded()
      ApiResult.Success(cachedRtdbAlbums)
    } catch (e: Exception) {
      ApiResult.Error(e.localizedMessage ?: "Không thể tải danh sách album.")
    }
  }

  suspend fun fetchAlbumDetail(id: String): ApiResult<Album?> = withContext(Dispatchers.IO) {
    val primary = tryPrimary { api.getAlbumById(id) }
    if (primary != null) {
      return@withContext ApiResult.Success(XkJsonParser.parseAlbumDetail(primary))
    }

    ensureRtdbLoaded()
    ApiResult.Success(cachedRtdbAlbums.firstOrNull { it.id == id })
  }

  suspend fun fetchArtists(): ApiResult<List<Artist>> = withContext(Dispatchers.IO) {
    val primary = tryPrimary { api.getArtists() }
    if (primary != null) {
      return@withContext ApiResult.Success(XkJsonParser.parseArtistsList(primary))
    }

    return@withContext try {
      ensureRtdbLoaded()
      ApiResult.Success(cachedRtdbArtists)
    } catch (e: Exception) {
      ApiResult.Error(e.localizedMessage ?: "Không thể tải danh sách nghệ sĩ.")
    }
  }

  suspend fun fetchArtistDetail(id: String): ApiResult<Artist?> = withContext(Dispatchers.IO) {
    val primary = tryPrimary { api.getArtistById(id) }
    if (primary != null) {
      return@withContext ApiResult.Success(XkJsonParser.parseArtistDetail(primary))
    }

    ensureRtdbLoaded()
    ApiResult.Success(cachedRtdbArtists.firstOrNull { it.id == id })
  }

  suspend fun fetchCharts(): ApiResult<List<ChartSection>> = withContext(Dispatchers.IO) {
    val primary = tryPrimary { api.getCharts() }
    if (primary != null) {
      return@withContext ApiResult.Success(XkJsonParser.parseCharts(primary))
    }

    return@withContext try {
      ensureRtdbLoaded()
      val charts = XkJsonParser.parseWeeklyCharts(cachedWeeklyRaw.orEmpty(), cachedRtdbSongs)
      ApiResult.Success(charts)
    } catch (e: Exception) {
      ApiResult.Error(e.localizedMessage ?: "Không thể tải bảng xếp hạng.")
    }
  }

  suspend fun fetchPlaylists(
    userId: String? = null,
    authToken: String? = null,
    isAdmin: Boolean = false,
  ): ApiResult<List<Playlist>> = withContext(Dispatchers.IO) {
    val primary = tryPrimary { api.getPlaylists() }
    if (primary != null) {
      return@withContext ApiResult.Success(XkJsonParser.parsePlaylistsList(primary))
    }

    return@withContext try {
      ensureRtdbLoaded()
      val songsLookup = cachedRtdbSongs.associateBy { it.id }
      val merged = linkedMapOf<String, Playlist>()
      cachedPublicPlaylists.forEach { merged[it.id] = it }

      if (!authToken.isNullOrBlank()) {
        // 1. Try full authed RTDB playlists (succeeds for admins or public nodes)
        val allAuthedRaw = runCatching { rtdb.getAllPlaylistsAuthed(authToken) }.getOrNull()
          ?.takeIf { it.isSuccessful }?.body()?.string().orEmpty()
        if (allAuthedRaw.trim().startsWith("{") || allAuthedRaw.trim().startsWith("[")) {
          XkJsonParser.parsePlaylistsList(allAuthedRaw, songsLookup)
            .forEach { merged[it.id] = it }
        }

        // 2. Query RTDB owner-filtered playlists: orderBy="userId"&equalTo="<uid>"&auth=<token>
        if (!userId.isNullOrBlank()) {
          val userRaw = runCatching {
            rtdb.getUserPlaylists(
              orderBy = "\"userId\"",
              equalTo = "\"$userId\"",
              authToken = authToken,
            )
          }.getOrNull()?.takeIf { it.isSuccessful }?.body()?.string().orEmpty()
          if (userRaw.trim().startsWith("{") || userRaw.trim().startsWith("[")) {
            XkJsonParser.parsePlaylistsList(userRaw, songsLookup)
              .forEach { merged[it.id] = it }
          }

          // 3. Query Firestore `playlists` collection fallback
          XkFirestoreHelper.fetchUserPlaylists(
            uid = userId,
            idToken = authToken,
            isAdmin = isAdmin,
            songsLookup = songsLookup,
          ).forEach { pl ->
            val existing = merged[pl.id]
            if (existing == null || (existing.songs.isEmpty() && pl.songs.isNotEmpty())) {
              merged[pl.id] = pl
            }
          }
        }
      }

      val finalPlaylists = merged.values.toList()
      cachedRtdbPlaylists = finalPlaylists
      ApiResult.Success(finalPlaylists)
    } catch (e: Exception) {
      ApiResult.Error(e.localizedMessage ?: "Không thể tải danh sách playlist.")
    }
  }

  suspend fun fetchPlaylistDetail(id: String): ApiResult<Playlist?> = withContext(Dispatchers.IO) {
    val primary = tryPrimary { api.getPlaylistById(id) }
    if (primary != null) {
      return@withContext ApiResult.Success(XkJsonParser.parsePlaylistDetail(primary))
    }

    ensureRtdbLoaded()
    ApiResult.Success(cachedRtdbPlaylists.firstOrNull { it.id == id })
  }

  suspend fun createPlaylist(
    title: String,
    description: String,
    songIds: List<String> = emptyList(),
    userId: String? = null,
    userName: String? = null,
    authToken: String? = null,
  ): ApiResult<Playlist> = withContext(Dispatchers.IO) {
    val cleanTitle = title.trim()
    if (cleanTitle.isEmpty()) return@withContext ApiResult.Error("Tên playlist không được để trống.")
    val cleanDesc = description.trim()
    val mediaType = okhttp3.MediaType.Companion.run { "application/json; charset=utf-8".toMediaType() }
    val bodyStr = org.json.JSONObject().apply {
      put("title", cleanTitle)
      put("name", cleanTitle)
      put("description", cleanDesc)
      put("songIds", org.json.JSONArray(songIds))
      if (!userId.isNullOrBlank()) put("userId", userId)
      if (!userName.isNullOrBlank()) put("curator", userName)
    }.toString()
    val body = okhttp3.RequestBody.Companion.run { bodyStr.toRequestBody(mediaType) }

    val primary = tryPrimary { api.createPlaylist(body) }
    if (primary != null) {
      val parsed = XkJsonParser.parsePlaylistDetail(primary)
        ?: Playlist(id = "pl_${System.currentTimeMillis()}", title = cleanTitle, description = cleanDesc)
      refreshRtdbSnapshot()
      return@withContext ApiResult.Success(parsed)
    }

    // Fallback: RTDB playlists/{id}
    if (authToken.isNullOrBlank() || userId.isNullOrBlank()) {
      return@withContext ApiResult.Error("Vui lòng đăng nhập trong mục Cá nhân để tạo playlist.", isUnauthorized = true)
    }
    val newId = "pl_${System.currentTimeMillis()}"
    val rtdbObj = org.json.JSONObject().apply {
      put("id", newId)
      put("title", cleanTitle)
      put("description", cleanDesc)
      put("userId", userId)
      put("curator", userName ?: "Thành viên XK")
      put("songIds", org.json.JSONArray(songIds))
      put("createdAt", System.currentTimeMillis())
    }.toString()
    val rtdbBody = okhttp3.RequestBody.Companion.run { rtdbObj.toRequestBody(mediaType) }
    return@withContext try {
      val res = rtdb.upsertPlaylist(newId, authToken, rtdbBody)
      if (res.isSuccessful) {
        ensureRtdbLoaded(forceRefresh = true)
        val created = cachedRtdbPlaylists.firstOrNull { it.id == newId }
          ?: Playlist(
            id = newId,
            title = cleanTitle,
            description = cleanDesc.ifBlank { null },
            curator = userName,
            curatorId = userId,
            songCount = songIds.size,
          )
        ApiResult.Success(created)
      } else {
        ApiResult.Error("Không thể tạo playlist (${res.code()}).")
      }
    } catch (e: Exception) {
      ApiResult.Error(e.localizedMessage ?: "Lỗi tạo playlist.")
    }
  }

  suspend fun updatePlaylist(
    playlistId: String,
    title: String,
    description: String,
    songIds: List<String>? = null,
    authToken: String? = null,
  ): ApiResult<Playlist> = withContext(Dispatchers.IO) {
    val cleanTitle = title.trim()
    if (cleanTitle.isEmpty()) return@withContext ApiResult.Error("Tên playlist không được để trống.")
    val cleanDesc = description.trim()
    val mediaType = okhttp3.MediaType.Companion.run { "application/json; charset=utf-8".toMediaType() }
    val bodyObj = org.json.JSONObject().apply {
      put("title", cleanTitle)
      put("name", cleanTitle)
      put("description", cleanDesc)
      if (songIds != null) put("songIds", org.json.JSONArray(songIds))
    }.toString()
    val body = okhttp3.RequestBody.Companion.run { bodyObj.toRequestBody(mediaType) }

    val primary = tryPrimary { api.updatePlaylist(playlistId, body) }
    if (primary != null) {
      val parsed = XkJsonParser.parsePlaylistDetail(primary)
        ?: Playlist(id = playlistId, title = cleanTitle, description = cleanDesc)
      refreshRtdbSnapshot()
      return@withContext ApiResult.Success(parsed)
    }

    if (authToken.isNullOrBlank()) {
      return@withContext ApiResult.Error("Vui lòng đăng nhập để chỉnh sửa playlist.", isUnauthorized = true)
    }
    return@withContext try {
      val res = rtdb.patchPlaylist(playlistId, authToken, body)
      if (res.isSuccessful) {
        ensureRtdbLoaded(forceRefresh = true)
        val updated = cachedRtdbPlaylists.firstOrNull { it.id == playlistId }
          ?: Playlist(id = playlistId, title = cleanTitle, description = cleanDesc.ifBlank { null })
        ApiResult.Success(updated)
      } else {
        ApiResult.Error("Không thể cập nhật playlist (${res.code()}).")
      }
    } catch (e: Exception) {
      ApiResult.Error(e.localizedMessage ?: "Lỗi cập nhật playlist.")
    }
  }

  suspend fun deletePlaylist(
    playlistId: String,
    authToken: String? = null,
  ): ApiResult<Unit> = withContext(Dispatchers.IO) {
    val primaryRes = runCatching { api.deletePlaylist(playlistId) }.getOrNull()
    if (primaryRes != null && primaryRes.isSuccessful && primaryRes.code() != 404) {
      refreshRtdbSnapshot()
      return@withContext ApiResult.Success(Unit)
    }

    if (authToken.isNullOrBlank()) {
      return@withContext ApiResult.Error("Vui lòng đăng nhập để xóa playlist.", isUnauthorized = true)
    }
    return@withContext try {
      val res = rtdb.deletePlaylist(playlistId, authToken)
      if (res.isSuccessful) {
        ensureRtdbLoaded(forceRefresh = true)
        ApiResult.Success(Unit)
      } else {
        ApiResult.Error("Không thể xóa playlist (${res.code()}).")
      }
    } catch (e: Exception) {
      ApiResult.Error(e.localizedMessage ?: "Lỗi xóa playlist.")
    }
  }

  suspend fun refreshRtdbSnapshot() = withContext(Dispatchers.IO) {
    ensureRtdbLoaded(forceRefresh = true)
  }

  private suspend fun tryPrimary(call: suspend () -> Response<ResponseBody>): String? {
    return try {
      val response = call()
      if (response.isSuccessful) {
        val body = response.body()?.string()?.trim().orEmpty()
        if (body.startsWith("{") || body.startsWith("[")) body else null
      } else {
        null
      }
    } catch (_: Exception) {
      null
    }
  }

  private suspend fun ensureRtdbLoaded(forceRefresh: Boolean = false) {
    cacheMutex.withLock {
      if (rtdbLoadedOnce && !forceRefresh) return
      coroutineScope {
        val songsDeferred = async { runCatching { rtdb.getSongs() }.getOrNull() }
        val albumsDeferred = async { runCatching { rtdb.getExclusiveAlbums() }.getOrNull() }
        val playlistsDeferred = async { runCatching { rtdb.getPlaylists() }.getOrNull() }
        val weeklyDeferred = async { runCatching { rtdb.getWeeklyPlays() }.getOrNull() }
        val biosDeferred = async { runCatching { rtdb.getArtistBios() }.getOrNull() }

        val songsRaw = songsDeferred.await()?.takeIf { it.isSuccessful }?.body()?.string().orEmpty()
        val albumsRaw = albumsDeferred.await()?.takeIf { it.isSuccessful }?.body()?.string().orEmpty()
        val playlistsRaw = playlistsDeferred.await()?.takeIf { it.isSuccessful }?.body()?.string().orEmpty()
        val weeklyRaw = weeklyDeferred.await()?.takeIf { it.isSuccessful }?.body()?.string().orEmpty()
        val biosRaw = biosDeferred.await()?.takeIf { it.isSuccessful }?.body()?.string().orEmpty()

        val standaloneSongs = XkJsonParser.parseSongsList(songsRaw)
        val albums = XkJsonParser.parseAlbumsList(albumsRaw)
        val albumSongs = albums.flatMap { it.songs }

        // Combine standalone songs + exclusive album tracks without duplicates
        val allSongsMap = LinkedHashMap<String, Song>()
        standaloneSongs.forEach { allSongsMap[it.id] = it }
        albumSongs.forEach { s ->
          if (!allSongsMap.containsKey(s.id)) {
            allSongsMap[s.id] = s
          }
        }
        val allSongs = allSongsMap.values.toList()

        val playlists = XkJsonParser.parsePlaylistsList(playlistsRaw, allSongsMap)
        val bios = XkJsonParser.parseArtistBios(biosRaw)
        val artists = buildArtistsFromCatalog(allSongs, albums, bios)

        if (allSongs.isNotEmpty() || albums.isNotEmpty() || playlists.isNotEmpty()) {
          cachedRtdbSongs = allSongs
          cachedRtdbAlbums = albums
          cachedPublicPlaylists = playlists
          if (cachedRtdbPlaylists.isEmpty()) {
            cachedRtdbPlaylists = playlists
          } else {
            val byId = linkedMapOf<String, Playlist>()
            playlists.forEach { byId[it.id] = it }
            cachedRtdbPlaylists.forEach { pl ->
              if (!byId.containsKey(pl.id)) byId[pl.id] = pl
            }
            cachedRtdbPlaylists = byId.values.toList()
          }
          cachedRtdbArtists = artists
          cachedWeeklyRaw = weeklyRaw
          rtdbLoadedOnce = true
        }
      }
    }
  }

  private fun buildArtistsFromCatalog(
    songs: List<Song>,
    albums: List<Album>,
    bios: Map<String, Pair<String?, String?>>,
  ): List<Artist> {
    val songsByArtist = linkedMapOf<String, MutableList<Song>>()
    songs.forEach { song ->
      val names = song.artistName.split(",").map { it.trim() }.filter { it.isNotEmpty() }
      names.ifEmpty { listOf(song.artistName) }.forEach { artistName ->
        songsByArtist.getOrPut(artistName) { mutableListOf() }.add(song)
      }
    }

    val albumsByArtist = albums.groupBy { it.artistName.trim() }

    return songsByArtist.entries
      .sortedByDescending { it.value.sumOf { s -> s.playCount } }
      .map { (name, artistSongs) ->
        val id = name.lowercase().replace(Regex("[^a-z0-9]+"), "-").trim('-').ifEmpty { name }
        val bioPair = bios[name]
        val artistAlbums = albumsByArtist[name].orEmpty()
        val avatar = bioPair?.second ?: artistSongs.firstOrNull { !it.coverUrl.isNullOrBlank() }?.coverUrl
        val genre = artistSongs.firstOrNull { it.genre.isNotBlank() }?.genre
        Artist(
          id = id,
          name = name,
          avatarUrl = avatar,
          coverUrl = avatar,
          bio = bioPair?.first,
          genre = genre,
          followerCount = artistSongs.sumOf { it.playCount },
          songCount = artistSongs.size,
          songs = artistSongs,
          albums = artistAlbums,
        )
      }
  }

  private fun filterAndSortSongs(
    songs: List<Song>,
    query: String,
    genre: String,
    paid: Boolean?,
    sort: String,
  ): List<Song> {
    val q = query.trim().lowercase()
    val g = genre.trim().lowercase()

    val filtered = songs.filter { song ->
      val matchQuery = q.isEmpty() ||
        song.title.lowercase().contains(q) ||
        song.artistName.lowercase().contains(q) ||
        song.genre.lowercase().contains(q) ||
        (song.albumTitle?.lowercase()?.contains(q) == true)

      val matchGenre = g.isEmpty() || song.genre.lowercase().contains(g)

      val matchPaid = when (paid) {
        null -> true
        true -> song.isPaid
        false -> !song.isPaid
      }

      matchQuery && matchGenre && matchPaid
    }

    return when (sort.lowercase()) {
      "latest", "newest" -> {
        if (filtered.any { it.createdAtMs > 0L }) {
          filtered.sortedByDescending { it.createdAtMs }
        } else {
          filtered.reversed()
        }
      }
      else -> filtered.sortedByDescending { it.playCount }
    }
  }

  private suspend fun hydrateLyricsIfNeeded(song: Song?): Song? {
    song ?: return null
    val raw = song.lyrics ?: return song
    if (!raw.startsWith("LRC_URL:")) return song
    val url = raw.removePrefix("LRC_URL:")
    val fetchedText = runCatching {
      val res = api.getTextFromUrl(url)
      if (res.isSuccessful) res.body()?.string()?.trim() else null
    }.getOrNull()
    return song.copy(lyrics = fetchedText?.takeIf { it.isNotBlank() })
  }
}
