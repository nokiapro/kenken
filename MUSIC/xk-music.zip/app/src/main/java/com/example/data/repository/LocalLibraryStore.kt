package com.example.data.repository

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.model.AuthSession
import com.example.model.ListeningStats
import com.example.model.Song
import com.example.ui.AppearanceSettings
import com.example.ui.PersonalizationSettings
import com.example.ui.RhythmColorPreset
import com.example.ui.ThemeMode
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

private val Context.musicLibraryDataStore: DataStore<Preferences> by preferencesDataStore(name = "xk_music_library")

class LocalLibraryStore(private val context: Context) {

  private val json = Json {
    ignoreUnknownKeys = true
    encodeDefaults = true
  }

  private val favoritesKey = stringPreferencesKey("favorite_songs_json")
  private val favoriteAlbumIdsKey = stringPreferencesKey("favorite_album_ids_json")
  private val blockedSongIdsKey = stringPreferencesKey("blocked_song_ids_json")
  private val recentKey = stringPreferencesKey("recent_songs_json")
  private val authSessionKey = stringPreferencesKey("auth_session_json")
  private val themeModeKey = stringPreferencesKey("appearance_theme_mode")
  private val dynamicColorKey = booleanPreferencesKey("appearance_dynamic_color")
  private val colorPresetKey = stringPreferencesKey("appearance_color_preset")
  private val amoledModeKey = booleanPreferencesKey("appearance_amoled_mode")
  private val totalListeningTimeMsKey = longPreferencesKey("total_listening_time_ms")
  private val totalSongsPlayedCountKey = intPreferencesKey("total_songs_played_count")
  private val songPlayCountsJsonKey = stringPreferencesKey("song_play_counts_json")
  private val personalizationJsonKey = stringPreferencesKey("personalization_settings_json")

  val favoritesFlow: Flow<List<Song>> = context.musicLibraryDataStore.data.map { prefs ->
    decodeSongs(prefs[favoritesKey])
  }

  val favoriteAlbumIdsFlow: Flow<Set<String>> = context.musicLibraryDataStore.data.map { prefs ->
    decodeStringList(prefs[favoriteAlbumIdsKey]).toSet()
  }

  val blockedSongIdsFlow: Flow<Set<String>> = context.musicLibraryDataStore.data.map { prefs ->
    decodeStringList(prefs[blockedSongIdsKey]).toSet()
  }

  val recentFlow: Flow<List<Song>> = context.musicLibraryDataStore.data.map { prefs ->
    decodeSongs(prefs[recentKey])
  }

  val authSessionFlow: Flow<AuthSession?> = context.musicLibraryDataStore.data.map { prefs ->
    decodeAuthSession(prefs[authSessionKey])
  }

  val appearanceFlow: Flow<AppearanceSettings> = context.musicLibraryDataStore.data.map { prefs ->
    val mode = runCatching {
      ThemeMode.valueOf(prefs[themeModeKey] ?: ThemeMode.DARK.name)
    }.getOrDefault(ThemeMode.DARK)
    val dynamic = prefs[dynamicColorKey] ?: false
    val preset = runCatching {
      RhythmColorPreset.valueOf(prefs[colorPresetKey] ?: RhythmColorPreset.DEFAULT.name)
    }.getOrDefault(RhythmColorPreset.DEFAULT)
    val amoled = prefs[amoledModeKey] ?: false
    AppearanceSettings(
      themeMode = mode,
      useDynamicColor = dynamic,
      colorPreset = preset,
      amoledMode = amoled,
    )
  }

  val listeningStatsFlow: Flow<ListeningStats> = context.musicLibraryDataStore.data.map { prefs ->
    ListeningStats(
      totalListeningTimeMs = (prefs[totalListeningTimeMsKey] ?: 0L).coerceAtLeast(0L),
      songsPlayedCount = (prefs[totalSongsPlayedCountKey] ?: 0).coerceAtLeast(0),
      songPlayCounts = decodePlayCounts(prefs[songPlayCountsJsonKey]),
    )
  }

  val personalizationFlow: Flow<PersonalizationSettings> = context.musicLibraryDataStore.data.map { prefs ->
    decodePersonalization(prefs[personalizationJsonKey])
  }

  suspend fun toggleFavorite(song: Song): Boolean {
    var nowFavorite = false
    context.musicLibraryDataStore.edit { prefs ->
      val current = decodeSongs(prefs[favoritesKey]).toMutableList()
      val existingIndex = current.indexOfFirst { it.id == song.id }
      if (existingIndex >= 0) {
        current.removeAt(existingIndex)
        nowFavorite = false
      } else {
        current.add(0, song)
        nowFavorite = true
      }
      prefs[favoritesKey] = json.encodeToString(current)
    }
    return nowFavorite
  }

  suspend fun mergeFavorites(remoteSongs: List<Song>) {
    if (remoteSongs.isEmpty()) return
    context.musicLibraryDataStore.edit { prefs ->
      val current = decodeSongs(prefs[favoritesKey]).toMutableList()
      val existingIds = current.map { it.id }.toSet()
      val additions = remoteSongs.filter { it.id !in existingIds }
      if (additions.isNotEmpty()) {
        current.addAll(additions)
        prefs[favoritesKey] = json.encodeToString(current)
      }
    }
  }

  suspend fun recordPlayed(song: Song) {
    context.musicLibraryDataStore.edit { prefs ->
      val current = decodeSongs(prefs[recentKey]).toMutableList()
      current.removeAll { it.id == song.id }
      current.add(0, song)
      val trimmed = current.take(30)
      prefs[recentKey] = json.encodeToString(trimmed)
      val prevCount = prefs[totalSongsPlayedCountKey] ?: 0
      prefs[totalSongsPlayedCountKey] = prevCount + 1
      val counts = decodePlayCounts(prefs[songPlayCountsJsonKey]).toMutableMap()
      counts[song.id] = (counts[song.id] ?: 0) + 1
      prefs[songPlayCountsJsonKey] = json.encodeToString(counts)
    }
  }

  suspend fun addListeningTime(deltaMs: Long) {
    if (deltaMs <= 0L) return
    context.musicLibraryDataStore.edit { prefs ->
      val current = (prefs[totalListeningTimeMsKey] ?: 0L).coerceAtLeast(0L)
      prefs[totalListeningTimeMsKey] = current + deltaMs
    }
  }

  suspend fun saveAuthSession(session: AuthSession?) {
    context.musicLibraryDataStore.edit { prefs ->
      if (session == null) {
        prefs.remove(authSessionKey)
      } else {
        prefs[authSessionKey] = json.encodeToString(session)
      }
    }
  }

  suspend fun setThemeMode(mode: ThemeMode) {
    context.musicLibraryDataStore.edit { prefs ->
      prefs[themeModeKey] = mode.name
    }
  }

  suspend fun setDynamicColor(enabled: Boolean) {
    context.musicLibraryDataStore.edit { prefs ->
      prefs[dynamicColorKey] = enabled
    }
  }

  suspend fun setColorPreset(preset: RhythmColorPreset) {
    context.musicLibraryDataStore.edit { prefs ->
      prefs[colorPresetKey] = preset.name
    }
  }

  suspend fun setAmoledMode(enabled: Boolean) {
    context.musicLibraryDataStore.edit { prefs ->
      prefs[amoledModeKey] = enabled
    }
  }

  suspend fun updatePersonalization(transform: (PersonalizationSettings) -> PersonalizationSettings) {
    context.musicLibraryDataStore.edit { prefs ->
      val current = decodePersonalization(prefs[personalizationJsonKey])
      val updated = transform(current)
      prefs[personalizationJsonKey] = json.encodeToString(updated)
    }
  }

  suspend fun toggleFavoriteAlbumId(albumId: String): Boolean {
    var nowLiked = false
    context.musicLibraryDataStore.edit { prefs ->
      val current = decodeStringList(prefs[favoriteAlbumIdsKey]).toMutableSet()
      if (albumId in current) {
        current.remove(albumId)
        nowLiked = false
      } else {
        current.add(albumId)
        nowLiked = true
      }
      prefs[favoriteAlbumIdsKey] = json.encodeToString(current.toList())
    }
    return nowLiked
  }

  suspend fun mergeFavoriteAlbumIds(remoteIds: List<String>) {
    if (remoteIds.isEmpty()) return
    context.musicLibraryDataStore.edit { prefs ->
      val current = (decodeStringList(prefs[favoriteAlbumIdsKey]) + remoteIds).distinct()
      prefs[favoriteAlbumIdsKey] = json.encodeToString(current)
    }
  }

  suspend fun setBlockedSongIds(ids: List<String>) {
    context.musicLibraryDataStore.edit { prefs ->
      prefs[blockedSongIdsKey] = json.encodeToString(ids.distinct())
    }
  }

  suspend fun addBlockedSongId(songId: String) {
    context.musicLibraryDataStore.edit { prefs ->
      val current = (decodeStringList(prefs[blockedSongIdsKey]) + songId).distinct()
      prefs[blockedSongIdsKey] = json.encodeToString(current)
    }
  }

  suspend fun removeBlockedSongId(songId: String) {
    context.musicLibraryDataStore.edit { prefs ->
      val current = decodeStringList(prefs[blockedSongIdsKey]).filterNot { it == songId }
      prefs[blockedSongIdsKey] = json.encodeToString(current)
    }
  }

  private fun decodeSongs(raw: String?): List<Song> {
    if (raw.isNullOrBlank()) return emptyList()
    return runCatching { json.decodeFromString<List<Song>>(raw) }.getOrDefault(emptyList())
  }

  private fun decodeStringList(raw: String?): List<String> {
    if (raw.isNullOrBlank()) return emptyList()
    return runCatching { json.decodeFromString<List<String>>(raw) }.getOrDefault(emptyList())
  }

  private fun decodeAuthSession(raw: String?): AuthSession? {
    if (raw.isNullOrBlank()) return null
    return runCatching { json.decodeFromString<AuthSession>(raw) }.getOrNull()
  }

  private fun decodePersonalization(raw: String?): PersonalizationSettings {
    if (raw.isNullOrBlank()) return PersonalizationSettings()
    return runCatching { json.decodeFromString<PersonalizationSettings>(raw) }
      .getOrDefault(PersonalizationSettings())
  }

  private fun decodePlayCounts(raw: String?): Map<String, Int> {
    if (raw.isNullOrBlank()) return emptyMap()
    return runCatching { json.decodeFromString<Map<String, Int>>(raw) }.getOrDefault(emptyMap())
  }
}
