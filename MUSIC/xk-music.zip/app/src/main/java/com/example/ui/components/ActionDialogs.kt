package com.example.ui.components

import android.content.Context
import android.content.Intent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import com.example.ui.rhythm.MaterialSymbolIcon
import com.example.ui.rhythm.RhythmIcons
import com.example.ui.rhythm.RhythmSymbolIcon
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.model.Playlist
import com.example.model.Song
import com.example.ui.FormatUtils
import com.example.ui.PurchaseDialogState
import java.text.NumberFormat
import java.util.Locale

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun PurchaseSongDialog(
  state: PurchaseDialogState,
  isSignedIn: Boolean,
  onVoucherCodeChange: (String) -> Unit,
  onCheckVoucher: () -> Unit,
  onConfirmPurchase: () -> Unit,
  onNavigateToProfile: () -> Unit,
  onDismiss: () -> Unit,
) {
  val nf = remember { NumberFormat.getNumberInstance(Locale.forLanguageTag("vi-VN")) }
  val validation = state.voucherValidation

  AlertDialog(
    onDismissRequest = onDismiss,
    title = {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
      ) {
        RhythmSymbolIcon(
          icon = RhythmIcons.ShoppingBag,
          contentDescription = null,
          tint = MaterialTheme.colorScheme.primary,
          size = 24.dp,
          modifier = Modifier.size(24.dp),
        )
        Text(
          text = "Mở khóa bài hát bản quyền",
          style = MaterialTheme.typography.titleLarge,
        )
      }
    },
    text = {
      Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Surface(
          shape = RoundedCornerShape(14.dp),
          color = MaterialTheme.colorScheme.surfaceContainerHigh,
        ) {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp),
          ) {
            ArtworkImage(
              imageUrl = state.song.coverUrl,
              contentDescription = state.song.title,
              modifier = Modifier.size(48.dp),
              shape = RoundedCornerShape(10.dp),
            )
            Column(modifier = Modifier.weight(1f)) {
              Text(
                text = state.song.title,
                style = MaterialTheme.typography.titleSmall,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
              )
              Text(
                text = state.song.artistName,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
              )
            }
            Text(
              text = state.song.priceText ?: "Trả phí",
              style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold),
              color = MaterialTheme.colorScheme.tertiary,
            )
          }
        }

        if (!isSignedIn) {
          Text(
            text = "Bạn cần đăng nhập tài khoản XK Music trong mục Cá nhân để áp dụng voucher và mua bài hát.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
          )
        } else {
          Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
          ) {
            OutlinedTextField(
              value = state.voucherCode,
              onValueChange = onVoucherCodeChange,
              label = { Text("Mã voucher") },
              singleLine = true,
              leadingIcon = {
                RhythmSymbolIcon(
                  icon = MaterialSymbolIcon("confirmation_number"),
                  contentDescription = null,
                  size = 20.dp,
                  modifier = Modifier.size(20.dp),
                )
              },
              modifier = Modifier
                .weight(1f)
                .testTag("voucher_code_input"),
            )
            OutlinedButton(
              onClick = onCheckVoucher,
              enabled = state.voucherCode.isNotBlank() && !state.isCheckingVoucher,
              modifier = Modifier
                .minimumInteractiveComponentSize()
                .testTag("validate_voucher_button"),
            ) {
              if (state.isCheckingVoucher) {
                CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp)
              } else {
                Text("Áp dụng")
              }
            }
          }

          if (state.availableVouchers.isNotEmpty()) {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
              Text(
                text = "Mã ưu đãi khả dụng:",
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
              )
              FlowRow(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp),
              ) {
                state.availableVouchers.take(6).forEach { voucher ->
                  AssistChip(
                    onClick = {
                      onVoucherCodeChange(voucher.code)
                      onCheckVoucher()
                    },
                    label = {
                      val suffix = if (voucher.discountType == "fixed") {
                        "-${nf.format(voucher.discountValue)}đ"
                      } else {
                        "-${voucher.discountValue}%"
                      }
                      Text("${voucher.code} ($suffix)")
                    },
                    shape = CircleShape,
                  )
                }
              }
            }
          }

          if (validation != null && validation.valid) {
            Surface(
              shape = RoundedCornerShape(10.dp),
              color = MaterialTheme.colorScheme.primary.copy(alpha = 0.14f),
            ) {
              Column(
                modifier = Modifier
                  .fillMaxWidth()
                  .padding(10.dp),
                verticalArrangement = Arrangement.spacedBy(2.dp),
              ) {
                Text(
                  text = validation.description ?: "Mã ${validation.code} hợp lệ!",
                  style = MaterialTheme.typography.labelLarge,
                  color = MaterialTheme.colorScheme.primary,
                )
                Text(
                  text = "Giá sau giảm: ${nf.format(validation.finalPrice)}đ",
                  style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
                  color = MaterialTheme.colorScheme.onSurface,
                )
              }
            }
          }

          if (!state.errorMessage.isNullOrBlank()) {
            Text(
              text = state.errorMessage,
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.error,
            )
          }
        }
      }
    },
    confirmButton = {
      if (!isSignedIn) {
        Button(
          onClick = {
            onDismiss()
            onNavigateToProfile()
          },
          modifier = Modifier
            .minimumInteractiveComponentSize()
            .testTag("purchase_go_login_button"),
        ) {
          Text("Đi đến Cá nhân")
        }
      } else {
        Button(
          onClick = onConfirmPurchase,
          enabled = !state.isPurchasing,
          modifier = Modifier
            .minimumInteractiveComponentSize()
            .testTag("confirm_purchase_button"),
        ) {
          if (state.isPurchasing) {
            CircularProgressIndicator(
              modifier = Modifier.size(18.dp),
              strokeWidth = 2.dp,
              color = MaterialTheme.colorScheme.onPrimary,
            )
            Spacer(Modifier.width(8.dp))
          }
          Text("Mua ngay")
        }
      }
    },
    dismissButton = {
      TextButton(
        onClick = onDismiss,
        modifier = Modifier.minimumInteractiveComponentSize(),
      ) {
        Text("Đóng")
      }
    },
  )
}

@Composable
fun PlaylistEditorDialog(
  dialogTitle: String,
  initialTitle: String = "",
  initialDescription: String = "",
  confirmLabel: String = "Lưu",
  onConfirm: (title: String, description: String) -> Unit,
  onDismiss: () -> Unit,
) {
  var title by remember(initialTitle) { mutableStateOf(initialTitle) }
  var description by remember(initialDescription) { mutableStateOf(initialDescription) }

  AlertDialog(
    onDismissRequest = onDismiss,
    title = { Text(dialogTitle, style = MaterialTheme.typography.titleLarge) },
    text = {
      Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        OutlinedTextField(
          value = title,
          onValueChange = { title = it },
          label = { Text("Tên playlist") },
          singleLine = true,
          modifier = Modifier
            .fillMaxWidth()
            .testTag("playlist_title_input"),
        )
        OutlinedTextField(
          value = description,
          onValueChange = { description = it },
          label = { Text("Mô tả (tùy chọn)") },
          maxLines = 3,
          modifier = Modifier
            .fillMaxWidth()
            .testTag("playlist_description_input"),
        )
      }
    },
    confirmButton = {
      Button(
        onClick = { onConfirm(title, description) },
        enabled = title.isNotBlank(),
        modifier = Modifier
          .minimumInteractiveComponentSize()
          .testTag("playlist_save_button"),
      ) {
        Text(confirmLabel)
      }
    },
    dismissButton = {
      TextButton(
        onClick = onDismiss,
        modifier = Modifier.minimumInteractiveComponentSize(),
      ) {
        Text("Hủy")
      }
    },
  )
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ReportSongDialog(
  song: Song,
  onConfirmReport: (reason: String, detail: String) -> Unit,
  onDismiss: () -> Unit,
) {
  val presetReasons = remember {
    listOf(
      "Âm thanh lỗi / không phát được",
      "Sai thông tin / lời bài hát",
      "Vi phạm bản quyền",
      "Nội dung không phù hợp",
    )
  }
  var selectedReason by remember { mutableStateOf(presetReasons.first()) }
  var detail by remember { mutableStateOf("") }

  AlertDialog(
    onDismissRequest = onDismiss,
    title = {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
      ) {
        RhythmSymbolIcon(
          icon = RhythmIcons.Flag,
          contentDescription = null,
          tint = MaterialTheme.colorScheme.error,
          size = 22.dp,
          modifier = Modifier.size(22.dp),
        )
        Text("Báo cáo bài hát", style = MaterialTheme.typography.titleLarge)
      }
    },
    text = {
      Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(
          text = "${song.title} • ${song.artistName}",
          style = MaterialTheme.typography.labelLarge,
          color = MaterialTheme.colorScheme.primary,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis,
        )
        FlowRow(
          horizontalArrangement = Arrangement.spacedBy(6.dp),
          verticalArrangement = Arrangement.spacedBy(6.dp),
        ) {
          presetReasons.forEach { reason ->
            FilterChip(
              selected = selectedReason == reason,
              onClick = { selectedReason = reason },
              label = { Text(reason) },
              shape = CircleShape,
            )
          }
        }
        OutlinedTextField(
          value = detail,
          onValueChange = { detail = it },
          label = { Text("Mô tả chi tiết (tùy chọn)") },
          maxLines = 3,
          modifier = Modifier.fillMaxWidth(),
        )
      }
    },
    confirmButton = {
      Button(
        onClick = {
          onConfirmReport(selectedReason, detail.ifBlank { selectedReason })
          onDismiss()
        },
        modifier = Modifier.minimumInteractiveComponentSize(),
      ) {
        Text("Gửi báo cáo")
      }
    },
    dismissButton = {
      TextButton(onClick = onDismiss) { Text("Hủy") }
    },
  )
}

@Composable
fun AddToPlaylistDialog(
  song: Song,
  playlists: List<Playlist>,
  currentUserId: String?,
  onSelectPlaylist: (Playlist) -> Unit,
  onCreateNewPlaylist: (title: String, description: String) -> Unit,
  onDismiss: () -> Unit,
) {
  val editablePlaylists = remember(playlists, currentUserId) {
    if (currentUserId.isNullOrBlank()) {
      emptyList()
    } else {
      val collator = java.text.Collator.getInstance(java.util.Locale.forLanguageTag("vi-VN")).apply {
        strength = java.text.Collator.PRIMARY
      }
      playlists
        .filter { it.curatorId == currentUserId }
        .sortedWith { a, b -> collator.compare(a.title.trim(), b.title.trim()) }
    }
  }
  var showCreateForm by remember { mutableStateOf(false) }

  if (showCreateForm) {
    PlaylistEditorDialog(
      dialogTitle = "Tạo playlist mới",
      confirmLabel = "Tạo & thêm",
      onConfirm = { title, desc ->
        onCreateNewPlaylist(title, desc)
        showCreateForm = false
        onDismiss()
      },
      onDismiss = { showCreateForm = false },
    )
    return
  }

  AlertDialog(
    onDismissRequest = onDismiss,
    title = {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
      ) {
        RhythmSymbolIcon(
          icon = RhythmIcons.AddToPlaylist,
          contentDescription = null,
          tint = MaterialTheme.colorScheme.primary,
          size = 22.dp,
          modifier = Modifier.size(22.dp),
        )
        Text("Thêm vào playlist", style = MaterialTheme.typography.titleLarge)
      }
    },
    text = {
      Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(
          text = song.title,
          style = MaterialTheme.typography.labelLarge,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis,
        )
        if (editablePlaylists.isEmpty()) {
          Text(
            text = "Chưa có playlist cá nhân nào. Tạo playlist mới ngay!",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
          )
        } else {
          LazyColumn(
            modifier = Modifier
              .fillMaxWidth()
              .heightIn(max = 260.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp),
          ) {
            items(editablePlaylists, key = { it.id }) { pl ->
              Surface(
                shape = RoundedCornerShape(14.dp),
                color = MaterialTheme.colorScheme.surfaceContainerHigh,
                modifier = Modifier
                  .fillMaxWidth()
                  .clickable {
                    onSelectPlaylist(pl)
                    onDismiss()
                  },
              ) {
                Row(
                  modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                  verticalAlignment = Alignment.CenterVertically,
                  horizontalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                  ArtworkImage(
                    imageUrl = pl.coverUrl,
                    contentDescription = pl.title,
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.size(40.dp),
                  )
                  Column(modifier = Modifier.weight(1f)) {
                    Text(
                      text = pl.title,
                      style = MaterialTheme.typography.titleSmall,
                      maxLines = 1,
                      overflow = TextOverflow.Ellipsis,
                    )
                    Text(
                      text = "${maxOf(pl.songCount, pl.songs.size)} bài hát",
                      style = MaterialTheme.typography.bodySmall,
                      color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                  }
                }
              }
            }
          }
        }
        OutlinedButton(
          onClick = { showCreateForm = true },
          shape = CircleShape,
          modifier = Modifier.fillMaxWidth(),
        ) {
          RhythmSymbolIcon(
            icon = RhythmIcons.Add,
            contentDescription = null,
            size = 18.dp,
            modifier = Modifier.size(18.dp),
          )
          Spacer(Modifier.width(6.dp))
          Text("Tạo playlist mới")
        }
      }
    },
    confirmButton = {
      TextButton(onClick = onDismiss) { Text("Đóng") }
    },
  )
}

fun shareSongIntent(context: Context, song: Song) {
  val text = buildString {
    append("Đang nghe \"${song.title}\" — ${song.artistName} trên XuanKen Music")
    song.albumTitle?.takeIf { it.isNotBlank() }?.let { append(" (Album: $it)") }
  }
  val sendIntent = Intent(Intent.ACTION_SEND).apply {
    type = "text/plain"
    putExtra(Intent.EXTRA_SUBJECT, song.title)
    putExtra(Intent.EXTRA_TEXT, text)
  }
  val chooser = Intent.createChooser(sendIntent, "Chia sẻ bài hát")
  runCatching { context.startActivity(chooser) }
}

@Composable
fun SongInfoDialog(
  song: Song,
  isPurchased: Boolean,
  playCountOnDevice: Int = 0,
  onShareClick: (() -> Unit)? = null,
  onDismiss: () -> Unit,
) {
  AlertDialog(
    onDismissRequest = onDismiss,
    title = {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
      ) {
        RhythmSymbolIcon(
          icon = RhythmIcons.Actions.Info,
          contentDescription = null,
          tint = MaterialTheme.colorScheme.primary,
          size = 22.dp,
          modifier = Modifier.size(22.dp),
        )
        Text("Thông tin bài hát", style = MaterialTheme.typography.titleLarge)
      }
    },
    text = {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .testTag("song_info_dialog"),
        verticalArrangement = Arrangement.spacedBy(10.dp),
      ) {
        Surface(
          shape = RoundedCornerShape(16.dp),
          color = MaterialTheme.colorScheme.surfaceContainerHigh,
        ) {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp),
          ) {
            ArtworkImage(
              imageUrl = song.coverUrl,
              contentDescription = song.title,
              shape = RoundedCornerShape(12.dp),
              modifier = Modifier.size(56.dp),
            )
            Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
              Text(
                text = song.title,
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
              )
              Text(
                text = song.artistName,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
              )
            }
          }
        }

        @Composable
        fun MetaRow(label: String, value: String) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
          ) {
            Text(
              text = label,
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Text(
              text = value,
              style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold),
              color = MaterialTheme.colorScheme.onSurface,
              maxLines = 1,
              overflow = TextOverflow.Ellipsis,
            )
          }
        }

        MetaRow("Nghệ sĩ", song.artistName)
        song.albumTitle?.takeIf { it.isNotBlank() }?.let { MetaRow("Album", it) }
        song.genre?.takeIf { it.isNotBlank() }?.let { MetaRow("Thể loại", it) }
        if (song.durationSeconds > 0) {
          MetaRow("Thời lượng", FormatUtils.formatDurationSeconds(song.durationSeconds))
        }
        val totalPlays = maxOf(song.playCount, playCountOnDevice.toLong())
        if (totalPlays > 0L) {
          MetaRow("Lượt nghe", "$totalPlays lượt")
        }
        MetaRow(
          "Bản quyền",
          when {
            !song.isPaid -> "Miễn phí"
            isPurchased -> "Đã mở khóa"
            else -> song.priceText ?: "Trả phí"
          },
        )
        song.description?.takeIf { it.isNotBlank() }?.let { desc ->
          Text(
            text = desc,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            maxLines = 4,
            overflow = TextOverflow.Ellipsis,
          )
        }
      }
    },
    confirmButton = {
      TextButton(onClick = onDismiss) { Text("Đóng") }
    },
    dismissButton = if (onShareClick != null) {
      {
        OutlinedButton(onClick = {
          onShareClick()
          onDismiss()
        }) {
          RhythmSymbolIcon(
            icon = RhythmIcons.Actions.Share,
            contentDescription = null,
            size = 16.dp,
            modifier = Modifier.size(16.dp),
          )
          Spacer(Modifier.width(6.dp))
          Text("Chia sẻ")
        }
      }
    } else null,
  )
}
