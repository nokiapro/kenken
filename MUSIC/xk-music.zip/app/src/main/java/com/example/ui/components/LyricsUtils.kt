package com.example.ui.components

data class LyricLine(
  val timeMs: Long,
  val text: String,
)

data class ParsedLyrics(
  val syncedLines: List<LyricLine> = emptyList(),
  val plainLines: List<String> = emptyList(),
) {
  val isSynced: Boolean get() = syncedLines.isNotEmpty()
  val isEmpty: Boolean get() = syncedLines.isEmpty() && plainLines.isEmpty()
}

object LyricsUtils {
  private val TIMESTAMP_REGEX = Regex("""\[(\d{1,3}):(\d{2})(?:\.(\d{1,3}))?]""")
  private val META_TAG_REGEX = Regex("""^\[(ar|ti|al|by|offset|length|re|ve):.*]$""", RegexOption.IGNORE_CASE)

  fun parse(rawLyrics: String?): ParsedLyrics {
    val clean = rawLyrics?.trim()?.takeIf { it.isNotBlank() && !it.startsWith("LRC_URL:") }
      ?: return ParsedLyrics()

    val synced = mutableListOf<LyricLine>()
    val plain = mutableListOf<String>()

    clean.lineSequence().forEach { rawLine ->
      val line = rawLine.trim()
      if (line.isEmpty() || META_TAG_REGEX.matches(line)) return@forEach

      val matches = TIMESTAMP_REGEX.findAll(line).toList()
      if (matches.isNotEmpty()) {
        val textContent = line.replace(TIMESTAMP_REGEX, "").trim()
        if (textContent.isNotEmpty()) {
          matches.forEach { match ->
            val minutes = match.groupValues[1].toLongOrNull() ?: 0L
            val seconds = match.groupValues[2].toLongOrNull() ?: 0L
            val fracRaw = match.groupValues.getOrNull(3).orEmpty()
            val millis = when (fracRaw.length) {
              0 -> 0L
              1 -> (fracRaw.toLongOrNull() ?: 0L) * 100L
              2 -> (fracRaw.toLongOrNull() ?: 0L) * 10L
              else -> fracRaw.take(3).toLongOrNull() ?: 0L
            }
            val totalMs = minutes * 60_000L + seconds * 1_000L + millis
            synced.add(LyricLine(timeMs = totalMs, text = textContent))
          }
        }
      } else {
        plain.add(line)
      }
    }

    return if (synced.isNotEmpty()) {
      ParsedLyrics(syncedLines = synced.sortedBy { it.timeMs })
    } else {
      ParsedLyrics(plainLines = plain)
    }
  }

  fun findActiveIndex(lines: List<LyricLine>, positionMs: Long): Int {
    if (lines.isEmpty()) return -1
    var activeIdx = -1
    for (i in lines.indices) {
      if (lines[i].timeMs <= positionMs + 180L) {
        activeIdx = i
      } else {
        break
      }
    }
    return activeIdx
  }
}
