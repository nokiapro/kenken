package com.example.player

import android.app.PendingIntent
import android.content.Intent
import androidx.annotation.OptIn
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DataSource
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import com.example.MainActivity
import com.example.data.network.ApiClient
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

object PlaybackAudioConfig {
  private val _skipSilenceEnabled = MutableStateFlow(false)
  val skipSilenceEnabled: StateFlow<Boolean> = _skipSilenceEnabled.asStateFlow()

  fun setSkipSilenceEnabled(enabled: Boolean) {
    _skipSilenceEnabled.value = enabled
  }
}

class PlaybackService : MediaSessionService() {

  private var mediaSession: MediaSession? = null
  private var serviceScope: CoroutineScope? = null

  @OptIn(UnstableApi::class)
  override fun onCreate() {
    super.onCreate()

    val baseHttpFactory = DefaultHttpDataSource.Factory()
      .setAllowCrossProtocolRedirects(true)

    val authAwareDataSourceFactory = DataSource.Factory {
      val ds = baseHttpFactory.createDataSource()
      // Always wrap open() so xuanken.name.vn receives x-user-token / Authorization even if no static API key is compiled in
      HostScopedHeaderDataSource(ds)
    }

    val audioAttributes = AudioAttributes.Builder()
      .setUsage(C.USAGE_MEDIA)
      .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
      .build()

    val player = ExoPlayer.Builder(this)
      .setMediaSourceFactory(DefaultMediaSourceFactory(authAwareDataSourceFactory))
      .setAudioAttributes(audioAttributes, true)
      .setHandleAudioBecomingNoisy(true)
      .build()

    player.skipSilenceEnabled = PlaybackAudioConfig.skipSilenceEnabled.value

    serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate).also { scope ->
      scope.launch {
        PlaybackAudioConfig.skipSilenceEnabled.collectLatest { enabled ->
          player.skipSilenceEnabled = enabled
        }
      }
    }

    if (player.audioSessionId != C.AUDIO_SESSION_ID_UNSET && player.audioSessionId != 0) {
      AudioEqualizerManager.bindToAudioSession(player.audioSessionId)
    }
    player.addListener(object : Player.Listener {
      override fun onAudioSessionIdChanged(audioSessionId: Int) {
        if (audioSessionId != C.AUDIO_SESSION_ID_UNSET && audioSessionId != 0) {
          AudioEqualizerManager.bindToAudioSession(audioSessionId)
        }
      }
    })

    val launchIntent = Intent(this, MainActivity::class.java).apply {
      flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
    }
    val sessionActivityIntent = PendingIntent.getActivity(
      this,
      0,
      launchIntent,
      PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
    )

    mediaSession = MediaSession.Builder(this, player)
      .setSessionActivity(sessionActivityIntent)
      .build()
  }

  override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? {
    return mediaSession
  }

  override fun onTaskRemoved(rootIntent: Intent?) {
    val player = mediaSession?.player
    if (player == null || !player.playWhenReady || player.mediaItemCount == 0) {
      stopSelf()
    }
  }

  override fun onDestroy() {
    serviceScope?.cancel()
    serviceScope = null
    AudioEqualizerManager.release()
    mediaSession?.run {
      player.release()
      release()
      mediaSession = null
    }
    super.onDestroy()
  }
}

@OptIn(UnstableApi::class)
private class HostScopedHeaderDataSource(
  private val delegate: DefaultHttpDataSource,
) : DataSource by delegate {
  override fun open(dataSpec: androidx.media3.datasource.DataSpec): Long {
    val host = dataSpec.uri.host.orEmpty()
    delegate.clearAllRequestProperties()
    if (host.contains("xuanken.name.vn", ignoreCase = true)) {
      val apiKey = ApiClient.currentApiKey()
      if (ApiClient.isApiKeyConfigured()) {
        delegate.setRequestProperty("x-api-key", apiKey)
      }
      val userToken = ApiClient.currentUserToken()
      if (!userToken.isNullOrBlank()) {
        delegate.setRequestProperty("x-user-token", userToken)
        delegate.setRequestProperty("Authorization", "Bearer $userToken")
      } else if (ApiClient.isApiKeyConfigured()) {
        delegate.setRequestProperty("Authorization", "Bearer $apiKey")
      }
    }
    return delegate.open(dataSpec)
  }
}
