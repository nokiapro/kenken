package com.example.player

import android.media.audiofx.BassBoost
import android.media.audiofx.Equalizer
import android.media.audiofx.Virtualizer
import kotlin.math.roundToInt

/**
 * Process-scoped Android AudioEffect engine binding real Equalizer, BassBoost, and Virtualizer
 * to ExoPlayer's active audioSessionId, matching Rhythm's Equalizer architecture.
 */
object AudioEqualizerManager {

  private val lock = Any()
  private var boundSessionId: Int = 0
  private var equalizer: Equalizer? = null
  private var bassBoost: BassBoost? = null
  private var virtualizer: Virtualizer? = null

  private var lastEnabled: Boolean = false
  private var lastBandsDb: List<Float> = listOf(0f, 0f, 0f, 0f, 0f)
  private var lastBassLevel: Int = 0
  private var lastVirtualizerLevel: Int = 0

  fun bindToAudioSession(audioSessionId: Int) {
    if (audioSessionId <= 0) return
    synchronized(lock) {
      if (boundSessionId == audioSessionId && equalizer != null) {
        applyLocked()
        return
      }
      releaseEffectsLocked()
      boundSessionId = audioSessionId
      runCatching {
        equalizer = Equalizer(0, audioSessionId)
      }
      runCatching {
        bassBoost = BassBoost(0, audioSessionId)
      }
      runCatching {
        virtualizer = Virtualizer(0, audioSessionId)
      }
      applyLocked()
    }
  }

  fun applySettings(
    enabled: Boolean,
    bandsDb: List<Float>,
    bassBoostLevel: Int,
    virtualizerLevel: Int,
  ) {
    synchronized(lock) {
      lastEnabled = enabled
      lastBandsDb = bandsDb
      lastBassLevel = bassBoostLevel.coerceIn(0, 1000)
      lastVirtualizerLevel = virtualizerLevel.coerceIn(0, 1000)
      applyLocked()
    }
  }

  fun release() {
    synchronized(lock) {
      releaseEffectsLocked()
      boundSessionId = 0
    }
  }

  private fun applyLocked() {
    runCatching {
      val eq = equalizer ?: return@runCatching
      eq.enabled = lastEnabled
      if (lastEnabled && lastBandsDb.isNotEmpty()) {
        val bandCount = eq.numberOfBands.toInt().coerceAtLeast(0)
        val range = eq.bandLevelRange
        val minMb = range.getOrNull(0)?.toInt() ?: -1500
        val maxMb = range.getOrNull(1)?.toInt() ?: 1500
        for (band in 0 until bandCount) {
          val mappedIdx = if (bandCount == 1) 0 else {
            (band * (lastBandsDb.size - 1).coerceAtLeast(0)) / (bandCount - 1).coerceAtLeast(1)
          }
          val db = lastBandsDb.getOrElse(mappedIdx) { 0f }
          val mb = (db * 100f).roundToInt().coerceIn(minMb, maxMb).toShort()
          eq.setBandLevel(band.toShort(), mb)
        }
      }
    }

    runCatching {
      val bass = bassBoost ?: return@runCatching
      val active = lastEnabled && lastBassLevel > 0
      bass.enabled = active
      if (active && bass.strengthSupported) {
        bass.setStrength(lastBassLevel.coerceIn(0, 1000).toShort())
      }
    }

    runCatching {
      val virt = virtualizer ?: return@runCatching
      val active = lastEnabled && lastVirtualizerLevel > 0
      virt.enabled = active
      if (active && virt.strengthSupported) {
        virt.setStrength(lastVirtualizerLevel.coerceIn(0, 1000).toShort())
      }
    }
  }

  private fun releaseEffectsLocked() {
    runCatching { equalizer?.release() }
    runCatching { bassBoost?.release() }
    runCatching { virtualizer?.release() }
    equalizer = null
    bassBoost = null
    virtualizer = null
  }
}
