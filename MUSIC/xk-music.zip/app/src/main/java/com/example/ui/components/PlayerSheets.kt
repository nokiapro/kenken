@file:OptIn(ExperimentalMaterial3ExpressiveApi::class, ExperimentalMaterial3Api::class)

package com.example.ui.components

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.Crossfade
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExperimentalMaterial3ExpressiveApi
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat
import com.example.model.Playlist
import com.example.model.SleepTimerUiState
import com.example.model.Song
import com.example.player.PlaybackUiState
import com.example.player.RepeatModeState
import com.example.ui.FormatUtils
import com.example.ui.LyricsAlignment
import com.example.ui.PersonalizationSettings
import com.example.ui.rhythm.ExpressiveShapeTarget
import com.example.ui.rhythm.RhythmIcons
import com.example.ui.rhythm.RhythmSymbolIcon
import com.example.ui.rhythm.rememberExpressiveShapeFor
import com.example.ui.screens.SleepTimerPersonalizationContent
import com.example.ui.theme.LocalRhythmHapticsEnabled
import com.example.ui.theme.MonoNumericStyle
import com.example.ui.theme.RhythmColorExtractor
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.Locale
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.roundToInt
import kotlin.math.sin

// ---------------------------------------------------------------------------
// 1. ExpressiveMiniPlayer — Authentic Rhythm v5.5.499.1302-stable MiniPlayer
// ---------------------------------------------------------------------------

@Composable
fun MiniPlayerBar(
  playbackState: PlaybackUiState,
  isFavorite: Boolean,
  onExpandClick: () -> Unit,
  onTogglePlayPause: () -> Unit,
  onSkipNext: () -> Unit,
  onSkipPrevious: () -> Unit = {},
  onToggleFavorite: () -> Unit,
  modifier: Modifier = Modifier,
  onDismissClick: () -> Unit = {},
  showProgressBar: Boolean = true,
  gesturesEnabled: Boolean = true,
) {
  val song = playbackState.currentSong ?: return
  val haptic = LocalHapticFeedback.current
  val hapticsEnabled = LocalRhythmHapticsEnabled.current
  val miniArtworkShape = rememberExpressiveShapeFor(ExpressiveShapeTarget.MINI_PLAYER)

  val progress = if (playbackState.durationMs > 0L) {
    (playbackState.positionMs.toFloat() / playbackState.durationMs.toFloat()).coerceIn(0f, 1f)
  } else {
    0f
  }
  val animatedProgress by animateFloatAsState(
    targetValue = progress,
    animationSpec = spring(stiffness = Spring.StiffnessLow),
    label = "mini_player_progress",
  )

  var firstAppear by remember { mutableStateOf(true) }
  LaunchedEffect(Unit) { firstAppear = false }
  val appearScale by animateFloatAsState(
    targetValue = if (firstAppear) 1.05f else 1f,
    animationSpec = spring(
      dampingRatio = Spring.DampingRatioMediumBouncy,
      stiffness = Spring.StiffnessLow,
    ),
    label = "mini_appear_bounce",
  )

  var songPulseTarget by remember { mutableFloatStateOf(1f) }
  LaunchedEffect(song.id) {
    songPulseTarget = 1.02f
    delay(110)
    songPulseTarget = 1f
  }
  val songChangeScale by animateFloatAsState(
    targetValue = songPulseTarget,
    animationSpec = spring(
      dampingRatio = Spring.DampingRatioMediumBouncy,
      stiffness = Spring.StiffnessMediumLow,
    ),
    label = "mini_song_bounce",
  )

  var offsetX by remember { mutableFloatStateOf(0f) }
  var offsetY by remember { mutableFloatStateOf(0f) }

  val animatedOffsetX by animateFloatAsState(
    targetValue = offsetX,
    animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy),
    label = "mini_swipe_x",
  )
  val animatedOffsetY by animateFloatAsState(
    targetValue = offsetY,
    animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy),
    label = "mini_swipe_y",
  )

  val swipeHorizontalThreshold = 110f
  val swipeUpThreshold = 80f
  val swipeDownThreshold = 90f

  val dismissFraction = if (animatedOffsetY > 0f) {
    (animatedOffsetY / swipeDownThreshold).coerceIn(0f, 1f)
  } else {
    0f
  }
  val dismissScale = 1f - dismissFraction * 0.10f
  val dismissAlpha = 1f - dismissFraction * 0.45f
  val cardColor = MaterialTheme.colorScheme.surfaceContainer

  Box(
    modifier = modifier
      .fillMaxWidth()
      .padding(horizontal = 16.dp, vertical = 6.dp),
    contentAlignment = Alignment.Center,
  ) {
    Surface(
      modifier = Modifier
        .fillMaxWidth()
        .height(84.dp)
        .offset { IntOffset(animatedOffsetX.roundToInt(), animatedOffsetY.roundToInt()) }
        .graphicsLayer {
          val s = appearScale * songChangeScale * dismissScale
          scaleX = s
          scaleY = s
          alpha = dismissAlpha
        }
        .then(
          if (gesturesEnabled) {
            Modifier.pointerInput(song.id) {
              detectDragGestures(
                onDragEnd = {
                  when {
                    offsetY < -swipeUpThreshold && abs(offsetY) > abs(offsetX) -> {
                      if (hapticsEnabled) haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                      onExpandClick()
                    }
                    offsetY > swipeDownThreshold && abs(offsetY) > abs(offsetX) -> {
                      if (hapticsEnabled) haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                      onDismissClick()
                    }
                    offsetX < -swipeHorizontalThreshold && abs(offsetX) > abs(offsetY) -> {
                      if (hapticsEnabled) haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                      onSkipNext()
                    }
                    offsetX > swipeHorizontalThreshold && abs(offsetX) > abs(offsetY) -> {
                      if (hapticsEnabled) haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                      onSkipPrevious()
                    }
                  }
                  offsetX = 0f
                  offsetY = 0f
                },
                onDragCancel = {
                  offsetX = 0f
                  offsetY = 0f
                },
                onDrag = { change, dragAmount ->
                  change.consume()
                  if (abs(dragAmount.x) >= abs(dragAmount.y) && offsetY == 0f) {
                    offsetX = (offsetX + dragAmount.x).coerceIn(-160f, 160f)
                  } else if (offsetX == 0f) {
                    offsetY = (offsetY + dragAmount.y).coerceIn(-120f, 130f)
                  }
                },
              )
            }
          } else {
            Modifier
          },
        )
        .testTag("mini_player_bar"),
      onClick = onExpandClick,
      shape = CircleShape,
      color = cardColor,
      shadowElevation = 0.dp,
      tonalElevation = 2.dp,
    ) {
      Box(modifier = Modifier.fillMaxSize()) {
        if (showProgressBar && animatedProgress > 0f) {
          Box(
            modifier = Modifier
              .fillMaxHeight()
              .fillMaxWidth(fraction = animatedProgress.coerceIn(0.001f, 1f))
              .clip(CircleShape)
              .background(MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.60f)),
          )
        }

        Row(
          modifier = Modifier
            .fillMaxSize()
            .padding(end = 12.dp),
          verticalAlignment = Alignment.CenterVertically,
        ) {
          val artRingTransition = rememberInfiniteTransition(label = "mini_art_ring")
          val ringAlpha by artRingTransition.animateFloat(
            initialValue = 0.28f,
            targetValue = 0.72f,
            animationSpec = infiniteRepeatable(
              animation = tween(durationMillis = 1200, easing = FastOutSlowInEasing),
              repeatMode = RepeatMode.Reverse,
            ),
            label = "mini_ring_alpha",
          )
          Box(
            modifier = Modifier
              .fillMaxHeight()
              .aspectRatio(1f)
              .padding(7.dp)
              .then(
                if (playbackState.isPlaying) {
                  Modifier.border(
                    width = 1.5.dp,
                    color = MaterialTheme.colorScheme.primary.copy(alpha = ringAlpha),
                    shape = miniArtworkShape,
                  )
                } else {
                  Modifier
                },
              ),
            contentAlignment = Alignment.Center,
          ) {
            ArtworkImage(
              imageUrl = song.coverUrl,
              contentDescription = song.title,
              shape = miniArtworkShape,
              sizePx = 200,
              modifier = Modifier.fillMaxSize(),
            )
          }

          Spacer(modifier = Modifier.width(10.dp))

          AnimatedContent(
            targetState = song,
            transitionSpec = {
              (fadeIn(tween(240)) + slideInVertically(tween(240)) { it / 4 }) togetherWith
                (fadeOut(tween(180)) + slideOutVertically(tween(180)) { -it / 4 })
            },
            modifier = Modifier.weight(1f),
            label = "mini_song_text_transition",
          ) { currentSong ->
            Column(
              modifier = Modifier.fillMaxWidth(),
              verticalArrangement = Arrangement.Center,
            ) {
              AutoScrollingTextOnDemand(
                text = currentSong.title,
                gradientEdgeColor = cardColor,
                style = MaterialTheme.typography.titleMedium.copy(
                  fontWeight = FontWeight.Bold,
                  fontSize = 16.sp,
                  letterSpacing = (-0.2).sp,
                  color = MaterialTheme.colorScheme.onSurface,
                ),
              )
              AutoScrollingTextOnDemand(
                text = currentSong.artistName,
                gradientEdgeColor = cardColor,
                style = MaterialTheme.typography.bodyMedium.copy(
                  fontSize = 13.sp,
                  color = MaterialTheme.colorScheme.onSurfaceVariant,
                ),
              )
            }
          }

          Spacer(modifier = Modifier.width(12.dp))

          RhythmMorphingPlayPauseButton(
            isPlaying = playbackState.isPlaying,
            onClick = onTogglePlayPause,
            size = 56.dp,
            containerColor = MaterialTheme.colorScheme.primary,
            iconColor = MaterialTheme.colorScheme.onPrimary,
            modifier = Modifier.testTag("mini_player_play_pause"),
          )
        }
      }
    }

    AnimatedVisibility(
      visible = offsetY < -20f && abs(offsetY) > abs(offsetX),
      enter = fadeIn() + slideInVertically(),
      exit = fadeOut() + slideOutVertically(),
    ) {
      Surface(
        shape = CircleShape,
        color = MaterialTheme.colorScheme.primaryContainer.copy(
          alpha = (-offsetY / swipeUpThreshold).coerceIn(0.35f, 0.94f),
        ),
      ) {
        Text(
          text = "Vuốt lên để mở trình phát",
          style = MaterialTheme.typography.labelSmall,
          color = MaterialTheme.colorScheme.onPrimaryContainer,
          modifier = Modifier.padding(horizontal = 12.dp, vertical = 5.dp),
        )
      }
    }

    AnimatedVisibility(
      visible = offsetY > 24f && abs(offsetY) > abs(offsetX),
      enter = fadeIn() + slideInVertically(),
      exit = fadeOut() + slideOutVertically(),
    ) {
      Surface(
        shape = CircleShape,
        color = MaterialTheme.colorScheme.errorContainer.copy(
          alpha = (offsetY / swipeDownThreshold).coerceIn(0.35f, 0.94f),
        ),
      ) {
        Text(
          text = "Vuốt xuống để đóng",
          style = MaterialTheme.typography.labelSmall,
          color = MaterialTheme.colorScheme.onErrorContainer,
          modifier = Modifier.padding(horizontal = 12.dp, vertical = 5.dp),
        )
      }
    }

    AnimatedVisibility(
      visible = abs(offsetX) > 28f && abs(offsetX) > abs(offsetY),
      enter = fadeIn(),
      exit = fadeOut(),
    ) {
      Surface(
        shape = CircleShape,
        color = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.92f),
      ) {
        Text(
          text = if (offsetX < 0f) "Bài tiếp theo" else "Bài trước",
          style = MaterialTheme.typography.labelSmall,
          color = MaterialTheme.colorScheme.onSecondaryContainer,
          modifier = Modifier.padding(horizontal = 12.dp, vertical = 5.dp),
        )
      }
    }
  }
}

// ---------------------------------------------------------------------------
// 2. ExpressivePlayerScreen — Genuine Rhythm v5.5.499.1302-stable Fullscreen Player
// ---------------------------------------------------------------------------

private enum class PlayerSheetModal {
  NONE,
  QUEUE,
  SLEEP_TIMER,
  MORE,
}

private tailrec fun Context.findActivity(): Activity? = when (this) {
  is Activity -> this
  is ContextWrapper -> baseContext.findActivity()
  else -> null
}

private fun cascadeSegment(fraction: Float, start: Float, end: Float): Float {
  val span = (end - start).coerceAtLeast(0.001f)
  val linear = ((fraction - start) / span).coerceIn(0f, 1f)
  return FastOutSlowInEasing.transform(linear)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NowPlayingSheet(
  playbackState: PlaybackUiState,
  favoriteIds: Set<String>,
  purchasedIds: Set<String>,
  sleepTimerState: SleepTimerUiState,
  playlists: List<Playlist> = emptyList(),
  currentUserId: String? = null,
  playCountOnDevice: Int = 0,
  onDismiss: () -> Unit,
  onTogglePlayPause: () -> Unit,
  onSkipNext: () -> Unit,
  onSkipPrevious: () -> Unit,
  onSeekTo: (Long) -> Unit,
  @Suppress("UNUSED_PARAMETER") onSeekRelative: (Long) -> Unit = { delta ->
    onSeekTo((playbackState.positionMs + delta).coerceAtLeast(0L))
  },
  onToggleShuffle: () -> Unit,
  onCycleRepeat: () -> Unit,
  onToggleFavorite: (Song) -> Unit,
  onPlayQueueItem: (Song, List<Song>) -> Unit,
  onRemoveQueueItem: (Int) -> Unit = {},
  onMoveQueueItem: (Int, Int) -> Unit = { _, _ -> },
  onShuffleUpcomingQueue: () -> Unit = {},
  onClearUpcomingQueue: () -> Unit = {},
  onSetPlaybackSpeed: (Float) -> Unit = {},
  onOpenEqualizer: () -> Unit = {},
  onOpenArtist: (String) -> Unit,
  onOpenAlbum: (String) -> Unit = {},
  onPurchaseSong: (Song) -> Unit,
  onStartSleepTimer: (Int) -> Unit,
  onStartSleepAfterCurrentTrack: () -> Unit,
  onCancelSleepTimer: () -> Unit,
  onSleepTimerFadeOutChange: (Boolean) -> Unit = {},
  onDownloadSong: (Song) -> Unit = {},
  onAddSongToPlaylist: (Playlist, Song) -> Unit = { _, _ -> },
  onCreatePlaylistWithSong: (title: String, desc: String) -> Unit = { _, _ -> },
  onReportSong: (Song, reason: String, detail: String) -> Unit = { _, _, _ -> },
  onBlockSong: (Song) -> Unit = {},
  backHandlerEnabled: Boolean = true,
  personalization: PersonalizationSettings = PersonalizationSettings(),
) {
  val song = playbackState.currentSong ?: return
  val isFavorite = song.id in favoriteIds
  val isPurchased = song.id in purchasedIds || !song.isPaid

  val context = LocalContext.current
  val view = LocalView.current
  val haptic = LocalHapticFeedback.current
  val hapticsEnabled = LocalRhythmHapticsEnabled.current
  val playerArtworkShape = CircleShape

  var showLyrics by remember(song.id) { mutableStateOf(false) }
  var activeModal by remember { mutableStateOf(PlayerSheetModal.NONE) }
  var showReportDialog by remember(song.id) { mutableStateOf(false) }
  var showAddToPlaylistDialog by remember(song.id) { mutableStateOf(false) }
  var showSongInfoDialog by remember(song.id) { mutableStateOf(false) }

  // Keep screen on when enabled in Điều khiển người chơi
  DisposableEffect(view, personalization.keepScreenOnPlayer) {
    view.keepScreenOn = personalization.keepScreenOnPlayer
    onDispose {
      view.keepScreenOn = false
    }
  }

  // Dark mode = Bầu trời đêm nhiều sao; Light mode = Bầu trời trong xanh
  val isLightAppTheme = MaterialTheme.colorScheme.background.luminance() > 0.45f
  val isDarkMode = !isLightAppTheme
  val fallbackPalette = remember(song.id, song.title, song.artistName, isDarkMode) {
    RhythmColorExtractor.fallbackFromTrack(song.title, song.artistName, isDarkMode)
  }
  val targetPalette by produceState(
    initialValue = fallbackPalette,
    key1 = song.id,
    key2 = song.coverUrl,
    key3 = isDarkMode,
  ) {
    value = RhythmColorExtractor.extractForCover(
      context = context,
      coverUrl = song.coverUrl,
      title = song.title,
      artist = song.artistName,
      isDarkTheme = isDarkMode,
    )
  }

  val isLightCanvas = isLightAppTheme
  val canvasColor by animateColorAsState(
    targetValue = if (isDarkMode) Color(0xFF0A132B) else Color(0xFF60B6F7),
    animationSpec = tween(400, easing = FastOutSlowInEasing),
    label = "rhythm_player_canvas",
  )
  val inkColor by animateColorAsState(
    targetValue = if (isDarkMode) Color.White else Color(0xFF082340),
    animationSpec = tween(400, easing = FastOutSlowInEasing),
    label = "rhythm_player_ink",
  )
  val mutedInkColor = inkColor.copy(alpha = 0.76f)
  val primaryAccent by animateColorAsState(
    targetValue = if (isDarkMode) Color(0xFFF6F7FF) else Color(0xFF0A2E57),
    animationSpec = tween(400, easing = FastOutSlowInEasing),
    label = "rhythm_player_primary",
  )
  val onPrimaryAccent by animateColorAsState(
    targetValue = if (isDarkMode) Color(0xFF0A1430) else Color.White,
    animationSpec = tween(400, easing = FastOutSlowInEasing),
    label = "rhythm_player_on_primary",
  )
  val softPillColor by animateColorAsState(
    targetValue = if (isDarkMode) {
      Color.White.copy(alpha = 0.16f)
    } else {
      Color(0xFF0A2E57).copy(alpha = 0.14f)
    },
    animationSpec = tween(400, easing = FastOutSlowInEasing),
    label = "rhythm_player_soft_pill",
  )

  DisposableEffect(isLightCanvas, isDarkMode) {
    val activity = context.findActivity()
    val window = activity?.window
    val controller = if (window != null) WindowCompat.getInsetsController(window, view) else null
    controller?.isAppearanceLightStatusBars = isLightCanvas
    controller?.isAppearanceLightNavigationBars = isLightCanvas
    onDispose {
      controller?.isAppearanceLightStatusBars = !isDarkMode
      controller?.isAppearanceLightNavigationBars = !isDarkMode
    }
  }

  var prevSongId by remember { mutableStateOf(song.id) }
  var trackDirection by remember { mutableIntStateOf(1) }
  LaunchedEffect(song.id) {
    if (song.id != prevSongId) {
      val prevIdx = playbackState.queue.indexOfFirst { it.id == prevSongId }
      val nextIdx = playbackState.queue.indexOfFirst { it.id == song.id }
      trackDirection = if (prevIdx >= 0 && nextIdx >= 0 && nextIdx < prevIdx) -1 else 1
      prevSongId = song.id
    }
  }

  // Genuine Rhythm ExpressivePlayerScreen staggered cascade animation
  var entranceStarted by remember { mutableStateOf(false) }
  LaunchedEffect(Unit) { entranceStarted = true }
  val entranceFraction by animateFloatAsState(
    targetValue = if (entranceStarted) 1f else 0f,
    animationSpec = tween(durationMillis = 420, easing = LinearEasing),
    label = "rhythm_player_entrance",
  )

  val artEntrance = cascadeSegment(entranceFraction, 0.0f, 0.52f)
  val titleEntrance = cascadeSegment(entranceFraction, 0.14f, 0.66f)
  val controlsEntrance = cascadeSegment(entranceFraction, 0.24f, 0.78f)
  val dockEntrance = cascadeSegment(entranceFraction, 0.36f, 0.92f)

  val artworkScale by animateFloatAsState(
    targetValue = if (playbackState.isPlaying) 1f else 0.93f,
    animationSpec = spring(
      dampingRatio = Spring.DampingRatioMediumBouncy,
      stiffness = Spring.StiffnessMediumLow,
    ),
    label = "player_art_scale",
  )

  val discRotation = remember(song.id) { Animatable(0f) }
  LaunchedEffect(song.id, playbackState.isPlaying, personalization.rotateArtwork) {
    if (playbackState.isPlaying && personalization.rotateArtwork) {
      val start = discRotation.value % 360f
      discRotation.snapTo(start)
      discRotation.animateTo(
        targetValue = start + 360f,
        animationSpec = infiniteRepeatable(
          animation = tween(durationMillis = 15_000, easing = LinearEasing),
          repeatMode = RepeatMode.Restart,
        ),
      )
    } else {
      discRotation.stop()
      if (!personalization.rotateArtwork) {
        discRotation.snapTo(0f)
      }
    }
  }

  var rawArtSwipeX by remember { mutableFloatStateOf(0f) }
  val animArtSwipeX by animateFloatAsState(
    targetValue = rawArtSwipeX,
    animationSpec = spring(
      dampingRatio = Spring.DampingRatioMediumBouncy,
      stiffness = Spring.StiffnessMediumLow,
    ),
    label = "player_art_swipe_x",
  )

  var swipeDownOffset by remember { mutableFloatStateOf(0f) }
  val animatedSwipeDown by animateFloatAsState(
    targetValue = swipeDownOffset,
    animationSpec = spring(
      dampingRatio = Spring.DampingRatioNoBouncy,
      stiffness = Spring.StiffnessMedium,
    ),
    label = "player_sheet_drag_y",
  )
  val swipeFraction = (animatedSwipeDown / 420f).coerceIn(0f, 1f)
  val sheetScale = 1f - swipeFraction * 0.14f
  val sheetCornerDp by animateDpAsState(
    targetValue = (swipeFraction * 56f).dp,
    animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy),
    label = "player_sheet_corner",
  )

  BackHandler(enabled = backHandlerEnabled && activeModal != PlayerSheetModal.NONE) {
    activeModal = PlayerSheetModal.NONE
  }
  BackHandler(enabled = backHandlerEnabled && showLyrics && activeModal == PlayerSheetModal.NONE) {
    showLyrics = false
  }
  BackHandler(enabled = backHandlerEnabled && !showLyrics && activeModal == PlayerSheetModal.NONE) {
    onDismiss()
  }

  Box(
    modifier = Modifier
      .fillMaxSize()
      .offset { IntOffset(0, (animatedSwipeDown * 0.65f).roundToInt()) }
      .graphicsLayer {
        scaleX = sheetScale
        scaleY = sheetScale
      }
      .clip(RoundedCornerShape(sheetCornerDp))
      .background(canvasColor)
      .then(
        if (personalization.swipeDownToDismissPlayer) {
          Modifier.pointerInput(Unit) {
            detectVerticalDragGestures(
              onDragEnd = {
                if (swipeDownOffset > 140f) {
                  if (hapticsEnabled) haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                  onDismiss()
                }
                swipeDownOffset = 0f
              },
              onDragCancel = { swipeDownOffset = 0f },
              onVerticalDrag = { change, dragAmount ->
                if (dragAmount > 0f || swipeDownOffset > 0f) {
                  change.consume()
                  swipeDownOffset = (swipeDownOffset + dragAmount).coerceAtLeast(0f)
                }
              },
            )
          }
        } else {
          Modifier
        },
      ),
  ) {
    if (isDarkMode) {
      StarrySkyBackground(
        accentTint = targetPalette.accentBg,
        modifier = Modifier
          .fillMaxSize()
          .testTag("player_starry_sky"),
      )
    } else {
      ClearBlueSkyBackground(
        modifier = Modifier
          .fillMaxSize()
          .testTag("player_clear_sky"),
      )
    }

    BoxWithConstraints(
      modifier = Modifier
        .fillMaxSize()
        .statusBarsPadding()
        .navigationBarsPadding()
        .imePadding(),
      contentAlignment = Alignment.TopCenter,
    ) {
      val availW = maxWidth
      val availH = maxHeight
      val isTabletLandscape = availW >= 600.dp && availW > availH
      val isCompactHeight = availH < 610.dp
      val isVeryCompact = availH < 520.dp

      val contentMaxWidth = if (isTabletLandscape) 960.dp else 520.dp
      val horizontalPad = if (availW < 360.dp) 18.dp else 24.dp
      val topPad = if (isCompactHeight) 4.dp else 12.dp
      val bottomPad = when {
        isVeryCompact -> 10.dp
        isCompactHeight -> 14.dp
        else -> 18.dp
      }
      val showUnlockButton = song.isPaid && !isPurchased
      val controlHeight = when {
        isVeryCompact -> 54.dp
        isCompactHeight -> 60.dp
        else -> 66.dp
      }
      val controlSpacing = when {
        isVeryCompact -> 8.dp
        isCompactHeight -> 10.dp
        else -> 14.dp
      }
      val sectionSpacing = when {
        isVeryCompact -> 8.dp
        isCompactHeight -> 14.dp
        else -> 20.dp
      }
      val dockTopSpacing = when {
        isVeryCompact -> 10.dp
        isCompactHeight -> 16.dp
        else -> 22.dp
      }
      val dockHeight = if (isVeryCompact) 42.dp else 46.dp
      val safeDuration = playbackState.durationMs.coerceAtLeast(
        song.durationSeconds.toLong().coerceAtLeast(0L) * 1000L,
      )
      val sleepTimerBadgeText = remember(
        sleepTimerState.isActive,
        sleepTimerState.stopAfterCurrentSong,
        sleepTimerState.remainingSeconds,
      ) {
        if (!sleepTimerState.isActive) {
          null
        } else if (sleepTimerState.stopAfterCurrentSong) {
          "Hết bài"
        } else {
          FormatUtils.formatDurationMs(sleepTimerState.remainingSeconds * 1000L)
        }
      }

      if (isTabletLandscape) {
        // Genuine Rhythm 2-pane landscape tablet player layout
        Row(
          modifier = Modifier
            .widthIn(max = contentMaxWidth)
            .fillMaxSize()
            .padding(horizontal = horizontalPad, vertical = 16.dp),
          horizontalArrangement = Arrangement.spacedBy(28.dp),
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Box(
            modifier = Modifier
              .weight(1f)
              .fillMaxHeight()
              .graphicsLayer {
                translationY = (1f - artEntrance) * 24.dp.toPx()
                val s = 0.92f + 0.08f * artEntrance
                scaleX = s
                scaleY = s
              },
            contentAlignment = Alignment.Center,
          ) {
            val artSize = minOf(availH * 0.72f, availW * 0.42f).coerceIn(180.dp, 360.dp)
            PlayerArtworkOrLyricsSlot(
              song = song,
              isPlaying = playbackState.isPlaying,
              showLyrics = showLyrics,
              showUnlockButton = showUnlockButton,
              isCompactHeight = isCompactHeight,
              artSize = artSize,
              artworkShape = playerArtworkShape,
              artworkScale = artworkScale,
              artworkRotationProvider = { discRotation.value },
              animArtSwipeX = animArtSwipeX,
              positionMs = playbackState.positionMs,
              primaryAccent = primaryAccent,
              inkColor = inkColor,
              personalization = personalization,
              onToggleLyrics = { if (personalization.tapArtworkForLyrics) showLyrics = true },
              onSeekTo = onSeekTo,
              onPurchaseSong = { onPurchaseSong(song) },
              onSwipeXDelta = {
                if (personalization.swipeArtworkToSkip) {
                  rawArtSwipeX = (rawArtSwipeX + it * 0.65f).coerceIn(-150f, 150f)
                }
              },
              onSwipeXEnd = {
                if (personalization.swipeArtworkToSkip) {
                  when {
                    rawArtSwipeX < -85f -> {
                      if (hapticsEnabled) haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                      onSkipNext()
                    }
                    rawArtSwipeX > 85f -> {
                      if (hapticsEnabled) haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                      onSkipPrevious()
                    }
                  }
                }
                rawArtSwipeX = 0f
              },
              onSwipeXCancel = { rawArtSwipeX = 0f },
            )

            PlayerOverlayBadges(
              inkColor = inkColor,
              onDismiss = onDismiss,
            )
          }

          Column(
            modifier = Modifier
              .weight(1f)
              .fillMaxHeight(),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally,
          ) {
            PlayerTitleAndArtistBlock(
              song = song,
              trackDirection = trackDirection,
              titleEntrance = titleEntrance,
              isCompactHeight = isCompactHeight,
              canvasColor = canvasColor,
              inkColor = inkColor,
              mutedInkColor = mutedInkColor,
              onOpenArtist = { artistId ->
                onDismiss()
                onOpenArtist(artistId)
              },
            )
            Spacer(Modifier.height(sectionSpacing))
            PlayerTransportControls(
              playbackState = playbackState,
              safeDuration = safeDuration,
              isCompactHeight = isCompactHeight,
              controlHeight = controlHeight,
              controlSpacing = controlSpacing,
              controlsEntrance = controlsEntrance,
              useWavySeekbar = personalization.useWavySeekbar,
              primaryAccent = primaryAccent,
              onPrimaryAccent = onPrimaryAccent,
              softPillColor = softPillColor,
              inkColor = inkColor,
              mutedInkColor = mutedInkColor,
              onTogglePlayPause = onTogglePlayPause,
              onSkipNext = onSkipNext,
              onSkipPrevious = onSkipPrevious,
              onSeekTo = onSeekTo,
            )
            Spacer(Modifier.height(dockTopSpacing))
            PlayerBottomSegmentedDock(
              dockHeight = dockHeight,
              dockEntrance = dockEntrance,
              showLyrics = showLyrics,
              isFavorite = isFavorite,
              sleepTimerActive = sleepTimerState.isActive,
              sleepTimerBadgeText = sleepTimerBadgeText,
              activeModal = activeModal,
              softPillColor = softPillColor,
              primaryAccent = primaryAccent,
              inkColor = inkColor,
              onPrimaryAccent = onPrimaryAccent,
              onToggleLyrics = { showLyrics = !showLyrics },
              onToggleFavorite = { onToggleFavorite(song) },
              onOpenSleepTimer = { activeModal = PlayerSheetModal.SLEEP_TIMER },
              onOpenQueue = { activeModal = PlayerSheetModal.QUEUE },
              onOpenMore = { activeModal = PlayerSheetModal.MORE },
            )
          }
        }
      } else {
        // Genuine Rhythm Portrait ExpressivePlayerScreen with dynamic responsive sizing
        val titleBlockEst = if (isCompactHeight) 56.dp else 64.dp
        val unlockHeightEst = if (showUnlockButton) 44.dp else 0.dp
        val nonArtBudget = topPad + bottomPad +
          titleBlockEst + unlockHeightEst +
          sectionSpacing + (controlHeight * 2) + controlSpacing +
          dockTopSpacing + dockHeight + 12.dp

        val usableWidth = (minOf(availW, contentMaxWidth) - horizontalPad * 2).coerceAtLeast(180.dp)
        val maxArtByHeight = (availH - nonArtBudget).coerceAtLeast(116.dp)
        val maxArtByWidth = (usableWidth * 0.90f).coerceAtMost(336.dp)
        val artSize = minOf(maxArtByHeight, maxArtByWidth)

        Column(
          modifier = Modifier
            .widthIn(max = contentMaxWidth)
            .fillMaxSize()
            .padding(horizontal = horizontalPad)
            .padding(top = topPad, bottom = bottomPad),
          horizontalAlignment = Alignment.CenterHorizontally,
        ) {
          Box(
            modifier = Modifier
              .weight(1f, fill = true)
              .fillMaxWidth()
              .graphicsLayer {
                translationY = (1f - artEntrance) * 32.dp.toPx()
                val s = 0.92f + 0.08f * artEntrance
                scaleX = s
                scaleY = s
              },
            contentAlignment = Alignment.Center,
          ) {
            PlayerArtworkOrLyricsSlot(
              song = song,
              isPlaying = playbackState.isPlaying,
              showLyrics = showLyrics,
              showUnlockButton = showUnlockButton,
              isCompactHeight = isCompactHeight,
              artSize = artSize,
              artworkShape = playerArtworkShape,
              artworkScale = artworkScale,
              artworkRotationProvider = { discRotation.value },
              animArtSwipeX = animArtSwipeX,
              positionMs = playbackState.positionMs,
              primaryAccent = primaryAccent,
              inkColor = inkColor,
              personalization = personalization,
              onToggleLyrics = { if (personalization.tapArtworkForLyrics) showLyrics = true },
              onSeekTo = onSeekTo,
              onPurchaseSong = { onPurchaseSong(song) },
              onSwipeXDelta = {
                if (personalization.swipeArtworkToSkip) {
                  rawArtSwipeX = (rawArtSwipeX + it * 0.65f).coerceIn(-150f, 150f)
                }
              },
              onSwipeXEnd = {
                if (personalization.swipeArtworkToSkip) {
                  when {
                    rawArtSwipeX < -85f -> {
                      if (hapticsEnabled) haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                      onSkipNext()
                    }
                    rawArtSwipeX > 85f -> {
                      if (hapticsEnabled) haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                      onSkipPrevious()
                    }
                  }
                }
                rawArtSwipeX = 0f
              },
              onSwipeXCancel = { rawArtSwipeX = 0f },
            )

            PlayerOverlayBadges(
              inkColor = inkColor,
              onDismiss = onDismiss,
            )
          }

          PlayerTitleAndArtistBlock(
            song = song,
            trackDirection = trackDirection,
            titleEntrance = titleEntrance,
            isCompactHeight = isCompactHeight,
            canvasColor = canvasColor,
            inkColor = inkColor,
            mutedInkColor = mutedInkColor,
            onOpenArtist = { artistId ->
              onDismiss()
              onOpenArtist(artistId)
            },
          )

          Spacer(Modifier.height(sectionSpacing))

          PlayerTransportControls(
            playbackState = playbackState,
            safeDuration = safeDuration,
            isCompactHeight = isCompactHeight,
            controlHeight = controlHeight,
            controlSpacing = controlSpacing,
            controlsEntrance = controlsEntrance,
            useWavySeekbar = personalization.useWavySeekbar,
            primaryAccent = primaryAccent,
            onPrimaryAccent = onPrimaryAccent,
            softPillColor = softPillColor,
            inkColor = inkColor,
            mutedInkColor = mutedInkColor,
            onTogglePlayPause = onTogglePlayPause,
            onSkipNext = onSkipNext,
            onSkipPrevious = onSkipPrevious,
            onSeekTo = onSeekTo,
          )

          Spacer(Modifier.height(dockTopSpacing))

          PlayerBottomSegmentedDock(
            dockHeight = dockHeight,
            dockEntrance = dockEntrance,
            showLyrics = showLyrics,
            isFavorite = isFavorite,
            sleepTimerActive = sleepTimerState.isActive,
            sleepTimerBadgeText = sleepTimerBadgeText,
            activeModal = activeModal,
            softPillColor = softPillColor,
            primaryAccent = primaryAccent,
            inkColor = inkColor,
            onPrimaryAccent = onPrimaryAccent,
            onToggleLyrics = { showLyrics = !showLyrics },
            onToggleFavorite = { onToggleFavorite(song) },
            onOpenSleepTimer = { activeModal = PlayerSheetModal.SLEEP_TIMER },
            onOpenQueue = { activeModal = PlayerSheetModal.QUEUE },
            onOpenMore = { activeModal = PlayerSheetModal.MORE },
          )
        }
      }

      if (activeModal != PlayerSheetModal.NONE) {
        val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
        ModalBottomSheet(
          onDismissRequest = { activeModal = PlayerSheetModal.NONE },
          sheetState = sheetState,
          containerColor = MaterialTheme.colorScheme.surfaceContainerLow,
        ) {
          when (activeModal) {
            PlayerSheetModal.QUEUE -> QueueModalContent(
              queue = playbackState.queue,
              currentIndex = playbackState.currentIndex,
              currentSongId = song.id,
              isPlaying = playbackState.isPlaying,
              favoriteIds = favoriteIds,
              purchasedIds = purchasedIds,
              onSelectSong = { selected ->
                onPlayQueueItem(selected, playbackState.queue)
                activeModal = PlayerSheetModal.NONE
              },
              onToggleFavorite = onToggleFavorite,
              onRemoveQueueItem = onRemoveQueueItem,
              onMoveQueueItem = onMoveQueueItem,
              onShuffleUpcomingQueue = onShuffleUpcomingQueue,
              onClearUpcomingQueue = onClearUpcomingQueue,
            )
            PlayerSheetModal.SLEEP_TIMER -> Column(
              modifier = Modifier
                .fillMaxWidth()
                .heightIn(max = 560.dp)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp)
                .padding(bottom = 28.dp),
            ) {
              SleepTimerPersonalizationContent(
                sleepTimerState = sleepTimerState,
                fadeOutEnabled = personalization.sleepTimerFadeOut,
                onStartSleepTimer = onStartSleepTimer,
                onStartSleepAfterCurrentTrack = onStartSleepAfterCurrentTrack,
                onCancelSleepTimer = onCancelSleepTimer,
                onFadeOutChange = onSleepTimerFadeOutChange,
              )
            }
            PlayerSheetModal.MORE -> PlayerMoreActionsSheetContent(
              song = song,
              shuffleEnabled = playbackState.shuffleEnabled,
              repeatMode = playbackState.repeatMode,
              playbackSpeed = personalization.playbackSpeed,
              onToggleShuffle = onToggleShuffle,
              onCycleRepeat = onCycleRepeat,
              onSetPlaybackSpeed = onSetPlaybackSpeed,
              onOpenEqualizer = {
                activeModal = PlayerSheetModal.NONE
                onDismiss()
                onOpenEqualizer()
              },
              onDownload = {
                activeModal = PlayerSheetModal.NONE
                onDownloadSong(song)
              },
              onAddToPlaylist = {
                activeModal = PlayerSheetModal.NONE
                showAddToPlaylistDialog = true
              },
              onShowInfo = {
                activeModal = PlayerSheetModal.NONE
                showSongInfoDialog = true
              },
              onShareSong = {
                activeModal = PlayerSheetModal.NONE
                shareSongIntent(context, song)
              },
              onOpenArtist = {
                song.artistId?.takeIf { it.isNotBlank() }?.let { id ->
                  activeModal = PlayerSheetModal.NONE
                  onDismiss()
                  onOpenArtist(id)
                }
              },
              onOpenAlbum = {
                song.albumId?.takeIf { it.isNotBlank() }?.let { id ->
                  activeModal = PlayerSheetModal.NONE
                  onDismiss()
                  onOpenAlbum(id)
                }
              },
              onReportSong = {
                activeModal = PlayerSheetModal.NONE
                showReportDialog = true
              },
              onBlockSong = {
                activeModal = PlayerSheetModal.NONE
                onBlockSong(song)
              },
            )
            PlayerSheetModal.NONE -> Unit
          }
        }
      }

      if (showReportDialog) {
        ReportSongDialog(
          song = song,
          onConfirmReport = { reason, detail ->
            onReportSong(song, reason, detail)
          },
          onDismiss = { showReportDialog = false },
        )
      }

      if (showAddToPlaylistDialog) {
        AddToPlaylistDialog(
          song = song,
          playlists = playlists,
          currentUserId = currentUserId,
          onSelectPlaylist = { pl -> onAddSongToPlaylist(pl, song) },
          onCreateNewPlaylist = { title, desc -> onCreatePlaylistWithSong(title, desc) },
          onDismiss = { showAddToPlaylistDialog = false },
        )
      }

      if (showSongInfoDialog) {
        SongInfoDialog(
          song = song,
          isPurchased = isPurchased,
          playCountOnDevice = playCountOnDevice,
          onShareClick = { shareSongIntent(context, song) },
          onDismiss = { showSongInfoDialog = false },
        )
      }
    }
  }
}

@Composable
private fun StarrySkyBackground(
  accentTint: Color,
  modifier: Modifier = Modifier,
) {
  data class StarDot(val xFrac: Float, val yFrac: Float, val radiusDp: Float, val phase: Float, val baseAlpha: Float)

  val stars = remember {
    List(84) { i ->
      val idx = i + 1
      val rx = ((idx * 37 + 13) % 97) / 97f
      val ry = ((idx * 53 + 29) % 89) / 89f
      val rDp = 0.95f + (idx % 4) * 0.55f
      val phase = (idx * 0.618f) % 1f
      val alpha = 0.34f + (idx % 5) * 0.14f
      StarDot(rx, ry, rDp, phase, alpha)
    }
  }

  val twinkleTransition = rememberInfiniteTransition(label = "starry_twinkle")
  val twinklePhase by twinkleTransition.animateFloat(
    initialValue = 0f,
    targetValue = (2f * PI).toFloat(),
    animationSpec = infiniteRepeatable(
      animation = tween(durationMillis = 5200, easing = LinearEasing),
      repeatMode = RepeatMode.Restart,
    ),
    label = "starry_phase",
  )

  val nightSkyBrush = remember {
    Brush.verticalGradient(
      colors = listOf(
        Color(0xFF040714),
        Color(0xFF0A132C),
        Color(0xFF14224A),
      ),
    )
  }

  Box(
    modifier = modifier.drawWithCache {
      val haloCenter = Offset(size.width * 0.5f, size.height * 0.34f)
      val haloRadius = size.maxDimension * 0.52f
      val haloBrush = Brush.radialGradient(
        colors = listOf(accentTint.copy(alpha = 0.16f), Color.Transparent),
        center = haloCenter,
        radius = haloRadius,
      )
      val starPositions = stars.map { star ->
        Offset(x = star.xFrac * size.width, y = star.yFrac * size.height) to star.radiusDp.dp.toPx()
      }
      onDrawBehind {
        drawRect(brush = nightSkyBrush)
        drawCircle(
          brush = haloBrush,
          center = haloCenter,
          radius = haloRadius,
        )
        stars.forEachIndexed { idx, star ->
          val wave = 0.55f + 0.45f * sin(twinklePhase + star.phase * (2f * PI).toFloat())
          val alpha = (star.baseAlpha * wave).coerceIn(0.14f, 0.96f)
          val dotColor = if (idx % 7 == 0) Color(0xFFBBD7FF) else Color.White
          val (center, radiusPx) = starPositions[idx]
          if (idx % 5 == 0) {
            drawCircle(
              color = dotColor.copy(alpha = alpha * 0.28f),
              radius = radiusPx * 2.4f,
              center = center,
            )
          }
          drawCircle(
            color = dotColor.copy(alpha = alpha),
            radius = radiusPx,
            center = center,
          )
        }
      }
    },
  )
}

@Composable
private fun ClearBlueSkyBackground(
  modifier: Modifier = Modifier,
) {
  val skyBrush = remember {
    Brush.verticalGradient(
      colors = listOf(
        Color(0xFF3A9BF7),
        Color(0xFF7BC8FC),
        Color(0xFFD6EEFF),
      ),
    )
  }

  val driftTransition = rememberInfiniteTransition(label = "sky_clouds")
  val cloudDrift by driftTransition.animateFloat(
    initialValue = -0.04f,
    targetValue = 0.04f,
    animationSpec = infiniteRepeatable(
      animation = tween(durationMillis = 9000, easing = FastOutSlowInEasing),
      repeatMode = RepeatMode.Reverse,
    ),
    label = "cloud_drift",
  )

  Box(
    modifier = modifier.drawWithCache {
      val sunCenter = Offset(size.width * 0.82f, size.height * 0.14f)
      val sunRadius = size.minDimension * 0.48f
      val sunBrush = Brush.radialGradient(
        colors = listOf(Color(0xFFFFF8DC).copy(alpha = 0.45f), Color.Transparent),
        center = sunCenter,
        radius = sunRadius,
      )
      val r1 = 86.dp.toPx()
      val r2 = 64.dp.toPx()
      val r3 = 94.dp.toPx()
      val r4 = 68.dp.toPx()
      val r5 = 110.dp.toPx()
      onDrawBehind {
        drawRect(brush = skyBrush)
        drawCircle(
          brush = sunBrush,
          center = sunCenter,
          radius = sunRadius,
        )
        val shift = cloudDrift * size.width
        drawCircle(Color.White.copy(alpha = 0.26f), r1, Offset(size.width * 0.22f + shift, size.height * 0.20f))
        drawCircle(Color.White.copy(alpha = 0.22f), r2, Offset(size.width * 0.34f + shift, size.height * 0.18f))
        drawCircle(Color.White.copy(alpha = 0.20f), r3, Offset(size.width * 0.78f - shift, size.height * 0.44f))
        drawCircle(Color.White.copy(alpha = 0.18f), r4, Offset(size.width * 0.66f - shift, size.height * 0.46f))
        drawCircle(Color.White.copy(alpha = 0.18f), r5, Offset(size.width * 0.26f + shift * 0.6f, size.height * 0.72f))
      }
    },
  )
}

@Composable
private fun PlayerArtworkOrLyricsSlot(
  song: Song,
  isPlaying: Boolean,
  showLyrics: Boolean,
  showUnlockButton: Boolean,
  isCompactHeight: Boolean,
  artSize: Dp,
  artworkShape: androidx.compose.ui.graphics.Shape,
  artworkScale: Float,
  artworkRotationProvider: () -> Float,
  animArtSwipeX: Float,
  positionMs: Long,
  primaryAccent: Color,
  inkColor: Color,
  personalization: PersonalizationSettings,
  onToggleLyrics: () -> Unit,
  onSeekTo: (Long) -> Unit,
  onPurchaseSong: () -> Unit,
  onSwipeXDelta: (Float) -> Unit,
  onSwipeXEnd: () -> Unit,
  onSwipeXCancel: () -> Unit,
) {
  val haloTransition = rememberInfiniteTransition(label = "artwork_halo")
  val haloPulse by haloTransition.animateFloat(
    initialValue = 1.0f,
    targetValue = 1.06f,
    animationSpec = infiniteRepeatable(
      animation = tween(durationMillis = 2200, easing = FastOutSlowInEasing),
      repeatMode = RepeatMode.Reverse,
    ),
    label = "halo_pulse_scale",
  )
  val haloAlpha by haloTransition.animateFloat(
    initialValue = 0.14f,
    targetValue = 0.34f,
    animationSpec = infiniteRepeatable(
      animation = tween(durationMillis = 2200, easing = FastOutSlowInEasing),
      repeatMode = RepeatMode.Reverse,
    ),
    label = "halo_pulse_alpha",
  )

  Crossfade(
    targetState = showLyrics,
    animationSpec = tween(240),
    label = "art_lyrics_crossfade",
  ) { lyricsVisible ->
    if (!lyricsVisible) {
      Column(
        modifier = Modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
      ) {
        val swipeCompression = 1f - (abs(animArtSwipeX) / 900f).coerceIn(0f, 0.08f)
        Box(
          modifier = Modifier.size(artSize),
          contentAlignment = Alignment.Center,
        ) {
          if (isPlaying) {
            Box(
              modifier = Modifier
                .fillMaxSize()
                .graphicsLayer {
                  scaleX = haloPulse * artworkScale
                  scaleY = haloPulse * artworkScale
                  translationX = animArtSwipeX
                }
                .border(
                  width = 3.dp,
                  color = primaryAccent.copy(alpha = haloAlpha),
                  shape = artworkShape,
                ),
            )
          }
          Box(
            modifier = Modifier
              .fillMaxSize()
              .graphicsLayer {
                scaleX = artworkScale * swipeCompression
                scaleY = artworkScale * swipeCompression
                translationX = animArtSwipeX
                rotationY = (animArtSwipeX / 150f) * 10f
                rotationZ = artworkRotationProvider()
                cameraDistance = 12f * density
              }
              .border(1.5.dp, inkColor.copy(alpha = 0.24f), artworkShape)
              .clip(artworkShape)
              .pointerInput(song.id, personalization.swipeArtworkToSkip) {
                if (!personalization.swipeArtworkToSkip) return@pointerInput
                detectHorizontalDragGestures(
                  onDragEnd = onSwipeXEnd,
                  onDragCancel = onSwipeXCancel,
                  onHorizontalDrag = { change, dragAmount ->
                    change.consume()
                    onSwipeXDelta(dragAmount)
                  },
                )
              }
              .clickable(enabled = personalization.tapArtworkForLyrics, onClick = onToggleLyrics)
              .testTag("player_peanut_artwork"),
          ) {
            Crossfade(
              targetState = song.coverUrl,
              animationSpec = tween(380),
              label = "player_cover_crossfade",
            ) { url ->
              ArtworkImage(
                imageUrl = url,
                contentDescription = song.title,
                shape = artworkShape,
                sizePx = 800,
                modifier = Modifier.fillMaxSize(),
              )
            }
          }
        }

        if (showUnlockButton) {
          Spacer(Modifier.height(if (isCompactHeight) 6.dp else 10.dp))
          FilledTonalButton(
            onClick = onPurchaseSong,
            shape = CircleShape,
          ) {
            RhythmSymbolIcon(
              icon = RhythmIcons.LockOpen,
              contentDescription = null,
              size = 16.dp,
              modifier = Modifier.size(16.dp),
            )
            Spacer(Modifier.width(6.dp))
            Text(
              text = "Mở khóa bản đầy đủ • ${song.priceText ?: "Trả phí"}",
              style = MaterialTheme.typography.labelLarge,
            )
          }
        }
      }
    } else {
      SyncedLyricsPanel(
        song = song,
        positionMs = positionMs,
        accentColor = primaryAccent,
        inkColor = inkColor,
        personalization = personalization,
        onSeekTo = onSeekTo,
      )
    }
  }
}

@Composable
private fun androidx.compose.foundation.layout.BoxScope.PlayerOverlayBadges(
  inkColor: Color,
  onDismiss: () -> Unit,
) {
  // Subtle Rhythm sheet handle / collapse trigger overlaid inside top of artwork Box (0dp wasted height)
  Box(
    modifier = Modifier
      .align(Alignment.TopCenter)
      .minimumInteractiveComponentSize()
      .clickable(onClick = onDismiss)
      .padding(top = 4.dp)
      .testTag("player_collapse_button"),
    contentAlignment = Alignment.TopCenter,
  ) {
    Surface(
      shape = CircleShape,
      color = inkColor.copy(alpha = 0.28f),
      modifier = Modifier.size(width = 36.dp, height = 4.dp),
    ) {}
  }
}

@Composable
private fun PlayerTitleAndArtistBlock(
  song: Song,
  trackDirection: Int,
  titleEntrance: Float,
  isCompactHeight: Boolean,
  canvasColor: Color,
  inkColor: Color,
  mutedInkColor: Color,
  onOpenArtist: (String) -> Unit,
) {
  AnimatedContent(
    targetState = song,
    transitionSpec = {
      (slideInHorizontally(tween(420, easing = FastOutSlowInEasing)) { w -> trackDirection * (w / 2) } +
        fadeIn(tween(300))) togetherWith
        (slideOutHorizontally(tween(240, easing = FastOutSlowInEasing)) { w -> -trackDirection * (w / 2) } +
          fadeOut(tween(180)))
    },
    modifier = Modifier
      .fillMaxWidth()
      .graphicsLayer {
        translationY = (1f - titleEntrance) * 26.dp.toPx()
      },
    label = "player_title_artist_transition",
  ) { displaySong ->
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 8.dp),
      horizontalAlignment = Alignment.CenterHorizontally,
    ) {
      AutoScrollingTextOnDemand(
        text = displaySong.title,
        gradientEdgeColor = canvasColor,
        style = MaterialTheme.typography.headlineSmall.copy(
          fontWeight = FontWeight.Bold,
          fontSize = if (isCompactHeight) 21.sp else 24.sp,
          letterSpacing = (-0.6).sp,
          color = inkColor,
        ),
        textAlign = TextAlign.Center,
      )
      Spacer(Modifier.height(3.dp))
      AutoScrollingTextOnDemand(
        text = displaySong.artistName,
        gradientEdgeColor = canvasColor,
        style = MaterialTheme.typography.titleMedium.copy(
          fontWeight = FontWeight.Medium,
          fontSize = if (isCompactHeight) 14.sp else 16.sp,
          letterSpacing = (-0.2).sp,
          color = mutedInkColor,
        ),
        textAlign = TextAlign.Center,
        modifier = Modifier.clickable {
          displaySong.artistId?.takeIf { it.isNotBlank() }?.let(onOpenArtist)
        },
      )
    }
  }
}

@Composable
private fun PlayerTransportControls(
  playbackState: PlaybackUiState,
  safeDuration: Long,
  isCompactHeight: Boolean,
  controlHeight: Dp,
  controlSpacing: Dp,
  controlsEntrance: Float,
  useWavySeekbar: Boolean,
  primaryAccent: Color,
  onPrimaryAccent: Color,
  softPillColor: Color,
  inkColor: Color,
  mutedInkColor: Color,
  onTogglePlayPause: () -> Unit,
  onSkipNext: () -> Unit,
  onSkipPrevious: () -> Unit,
  onSeekTo: (Long) -> Unit,
) {
  val skipIconSize = if (isCompactHeight) 24.dp else 28.dp
  Column(
    modifier = Modifier
      .fillMaxWidth()
      .graphicsLayer {
        translationY = (1f - controlsEntrance) * 24.dp.toPx()
      },
  ) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.spacedBy(14.dp),
      verticalAlignment = Alignment.CenterVertically,
    ) {
      RhythmExpressiveCapsulePlayButton(
        isPlaying = playbackState.isPlaying,
        onClick = onTogglePlayPause,
        height = controlHeight,
        showBuffering = playbackState.isBuffering,
        containerColor = primaryAccent,
        contentColor = onPrimaryAccent,
        modifier = Modifier
          .weight(1f)
          .testTag("player_play_pause_button"),
      )

      RhythmScallopedPolygonButton(
        onClick = onSkipNext,
        size = controlHeight,
        lobes = 10,
        containerColor = softPillColor,
        contentColor = inkColor,
        modifier = Modifier.testTag("player_next_button"),
      ) {
        RhythmSymbolIcon(
          icon = RhythmIcons.Player.SkipNext,
          contentDescription = "Bài tiếp theo",
          tint = inkColor,
          size = skipIconSize,
          modifier = Modifier.size(skipIconSize),
        )
      }
    }

    Spacer(Modifier.height(controlSpacing))

    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.spacedBy(14.dp),
      verticalAlignment = Alignment.CenterVertically,
    ) {
      RhythmScallopedPolygonButton(
        onClick = onSkipPrevious,
        size = controlHeight,
        lobes = 10,
        containerColor = softPillColor,
        contentColor = inkColor,
        modifier = Modifier.testTag("player_prev_button"),
      ) {
        RhythmSymbolIcon(
          icon = RhythmIcons.Player.SkipPrevious,
          contentDescription = "Bài trước",
          tint = inkColor,
          size = skipIconSize,
          modifier = Modifier.size(skipIconSize),
        )
      }

      Column(modifier = Modifier.weight(1f)) {
        if (useWavySeekbar) {
          RhythmWavySlider(
            valueMs = playbackState.positionMs,
            durationMs = safeDuration,
            isPlaying = playbackState.isPlaying,
            onSeekTo = onSeekTo,
            activeColor = primaryAccent,
            inactiveColor = softPillColor,
          )
        } else {
          val fraction = if (safeDuration > 0L) {
            (playbackState.positionMs.toFloat() / safeDuration.toFloat()).coerceIn(0f, 1f)
          } else {
            0f
          }
          Slider(
            value = fraction,
            onValueChange = { next -> onSeekTo((next * safeDuration).toLong()) },
            enabled = safeDuration > 0L,
            colors = SliderDefaults.colors(
              thumbColor = primaryAccent,
              activeTrackColor = primaryAccent,
              inactiveTrackColor = softPillColor,
            ),
            modifier = Modifier.fillMaxWidth(),
          )
        }
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 2.dp),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Text(
            text = FormatUtils.formatDurationMs(playbackState.positionMs),
            style = MonoNumericStyle,
            color = mutedInkColor,
          )
          Text(
            text = FormatUtils.formatDurationMs(safeDuration),
            style = MonoNumericStyle,
            color = mutedInkColor,
          )
        }
      }
    }
  }
}

@Composable
private fun PlayerBottomSegmentedDock(
  dockHeight: Dp,
  dockEntrance: Float,
  showLyrics: Boolean,
  isFavorite: Boolean,
  sleepTimerActive: Boolean,
  sleepTimerBadgeText: String?,
  activeModal: PlayerSheetModal,
  softPillColor: Color,
  primaryAccent: Color,
  inkColor: Color,
  onPrimaryAccent: Color,
  onToggleLyrics: () -> Unit,
  onToggleFavorite: () -> Unit,
  onOpenSleepTimer: () -> Unit,
  onOpenQueue: () -> Unit,
  onOpenMore: () -> Unit,
) {
  RhythmSegmentedDockRow(
    modifier = Modifier.graphicsLayer {
      translationY = (1f - dockEntrance) * 20.dp.toPx()
    },
  ) {
    RhythmSegmentedDockButton(
      icon = RhythmIcons.Player.Lyrics,
      contentDescription = "Lời bài hát",
      isFirst = true,
      isLast = false,
      selected = showLyrics,
      containerColor = softPillColor,
      selectedContainerColor = primaryAccent,
      contentColor = inkColor,
      selectedContentColor = onPrimaryAccent,
      height = dockHeight,
      onClick = onToggleLyrics,
      modifier = Modifier.testTag("player_lyrics_toggle"),
    )
    RhythmSegmentedDockButton(
      icon = if (isFavorite) RhythmIcons.ThumbUpFilled else RhythmIcons.ThumbUp,
      contentDescription = "Yêu thích",
      isFirst = false,
      isLast = false,
      selected = isFavorite,
      containerColor = softPillColor,
      selectedContainerColor = primaryAccent,
      contentColor = inkColor,
      selectedContentColor = onPrimaryAccent,
      height = dockHeight,
      onClick = onToggleFavorite,
      modifier = Modifier.testTag("player_favorite_toggle"),
    )
    RhythmSegmentedDockButton(
      icon = RhythmIcons.Player.SleepTimer,
      contentDescription = "Hẹn giờ tắt nhạc",
      badgeText = sleepTimerBadgeText,
      isFirst = false,
      isLast = false,
      selected = sleepTimerActive || activeModal == PlayerSheetModal.SLEEP_TIMER,
      containerColor = softPillColor,
      selectedContainerColor = primaryAccent,
      contentColor = inkColor,
      selectedContentColor = onPrimaryAccent,
      height = dockHeight,
      onClick = onOpenSleepTimer,
      modifier = Modifier.testTag("player_sleep_timer_button"),
    )
    RhythmSegmentedDockButton(
      icon = RhythmIcons.Queue,
      contentDescription = "Danh sách chờ",
      isFirst = false,
      isLast = false,
      selected = activeModal == PlayerSheetModal.QUEUE,
      containerColor = softPillColor,
      selectedContainerColor = primaryAccent,
      contentColor = inkColor,
      selectedContentColor = onPrimaryAccent,
      height = dockHeight,
      onClick = onOpenQueue,
      modifier = Modifier.testTag("player_queue_button"),
    )
    RhythmSegmentedDockButton(
      icon = RhythmIcons.More,
      contentDescription = "Thêm tùy chọn",
      isFirst = false,
      isLast = true,
      selected = activeModal == PlayerSheetModal.MORE,
      containerColor = softPillColor,
      selectedContainerColor = primaryAccent,
      contentColor = inkColor,
      selectedContentColor = onPrimaryAccent,
      height = dockHeight,
      onClick = onOpenMore,
      modifier = Modifier.testTag("player_more_button"),
    )
  }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun PlayerMoreActionsSheetContent(
  song: Song,
  shuffleEnabled: Boolean,
  repeatMode: RepeatModeState,
  playbackSpeed: Float,
  onToggleShuffle: () -> Unit,
  onCycleRepeat: () -> Unit,
  onSetPlaybackSpeed: (Float) -> Unit,
  onOpenEqualizer: () -> Unit,
  onDownload: () -> Unit,
  onAddToPlaylist: () -> Unit,
  onShowInfo: () -> Unit,
  onShareSong: () -> Unit,
  onOpenArtist: () -> Unit,
  onOpenAlbum: () -> Unit,
  onReportSong: () -> Unit,
  onBlockSong: () -> Unit,
) {
  Column(
    modifier = Modifier
      .fillMaxWidth()
      .heightIn(max = 560.dp)
      .verticalScroll(rememberScrollState())
      .padding(horizontal = 16.dp)
      .padding(bottom = 28.dp),
    verticalArrangement = Arrangement.spacedBy(8.dp),
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 4.dp, vertical = 4.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
      ArtworkImage(
        imageUrl = song.coverUrl,
        contentDescription = song.title,
        shape = RoundedCornerShape(14.dp),
        modifier = Modifier.size(52.dp),
      )
      Column(modifier = Modifier.weight(1f)) {
        Text(
          text = song.title,
          style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
          maxLines = 1,
          overflow = TextOverflow.Ellipsis,
        )
        Text(
          text = song.artistName,
          style = MaterialTheme.typography.bodySmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis,
        )
      }
    }

    val repeatLabel = when (repeatMode) {
      RepeatModeState.OFF -> "Đang tắt"
      RepeatModeState.ALL -> "Lặp tất cả"
      RepeatModeState.ONE -> "Lặp 1 bài"
    }
    val speedLabel = String.format(Locale.US, "%.2fx", playbackSpeed).replace(".00x", ".0x")

    val itemsList = buildList {
      add(
        Material3SettingsItem(
          icon = RhythmIcons.Shuffle,
          title = "Phát ngẫu nhiên",
          subtitle = if (shuffleEnabled) "Đang bật trộn bài" else "Phát theo thứ tự",
          palette = SettingsPalettes.Purple,
          switchChecked = shuffleEnabled,
          onSwitchChange = { onToggleShuffle() },
          testTag = "player_shuffle_button",
        ),
      )
      add(
        Material3SettingsItem(
          icon = if (repeatMode == RepeatModeState.ONE) RhythmIcons.RepeatOne else RhythmIcons.Repeat,
          title = "Chế độ lặp lại",
          subtitle = "Chạm để chuyển chế độ",
          palette = SettingsPalettes.Indigo,
          trailingText = repeatLabel,
          onClick = onCycleRepeat,
          testTag = "player_repeat_button",
        ),
      )
      add(
        Material3SettingsItem(
          icon = RhythmIcons.Speed,
          title = "Tốc độ phát nhanh",
          subtitle = "Chạm chọn nhịp phát tức thì",
          palette = SettingsPalettes.SkyBlue,
          trailingText = speedLabel,
          customContent = {
            FlowRow(
              horizontalArrangement = Arrangement.spacedBy(8.dp),
              verticalArrangement = Arrangement.spacedBy(4.dp),
            ) {
              listOf(0.75f, 1.0f, 1.25f, 1.5f).forEach { spd ->
                val chipText = if (spd == 1.0f) "1.0x" else "${spd}x"
                FilterChip(
                  selected = abs(playbackSpeed - spd) < 0.03f,
                  onClick = { onSetPlaybackSpeed(spd) },
                  label = { Text(chipText, style = MonoNumericStyle) },
                  shape = CircleShape,
                )
              }
            }
          },
        ),
      )
      add(
        Material3SettingsItem(
          icon = RhythmIcons.Equalizer,
          title = "Bộ chỉnh âm (Equalizer)",
          subtitle = "Bass Boost, Virtualizer & 5 dải tần",
          palette = SettingsPalettes.Teal,
          showChevron = true,
          onClick = onOpenEqualizer,
          testTag = "player_equalizer_button",
        ),
      )
      add(
        Material3SettingsItem(
          icon = RhythmIcons.Download,
          title = "Tải bài hát",
          subtitle = "Lưu file âm thanh về thư mục Downloads",
          palette = SettingsPalettes.Emerald,
          onClick = onDownload,
          testTag = "player_download_button",
        ),
      )
      add(
        Material3SettingsItem(
          icon = RhythmIcons.AddToPlaylist,
          title = "Thêm vào playlist",
          subtitle = "Lưu vào danh sách phát cá nhân",
          palette = SettingsPalettes.SkyBlue,
          onClick = onAddToPlaylist,
          testTag = "player_add_playlist_button",
        ),
      )
      add(
        Material3SettingsItem(
          icon = RhythmIcons.Actions.Info,
          title = "Thông tin bài hát",
          subtitle = "Chi tiết album, thể loại, lượt nghe",
          palette = SettingsPalettes.Slate,
          onClick = onShowInfo,
          testTag = "player_song_info_button",
        ),
      )
      add(
        Material3SettingsItem(
          icon = RhythmIcons.Actions.Share,
          title = "Chia sẻ bài hát",
          subtitle = "Gửi tên ca khúc qua ứng dụng khác",
          palette = SettingsPalettes.Cyan,
          onClick = onShareSong,
          testTag = "player_share_button",
        ),
      )
      if (!song.artistId.isNullOrBlank()) {
        add(
          Material3SettingsItem(
            icon = RhythmIcons.ArtistFilled,
            title = "Xem nghệ sĩ",
            subtitle = song.artistName,
            palette = SettingsPalettes.Amber,
            showChevron = true,
            onClick = onOpenArtist,
          ),
        )
      }
      if (!song.albumId.isNullOrBlank()) {
        add(
          Material3SettingsItem(
            icon = RhythmIcons.AlbumFilled,
            title = "Xem album",
            subtitle = song.albumTitle ?: "Album",
            palette = SettingsPalettes.Orange,
            showChevron = true,
            onClick = onOpenAlbum,
          ),
        )
      }
      add(
        Material3SettingsItem(
          icon = RhythmIcons.Flag,
          title = "Báo cáo bài hát",
          subtitle = "Gửi phản hồi lỗi âm thanh hoặc bản quyền",
          palette = SettingsPalettes.Rose,
          onClick = onReportSong,
          testTag = "player_report_button",
        ),
      )
      add(
        Material3SettingsItem(
          icon = RhythmIcons.Block,
          title = "Chặn bài hát này",
          subtitle = "Ẩn khỏi trang chủ, BXH và danh sách tìm kiếm",
          palette = SettingsPalettes.Coral,
          onClick = onBlockSong,
          testTag = "player_block_button",
        ),
      )
    }

    Material3SettingsGroup(items = itemsList)
  }
}

@Composable
private fun SyncedLyricsPanel(
  song: Song,
  positionMs: Long,
  accentColor: Color,
  inkColor: Color,
  personalization: PersonalizationSettings,
  onSeekTo: (Long) -> Unit,
) {
  val parsed = remember(song.id, song.lyrics) { LyricsUtils.parse(song.lyrics) }
  val listState = rememberLazyListState()
  val scope = rememberCoroutineScope()

  val activeIndex = if (parsed.isSynced) {
    LyricsUtils.findActiveIndex(parsed.syncedLines, positionMs)
  } else {
    -1
  }

  val isActiveVisible by remember(activeIndex) {
    derivedStateOf {
      if (activeIndex < 0) return@derivedStateOf true
      val visible = listState.layoutInfo.visibleItemsInfo
      if (visible.isEmpty()) true else visible.any { it.index == activeIndex }
    }
  }

  LaunchedEffect(activeIndex, personalization.lyricsAutoScroll) {
    if (personalization.lyricsAutoScroll && activeIndex >= 0) {
      listState.animateScrollToItem((activeIndex - 2).coerceAtLeast(0))
    }
  }

  val align = when (personalization.lyricsAlignment) {
    LyricsAlignment.START -> TextAlign.Start
    LyricsAlignment.CENTER -> TextAlign.Center
    LyricsAlignment.END -> TextAlign.End
  }
  val lyricsScale = personalization.lyricsFontSize.scale
  val inactiveAlpha = if (personalization.lyricsDimInactive) 0.44f else 0.84f

  Surface(
    modifier = Modifier.fillMaxSize(),
    shape = RoundedCornerShape(32.dp),
    color = accentColor.copy(alpha = 0.12f),
  ) {
    when {
      parsed.isEmpty -> {
        Box(
          modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
          contentAlignment = Alignment.Center,
        ) {
          Text(
            text = "Chưa có lời bài hát cho ca khúc này.",
            style = MaterialTheme.typography.titleMedium,
            color = inkColor.copy(alpha = 0.72f),
            textAlign = TextAlign.Center,
          )
        }
      }
      parsed.isSynced -> {
        Box(modifier = Modifier.fillMaxSize()) {
          LazyColumn(
            state = listState,
            contentPadding = PaddingValues(horizontal = 22.dp, vertical = 28.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.fillMaxSize(),
          ) {
            itemsIndexed(parsed.syncedLines) { index, line ->
              val isActive = index == activeIndex
              val lineColor by animateColorAsState(
                targetValue = if (isActive) accentColor else inkColor.copy(alpha = inactiveAlpha),
                animationSpec = tween(durationMillis = 240),
                label = "lyric_line_color",
              )
              val lineBg by animateColorAsState(
                targetValue = if (isActive) accentColor.copy(alpha = 0.14f) else Color.Transparent,
                animationSpec = tween(durationMillis = 240),
                label = "lyric_line_bg",
              )
              val lineScale by animateFloatAsState(
                targetValue = if (isActive) 1.03f else 0.97f,
                animationSpec = spring(
                  dampingRatio = Spring.DampingRatioMediumBouncy,
                  stiffness = Spring.StiffnessMediumLow,
                ),
                label = "lyric_line_scale",
              )
              val baseStyle = if (isActive) {
                MaterialTheme.typography.headlineSmall.copy(
                  fontWeight = FontWeight.Bold,
                  fontSize = (24f * lyricsScale).sp,
                  lineHeight = (32f * lyricsScale).sp,
                )
              } else {
                MaterialTheme.typography.titleLarge.copy(
                  fontWeight = FontWeight.Medium,
                  fontSize = (20f * lyricsScale).sp,
                  lineHeight = (28f * lyricsScale).sp,
                )
              }
              Text(
                text = line.text,
                style = baseStyle,
                textAlign = align,
                color = lineColor,
                modifier = Modifier
                  .fillMaxWidth()
                  .graphicsLayer {
                    scaleX = lineScale
                    scaleY = lineScale
                  }
                  .clip(RoundedCornerShape(14.dp))
                  .background(lineBg)
                  .clickable(enabled = personalization.lyricsTapToSeek) { onSeekTo(line.timeMs) }
                  .padding(horizontal = 10.dp, vertical = 6.dp),
              )
            }
          }

          AnimatedVisibility(
            visible = activeIndex >= 0 && !isActiveVisible,
            enter = fadeIn() + scaleIn(initialScale = 0.85f),
            exit = fadeOut() + scaleOut(targetScale = 0.85f),
            modifier = Modifier
              .align(Alignment.BottomCenter)
              .padding(bottom = 12.dp),
          ) {
            FilledTonalButton(
              onClick = {
                scope.launch {
                  listState.animateScrollToItem((activeIndex - 2).coerceAtLeast(0))
                }
              },
              shape = CircleShape,
              modifier = Modifier.testTag("lyrics_jump_active_button"),
            ) {
              RhythmSymbolIcon(
                icon = RhythmIcons.Player.Lyrics,
                contentDescription = null,
                size = 16.dp,
                modifier = Modifier.size(16.dp),
              )
              Spacer(Modifier.width(6.dp))
              Text("Về câu đang hát")
            }
          }
        }
      }
      else -> {
        LazyColumn(
          contentPadding = PaddingValues(horizontal = 22.dp, vertical = 24.dp),
          verticalArrangement = Arrangement.spacedBy(10.dp),
          modifier = Modifier.fillMaxSize(),
        ) {
          itemsIndexed(parsed.plainLines) { _, line ->
            Text(
              text = line,
              style = MaterialTheme.typography.titleMedium.copy(
                fontSize = (16f * lyricsScale).sp,
                lineHeight = (24f * lyricsScale).sp,
              ),
              textAlign = align,
              color = inkColor,
              modifier = Modifier.fillMaxWidth(),
            )
          }
        }
      }
    }
  }
}

@Composable
private fun QueueModalContent(
  queue: List<Song>,
  currentIndex: Int,
  currentSongId: String,
  isPlaying: Boolean,
  favoriteIds: Set<String>,
  purchasedIds: Set<String>,
  onSelectSong: (Song) -> Unit,
  onToggleFavorite: (Song) -> Unit,
  onRemoveQueueItem: (Int) -> Unit,
  onMoveQueueItem: (Int, Int) -> Unit,
  onShuffleUpcomingQueue: () -> Unit,
  onClearUpcomingQueue: () -> Unit,
) {
  val hasUpcoming = queue.size > (currentIndex + 1).coerceAtLeast(1)

  Column(
    modifier = Modifier
      .fillMaxWidth()
      .heightIn(max = 500.dp)
      .padding(bottom = 24.dp),
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 20.dp, vertical = 8.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween,
    ) {
      Text(
        text = "Danh sách phát (${queue.size})",
        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
        modifier = Modifier.weight(1f),
      )
      if (hasUpcoming) {
        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
          TextButton(
            onClick = onShuffleUpcomingQueue,
            modifier = Modifier.testTag("queue_shuffle_upcoming_button"),
          ) {
            RhythmSymbolIcon(
              icon = RhythmIcons.Shuffle,
              contentDescription = null,
              size = 16.dp,
              modifier = Modifier.size(16.dp),
            )
            Spacer(Modifier.width(4.dp))
            Text("Trộn")
          }
          TextButton(
            onClick = onClearUpcomingQueue,
            modifier = Modifier.testTag("queue_clear_upcoming_button"),
          ) {
            RhythmSymbolIcon(
              icon = RhythmIcons.Delete,
              contentDescription = null,
              size = 16.dp,
              modifier = Modifier.size(16.dp),
            )
            Spacer(Modifier.width(4.dp))
            Text("Xóa tiếp")
          }
        }
      }
    }

    LazyColumn(
      contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
      verticalArrangement = Arrangement.spacedBy(4.dp),
    ) {
      itemsIndexed(queue, key = { idx, item -> "${item.id}_$idx" }) { idx, item ->
        val isUpcoming = idx != currentIndex
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .animateItem(),
          verticalAlignment = Alignment.CenterVertically,
        ) {
          SongRowItem(
            song = item,
            rankIndex = idx + 1,
            isCurrentSong = item.id == currentSongId && idx == currentIndex,
            isPlaying = isPlaying && item.id == currentSongId && idx == currentIndex,
            isFavorite = item.id in favoriteIds,
            isPurchased = item.id in purchasedIds || !item.isPaid,
            onClick = { onSelectSong(item) },
            onToggleFavorite = { onToggleFavorite(item) },
            modifier = Modifier.weight(1f),
          )
          if (isUpcoming) {
            if (idx > 0 && idx - 1 != currentIndex) {
              IconButton(
                onClick = { onMoveQueueItem(idx, idx - 1) },
                modifier = Modifier
                  .size(34.dp)
                  .testTag("queue_move_up_$idx"),
              ) {
                RhythmSymbolIcon(
                  icon = RhythmIcons.Navigation.ArrowUpward,
                  contentDescription = "Đưa lên",
                  size = 16.dp,
                  modifier = Modifier.size(16.dp),
                )
              }
            }
            if (idx < queue.lastIndex && idx + 1 != currentIndex) {
              IconButton(
                onClick = { onMoveQueueItem(idx, idx + 1) },
                modifier = Modifier
                  .size(34.dp)
                  .testTag("queue_move_down_$idx"),
              ) {
                RhythmSymbolIcon(
                  icon = RhythmIcons.Navigation.ArrowDownward,
                  contentDescription = "Đưa xuống",
                  size = 16.dp,
                  modifier = Modifier.size(16.dp),
                )
              }
            }
            IconButton(
              onClick = { onRemoveQueueItem(idx) },
              modifier = Modifier
                .size(34.dp)
                .testTag("queue_remove_$idx"),
            ) {
              RhythmSymbolIcon(
                icon = RhythmIcons.Close,
                contentDescription = "Xóa khỏi hàng đợi",
                size = 16.dp,
                modifier = Modifier.size(16.dp),
              )
            }
          }
        }
      }
    }
  }
}
