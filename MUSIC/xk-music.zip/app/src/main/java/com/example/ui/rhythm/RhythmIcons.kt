package com.example.ui.rhythm

/**
 * Authentic Rhythm icon registry powered by `res/font/material_symbols_outlined.ttf`
 * OpenType ligatures + variable FILL/wght/GRAD/opsz axes.
 */
object RhythmIcons {

  object Player {
    val Play = MaterialSymbolIcon("play_arrow", filled = true)
    val PlayCircle = MaterialSymbolIcon("play_circle", filled = true)
    val Pause = MaterialSymbolIcon("pause", filled = true)
    val PauseCircle = MaterialSymbolIcon("pause_circle", filled = true)
    val SkipNext = MaterialSymbolIcon("skip_next", filled = true)
    val SkipPrevious = MaterialSymbolIcon("skip_previous", filled = true)
    val Replay10 = MaterialSymbolIcon("replay_10")
    val Forward10 = MaterialSymbolIcon("forward_10")
    val Shuffle = MaterialSymbolIcon("shuffle")
    val Repeat = MaterialSymbolIcon("repeat")
    val RepeatOne = MaterialSymbolIcon("repeat_one")
    val VolumeUp = MaterialSymbolIcon("volume_up", filled = true)
    val VolumeDown = MaterialSymbolIcon("volume_down", filled = true)
    val VolumeMute = MaterialSymbolIcon("volume_mute", filled = true)
    val VolumeOff = MaterialSymbolIcon("volume_off", filled = true)
    val Queue = MaterialSymbolIcon("queue_music")
    val Equalizer = MaterialSymbolIcon("equalizer")
    val Lyrics = MaterialSymbolIcon("lyrics", filled = true)
    val LyricsOutlined = MaterialSymbolIcon("lyrics", filled = false)
    val Speed = MaterialSymbolIcon("speed")
    val Timer = MaterialSymbolIcon("timer")
    val SleepTimer = MaterialSymbolIcon("bedtime", filled = true)
    val Stop = MaterialSymbolIcon("stop", filled = true)
    val GraphicEq = MaterialSymbolIcon("graphic_eq")
  }

  object Navigation {
    val Home = MaterialSymbolIcon("home", filled = true, defaultWeight = 500)
    val HomeOutlined = MaterialSymbolIcon("home", filled = false, defaultWeight = 500)
    val Search = MaterialSymbolIcon("search", filled = true, defaultWeight = 500)
    val SearchOutlined = MaterialSymbolIcon("search", filled = false, defaultWeight = 500)
    val Library = MaterialSymbolIcon("library_music", filled = true, defaultWeight = 500)
    val LibraryOutlined = MaterialSymbolIcon("library_music", filled = false, defaultWeight = 500)
    val Settings = MaterialSymbolIcon("settings", filled = true, defaultWeight = 500)
    val SettingsOutlined = MaterialSymbolIcon("settings", filled = false, defaultWeight = 500)
    val Back = MaterialSymbolIcon("arrow_back", defaultWeight = 500)
    val Forward = MaterialSymbolIcon("arrow_forward", defaultWeight = 500)
    val ChevronRight = MaterialSymbolIcon("chevron_right", defaultWeight = 500)
    val Close = MaterialSymbolIcon("close", defaultWeight = 500)
    val ExpandMore = MaterialSymbolIcon("expand_more", defaultWeight = 500)
    val ExpandLess = MaterialSymbolIcon("expand_less", defaultWeight = 500)
    val ArrowDropDown = MaterialSymbolIcon("arrow_drop_down", defaultWeight = 500)
    val KeyboardArrowDown = MaterialSymbolIcon("keyboard_arrow_down", defaultWeight = 500)
    val KeyboardArrowUp = MaterialSymbolIcon("keyboard_arrow_up", defaultWeight = 500)
    val ArrowUpward = MaterialSymbolIcon("arrow_upward", defaultWeight = 500)
    val ArrowDownward = MaterialSymbolIcon("arrow_downward", defaultWeight = 500)
  }

  object Music {
    val Song = MaterialSymbolIcon("music_note", filled = true)
    val SongOutlined = MaterialSymbolIcon("music_note")
    val Album = MaterialSymbolIcon("album", filled = true)
    val AlbumOutlined = MaterialSymbolIcon("album")
    val Artist = MaterialSymbolIcon("person", filled = true)
    val ArtistOutlined = MaterialSymbolIcon("person")
    val Playlist = MaterialSymbolIcon("playlist_play")
    val PlaylistOutlined = MaterialSymbolIcon("playlist_play")
    val MusicNote = MaterialSymbolIcon("music_note")
    val Audiotrack = MaterialSymbolIcon("audio_file")
    val MusicOff = MaterialSymbolIcon("music_off")
  }

  object Actions {
    val Favorite = MaterialSymbolIcon("favorite", filled = true)
    val FavoriteOutlined = MaterialSymbolIcon("favorite")
    val ThumbUp = MaterialSymbolIcon("thumb_up", filled = true)
    val ThumbUpOutlined = MaterialSymbolIcon("thumb_up", filled = false)
    val Add = MaterialSymbolIcon("add")
    val Remove = MaterialSymbolIcon("remove")
    val Edit = MaterialSymbolIcon("edit")
    val Delete = MaterialSymbolIcon("delete")
    val Check = MaterialSymbolIcon("check")
    val More = MaterialSymbolIcon("more_vert")
    val List = MaterialSymbolIcon("list")
    val Apps = MaterialSymbolIcon("apps")
    val Refresh = MaterialSymbolIcon("refresh")
    val Download = MaterialSymbolIcon("download")
    val Tune = MaterialSymbolIcon("tune")
    val Sort = MaterialSymbolIcon("sort")
    val Update = MaterialSymbolIcon("update")
    val Info = MaterialSymbolIcon("info")
    val Pushpin = MaterialSymbolIcon("push_pin", filled = true)
    val PinOutline = MaterialSymbolIcon("push_pin")
    val ArrowUpward = MaterialSymbolIcon("arrow_upward")
    val Share = MaterialSymbolIcon("share")
    val ContentCopy = MaterialSymbolIcon("content_copy")
    val FilterList = MaterialSymbolIcon("filter_list")
    val SelectAll = MaterialSymbolIcon("select_all")
    val Block = MaterialSymbolIcon("block")
    val SwapVert = MaterialSymbolIcon("swap_vert")
    val DragHandle = MaterialSymbolIcon("drag_handle")
    val Restore = MaterialSymbolIcon("restore")
    val Flag = MaterialSymbolIcon("flag", filled = true)
    val Lock = MaterialSymbolIcon("lock", filled = true)
    val LockOpen = MaterialSymbolIcon("lock_open", filled = true)
    val PlaylistAdd = MaterialSymbolIcon("playlist_add")
    val ShoppingBag = MaterialSymbolIcon("shopping_bag", filled = true)
  }

  object Devices {
    val Bluetooth = MaterialSymbolIcon("bluetooth", filled = true)
    val BluetoothOutlined = MaterialSymbolIcon("bluetooth")
    val Headphones = MaterialSymbolIcon("headphones", filled = true)
    val HeadphonesOutlined = MaterialSymbolIcon("headphones")
    val Speaker = MaterialSymbolIcon("speaker", filled = true)
    val SpeakerOutlined = MaterialSymbolIcon("speaker")
    val Cast = MaterialSymbolIcon("cast")
    val CastConnected = MaterialSymbolIcon("cast_connected")
    val Location = MaterialSymbolIcon("place", filled = true)
    val LocationOutlined = MaterialSymbolIcon("place")
  }

  object System {
    val Warning = MaterialSymbolIcon("warning", filled = true)
    val BugReport = MaterialSymbolIcon("bug_report", filled = true)
    val Security = MaterialSymbolIcon("security", filled = true)
    val AccessTime = MaterialSymbolIcon("schedule", filled = true)
    val History = MaterialSymbolIcon("history")
    val Notifications = MaterialSymbolIcon("notifications")
    val NotificationsOff = MaterialSymbolIcon("notifications_off")
    val Visibility = MaterialSymbolIcon("visibility")
    val VisibilityOff = MaterialSymbolIcon("visibility_off")
    val DarkMode = MaterialSymbolIcon("dark_mode", filled = true)
    val LightMode = MaterialSymbolIcon("light_mode", filled = true)
    val Contrast = MaterialSymbolIcon("contrast", filled = true)
    val Language = MaterialSymbolIcon("language")
    val Public = MaterialSymbolIcon("public", filled = true)
    val Code = MaterialSymbolIcon("code")
    val ExitToApp = MaterialSymbolIcon("exit_to_app")
    val Login = MaterialSymbolIcon("login")
    val Logout = MaterialSymbolIcon("logout")
    val AccountCircle = MaterialSymbolIcon("account_circle", filled = true)
    val AccountCircleOutlined = MaterialSymbolIcon("account_circle", filled = false)
    val PersonAdd = MaterialSymbolIcon("person_add", filled = true)
    val AccountBalanceWallet = MaterialSymbolIcon("account_balance_wallet", filled = true)
    val Storage = MaterialSymbolIcon("storage")
    val CloudUpload = MaterialSymbolIcon("cloud_upload")
    val CloudDownload = MaterialSymbolIcon("cloud_download")
  }

  object Content {
    val Palette = MaterialSymbolIcon("palette", filled = true)
    val ColorLens = MaterialSymbolIcon("color_lens", filled = true)
    val WavingHand = MaterialSymbolIcon("waving_hand", filled = true)
    val GridView = MaterialSymbolIcon("grid_view", filled = true)
    val FormatListNumbered = MaterialSymbolIcon("format_list_numbered", filled = true)
    val SortByAlpha = MaterialSymbolIcon("sort_by_alpha", filled = true)
    val Folder = MaterialSymbolIcon("folder", filled = true)
    val FolderOpen = MaterialSymbolIcon("folder_open")
    val InsertDriveFile = MaterialSymbolIcon("description")
    val Image = MaterialSymbolIcon("image")
    val Category = MaterialSymbolIcon("category")
    val DateRange = MaterialSymbolIcon("date_range")
    val AutoAwesome = MaterialSymbolIcon("auto_awesome")
    val TrendingUp = MaterialSymbolIcon("trending_up")
    val BarChart = MaterialSymbolIcon("bar_chart")
    val Leaderboard = MaterialSymbolIcon("leaderboard", filled = true)
    val LeaderboardOutlined = MaterialSymbolIcon("leaderboard", filled = false)
    val CalendarMonth = MaterialSymbolIcon("calendar_month")
  }

  object Toggle {
    val CheckCircle = MaterialSymbolIcon("check_circle", filled = true)
    val RadioButtonChecked = MaterialSymbolIcon("radio_button_checked")
    val RadioButtonUnchecked = MaterialSymbolIcon("radio_button_unchecked")
  }

  // Flat compatibility aliases matching Rhythm's RhythmIcons.*
  val Play = Player.Play
  val PlayCircle = Player.PlayCircle
  val Pause = Player.Pause
  val SkipNext = Player.SkipNext
  val SkipPrevious = Player.SkipPrevious
  val Shuffle = Player.Shuffle
  val Repeat = Player.Repeat
  val RepeatOne = Player.RepeatOne
  val Stop = Player.Stop
  val GraphicEq = Player.GraphicEq
  val Equalizer = Player.Equalizer
  val Lyrics = Player.Lyrics
  val Queue = Player.Queue
  val SleepTimer = Player.SleepTimer

  val Home = Navigation.HomeOutlined
  val HomeFilled = Navigation.Home
  val Search = Navigation.SearchOutlined
  val SearchFilled = Navigation.Search
  val Library = Navigation.LibraryOutlined
  val LibraryFilled = Navigation.Library
  val Settings = Navigation.SettingsOutlined
  val SettingsFilled = Navigation.Settings
  val Back = Navigation.Back
  val Forward = Navigation.Forward
  val ChevronRight = Navigation.ChevronRight
  val Close = Navigation.Close
  val ExpandMore = Navigation.ExpandMore
  val ExpandLess = Navigation.ExpandLess
  val KeyboardArrowDown = Navigation.KeyboardArrowDown

  val Song = Music.SongOutlined
  val SongFilled = Music.Song
  val Album = Music.AlbumOutlined
  val AlbumFilled = Music.Album
  val Artist = Music.ArtistOutlined
  val ArtistFilled = Music.Artist
  val Playlist = Music.PlaylistOutlined
  val PlaylistFilled = Music.Playlist
  val MusicNote = Music.MusicNote
  val MusicOff = Music.MusicOff

  val Favorite = Actions.FavoriteOutlined
  val FavoriteFilled = Actions.Favorite
  val ThumbUp = Actions.ThumbUpOutlined
  val ThumbUpFilled = Actions.ThumbUp
  val Add = Actions.Add
  val Edit = Actions.Edit
  val Delete = Actions.Delete
  val AddToPlaylist = Actions.PlaylistAdd
  val More = Actions.More
  val Check = Actions.Check
  val Download = Actions.Download
  val Refresh = Actions.Refresh
  val Tune = Actions.Tune
  val Block = Actions.Block
  val Flag = Actions.Flag
  val Lock = Actions.Lock
  val LockOpen = Actions.LockOpen
  val ShoppingBag = Actions.ShoppingBag

  val BarChart = Content.BarChart
  val Leaderboard = Content.Leaderboard
  val LeaderboardOutlined = Content.LeaderboardOutlined
  val Palette = Content.Palette
  val ColorLens = Content.ColorLens
  val AutoAwesome = Content.AutoAwesome
  val Celebration = MaterialSymbolIcon("celebration", filled = true)
  val TextFields = MaterialSymbolIcon("text_fields", filled = true)
  val TouchApp = MaterialSymbolIcon("touch_app", filled = true)
  val Smartphone = MaterialSymbolIcon("smartphone", filled = true)
  val Speed = Player.Speed
  val VolumeUp = Player.VolumeUp
  val DarkMode = System.DarkMode
  val LightMode = System.LightMode
  val Contrast = System.Contrast
  val History = System.History
  val AccountCircle = System.AccountCircle
  val PersonAdd = System.PersonAdd
  val Wallet = System.AccountBalanceWallet
  val Login = System.Login
  val Logout = System.Logout
}
