package com.example.ui.navigation

import kotlinx.serialization.Serializable

@Serializable
data object DiscoverRoute

@Serializable
data object ExploreRoute

@Serializable
data object ChartsRoute

@Serializable
data object LibraryRoute

@Serializable
data object ProfileRoute

@Serializable
data class AlbumDetailRoute(val albumId: String)

@Serializable
data class ArtistDetailRoute(val artistId: String)

@Serializable
data object AllArtistsRoute

@Serializable
data class PlaylistDetailRoute(val playlistId: String)

@Serializable
data class PersonalizationDetailRoute(val sectionName: String)
