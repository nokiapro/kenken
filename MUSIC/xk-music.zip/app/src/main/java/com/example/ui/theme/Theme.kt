package com.example.ui.theme

import android.app.Activity
import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.ExperimentalMaterial3ExpressiveApi
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.MotionScheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.remember
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.dp
import androidx.core.view.WindowCompat
import com.example.ui.AppFontOption
import com.example.ui.FestiveThemeMode
import com.example.ui.FontScaleOption
import com.example.ui.RhythmColorPreset
import com.example.ui.RhythmPaletteStyle
import com.example.ui.ThemeMode
import com.example.ui.rhythm.LocalRhythmShapeConfig
import com.example.ui.rhythm.RhythmShapeConfig
import com.google.android.material.color.utilities.Hct
import java.util.Calendar

private val RhythmDefaultDarkScheme = darkColorScheme(
  primary = PrimaryDark,
  onPrimary = OnPrimaryDark,
  primaryContainer = PrimaryContainerDark,
  onPrimaryContainer = OnPrimaryContainerDark,
  secondary = SecondaryDark,
  onSecondary = OnSecondaryDark,
  secondaryContainer = SecondaryContainerDark,
  onSecondaryContainer = OnSecondaryContainerDark,
  tertiary = TertiaryDark,
  onTertiary = OnTertiaryDark,
  tertiaryContainer = TertiaryContainerDark,
  onTertiaryContainer = OnTertiaryContainerDark,
  error = ErrorDark,
  onError = OnErrorDark,
  errorContainer = ErrorContainerDark,
  onErrorContainer = OnErrorContainerDark,
  background = BackgroundDark,
  onBackground = OnBackgroundDark,
  surface = SurfaceDark,
  onSurface = OnSurfaceDark,
  surfaceVariant = SurfaceVariantDark,
  onSurfaceVariant = OnSurfaceVariantDark,
  outline = OutlineDark,
  outlineVariant = OutlineVariantDark,
  surfaceContainerLowest = SurfaceContainerLowestDark,
  surfaceContainerLow = SurfaceContainerLowDark,
  surfaceContainer = SurfaceContainerDark,
  surfaceContainerHigh = SurfaceContainerHighDark,
  surfaceContainerHighest = SurfaceContainerHighestDark,
  inverseSurface = InverseSurfaceDark,
  inverseOnSurface = InverseOnSurfaceDark,
  inversePrimary = InversePrimaryDark,
)

private val RhythmDefaultLightScheme = lightColorScheme(
  primary = PrimaryLight,
  onPrimary = OnPrimaryLight,
  primaryContainer = PrimaryContainerLight,
  onPrimaryContainer = OnPrimaryContainerLight,
  secondary = SecondaryLight,
  onSecondary = OnSecondaryLight,
  secondaryContainer = SecondaryContainerLight,
  onSecondaryContainer = OnSecondaryContainerLight,
  tertiary = TertiaryLight,
  onTertiary = OnTertiaryLight,
  tertiaryContainer = TertiaryContainerLight,
  onTertiaryContainer = OnTertiaryContainerLight,
  error = ErrorLight,
  onError = OnErrorLight,
  errorContainer = ErrorContainerLight,
  onErrorContainer = OnErrorContainerLight,
  background = BackgroundLight,
  onBackground = OnBackgroundLight,
  surface = SurfaceLight,
  onSurface = OnSurfaceLight,
  surfaceVariant = SurfaceVariantLight,
  onSurfaceVariant = OnSurfaceVariantLight,
  outline = OutlineLight,
  outlineVariant = OutlineVariantLight,
  surfaceContainerLowest = SurfaceContainerLowestLight,
  surfaceContainerLow = SurfaceContainerLowLight,
  surfaceContainer = SurfaceContainerLight,
  surfaceContainerHigh = SurfaceContainerHighLight,
  surfaceContainerHighest = SurfaceContainerHighestLight,
  inverseSurface = InverseSurfaceLight,
  inverseOnSurface = InverseOnSurfaceLight,
  inversePrimary = InversePrimaryLight,
)

private fun presetColorScheme(preset: RhythmColorPreset, isDark: Boolean): ColorScheme {
  if (preset == RhythmColorPreset.DEFAULT) {
    return if (isDark) RhythmDefaultDarkScheme else RhythmDefaultLightScheme
  }
  return if (isDark) {
    when (preset) {
      RhythmColorPreset.WARM -> RhythmDefaultDarkScheme.copy(
        primary = Color(0xFFFFB59D),
        onPrimary = Color(0xFF561F0E),
        primaryContainer = Color(0xFF733421),
        onPrimaryContainer = Color(0xFFFFDBD0),
        secondary = Color(0xFFE7BDB1),
        secondaryContainer = Color(0xFF5D4037),
        onSecondaryContainer = Color(0xFFFFDBD0),
        tertiary = Color(0xFFD7C68D),
        tertiaryContainer = Color(0xFF51461A),
        onTertiaryContainer = Color(0xFFF4E2A7),
        background = Color(0xFF1A110F),
        surface = Color(0xFF1A110F),
        surfaceContainerLowest = Color(0xFF140C0A),
        surfaceContainerLow = Color(0xFF231917),
        surfaceContainer = Color(0xFF271D1B),
        surfaceContainerHigh = Color(0xFF322825),
        surfaceContainerHighest = Color(0xFF3D322F),
      )
      RhythmColorPreset.COOL -> RhythmDefaultDarkScheme.copy(
        primary = Color(0xFF9ECAFF),
        onPrimary = Color(0xFF003258),
        primaryContainer = Color(0xFF00497D),
        onPrimaryContainer = Color(0xFFD1E4FF),
        secondary = Color(0xFFBAC8DB),
        secondaryContainer = Color(0xFF3B4858),
        onSecondaryContainer = Color(0xFFD6E3F7),
        tertiary = Color(0xFFD6BEE4),
        tertiaryContainer = Color(0xFF523F5F),
        onTertiaryContainer = Color(0xFFF2DAFF),
        background = Color(0xFF101418),
        surface = Color(0xFF101418),
        surfaceContainerLowest = Color(0xFF0B0E12),
        surfaceContainerLow = Color(0xFF181C20),
        surfaceContainer = Color(0xFF1D2024),
        surfaceContainerHigh = Color(0xFF272A2F),
        surfaceContainerHighest = Color(0xFF32353A),
      )
      RhythmColorPreset.FOREST -> RhythmDefaultDarkScheme.copy(
        primary = Color(0xFF9CD49F),
        onPrimary = Color(0xFF003913),
        primaryContainer = Color(0xFF1D5128),
        onPrimaryContainer = Color(0xFFB7F1BA),
        secondary = Color(0xFFB8CCB5),
        secondaryContainer = Color(0xFF3A4B39),
        onSecondaryContainer = Color(0xFFD4E8D0),
        tertiary = Color(0xFFA1CED5),
        tertiaryContainer = Color(0xFF1F4D53),
        onTertiaryContainer = Color(0xFFBDEAF1),
        background = Color(0xFF101510),
        surface = Color(0xFF101510),
        surfaceContainerLowest = Color(0xFF0B0F0B),
        surfaceContainerLow = Color(0xFF181D18),
        surfaceContainer = Color(0xFF1C211C),
        surfaceContainerHigh = Color(0xFF262B26),
        surfaceContainerHighest = Color(0xFF313630),
      )
      RhythmColorPreset.ROSE -> RhythmDefaultDarkScheme.copy(
        primary = Color(0xFFFFB0C9),
        onPrimary = Color(0xFF650033),
        primaryContainer = Color(0xFF8E004A),
        onPrimaryContainer = Color(0xFFFFD9E3),
        secondary = Color(0xFFE3BDC7),
        secondaryContainer = Color(0xFF5B3F47),
        onSecondaryContainer = Color(0xFFFFD9E3),
        tertiary = Color(0xFFEFBD94),
        tertiaryContainer = Color(0xFF623F20),
        onTertiaryContainer = Color(0xFFFFDCC0),
        background = Color(0xFF191114),
        surface = Color(0xFF191114),
        surfaceContainerLowest = Color(0xFF140C0F),
        surfaceContainerLow = Color(0xFF22191C),
        surfaceContainer = Color(0xFF261D20),
        surfaceContainerHigh = Color(0xFF31272A),
        surfaceContainerHighest = Color(0xFF3D3235),
      )
      RhythmColorPreset.LAVENDER -> RhythmDefaultDarkScheme.copy(
        primary = Color(0xFFCDBCFF),
        onPrimary = Color(0xFF330099),
        primaryContainer = Color(0xFF4B1CD6),
        onPrimaryContainer = Color(0xFFE8DDFF),
        secondary = Color(0xFFCBC3DC),
        secondaryContainer = Color(0xFF494458),
        onSecondaryContainer = Color(0xFFE7DFF8),
        tertiary = Color(0xFFEEB8CA),
        tertiaryContainer = Color(0xFF623B49),
        onTertiaryContainer = Color(0xFFFFD9E4),
      )
      RhythmColorPreset.OCEAN -> RhythmDefaultDarkScheme.copy(
        primary = Color(0xFF81D3DE),
        onPrimary = Color(0xFF00363C),
        primaryContainer = Color(0xFF004F57),
        onPrimaryContainer = Color(0xFF9DF0FB),
        secondary = Color(0xFFB1CBCE),
        secondaryContainer = Color(0xFF324B4E),
        onSecondaryContainer = Color(0xFFCDE7EA),
        tertiary = Color(0xFFB6C7E9),
        tertiaryContainer = Color(0xFF374764),
        onTertiaryContainer = Color(0xFFD6E3FF),
        background = Color(0xFF0E1415),
        surface = Color(0xFF0E1415),
        surfaceContainerLowest = Color(0xFF090F10),
        surfaceContainerLow = Color(0xFF171D1E),
        surfaceContainer = Color(0xFF1B2122),
        surfaceContainerHigh = Color(0xFF252B2C),
        surfaceContainerHighest = Color(0xFF303637),
      )
      RhythmColorPreset.CRIMSON -> RhythmDefaultDarkScheme.copy(
        primary = Color(0xFFFFB4AB),
        onPrimary = Color(0xFF690005),
        primaryContainer = Color(0xFF93000A),
        onPrimaryContainer = Color(0xFFFFDAD6),
        secondary = Color(0xFFE7BDB7),
        secondaryContainer = Color(0xFF5D3F3B),
        onSecondaryContainer = Color(0xFFFFDAD6),
        tertiary = Color(0xFFE5C18D),
        tertiaryContainer = Color(0xFF5B421A),
        onTertiaryContainer = Color(0xFFFFDEA8),
        background = Color(0xFF1A1110),
        surface = Color(0xFF1A1110),
        surfaceContainerLowest = Color(0xFF140C0B),
        surfaceContainerLow = Color(0xFF231918),
        surfaceContainer = Color(0xFF271D1C),
        surfaceContainerHigh = Color(0xFF322826),
        surfaceContainerHighest = Color(0xFF3D3231),
      )
      else -> RhythmDefaultDarkScheme
    }
  } else {
    when (preset) {
      RhythmColorPreset.WARM -> RhythmDefaultLightScheme.copy(
        primary = Color(0xFFA84220),
        primaryContainer = Color(0xFFFFDBD0),
        onPrimaryContainer = Color(0xFF3A0B00),
        secondary = Color(0xFF77574D),
        secondaryContainer = Color(0xFFFFDBD0),
        onSecondaryContainer = Color(0xFF2C150F),
        tertiary = Color(0xFF6B5E2E),
        tertiaryContainer = Color(0xFFF4E2A7),
        onTertiaryContainer = Color(0xFF231B00),
      )
      RhythmColorPreset.COOL -> RhythmDefaultLightScheme.copy(
        primary = Color(0xFF0061A4),
        primaryContainer = Color(0xFFD1E4FF),
        onPrimaryContainer = Color(0xFF001D36),
        secondary = Color(0xFF535F70),
        secondaryContainer = Color(0xFFD6E3F7),
        onSecondaryContainer = Color(0xFF101C2B),
        tertiary = Color(0xFF6B5778),
        tertiaryContainer = Color(0xFFF2DAFF),
        onTertiaryContainer = Color(0xFF251431),
      )
      RhythmColorPreset.FOREST -> RhythmDefaultLightScheme.copy(
        primary = Color(0xFF2E6B38),
        primaryContainer = Color(0xFFB7F1BA),
        onPrimaryContainer = Color(0xFF002107),
        secondary = Color(0xFF526350),
        secondaryContainer = Color(0xFFD4E8D0),
        onSecondaryContainer = Color(0xFF101F10),
        tertiary = Color(0xFF38656B),
        tertiaryContainer = Color(0xFFBDEAF1),
        onTertiaryContainer = Color(0xFF001F23),
      )
      RhythmColorPreset.ROSE -> RhythmDefaultLightScheme.copy(
        primary = Color(0xFFB7005F),
        primaryContainer = Color(0xFFFFD9E3),
        onPrimaryContainer = Color(0xFF3E001D),
        secondary = Color(0xFF74565F),
        secondaryContainer = Color(0xFFFFD9E3),
        onSecondaryContainer = Color(0xFF2B151C),
        tertiary = Color(0xFF7C5635),
        tertiaryContainer = Color(0xFFFFDCC0),
        onTertiaryContainer = Color(0xFF2E1500),
      )
      RhythmColorPreset.LAVENDER -> RhythmDefaultLightScheme.copy(
        primary = Color(0xFF633CF0),
        primaryContainer = Color(0xFFE8DDFF),
        onPrimaryContainer = Color(0xFF1E0060),
      )
      RhythmColorPreset.OCEAN -> RhythmDefaultLightScheme.copy(
        primary = Color(0xFF006972),
        primaryContainer = Color(0xFF9DF0FB),
        onPrimaryContainer = Color(0xFF001F23),
        secondary = Color(0xFF4A6366),
        secondaryContainer = Color(0xFFCDE7EA),
        onSecondaryContainer = Color(0xFF051F22),
      )
      RhythmColorPreset.CRIMSON -> RhythmDefaultLightScheme.copy(
        primary = Color(0xFFBA1A1A),
        primaryContainer = Color(0xFFFFDAD6),
        onPrimaryContainer = Color(0xFF410002),
      )
      else -> RhythmDefaultLightScheme
    }
  }
}

private fun ColorScheme.withAmoledBlack(): ColorScheme = copy(
  background = Color.Black,
  surface = Color.Black,
  surfaceContainerLowest = Color.Black,
  surfaceContainerLow = Color(0xFF0A0A0C),
  surfaceContainer = Color(0xFF121215),
  surfaceContainerHigh = Color(0xFF1C1C20),
  surfaceContainerHighest = Color(0xFF26262B),
)

/**
 * Shape tokens matching chromahub/Rhythm Shape.kt.
 */
object RhythmShapes {
  val Full = CircleShape
  val ExtraLarge = RoundedCornerShape(32.dp)
  val Large = RoundedCornerShape(28.dp)
  val SquircleLarge = RoundedCornerShape(26.dp)
  val Medium = RoundedCornerShape(20.dp)
  val Small = RoundedCornerShape(14.dp)
  val ExtraSmall = RoundedCornerShape(10.dp)
  val SearchBar = CircleShape
  val AlbumCover = RoundedCornerShape(18.dp)
  val SongCard = RoundedCornerShape(20.dp)
  val MiniPlayerFloating = CircleShape
}

val AppShapes = Shapes(
  extraSmall = RhythmShapes.ExtraSmall,
  small = RhythmShapes.Small,
  medium = RhythmShapes.Medium,
  large = RhythmShapes.Large,
  extraLarge = RhythmShapes.ExtraLarge,
)

val LocalRhythmHapticsEnabled = staticCompositionLocalOf { true }

fun resolveEffectiveFestiveTheme(mode: FestiveThemeMode): FestiveThemeMode {
  if (mode != FestiveThemeMode.AUTO) return mode
  val cal = Calendar.getInstance()
  val month = cal.get(Calendar.MONTH)
  val day = cal.get(Calendar.DAY_OF_MONTH)
  return when {
    month == Calendar.DECEMBER && day >= 10 -> FestiveThemeMode.CHRISTMAS
    month == Calendar.JANUARY && day <= 5 -> FestiveThemeMode.NEW_YEAR
    (month == Calendar.JANUARY && day >= 18) || (month == Calendar.FEBRUARY && day <= 10) -> FestiveThemeMode.TET
    month == Calendar.FEBRUARY && day in 11..16 -> FestiveThemeMode.VALENTINE
    month == Calendar.OCTOBER && day >= 20 -> FestiveThemeMode.HALLOWEEN
    else -> FestiveThemeMode.NONE
  }
}

private fun festiveSeedHex(mode: FestiveThemeMode): Long? = when (mode) {
  FestiveThemeMode.TET -> 0xFFD84315
  FestiveThemeMode.VALENTINE -> 0xFFE91E63
  FestiveThemeMode.HALLOWEEN -> 0xFFFF6D00
  FestiveThemeMode.CHRISTMAS -> 0xFF2E7D32
  FestiveThemeMode.NEW_YEAR -> 0xFF5E35B1
  FestiveThemeMode.NONE, FestiveThemeMode.AUTO -> null
}

@Composable
fun XkMusicTheme(
  themeMode: ThemeMode = ThemeMode.DARK,
  useDynamicColor: Boolean = false,
  colorPreset: RhythmColorPreset = RhythmColorPreset.DEFAULT,
  amoledMode: Boolean = false,
  paletteStyle: RhythmPaletteStyle = RhythmPaletteStyle.TONAL_SPOT,
  fontOption: AppFontOption = AppFontOption.PLUS_JAKARTA_SANS,
  fontScale: FontScaleOption = FontScaleOption.NORMAL,
  festiveThemeMode: FestiveThemeMode = FestiveThemeMode.NONE,
  hapticFeedbackEnabled: Boolean = true,
  shapeConfig: RhythmShapeConfig = RhythmShapeConfig(),
  content: @Composable () -> Unit,
) {
  val systemDark = isSystemInDarkTheme()
  val isDark = when (themeMode) {
    ThemeMode.SYSTEM -> systemDark
    ThemeMode.DARK -> true
    ThemeMode.LIGHT -> false
  }

  val effectiveFestive = remember(festiveThemeMode) { resolveEffectiveFestiveTheme(festiveThemeMode) }
  val festiveSeed = festiveSeedHex(effectiveFestive)

  val context = LocalContext.current
  val baseScheme = when {
    useDynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
      if (isDark) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
    }
    festiveSeed != null && colorPreset == RhythmColorPreset.DEFAULT -> {
      RhythmColorExtractor.createDynamicScheme(
        sourceHct = Hct.fromInt(festiveSeed.toInt()),
        paletteStyle = if (paletteStyle == RhythmPaletteStyle.TONAL_SPOT) "VIBRANT" else paletteStyle.apiKey,
        isDark = isDark,
      )
    }
    paletteStyle != RhythmPaletteStyle.TONAL_SPOT -> {
      RhythmColorExtractor.createDynamicScheme(
        sourceHct = Hct.fromInt(colorPreset.seedHex.toInt()),
        paletteStyle = paletteStyle.apiKey,
        isDark = isDark,
      )
    }
    else -> presetColorScheme(colorPreset, isDark)
  }

  val expressiveScheme = if (isDark) {
    baseScheme.copy(
      background = baseScheme.surfaceContainerLowest,
      surface = baseScheme.surfaceContainerLowest,
    )
  } else {
    baseScheme.copy(
      background = baseScheme.surfaceContainerLow,
      surface = baseScheme.surfaceContainerLow,
      surfaceContainerLowest = Color.White,
    )
  }

  val colorScheme = if (isDark && amoledMode) expressiveScheme.withAmoledBlack() else expressiveScheme
  val typography = remember(fontOption, fontScale) {
    buildAppTypography(fontOption = fontOption, fontScale = fontScale)
  }

  val view = LocalView.current
  if (!view.isInEditMode) {
    SideEffect {
      val window = (view.context as? Activity)?.window ?: return@SideEffect
      val controller = WindowCompat.getInsetsController(window, view)
      controller.isAppearanceLightStatusBars = !isDark
      controller.isAppearanceLightNavigationBars = !isDark
    }
  }

  @OptIn(ExperimentalMaterial3ExpressiveApi::class)
  CompositionLocalProvider(
    LocalRhythmHapticsEnabled provides hapticFeedbackEnabled,
    LocalRhythmShapeConfig provides shapeConfig,
  ) {
    MaterialTheme(
      colorScheme = colorScheme,
      motionScheme = MotionScheme.expressive(),
      typography = typography,
      shapes = AppShapes,
      content = content,
    )
  }
}
