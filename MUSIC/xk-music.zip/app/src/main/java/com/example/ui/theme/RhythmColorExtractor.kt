package com.example.ui.theme

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color as AndroidColor
import android.util.LruCache
import androidx.compose.material3.ColorScheme
import androidx.compose.runtime.Immutable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.toArgb
import androidx.core.graphics.ColorUtils
import androidx.core.graphics.drawable.toBitmap
import androidx.core.graphics.scale
import coil.imageLoader
import coil.request.ImageRequest
import coil.request.SuccessResult
import coil.size.Scale
import com.google.android.material.color.utilities.Hct
import com.google.android.material.color.utilities.QuantizerCelebi
import com.google.android.material.color.utilities.SchemeContent
import com.google.android.material.color.utilities.SchemeExpressive
import com.google.android.material.color.utilities.SchemeFidelity
import com.google.android.material.color.utilities.SchemeFruitSalad
import com.google.android.material.color.utilities.SchemeMonochrome
import com.google.android.material.color.utilities.SchemeNeutral
import com.google.android.material.color.utilities.SchemeRainbow
import com.google.android.material.color.utilities.SchemeTonalSpot
import com.google.android.material.color.utilities.SchemeVibrant
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.roundToInt

/**
 * Dynamic accent color palette extracted from album artwork matching chromahub/Rhythm's
 * `ColorExtractor.kt` + `ExpressivePlayerScreen` `useAccentBackground` mode (`accentBg`, `accentFg`).
 *
 * Uses `com.google.android.material.color.utilities.QuantizerCelebi` + `Hct` + `SchemeVibrant` /
 * `SchemeTonalSpot` / `SchemeMonochrome` identically to Rhythm v5.5.499.1302-stable.
 */
@Immutable
data class RhythmPlayerPalette(
  val accentBg: Color,
  val accentFg: Color,
  val accentGlass: Color,
  val accentGlassStrong: Color,
  val isLightCanvas: Boolean,
)

@SuppressLint("RestrictedApi")
object RhythmColorExtractor {
  private val paletteCache = LruCache<String, RhythmPlayerPalette>(48)

  fun fallbackFromTrack(
    title: String,
    artist: String,
    isDarkTheme: Boolean,
    fallbackPrimary: Color = Color(0xFFBDB4FF),
  ): RhythmPlayerPalette {
    val seedInt = abs(title.hashCode() * 31 + artist.hashCode())
    val argb = if (title.isBlank() && artist.isBlank()) {
      fallbackPrimary.toArgb()
    } else {
      val hue = (seedInt % 360).toDouble()
      Hct.from(hue, 56.0, 48.0).toInt()
    }
    return derivePlayerPalette(seedArgb = argb, isDarkTheme = isDarkTheme, isMonochrome = false)
  }

  suspend fun extractForCover(
    context: Context,
    coverUrl: String?,
    title: String,
    artist: String,
    isDarkTheme: Boolean,
  ): RhythmPlayerPalette {
    val cacheKey = "${coverUrl.orEmpty()}_${title}_${artist}_$isDarkTheme"
    paletteCache.get(cacheKey)?.let { return it }

    if (coverUrl.isNullOrBlank()) {
      return fallbackFromTrack(title, artist, isDarkTheme).also { paletteCache.put(cacheKey, it) }
    }

    val bitmap = loadSmallBitmap(context, coverUrl)
    val palette = if (bitmap != null) {
      withContext(Dispatchers.Default) {
        val (seedArgb, monochrome) = extractDominantSeed(bitmap)
        derivePlayerPalette(seedArgb = seedArgb, isDarkTheme = isDarkTheme, isMonochrome = monochrome)
      }
    } else {
      fallbackFromTrack(title, artist, isDarkTheme)
    }

    paletteCache.put(cacheKey, palette)
    return palette
  }

  private suspend fun loadSmallBitmap(context: Context, url: String): Bitmap? =
    withContext(Dispatchers.IO) {
      runCatching {
        val request = ImageRequest.Builder(context)
          .data(url)
          .size(128, 128)
          .scale(Scale.FILL)
          .allowHardware(false)
          .build()
        val result = context.imageLoader.execute(request) as? SuccessResult ?: return@withContext null
        result.drawable.toBitmap(width = 96, height = 96, config = Bitmap.Config.ARGB_8888)
      }.getOrNull()
    }

  private fun resizeForExtraction(bitmap: Bitmap, maxDimension: Int): Bitmap {
    val source = if (bitmap.config == Bitmap.Config.HARDWARE) {
      bitmap.copy(Bitmap.Config.ARGB_8888, false)
    } else {
      bitmap
    }
    if (maxDimension <= 0) return source
    if (source.width <= maxDimension && source.height <= maxDimension) return source
    val scaleFactor = maxDimension.toFloat() / max(source.width, source.height).toFloat()
    val newWidth = (source.width * scaleFactor).roundToInt().coerceAtLeast(1)
    val newHeight = (source.height * scaleFactor).roundToInt().coerceAtLeast(1)
    return source.scale(newWidth, newHeight, true)
  }

  /**
   * Authentic Rhythm `ColorExtractor.extractSeedAndNeutralStatus` via `QuantizerCelebi` + `Hct`.
   */
  internal fun extractDominantSeed(bitmap: Bitmap): Pair<Int, Boolean> {
    val working = resizeForExtraction(bitmap, 128)
    val w = working.width.coerceAtLeast(1)
    val h = working.height.coerceAtLeast(1)
    val pixels = IntArray(w * h)
    working.getPixels(pixels, 0, w, 0, 0, w, h)
    if (working !== bitmap) {
      working.recycle()
    }

    val fallbackArgb = averageColorArgb(pixels)
    val quantized = runCatching { QuantizerCelebi.quantize(pixels, 128) }.getOrNull()
      ?: return fallbackArgb to isMostlyNeutralPixels(pixels)

    val isMonochrome = isMostlyNeutralArtwork(quantized)
    if (isMonochrome) {
      return fallbackArgb to true
    }

    // Score colorful quantized entries grouped into 12 hue clusters (Rhythm exact algorithm)
    val colorfulEntries = quantized.entries.filter { (argb, pop) ->
      pop > 0 && !isArgbNearGrayscale(argb) && Hct.fromInt(argb).chroma >= 10.0
    }
    if (colorfulEntries.isEmpty()) {
      return fallbackArgb to true
    }

    val hueBins = DoubleArray(12)
    val hueBinColors = Array(12) { mutableListOf<Pair<Int, Int>>() }
    for ((argb, pop) in colorfulEntries) {
      val hct = Hct.fromInt(argb)
      val bin = ((hct.hue / 30.0).toInt()).coerceIn(0, 11)
      hueBins[bin] += pop.toDouble() * (1.0 + (hct.chroma / 48.0).coerceAtMost(1.2))
      hueBinColors[bin].add(argb to pop)
    }

    var bestBinIndex = 0
    var maxBinPopulation = 0.0
    for (i in 0 until 12) {
      if (hueBins[i] > maxBinPopulation) {
        maxBinPopulation = hueBins[i]
        bestBinIndex = i
      }
    }

    val dominantCluster = hueBinColors[bestBinIndex]
    if (dominantCluster.isEmpty()) {
      return (colorfulEntries.maxByOrNull { it.value }?.key ?: fallbackArgb) to false
    }

    val bestColor = dominantCluster.maxByOrNull { (argb, pop) ->
      val hct = Hct.fromInt(argb)
      val popScore = (pop.toDouble() / maxBinPopulation.coerceAtLeast(1.0)) * 100.0
      val tonePenalty = when {
        hct.tone < 20.0 -> (20.0 - hct.tone) * 2.0
        hct.tone > 85.0 -> (hct.tone - 85.0) * 1.5
        else -> 0.0
      }
      val chromaBonus = (hct.chroma / 36.0) * 22.0
      popScore + chromaBonus - tonePenalty
    }?.first ?: fallbackArgb

    return bestColor to false
  }

  /**
   * Derives `(accentBg, accentFg)` using Material Color Utilities `Hct` + `SchemeVibrant`/`SchemeTonalSpot`,
   * matching Rhythm `ExpressivePlayerScreen`:
   * - Dark theme: luminous pastel `primary` (tone ~80+) canvas with deep ink `onPrimary` (tone <= 20, contrast >= 7.0)
   * - Light theme: rich deep `primary` canvas with crisp luminous ink
   */
  internal fun derivePlayerPalette(
    seedArgb: Int,
    isDarkTheme: Boolean,
    isMonochrome: Boolean,
  ): RhythmPlayerPalette {
    val sourceHct = Hct.fromInt(seedArgb)
    val style = when {
      isMonochrome || sourceHct.chroma <= 8.0 || isArgbNearGrayscale(seedArgb) -> "MONOCHROME"
      sourceHct.chroma > 18.0 -> "VIBRANT"
      else -> "TONAL_SPOT"
    }
    val scheme = createDynamicScheme(
      sourceHct = sourceHct,
      paletteStyle = style,
      isDark = isDarkTheme,
      contrastLevel = 0.25,
    )

    var bgArgb = scheme.primary.toArgb()
    var fgArgb = scheme.onPrimary.toArgb()

    // Guarantee bright pastel canvas luminance in dark mode & deep WCAG AA/AAA >= 7.0 ink contrast
    if (isDarkTheme) {
      val bgHct = Hct.fromInt(bgArgb)
      if (Color(bgArgb).luminance() <= 0.52f) {
        bgArgb = Hct.from(bgHct.hue, bgHct.chroma.coerceAtLeast(if (isMonochrome) 0.0 else 36.0), 82.0).toInt()
      }
      val fgHct = Hct.fromInt(fgArgb)
      var targetTone = fgHct.tone.coerceAtMost(24.0)
      while (ColorUtils.calculateContrast(fgArgb, bgArgb) < 7.0 && targetTone > 2.0) {
        targetTone = (targetTone - 3.0).coerceAtLeast(0.0)
        fgArgb = Hct.from(fgHct.hue, fgHct.chroma, targetTone).toInt()
      }
    } else {
      val fgHct = Hct.fromInt(fgArgb)
      var bgHct = Hct.fromInt(bgArgb)
      var bgTone = bgHct.tone.coerceAtMost(38.0)
      while (ColorUtils.calculateContrast(fgArgb, bgArgb) < 5.5 && bgTone > 8.0) {
        bgTone = (bgTone - 3.0).coerceAtLeast(8.0)
        bgHct = Hct.from(bgHct.hue, bgHct.chroma, bgTone)
        bgArgb = bgHct.toInt()
      }
      if (ColorUtils.calculateContrast(fgArgb, bgArgb) < 5.5) {
        fgArgb = Hct.from(fgHct.hue, fgHct.chroma, 98.0).toInt()
      }
    }

    val accentBg = Color(bgArgb)
    val accentFg = Color(fgArgb)
    return RhythmPlayerPalette(
      accentBg = accentBg,
      accentFg = accentFg,
      accentGlass = accentFg.copy(alpha = 0.15f),
      accentGlassStrong = accentFg.copy(alpha = 0.28f),
      isLightCanvas = accentBg.luminance() > 0.5f,
    )
  }

  /**
   * Direct port of Rhythm `ColorExtractor.createDynamicScheme`.
   */
  fun createDynamicScheme(
    sourceHct: Hct,
    paletteStyle: String,
    isDark: Boolean,
    contrastLevel: Double = 0.0,
    chromaMultiplier: Double = 1.0,
  ): ColorScheme {
    val effectiveHct = if (chromaMultiplier != 1.0 && sourceHct.chroma > 0.0) {
      val adjustedChroma = (sourceHct.chroma * chromaMultiplier).coerceIn(0.0, 150.0)
      Hct.from(sourceHct.hue, adjustedChroma, sourceHct.tone)
    } else {
      sourceHct
    }
    val clampedContrast = contrastLevel.coerceIn(-1.0, 1.0)
    val scheme = when (paletteStyle) {
      "TONAL_SPOT" -> SchemeTonalSpot(effectiveHct, isDark, clampedContrast)
      "VIBRANT" -> SchemeVibrant(effectiveHct, isDark, clampedContrast)
      "EXPRESSIVE" -> SchemeExpressive(effectiveHct, isDark, clampedContrast)
      "FRUIT_SALAD" -> SchemeFruitSalad(effectiveHct, isDark, clampedContrast)
      "CONTENT" -> SchemeContent(effectiveHct, isDark, clampedContrast)
      "MONOCHROME" -> SchemeMonochrome(effectiveHct, isDark, clampedContrast)
      "NEUTRAL" -> SchemeNeutral(effectiveHct, isDark, clampedContrast)
      "FIDELITY" -> SchemeFidelity(effectiveHct, isDark, clampedContrast)
      "RAINBOW" -> SchemeRainbow(effectiveHct, isDark, clampedContrast)
      else -> SchemeTonalSpot(effectiveHct, isDark, clampedContrast)
    }
    return ColorScheme(
      primary = Color(scheme.primary),
      onPrimary = Color(scheme.onPrimary),
      primaryContainer = Color(scheme.primaryContainer),
      onPrimaryContainer = Color(scheme.onPrimaryContainer),
      inversePrimary = Color(scheme.inversePrimary),
      secondary = Color(scheme.secondary),
      onSecondary = Color(scheme.onSecondary),
      secondaryContainer = Color(scheme.secondaryContainer),
      onSecondaryContainer = Color(scheme.onSecondaryContainer),
      tertiary = Color(scheme.tertiary),
      onTertiary = Color(scheme.onTertiary),
      tertiaryContainer = Color(scheme.tertiaryContainer),
      onTertiaryContainer = Color(scheme.onTertiaryContainer),
      background = Color(scheme.background),
      onBackground = Color(scheme.onBackground),
      surface = Color(scheme.surface),
      onSurface = Color(scheme.onSurface),
      surfaceVariant = Color(scheme.surfaceVariant),
      onSurfaceVariant = Color(scheme.onSurfaceVariant),
      surfaceTint = Color(scheme.primary),
      inverseSurface = Color(scheme.inverseSurface),
      inverseOnSurface = Color(scheme.inverseOnSurface),
      error = Color(scheme.error),
      onError = Color(scheme.onError),
      errorContainer = Color(scheme.errorContainer),
      onErrorContainer = Color(scheme.onErrorContainer),
      outline = Color(scheme.outline),
      outlineVariant = Color(scheme.outlineVariant),
      scrim = Color(scheme.scrim),
      surfaceBright = Color(scheme.surfaceBright),
      surfaceDim = Color(scheme.surfaceDim),
      surfaceContainer = Color(scheme.surfaceContainer),
      surfaceContainerHigh = Color(scheme.surfaceContainerHigh),
      surfaceContainerHighest = Color(scheme.surfaceContainerHighest),
      surfaceContainerLow = Color(scheme.surfaceContainerLow),
      surfaceContainerLowest = Color(scheme.surfaceContainerLowest),
      primaryFixed = Color(scheme.primaryFixed),
      primaryFixedDim = Color(scheme.primaryFixedDim),
      onPrimaryFixed = Color(scheme.onPrimaryFixed),
      onPrimaryFixedVariant = Color(scheme.onPrimaryFixedVariant),
      secondaryFixed = Color(scheme.secondaryFixed),
      secondaryFixedDim = Color(scheme.secondaryFixedDim),
      onSecondaryFixed = Color(scheme.onSecondaryFixed),
      onSecondaryFixedVariant = Color(scheme.onSecondaryFixedVariant),
      tertiaryFixed = Color(scheme.tertiaryFixed),
      tertiaryFixedDim = Color(scheme.tertiaryFixedDim),
      onTertiaryFixed = Color(scheme.onTertiaryFixed),
      onTertiaryFixedVariant = Color(scheme.onTertiaryFixedVariant),
    )
  }

  private fun averageColorArgb(pixels: IntArray): Int {
    if (pixels.isEmpty()) return 0xFF6750A4.toInt()
    var totalRed = 0L
    var totalGreen = 0L
    var totalBlue = 0L
    for (argb in pixels) {
      totalRed += (argb ushr 16) and 0xFF
      totalGreen += (argb ushr 8) and 0xFF
      totalBlue += argb and 0xFF
    }
    val size = pixels.size.toLong()
    val r = (totalRed / size).toInt().coerceIn(0, 255)
    val g = (totalGreen / size).toInt().coerceIn(0, 255)
    val b = (totalBlue / size).toInt().coerceIn(0, 255)
    return (0xFF shl 24) or (r shl 16) or (g shl 8) or b
  }

  private fun isMostlyNeutralPixels(pixels: IntArray): Boolean {
    if (pixels.isEmpty()) return true
    var neutral = 0
    for (p in pixels) {
      if (isArgbNearGrayscale(p)) neutral++
    }
    return neutral.toDouble() / pixels.size.toDouble() >= 0.85
  }

  fun isMostlyNeutralArtwork(colorsToPopulation: Map<Int, Int>): Boolean {
    if (colorsToPopulation.isEmpty()) return false
    var totalPopulation = 0.0
    var neutralPopulation = 0.0
    var highChromaPopulation = 0.0
    var weightedChroma = 0.0
    for ((argb, populationInt) in colorsToPopulation) {
      if (populationInt <= 0) continue
      val population = populationInt.toDouble()
      val hct = Hct.fromInt(argb)
      val isGrayscale = isArgbNearGrayscale(argb)
      val chroma = if (isGrayscale) 0.0 else hct.chroma
      totalPopulation += population
      weightedChroma += chroma * population
      if (chroma <= 8.0 || isGrayscale) {
        neutralPopulation += population
      }
      if (chroma >= 16.0 && !isGrayscale) {
        highChromaPopulation += population
      }
    }
    if (totalPopulation <= 0.0) return false
    val neutralRatio = neutralPopulation / totalPopulation
    val highChromaRatio = highChromaPopulation / totalPopulation
    val meanChroma = weightedChroma / totalPopulation
    return neutralRatio >= 0.82 || (meanChroma <= 8.0 && highChromaRatio <= 0.04)
  }

  fun isArgbNearGrayscale(argb: Int): Boolean {
    val red = (argb ushr 16) and 0xFF
    val green = (argb ushr 8) and 0xFF
    val blue = argb and 0xFF
    return maxOf(abs(red - green), abs(green - blue), abs(red - blue)) <= 10
  }
}
