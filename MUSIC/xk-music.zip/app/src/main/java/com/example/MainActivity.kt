package com.example

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.SystemClock
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.EaseOutQuart
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.NavigationRailItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import com.example.ui.rhythm.AnyIcon
import com.example.ui.rhythm.MaterialSymbolIcon
import com.example.ui.rhythm.RhythmIcons
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavDestination.Companion.hasRoute
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.toRoute
import com.example.model.SleepTimerUiState
import com.example.ui.MusicViewModel
import com.example.ui.PersonalizationSection
import com.example.ui.PersonalizationSettings
import com.example.ui.components.FestiveParticlesOverlay
import com.example.ui.components.MiniPlayerBar
import com.example.ui.components.NowPlayingSheet
import com.example.ui.components.PurchaseSongDialog
import com.example.ui.components.RhythmDockedNavBar
import com.example.ui.components.RhythmFloatingNavBarWithSearch
import com.example.ui.components.RhythmNavItem
import com.example.ui.navigation.AlbumDetailRoute
import com.example.ui.navigation.AllArtistsRoute
import com.example.ui.navigation.ArtistDetailRoute
import com.example.ui.navigation.ChartsRoute
import com.example.ui.navigation.DiscoverRoute
import com.example.ui.navigation.ExploreRoute
import com.example.ui.navigation.LibraryRoute
import com.example.ui.navigation.PersonalizationDetailRoute
import com.example.ui.navigation.PlaylistDetailRoute
import com.example.ui.navigation.ProfileRoute
import com.example.ui.rhythm.RhythmShapeConfig
import com.example.ui.screens.AlbumDetailScreen
import com.example.ui.screens.AllArtistsScreen
import com.example.ui.screens.ArtistDetailScreen
import com.example.ui.screens.ChartsScreen
import com.example.ui.screens.DiscoverScreen
import com.example.ui.screens.ExploreScreen
import com.example.ui.screens.LibraryScreen
import com.example.ui.screens.PersonalizationDetailScreen
import com.example.ui.screens.PlaylistDetailScreen
import com.example.ui.screens.ProfileScreen
import com.example.ui.theme.XkMusicTheme

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    setContent {
      val viewModel: MusicViewModel = viewModel()
      val appearanceSettings by viewModel.appearanceSettings.collectAsStateWithLifecycle()
      val personalizationSettings by viewModel.personalizationSettings.collectAsStateWithLifecycle()
      XkMusicTheme(
        themeMode = appearanceSettings.themeMode,
        useDynamicColor = appearanceSettings.useDynamicColor,
        colorPreset = appearanceSettings.colorPreset,
        amoledMode = appearanceSettings.amoledMode,
        paletteStyle = personalizationSettings.paletteStyle,
        fontOption = personalizationSettings.fontOption,
        fontScale = personalizationSettings.fontScale,
        festiveThemeMode = personalizationSettings.festiveThemeMode,
        hapticFeedbackEnabled = personalizationSettings.hapticFeedbackEnabled,
        shapeConfig = RhythmShapeConfig(
          albumArtShapeId = personalizationSettings.albumArtShapeId,
          songArtShapeId = personalizationSettings.songArtShapeId,
          playlistArtShapeId = personalizationSettings.playlistArtShapeId,
          miniPlayerShapeId = personalizationSettings.miniPlayerShapeId,
        ),
      ) {
        XkMusicApp(viewModel = viewModel)
      }
    }
  }
}

private data class TopLevelDestination(
  val route: Any,
  val labelRes: Int,
  val selectedIcon: MaterialSymbolIcon,
  val unselectedIcon: MaterialSymbolIcon,
  val testTag: String,
)

@Composable
fun XkMusicApp(
  viewModel: MusicViewModel = viewModel(),
) {
  val context = LocalContext.current
  val navController = rememberNavController()
  val navBackStackEntry by navController.currentBackStackEntryAsState()
  val currentDestination = navBackStackEntry?.destination

  val discoverState by viewModel.discoverState.collectAsStateWithLifecycle()
  val exploreState by viewModel.exploreState.collectAsStateWithLifecycle()
  val activeTrack by viewModel.activeTrackMeta.collectAsStateWithLifecycle()
  val favorites by viewModel.favorites.collectAsStateWithLifecycle()
  val favoriteIds by viewModel.favoriteIds.collectAsStateWithLifecycle()
  val favoriteAlbumIds by viewModel.favoriteAlbumIds.collectAsStateWithLifecycle()
  val blockedSongIds by viewModel.blockedSongIds.collectAsStateWithLifecycle()
  val purchasedIds by viewModel.purchasedIds.collectAsStateWithLifecycle()
  val recentSongs by viewModel.recentSongs.collectAsStateWithLifecycle()
  val albumDetailState by viewModel.albumDetailState.collectAsStateWithLifecycle()
  val artistDetailState by viewModel.artistDetailState.collectAsStateWithLifecycle()
  val playlistDetailState by viewModel.playlistDetailState.collectAsStateWithLifecycle()
  val authState by viewModel.authState.collectAsStateWithLifecycle()
  val sleepTimerState by viewModel.sleepTimerState.collectAsStateWithLifecycle()
  val purchaseDialogState by viewModel.purchaseDialogState.collectAsStateWithLifecycle()
  val snackbarMessage by viewModel.snackbarMessage.collectAsStateWithLifecycle()
  val appearanceSettings by viewModel.appearanceSettings.collectAsStateWithLifecycle()
  val personalizationSettings by viewModel.personalizationSettings.collectAsStateWithLifecycle()
  val listeningStats by viewModel.listeningStats.collectAsStateWithLifecycle()

  var showNowPlaying by rememberSaveable { mutableStateOf(false) }
  var askedNotificationPermission by remember { mutableStateOf(false) }
  var lastRootBackPressMs by remember { mutableLongStateOf(0L) }
  val snackbarHostState = remember { SnackbarHostState() }

  val notificationPermissionLauncher = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.RequestPermission(),
  ) { _ -> }

  val hasActiveSong = activeTrack.songId != null
  val canPopBack = remember(navBackStackEntry) {
    navController.previousBackStackEntry != null
  }
  val lifecycleOwner = LocalLifecycleOwner.current

  DisposableEffect(lifecycleOwner, viewModel) {
    val observer = LifecycleEventObserver { _, event ->
      if (event == Lifecycle.Event.ON_RESUME) {
        viewModel.onAppResumed()
      }
    }
    lifecycleOwner.lifecycle.addObserver(observer)
    onDispose {
      lifecycleOwner.lifecycle.removeObserver(observer)
    }
  }

  LaunchedEffect(hasActiveSong) {
    if (!hasActiveSong) {
      showNowPlaying = false
    }
  }

  LaunchedEffect(activeTrack.songId) {
    if (activeTrack.songId != null && !askedNotificationPermission) {
      askedNotificationPermission = true
      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
        val granted = ContextCompat.checkSelfPermission(
          context,
          Manifest.permission.POST_NOTIFICATIONS,
        ) == PackageManager.PERMISSION_GRANTED
        if (!granted) {
          notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
      }
    }
  }

  LaunchedEffect(snackbarMessage) {
    val msg = snackbarMessage
    if (!msg.isNullOrBlank()) {
      snackbarHostState.showSnackbar(msg)
      viewModel.clearSnackbarMessage()
    }
  }

  // Authentic Rhythm Pill Navigation: 4 main destinations in pill + detached Search FAB!
  val pillDestinations = remember {
    listOf(
      TopLevelDestination(
        route = DiscoverRoute,
        labelRes = R.string.nav_discover,
        selectedIcon = RhythmIcons.Navigation.Home,
        unselectedIcon = RhythmIcons.Navigation.HomeOutlined,
        testTag = "nav_discover",
      ),
      TopLevelDestination(
        route = ChartsRoute,
        labelRes = R.string.nav_charts,
        selectedIcon = RhythmIcons.Leaderboard,
        unselectedIcon = RhythmIcons.LeaderboardOutlined,
        testTag = "nav_charts",
      ),
      TopLevelDestination(
        route = LibraryRoute,
        labelRes = R.string.nav_library,
        selectedIcon = RhythmIcons.Navigation.Library,
        unselectedIcon = RhythmIcons.Navigation.LibraryOutlined,
        testTag = "nav_library",
      ),
      TopLevelDestination(
        route = ProfileRoute,
        labelRes = R.string.nav_profile,
        selectedIcon = RhythmIcons.Music.Artist,
        unselectedIcon = RhythmIcons.Music.ArtistOutlined,
        testTag = "nav_profile",
      ),
    )
  }

  val tabletDestinations = remember {
    listOf(
      pillDestinations[0],
      TopLevelDestination(
        route = ExploreRoute,
        labelRes = R.string.nav_explore,
        selectedIcon = RhythmIcons.SearchFilled,
        unselectedIcon = RhythmIcons.Search,
        testTag = "nav_explore",
      ),
      pillDestinations[1],
      pillDestinations[2],
      pillDestinations[3],
    )
  }

  val discoverLabel = stringResource(R.string.nav_discover)
  val chartsLabel = stringResource(R.string.nav_charts)
  val libraryLabel = stringResource(R.string.nav_library)
  val profileLabel = stringResource(R.string.nav_profile)

  val rhythmNavItems = remember(discoverLabel, chartsLabel, libraryLabel, profileLabel) {
    val labels = listOf(discoverLabel, chartsLabel, libraryLabel, profileLabel)
    pillDestinations.mapIndexed { index, dest ->
      RhythmNavItem(
        route = dest.route,
        label = labels[index],
        selectedIcon = dest.selectedIcon,
        unselectedIcon = dest.unselectedIcon,
        testTag = dest.testTag,
      )
    }
  }

  fun navigateTopLevel(route: Any) {
    navController.navigate(route) {
      popUpTo(navController.graph.findStartDestination().id) {
        saveState = true
      }
      launchSingleTop = true
      restoreState = true
    }
  }

  val isSearchSelected = currentDestination?.hasRoute(ExploreRoute::class) == true

  BoxWithConstraints(
    modifier = Modifier
      .fillMaxSize()
      .background(MaterialTheme.colorScheme.background),
  ) {
    val useNavRail = maxWidth >= 600.dp

    Row(modifier = Modifier.fillMaxSize()) {
      if (useNavRail) {
        NavigationRail(
          containerColor = MaterialTheme.colorScheme.surfaceContainerLow,
          modifier = Modifier
            .fillMaxHeight()
            .windowInsetsPadding(WindowInsets.statusBars)
            .windowInsetsPadding(WindowInsets.navigationBars),
        ) {
          tabletDestinations.forEach { dest ->
            val selected = currentDestination?.hasRoute(dest.route::class) == true
            NavigationRailItem(
              selected = selected,
              onClick = { navigateTopLevel(dest.route) },
              icon = {
                AnyIcon(
                  icon = if (selected) dest.selectedIcon else dest.unselectedIcon,
                  contentDescription = stringResource(dest.labelRes),
                )
              },
              label = { Text(stringResource(dest.labelRes)) },
              colors = NavigationRailItemDefaults.colors(
                selectedIconColor = MaterialTheme.colorScheme.onPrimaryContainer,
                selectedTextColor = MaterialTheme.colorScheme.primary,
                indicatorColor = MaterialTheme.colorScheme.primaryContainer,
              ),
              modifier = Modifier.testTag(dest.testTag),
            )
          }
        }
      }

      Scaffold(
        modifier = Modifier.weight(1f),
        containerColor = Color.Transparent,
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
        bottomBar = {
          Column(modifier = Modifier.fillMaxWidth()) {
            AnimatedVisibility(
              visible = hasActiveSong,
              enter = slideInVertically(initialOffsetY = { it }) + fadeIn(),
              exit = slideOutVertically(targetOffsetY = { it }) + fadeOut(),
            ) {
              MiniPlayerHost(
                viewModel = viewModel,
                favoriteIds = favoriteIds,
                personalization = personalizationSettings,
                useNavRail = useNavRail,
                snackbarHostState = snackbarHostState,
                onExpandClick = { showNowPlaying = true },
              )
            }

            if (!useNavRail) {
              if (personalizationSettings.floatingNavBarEnabled) {
                RhythmFloatingNavBarWithSearch(
                  items = rhythmNavItems,
                  selectedPredicate = { item -> currentDestination?.hasRoute(item.route::class) == true },
                  onSelect = { item -> navigateTopLevel(item.route) },
                  isSearchSelected = isSearchSelected,
                  onSearchClick = { navigateTopLevel(ExploreRoute) },
                  searchTestTag = "nav_explore",
                  labelBehavior = personalizationSettings.navBarLabelBehavior,
                  showDetachedSearchFab = personalizationSettings.showDetachedSearchFab,
                )
              } else {
                RhythmDockedNavBar(
                  items = rhythmNavItems,
                  selectedPredicate = { item -> currentDestination?.hasRoute(item.route::class) == true },
                  onSelect = { item -> navigateTopLevel(item.route) },
                  isSearchSelected = isSearchSelected,
                  onSearchClick = { navigateTopLevel(ExploreRoute) },
                  searchTestTag = "nav_explore",
                  labelBehavior = personalizationSettings.navBarLabelBehavior,
                )
              }
            }
          }
        },
      ) { innerPadding ->
        Box(
          modifier = Modifier
            .fillMaxSize()
            .windowInsetsPadding(WindowInsets.statusBars),
          contentAlignment = Alignment.TopCenter,
        ) {
          val listBottomPadding = PaddingValues(bottom = innerPadding.calculateBottomPadding())

          NavHost(
            navController = navController,
            startDestination = DiscoverRoute,
            modifier = Modifier.fillMaxSize(),
            enterTransition = {
              fadeIn(animationSpec = tween(180)) +
                slideInHorizontally(animationSpec = tween(200, easing = EaseOutQuart)) { it / 14 }
            },
            exitTransition = {
              fadeOut(animationSpec = tween(150)) +
                slideOutHorizontally(animationSpec = tween(180, easing = EaseOutQuart)) { -it / 18 }
            },
            popEnterTransition = {
              fadeIn(animationSpec = tween(180)) +
                slideInHorizontally(animationSpec = tween(200, easing = EaseOutQuart)) { -it / 14 }
            },
            popExitTransition = {
              fadeOut(animationSpec = tween(150)) +
                slideOutHorizontally(animationSpec = tween(180, easing = EaseOutQuart)) { it / 12 }
            },
          ) {
            composable<DiscoverRoute> {
              DiscoverScreen(
                uiState = discoverState,
                activeTrack = activeTrack,
                favoriteIds = favoriteIds,
                purchasedIds = purchasedIds,
                bottomOverlayPadding = listBottomPadding,
                onRefresh = { viewModel.refreshHome() },
                onOpenSearch = { navigateTopLevel(ExploreRoute) },
                onOpenCharts = { navigateTopLevel(ChartsRoute) },
                onPlaySong = { song, queue -> viewModel.playSong(song, queue) },
                onToggleFavorite = { viewModel.toggleFavorite(it) },
                onPurchaseSong = { viewModel.openPurchaseDialog(it) },
                onOpenAlbum = { albumId -> navController.navigate(AlbumDetailRoute(albumId)) },
                onOpenArtist = { artistId -> navController.navigate(ArtistDetailRoute(artistId)) },
                onOpenPlaylist = { playlistId -> navController.navigate(PlaylistDetailRoute(playlistId)) },
                userName = authState.session?.user?.displayName,
                listeningStats = listeningStats,
                onOpenAllArtists = { navController.navigate(AllArtistsRoute) },
                onPlayNext = { viewModel.playNext(it) },
                onAddToQueue = { viewModel.addToQueue(it) },
              )
            }

            composable<AllArtistsRoute> {
              AllArtistsScreen(
                artists = discoverState.artists,
                bottomOverlayPadding = listBottomPadding,
                onBack = { navController.popBackStack() },
                onOpenArtist = { artistId -> navController.navigate(ArtistDetailRoute(artistId)) },
              )
            }

            composable<ExploreRoute> {
              ExploreScreen(
                uiState = exploreState,
                activeTrack = activeTrack,
                favoriteIds = favoriteIds,
                purchasedIds = purchasedIds,
                bottomOverlayPadding = listBottomPadding,
                onQueryChange = { viewModel.updateSearchQuery(it) },
                onSelectGenre = { viewModel.selectGenre(it) },
                onSelectPaidFilter = { viewModel.selectPaidFilter(it) },
                onSelectSort = { viewModel.selectSort(it) },
                onRetry = { viewModel.loadExploreSongs() },
                onPlaySong = { song, queue -> viewModel.playSong(song, queue) },
                onPlayAll = { songs, shuffle -> viewModel.playAll(songs, shuffle) },
                onToggleFavorite = { viewModel.toggleFavorite(it) },
                onPurchaseSong = { viewModel.openPurchaseDialog(it) },
                onPlayNext = { viewModel.playNext(it) },
                onAddToQueue = { viewModel.addToQueue(it) },
                playCounts = listeningStats.songPlayCounts,
              )
            }

            composable<ChartsRoute> {
              ChartsScreen(
                discoverState = discoverState,
                activeTrack = activeTrack,
                favoriteIds = favoriteIds,
                purchasedIds = purchasedIds,
                bottomOverlayPadding = listBottomPadding,
                onRetry = { viewModel.refreshHome() },
                onPlaySong = { song, queue -> viewModel.playSong(song, queue) },
                onPlayAll = { songs, shuffle -> viewModel.playAll(songs, shuffle) },
                onToggleFavorite = { viewModel.toggleFavorite(it) },
                onPurchaseSong = { viewModel.openPurchaseDialog(it) },
                onPlayNext = { viewModel.playNext(it) },
                onAddToQueue = { viewModel.addToQueue(it) },
                playCounts = listeningStats.songPlayCounts,
              )
            }

            composable<LibraryRoute> {
              LibraryScreen(
                favorites = favorites,
                recentSongs = recentSongs,
                playlists = discoverState.playlists,
                activeTrack = activeTrack,
                favoriteIds = favoriteIds,
                purchasedIds = purchasedIds,
                currentUserId = authState.session?.user?.uid,
                bottomOverlayPadding = listBottomPadding,
                onPlaySong = { song, queue -> viewModel.playSong(song, queue) },
                onPlayAll = { songs, shuffle -> viewModel.playAll(songs, shuffle) },
                onToggleFavorite = { viewModel.toggleFavorite(it) },
                onPurchaseSong = { viewModel.openPurchaseDialog(it) },
                onOpenPlaylist = { playlistId -> navController.navigate(PlaylistDetailRoute(playlistId)) },
                onCreatePlaylist = { title, desc -> viewModel.createPlaylist(title, desc) },
                onPlayNext = { viewModel.playNext(it) },
                onAddToQueue = { viewModel.addToQueue(it) },
                playCounts = listeningStats.songPlayCounts,
              )
            }

            composable<ProfileRoute> {
              val allKnownSongs = remember(discoverState, exploreState, recentSongs, favorites) {
                (discoverState.popularSongs +
                  discoverState.latestSongs +
                  discoverState.albums.flatMap { it.songs } +
                  discoverState.chartSections.flatMap { it.songs } +
                  exploreState.songs +
                  recentSongs +
                  favorites).distinctBy { it.id }
              }
              ProfileScreen(
                authState = authState,
                sleepTimerState = sleepTimerState,
                bottomOverlayPadding = listBottomPadding,
                onLogin = { email, password -> viewModel.login(email, password) },
                onRegister = { email, password, name -> viewModel.register(email, password, name) },
                onRefreshProfile = { viewModel.refreshProfile() },
                onLogout = { viewModel.logout() },
                onClearAuthError = { viewModel.clearAuthError() },
                onPlayPurchasedSong = { songId -> viewModel.playPurchasedSong(songId) },
                onStartSleepTimer = { minutes -> viewModel.startSleepTimer(minutes) },
                onStartSleepAfterCurrentTrack = { viewModel.startSleepAfterCurrentTrack() },
                onCancelSleepTimer = { viewModel.cancelSleepTimer() },
                appearanceSettings = appearanceSettings,
                personalizationSettings = personalizationSettings,
                onThemeModeChange = { viewModel.setThemeMode(it) },
                onDynamicColorChange = { viewModel.setDynamicColor(it) },
                onColorPresetChange = { viewModel.setColorPreset(it) },
                onAmoledModeChange = { viewModel.setAmoledMode(it) },
                onOpenPersonalization = { section ->
                  navController.navigate(PersonalizationDetailRoute(section.name))
                },
                blockedSongIds = blockedSongIds,
                allKnownSongs = allKnownSongs,
                onUpdateDisplayName = { viewModel.updateDisplayName(it) },
                onUnblockSong = { viewModel.unblockSong(it) },
              )
            }

            composable<PersonalizationDetailRoute> { backStackEntry ->
              val route = backStackEntry.toRoute<PersonalizationDetailRoute>()
              val section = remember(route.sectionName) {
                runCatching { PersonalizationSection.valueOf(route.sectionName) }
                  .getOrDefault(PersonalizationSection.COLOR_CUSTOMIZATION)
              }
              PersonalizationDetailScreen(
                section = section,
                appearanceSettings = appearanceSettings,
                personalization = personalizationSettings,
                sleepTimerState = sleepTimerState,
                bottomOverlayPadding = listBottomPadding,
                onBack = { navController.popBackStack() },
                onThemeModeChange = { viewModel.setThemeMode(it) },
                onColorPresetChange = { viewModel.setColorPreset(it) },
                onAmoledModeChange = { viewModel.setAmoledMode(it) },
                onDynamicColorChange = { viewModel.setDynamicColor(it) },
                onPaletteStyleChange = { viewModel.setPaletteStyle(it) },
                onStartSleepTimer = { viewModel.startSleepTimer(it) },
                onStartSleepAfterCurrentTrack = { viewModel.startSleepAfterCurrentTrack() },
                onCancelSleepTimer = { viewModel.cancelSleepTimer() },
                onSleepTimerFadeOutChange = { viewModel.setSleepTimerFadeOut(it) },
                onPlaybackSpeedChange = { viewModel.setPlaybackSpeed(it) },
                onRotateArtworkChange = { viewModel.setRotateArtwork(it) },
                onUseWavySeekbarChange = { viewModel.setUseWavySeekbar(it) },
                onShowMiniPlayerProgressChange = { viewModel.setShowMiniPlayerProgress(it) },
                onKeepScreenOnPlayerChange = { viewModel.setKeepScreenOnPlayer(it) },
                onFontOptionChange = { viewModel.setFontOption(it) },
                onFontScaleChange = { viewModel.setFontScale(it) },
                onFloatingNavBarEnabledChange = { viewModel.setFloatingNavBarEnabled(it) },
                onNavBarLabelBehaviorChange = { viewModel.setNavBarLabelBehavior(it) },
                onShowDetachedSearchFabChange = { viewModel.setShowDetachedSearchFab(it) },
                onFestiveThemeModeChange = { viewModel.setFestiveThemeMode(it) },
                onFestiveParticlesEnabledChange = { viewModel.setFestiveParticlesEnabled(it) },
                onSwipeDownToDismissPlayerChange = { viewModel.setSwipeDownToDismissPlayer(it) },
                onSwipeArtworkToSkipChange = { viewModel.setSwipeArtworkToSkip(it) },
                onTapArtworkForLyricsChange = { viewModel.setTapArtworkForLyrics(it) },
                onMiniPlayerGesturesEnabledChange = { viewModel.setMiniPlayerGesturesEnabled(it) },
                onHapticFeedbackEnabledChange = { viewModel.setHapticFeedbackEnabled(it) },
                onEqualizerEnabledChange = { viewModel.setEqualizerEnabled(it) },
                onSelectEqualizerPreset = { viewModel.selectEqualizerPreset(it) },
                onSetEqualizerBand = { idx, gain -> viewModel.setEqualizerBand(idx, gain) },
                onBassBoostLevelChange = { viewModel.setBassBoostLevel(it) },
                onVirtualizerLevelChange = { viewModel.setVirtualizerLevel(it) },
                onLyricsAutoScrollChange = { viewModel.setLyricsAutoScroll(it) },
                onLyricsAlignmentChange = { viewModel.setLyricsAlignment(it) },
                onLyricsFontSizeChange = { viewModel.setLyricsFontSize(it) },
                onLyricsDimInactiveChange = { viewModel.setLyricsDimInactive(it) },
                onLyricsTapToSeekChange = { viewModel.setLyricsTapToSeek(it) },
                onSkipSilenceEnabledChange = { viewModel.setSkipSilenceEnabled(it) },
                onShowSeek10sButtonsChange = { viewModel.setShowSeek10sButtons(it) },
                onAlbumArtShapeChange = { viewModel.setAlbumArtShapeId(it) },
                onSongArtShapeChange = { viewModel.setSongArtShapeId(it) },
                onPlaylistArtShapeChange = { viewModel.setPlaylistArtShapeId(it) },
                onMiniPlayerShapeChange = { viewModel.setMiniPlayerShapeId(it) },
                onResetShapes = { viewModel.resetAllShapes() },
              )
            }

            composable<AlbumDetailRoute> { backStackEntry ->
              val route = backStackEntry.toRoute<AlbumDetailRoute>()
              LaunchedEffect(route.albumId) {
                viewModel.loadAlbumDetail(route.albumId)
              }
              val loadedAlbum = (albumDetailState as? com.example.ui.DetailLoadState.Success)?.data
              AlbumDetailScreen(
                state = albumDetailState,
                activeTrack = activeTrack,
                favoriteIds = favoriteIds,
                purchasedIds = purchasedIds,
                bottomOverlayPadding = listBottomPadding,
                isAlbumFavorite = route.albumId in favoriteAlbumIds,
                onToggleAlbumFavorite = {
                  if (loadedAlbum != null) viewModel.toggleAlbumFavorite(loadedAlbum)
                },
                onBack = { navController.popBackStack() },
                onRetry = { viewModel.loadAlbumDetail(route.albumId) },
                onPlaySong = { song, queue -> viewModel.playSong(song, queue) },
                onPlayAll = { songs, shuffle -> viewModel.playAll(songs, shuffle) },
                onToggleFavorite = { viewModel.toggleFavorite(it) },
                onPurchaseSong = { viewModel.openPurchaseDialog(it) },
                onOpenArtist = { artistId -> navController.navigate(ArtistDetailRoute(artistId)) },
                onPlayNext = { viewModel.playNext(it) },
                onAddToQueue = { viewModel.addToQueue(it) },
                playCounts = listeningStats.songPlayCounts,
              )
            }

            composable<ArtistDetailRoute> { backStackEntry ->
              val route = backStackEntry.toRoute<ArtistDetailRoute>()
              LaunchedEffect(route.artistId) {
                viewModel.loadArtistDetail(route.artistId)
              }
              ArtistDetailScreen(
                state = artistDetailState,
                activeTrack = activeTrack,
                favoriteIds = favoriteIds,
                purchasedIds = purchasedIds,
                bottomOverlayPadding = listBottomPadding,
                onBack = { navController.popBackStack() },
                onRetry = { viewModel.loadArtistDetail(route.artistId) },
                onPlaySong = { song, queue -> viewModel.playSong(song, queue) },
                onPlayAll = { songs, shuffle -> viewModel.playAll(songs, shuffle) },
                onToggleFavorite = { viewModel.toggleFavorite(it) },
                onPurchaseSong = { viewModel.openPurchaseDialog(it) },
                onOpenAlbum = { albumId -> navController.navigate(AlbumDetailRoute(albumId)) },
                onPlayNext = { viewModel.playNext(it) },
                onAddToQueue = { viewModel.addToQueue(it) },
                playCounts = listeningStats.songPlayCounts,
              )
            }

            composable<PlaylistDetailRoute> { backStackEntry ->
              val route = backStackEntry.toRoute<PlaylistDetailRoute>()
              LaunchedEffect(route.playlistId) {
                viewModel.loadPlaylistDetail(route.playlistId)
              }
              PlaylistDetailScreen(
                state = playlistDetailState,
                currentUserId = authState.session?.user?.uid,
                activeTrack = activeTrack,
                favoriteIds = favoriteIds,
                purchasedIds = purchasedIds,
                bottomOverlayPadding = listBottomPadding,
                onBack = { navController.popBackStack() },
                onRetry = { viewModel.loadPlaylistDetail(route.playlistId) },
                onPlaySong = { song, queue -> viewModel.playSong(song, queue) },
                onPlayAll = { songs, shuffle -> viewModel.playAll(songs, shuffle) },
                onToggleFavorite = { viewModel.toggleFavorite(it) },
                onPurchaseSong = { viewModel.openPurchaseDialog(it) },
                onUpdatePlaylist = { id, title, desc -> viewModel.updatePlaylist(id, title, desc) },
                onDeletePlaylist = { id ->
                  viewModel.deletePlaylist(id) {
                    navController.popBackStack()
                  }
                },
                onPlayNext = { viewModel.playNext(it) },
                onAddToQueue = { viewModel.addToQueue(it) },
                playCounts = listeningStats.songPlayCounts,
              )
            }
          }
        }
      }
    }

    AnimatedVisibility(
      visible = showNowPlaying && hasActiveSong,
      enter = slideInVertically(
        animationSpec = spring(
          dampingRatio = Spring.DampingRatioNoBouncy,
          stiffness = 420f,
        ),
        initialOffsetY = { it },
      ) + fadeIn(animationSpec = tween(160)),
      exit = slideOutVertically(
        animationSpec = spring(
          dampingRatio = Spring.DampingRatioNoBouncy,
          stiffness = 460f,
        ),
        targetOffsetY = { it },
      ) + fadeOut(animationSpec = tween(150)),
    ) {
      NowPlayingHost(
        viewModel = viewModel,
        favoriteIds = favoriteIds,
        purchasedIds = purchasedIds,
        sleepTimerState = sleepTimerState,
        playlists = discoverState.playlists,
        currentUserId = authState.session?.user?.uid,
        playCounts = listeningStats.songPlayCounts,
        personalization = personalizationSettings,
        backHandlerEnabled = showNowPlaying && hasActiveSong && purchaseDialogState == null,
        onDismiss = { showNowPlaying = false },
        onOpenArtist = { artistId -> navController.navigate(ArtistDetailRoute(artistId)) },
        onOpenAlbum = { albumId -> navController.navigate(AlbumDetailRoute(albumId)) },
        onOpenEqualizer = {
          showNowPlaying = false
          navController.navigate(PersonalizationDetailRoute(PersonalizationSection.EQUALIZER.name))
        },
      )
    }

    FestiveParticlesOverlay(
      festiveThemeMode = personalizationSettings.festiveThemeMode,
      enabled = personalizationSettings.festiveParticlesEnabled,
    )

    val activePurchase = purchaseDialogState
    if (activePurchase != null) {
      PurchaseSongDialog(
        state = activePurchase,
        isSignedIn = authState.session != null,
        onVoucherCodeChange = { viewModel.updateVoucherInput(it) },
        onCheckVoucher = { viewModel.validateVoucherForDialog() },
        onConfirmPurchase = { viewModel.confirmPurchaseSong() },
        onNavigateToProfile = { navigateTopLevel(ProfileRoute) },
        onDismiss = { viewModel.dismissPurchaseDialog() },
      )
    }

    BackHandler(enabled = showNowPlaying && purchaseDialogState == null && !hasActiveSong) {
      showNowPlaying = false
    }

    BackHandler(enabled = purchaseDialogState != null) {
      viewModel.dismissPurchaseDialog()
    }

    BackHandler(
      enabled = !showNowPlaying && purchaseDialogState == null && !canPopBack,
    ) {
      val now = SystemClock.elapsedRealtime()
      if (now - lastRootBackPressMs <= 2_000L) {
        lastRootBackPressMs = 0L
        if (activeTrack.isPlaying) {
          context.findActivity()?.moveTaskToBack(true)
        } else {
          context.findActivity()?.finish()
        }
      } else {
        lastRootBackPressMs = now
        val msg = if (activeTrack.isPlaying) {
          "Nhấn Back lần nữa để thu nhỏ ứng dụng (nhạc vẫn phát)"
        } else {
          "Nhấn Back lần nữa để thoát ứng dụng"
        }
        Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
      }
    }
  }
}

private tailrec fun Context.findActivity(): Activity? = when (this) {
  is Activity -> this
  is ContextWrapper -> baseContext.findActivity()
  else -> null
}

@Composable
private fun MiniPlayerHost(
  viewModel: MusicViewModel,
  favoriteIds: Set<String>,
  personalization: PersonalizationSettings,
  useNavRail: Boolean,
  snackbarHostState: SnackbarHostState,
  onExpandClick: () -> Unit,
) {
  val playbackState by viewModel.playbackState.collectAsStateWithLifecycle()

  LaunchedEffect(playbackState.playbackError) {
    val err = playbackState.playbackError
    if (!err.isNullOrBlank()) {
      snackbarHostState.showSnackbar(err)
      viewModel.clearPlaybackError()
    }
  }

  val currentSong = playbackState.currentSong ?: return
  MiniPlayerBar(
    playbackState = playbackState,
    isFavorite = currentSong.id in favoriteIds,
    onExpandClick = onExpandClick,
    onTogglePlayPause = { viewModel.togglePlayPause() },
    onSkipNext = { viewModel.skipNext() },
    onSkipPrevious = { viewModel.skipPrevious() },
    onToggleFavorite = { viewModel.toggleFavorite(currentSong) },
    onDismissClick = { viewModel.stopAndDismissPlayer() },
    showProgressBar = personalization.showMiniPlayerProgress,
    gesturesEnabled = personalization.miniPlayerGesturesEnabled,
    modifier = if (useNavRail) {
      Modifier.windowInsetsPadding(WindowInsets.navigationBars)
    } else {
      Modifier
    },
  )
}

@Composable
private fun NowPlayingHost(
  viewModel: MusicViewModel,
  favoriteIds: Set<String>,
  purchasedIds: Set<String>,
  sleepTimerState: SleepTimerUiState,
  playlists: List<com.example.model.Playlist>,
  currentUserId: String?,
  playCounts: Map<String, Int>,
  personalization: PersonalizationSettings,
  backHandlerEnabled: Boolean,
  onDismiss: () -> Unit,
  onOpenArtist: (String) -> Unit,
  onOpenAlbum: (String) -> Unit,
  onOpenEqualizer: () -> Unit,
) {
  val playbackState by viewModel.playbackState.collectAsStateWithLifecycle()
  val activeSong = playbackState.currentSong ?: return

  NowPlayingSheet(
    playbackState = playbackState,
    favoriteIds = favoriteIds,
    purchasedIds = purchasedIds,
    sleepTimerState = sleepTimerState,
    playlists = playlists,
    currentUserId = currentUserId,
    playCountOnDevice = playCounts[activeSong.id] ?: 0,
    backHandlerEnabled = backHandlerEnabled,
    personalization = personalization,
    onDismiss = onDismiss,
    onTogglePlayPause = { viewModel.togglePlayPause() },
    onSkipNext = { viewModel.skipNext() },
    onSkipPrevious = { viewModel.skipPrevious() },
    onSeekTo = { viewModel.seekTo(it) },
    onSeekRelative = { viewModel.seekRelative(it) },
    onToggleShuffle = { viewModel.toggleShuffle() },
    onCycleRepeat = { viewModel.cycleRepeatMode() },
    onToggleFavorite = { viewModel.toggleFavorite(it) },
    onPlayQueueItem = { song, queue -> viewModel.playSong(song, queue) },
    onRemoveQueueItem = { viewModel.removeFromQueue(it) },
    onMoveQueueItem = { from, to -> viewModel.moveQueueItem(from, to) },
    onShuffleUpcomingQueue = { viewModel.shuffleUpcomingQueue() },
    onClearUpcomingQueue = { viewModel.clearUpcomingQueue() },
    onSetPlaybackSpeed = { viewModel.setPlaybackSpeed(it) },
    onOpenEqualizer = onOpenEqualizer,
    onOpenArtist = onOpenArtist,
    onOpenAlbum = onOpenAlbum,
    onPurchaseSong = { song -> viewModel.openPurchaseDialog(song) },
    onStartSleepTimer = { mins -> viewModel.startSleepTimer(mins) },
    onStartSleepAfterCurrentTrack = { viewModel.startSleepAfterCurrentTrack() },
    onCancelSleepTimer = { viewModel.cancelSleepTimer() },
    onSleepTimerFadeOutChange = { viewModel.setSleepTimerFadeOut(it) },
    onDownloadSong = { song -> viewModel.downloadSong(song) },
    onAddSongToPlaylist = { playlist, song -> viewModel.addSongToPlaylist(playlist, song) },
    onCreatePlaylistWithSong = { title, desc -> viewModel.createPlaylist(title, desc) },
    onReportSong = { song, reason, detail -> viewModel.reportSong(song, reason, detail) },
    onBlockSong = { song -> viewModel.blockSong(song) },
  )
}
