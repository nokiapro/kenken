@file:OptIn(ExperimentalTextApi::class)

package com.example.ui.rhythm

import android.content.Context
import android.os.Build
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.painter.Painter
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.role
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.ExperimentalTextApi
import androidx.compose.ui.text.PlatformTextStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontVariation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.res.ResourcesCompat
import com.example.R
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap

private const val MaterialSymbolGlyphScale = 0.875f

/**
 * Thread-safe cache and fallback provider for Rhythm's Material Symbols variable icon font.
 */
private object RhythmIconFontCache {
  private val cache = ConcurrentHashMap<String, FontFamily>()
  private var fallbackFontFamily: FontFamily? = null
  private val lock = Any()

  fun getFallbackFontFamily(context: Context): FontFamily {
    fallbackFontFamily?.let { return it }
    synchronized(lock) {
      fallbackFontFamily?.let { return it }
      val tf = try {
        ResourcesCompat.getFont(context, R.font.material_symbols_outlined)
      } catch (_: Throwable) {
        null
      }
      val ff = if (tf != null) {
        FontFamily(tf)
      } else {
        FontFamily(Font(R.font.material_symbols_outlined))
      }
      fallbackFontFamily = ff
      return ff
    }
  }

  fun getOrCreate(
    context: Context,
    filled: Boolean,
    weight: Int,
    grade: Float,
    opticalSize: Float,
  ): FontFamily {
    val manufacturer = Build.MANUFACTURER.lowercase(Locale.US)
    val isXiaomiDevice = manufacturer.contains("xiaomi") ||
      manufacturer.contains("redmi") ||
      manufacturer.contains("poco")
    if (isXiaomiDevice) {
      return getFallbackFontFamily(context)
    }

    val key = "$filled-$weight-$grade-$opticalSize"
    return cache.getOrPut(key) {
      try {
        FontFamily(
          Font(
            resId = R.font.material_symbols_outlined,
            variationSettings = FontVariation.Settings(
              FontVariation.weight(weight),
              FontVariation.Setting("FILL", if (filled) 1f else 0f),
              FontVariation.Setting("GRAD", grade),
              FontVariation.Setting("opsz", opticalSize),
            ),
          ),
        )
      } catch (_: Throwable) {
        getFallbackFontFamily(context)
      }
    }
  }
}

/**
 * Representation of a Material Symbol variable-font icon in Rhythm (`FILL`, `wght`, `GRAD`, `opsz`).
 */
data class MaterialSymbolIcon(
  val name: String,
  val filled: Boolean = false,
  val defaultWeight: Int = 400,
) {
  fun filled(): MaterialSymbolIcon = copy(filled = true)
  fun outlined(): MaterialSymbolIcon = copy(filled = false)
}

@Composable
fun rememberSymbolsFontFamily(
  filled: Boolean = false,
  weight: Int = 400,
  grade: Float = 0f,
  opticalSize: Float = 24f,
): FontFamily {
  val context = LocalContext.current
  return remember(filled, weight, grade, opticalSize) {
    RhythmIconFontCache.getOrCreate(context, filled, weight, grade, opticalSize)
  }
}

@Composable
fun RhythmSymbolIcon(
  icon: MaterialSymbolIcon,
  contentDescription: String?,
  modifier: Modifier = Modifier,
  tint: Color = LocalContentColor.current,
  size: Dp = 24.dp,
  weight: Int = icon.defaultWeight,
  grade: Float = 0f,
) {
  val fontFamily = rememberSymbolsFontFamily(
    filled = icon.filled,
    weight = weight,
    grade = grade,
    opticalSize = size.value * MaterialSymbolGlyphScale,
  )

  BoxWithConstraints(
    modifier = modifier.semantics(mergeDescendants = true) {
      if (contentDescription != null) {
        this.contentDescription = contentDescription
      }
      this.role = Role.Image
    },
    contentAlignment = Alignment.Center,
  ) {
    val slotSize = if (maxWidth != Dp.Infinity && maxHeight != Dp.Infinity) {
      minOf(maxWidth, maxHeight)
    } else {
      size
    }
    val glyphSize = slotSize * MaterialSymbolGlyphScale

    Text(
      text = icon.name,
      fontFamily = fontFamily,
      fontSize = glyphSize.value.sp,
      color = tint,
      textAlign = TextAlign.Center,
      maxLines = 1,
      softWrap = false,
      overflow = TextOverflow.Clip,
      style = TextStyle(
        lineHeight = glyphSize.value.sp,
        platformStyle = PlatformTextStyle(includeFontPadding = false),
      ),
    )
  }
}

@Composable
fun RhythmIcon(
  imageVector: MaterialSymbolIcon,
  contentDescription: String?,
  modifier: Modifier = Modifier,
  tint: Color = LocalContentColor.current,
  size: Dp = 24.dp,
  weight: Int = imageVector.defaultWeight,
  grade: Float = 0f,
) {
  RhythmSymbolIcon(
    icon = imageVector,
    contentDescription = contentDescription,
    modifier = modifier,
    tint = tint,
    size = size,
    weight = weight,
    grade = grade,
  )
}

@Composable
fun RhythmIcon(
  imageVector: ImageVector,
  contentDescription: String?,
  modifier: Modifier = Modifier,
  tint: Color = LocalContentColor.current,
) {
  androidx.compose.material3.Icon(
    imageVector = imageVector,
    contentDescription = contentDescription,
    modifier = modifier,
    tint = tint,
  )
}

@Composable
fun RhythmIcon(
  painter: Painter,
  contentDescription: String?,
  modifier: Modifier = Modifier,
  tint: Color = LocalContentColor.current,
) {
  androidx.compose.material3.Icon(
    painter = painter,
    contentDescription = contentDescription,
    modifier = modifier,
    tint = tint,
  )
}

@Composable
fun RhythmIcon(
  bitmap: ImageBitmap,
  contentDescription: String?,
  modifier: Modifier = Modifier,
  tint: Color = LocalContentColor.current,
) {
  androidx.compose.material3.Icon(
    bitmap = bitmap,
    contentDescription = contentDescription,
    modifier = modifier,
    tint = tint,
  )
}

/**
 * Helper wrapper allowing components (e.g. Settings items, Nav items, Action buttons)
 * to accept either genuine Rhythm [MaterialSymbolIcon] or standard [ImageVector] seamlessly.
 */
@Composable
fun AnyIcon(
  icon: Any,
  contentDescription: String?,
  modifier: Modifier = Modifier,
  tint: Color = LocalContentColor.current,
  size: Dp = 24.dp,
) {
  when (icon) {
    is MaterialSymbolIcon -> RhythmSymbolIcon(
      icon = icon,
      contentDescription = contentDescription,
      modifier = modifier,
      tint = tint,
      size = size,
    )
    is ImageVector -> androidx.compose.material3.Icon(
      imageVector = icon,
      contentDescription = contentDescription,
      modifier = modifier,
      tint = tint,
    )
    is Painter -> androidx.compose.material3.Icon(
      painter = icon,
      contentDescription = contentDescription,
      modifier = modifier,
      tint = tint,
    )
  }
}
