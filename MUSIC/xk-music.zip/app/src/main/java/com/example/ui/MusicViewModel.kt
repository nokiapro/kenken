package com.example.ui

import android.app.Application
import android.app.DownloadManager
import android.content.Context
import android.net.Uri
import android.os.Environment
import android.os.SystemClock
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.network.ApiClient
import com.example.data.network.XkJsonParser
import com.example.data.repository.AccountRepository
import com.example.data.repository.LocalLibraryStore
import com.example.data.repository.MusicRepository
import com.example.model.Album
import com.example.model.ApiResult
import com.example.model.Artist
import com.example.model.ListeningStats
import com.example.model.Playlist
import com.example.model.SiteInfo
import com.example.model.SleepTimerUiState
import com.example.model.Song
import com.example.player.AudioEqualizerManager
import com.example.player.PlaybackAudioConfig
import com.example.player.PlaybackManager
import com.example.player.PlaybackUiState
import kotlinx.coroutines.Job
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MusicViewModel(application: Application) : AndroidViewModel(application) {

  private val localStore = LocalLibraryStore(application)
  private val repository = MusicRepository(localStore = localStore)
  private val accountRepository = AccountRepository(localStore = localStore)
  private val verifiedMasterIds = java.util.Collections.synchronizedSet(mutableSetOf<String>())
  private var lastSyncedUid: String? = null

  private val playbackManager: PlaybackManager = PlaybackManager(
    context = application,
    onSongChanged = { song ->
      viewModelScope.launch {
        repository.recordPlayed(song)
        repository.recordSongPlay(song.id)
        enrichSongDetail(song)
        verifyFullStreamIfPurchased(song)
      }
    },
    onSleepTimerAutoPaused = {
      _sleepTimerState.value = SleepTimerUiState()
      _snackbarMessage.value = "Đã tắt nhạc khi kết thúc bài hát hiện tại."
    },
  )

  val playbackState: StateFlow<PlaybackUiState> = playbackManager.state

  val activeTrackMeta: StateFlow<ActiveTrackMeta> = playbackState
    .map { ActiveTrackMeta(songId = it.currentSong?.id, isPlaying = it.isPlaying) }
    .distinctUntilChanged()
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), ActiveTrackMeta())

  private val _discoverState = MutableStateFlow(DiscoverUiState())
  val discoverState: StateFlow<DiscoverUiState> = _discoverState.asStateFlow()

  private val _exploreState = MutableStateFlow(ExploreUiState())
  val exploreState: StateFlow<ExploreUiState> = _exploreState.asStateFlow()

  private val _albumDetailState = MutableStateFlow<DetailLoadState<Album>>(DetailLoadState.Loading)
  val albumDetailState: StateFlow<DetailLoadState<Album>> = _albumDetailState.asStateFlow()

  private val _artistDetailState = MutableStateFlow<DetailLoadState<Artist>>(DetailLoadState.Loading)
  val artistDetailState: StateFlow<DetailLoadState<Artist>> = _artistDetailState.asStateFlow()

  private val _playlistDetailState = MutableStateFlow<DetailLoadState<Playlist>>(DetailLoadState.Loading)
  val playlistDetailState: StateFlow<DetailLoadState<Playlist>> = _playlistDetailState.asStateFlow()

  private val _authState = MutableStateFlow(AuthUiState())
  val authState: StateFlow<AuthUiState> = _authState.asStateFlow()

  private val _sleepTimerState = MutableStateFlow(SleepTimerUiState())
  val sleepTimerState: StateFlow<SleepTimerUiState> = _sleepTimerState.asStateFlow()

  private val _purchaseDialogState = MutableStateFlow<PurchaseDialogState?>(null)
  val purchaseDialogState: StateFlow<PurchaseDialogState?> = _purchaseDialogState.asStateFlow()

  private val _snackbarMessage = MutableStateFlow<String?>(null)
  val snackbarMessage: StateFlow<String?> = _snackbarMessage.asStateFlow()

  val favorites: StateFlow<List<Song>> = repository.favoritesFlow
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

  val favoriteIds: StateFlow<Set<String>> = favorites
    .map { list -> list.map { it.id }.toSet() }
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptySet())

  val favoriteAlbumIds: StateFlow<Set<String>> = repository.favoriteAlbumIdsFlow
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptySet())

  val blockedSongIds: StateFlow<Set<String>> = repository.blockedSongIdsFlow
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptySet())

  val recentSongs: StateFlow<List<Song>> = repository.recentFlow
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

  val purchasedIds: StateFlow<Set<String>> = _authState
    .map { state ->
      buildSet {
        state.session?.user?.purchasedSongIds?.forEach { if (it.isNotBlank()) add(it) }
        state.purchases.forEach { if (it.songId.isNotBlank()) add(it.songId) }
      }
    }
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptySet())

  val appearanceSettings: StateFlow<AppearanceSettings> = localStore.appearanceFlow
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), AppearanceSettings())

  val personalizationSettings: StateFlow<PersonalizationSettings> = localStore.personalizationFlow
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), PersonalizationSettings())

  val listeningStats: StateFlow<ListeningStats> = repository.listeningStatsFlow
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), ListeningStats())

  private val isAdminUser: Boolean
    get() = _authState.value.session?.user?.role.equals("admin", ignoreCase = true)

  private var searchDebounceJob: Job? = null
  private var sleepTimerJob: Job? = null
  private var lastAutoSyncMs: Long = 0L

  fun onAppResumed() {
    val now = SystemClock.elapsedRealtime()
    if (lastAutoSyncMs != 0L && now - lastAutoSyncMs < 15_000L) return
    lastAutoSyncMs = now
    refreshHome(silent = true)
    loadExploreSongs(silent = true)
    if (_authState.value.session != null) {
      refreshProfile(silent = true)
    }
  }

  init {
    viewModelScope.launch {
      accountRepository.restoreTokenIntoClient()
      accountRepository.authSessionFlow.collectLatest { session ->
        ApiClient.setUserToken(session?.idToken)
        _authState.update { it.copy(session = session) }
        if (session != null) {
          val freshSession = accountRepository.ensureFreshSession() ?: session
          val uid = freshSession.user.uid
          if (uid != lastSyncedUid) {
            lastSyncedUid = uid
            val meRes = accountRepository.fetchMe()
            if (meRes is ApiResult.Success) {
              repository.mergeRemoteFavorites(meRes.data.likedSongIds)
            }
            loadPurchasesInternal()
            refreshPlaylistsAndEntitlements()
            syncRemoteSettingsAndBlocks()
          } else {
            unlockPurchasedAudioUrls()
          }
        } else {
          lastSyncedUid = null
          verifiedMasterIds.clear()
          _authState.update { it.copy(purchases = emptyList()) }
          refreshPlaylistsOnly()
        }
      }
    }
    viewModelScope.launch {
      playbackState
        .map { it.isPlaying && it.currentSong != null }
        .distinctUntilChanged()
        .collectLatest { isActivelyPlaying ->
          if (isActivelyPlaying) {
            var lastTickMs = SystemClock.elapsedRealtime()
            try {
              while (isActive) {
                delay(5_000L)
                val now = SystemClock.elapsedRealtime()
                val delta = (now - lastTickMs).coerceIn(0L, 15_000L)
                lastTickMs = now
                if (delta > 0L) {
                  repository.addListeningTime(delta)
                }
              }
            } finally {
              val now = SystemClock.elapsedRealtime()
              val delta = (now - lastTickMs).coerceIn(0L, 15_000L)
              if (delta > 0L) {
                withContext(NonCancellable) {
                  repository.addListeningTime(delta)
                }
              }
            }
          }
        }
    }
    viewModelScope.launch {
      personalizationSettings.collectLatest { settings ->
        playbackManager.setPlaybackSpeed(settings.playbackSpeed)
        PlaybackAudioConfig.setSkipSilenceEnabled(settings.skipSilenceEnabled)
        AudioEqualizerManager.applySettings(
          enabled = settings.equalizerEnabled,
          bandsDb = settings.equalizerBandsDb,
          bassBoostLevel = settings.bassBoostLevel,
          virtualizerLevel = settings.virtualizerLevel,
        )
      }
    }
    refreshHome()
    loadExploreSongs()
  }

  fun refreshHome(silent: Boolean = false) {
    viewModelScope.launch {
      if (!silent || (_discoverState.value.popularSongs.isEmpty() && _discoverState.value.albums.isEmpty())) {
        _discoverState.update { it.copy(isLoading = true, errorMessage = null) }
      }
      val blocked = blockedSongIds.value
      val homeBundle = repository.fetchHomeBundle()
      if (homeBundle != null && (homeBundle.popularSongs.isNotEmpty() || homeBundle.chartSections.isNotEmpty())) {
        val visibleSongs = homeBundle.popularSongs.filterNot { it.id in blocked }
        val visibleCharts = homeBundle.chartSections.map { sec ->
          sec.copy(songs = sec.songs.filterNot { it.id in blocked })
        }.filter { it.songs.isNotEmpty() }
        val visibleFeatured = homeBundle.siteInfo.featuredSongs.filterNot { it.id in blocked }
        val discoveredGenres = buildList {
          addAll(homeBundle.siteInfo.genres)
          visibleSongs.flatMap { it.genre.split(",") }
            .map { it.trim() }
            .filter { it.isNotBlank() }
            .forEach { add(it) }
          homeBundle.albums.mapNotNull { it.genre?.takeIf { g -> g.isNotBlank() } }.forEach { add(it) }
        }.distinct()
        _exploreState.update { exp ->
          exp.copy(availableGenres = (exp.availableGenres + discoveredGenres).distinct())
        }
        val visibleLatestSongs = if (homeBundle.latestSongs.isNotEmpty()) {
          homeBundle.latestSongs.filterNot { it.id in blocked }
        } else {
          val fetchedLatest = (repository.fetchSongs(sort = "latest") as? ApiResult.Success)?.data
            ?.filterNot { it.id in blocked }
            .orEmpty()
          fetchedLatest.ifEmpty {
            if (visibleSongs.any { it.createdAtMs > 0L }) {
              visibleSongs.sortedByDescending { it.createdAtMs }
            } else {
              visibleSongs.reversed()
            }
          }
        }
        _discoverState.value = DiscoverUiState(
          isLoading = false,
          siteInfo = homeBundle.siteInfo.copy(featuredSongs = visibleFeatured),
          chartSections = visibleCharts,
          playlists = homeBundle.playlists,
          albums = homeBundle.albums,
          artists = homeBundle.artists,
          popularSongs = visibleSongs,
          latestSongs = visibleLatestSongs,
          errorMessage = null,
          isMissingApiKey = false,
        )
        unlockPurchasedAudioUrls()
        return@launch
      }

      repository.refreshRtdbSnapshot()
      val session = _authState.value.session
      val admin = isAdminUser
      coroutineScope {
        val siteDeferred = async { repository.fetchSiteInfo() }
        val chartsDeferred = async { repository.fetchCharts() }
        val playlistsDeferred = async {
          repository.fetchPlaylists(
            userId = session?.user?.uid,
            authToken = session?.idToken,
            isAdmin = admin,
          )
        }
        val albumsDeferred = async { repository.fetchAlbums() }
        val artistsDeferred = async { repository.fetchArtists() }
        val songsDeferred = async { repository.fetchSongs(sort = "popular") }
        val latestSongsDeferred = async { repository.fetchSongs(sort = "latest") }

        val siteRes = siteDeferred.await()
        val chartsRes = chartsDeferred.await()
        val playlistsRes = playlistsDeferred.await()
        val albumsRes = albumsDeferred.await()
        val artistsRes = artistsDeferred.await()
        val songsRes = songsDeferred.await()
        val latestSongsRes = latestSongsDeferred.await()

        val errors = listOf(siteRes, chartsRes, playlistsRes, albumsRes, artistsRes, songsRes)
          .filterIsInstance<ApiResult.Error>()
        val anySuccess = listOf(siteRes, chartsRes, playlistsRes, albumsRes, artistsRes, songsRes, latestSongsRes)
          .any { it is ApiResult.Success }

        val siteInfoRaw = (siteRes as? ApiResult.Success)?.data ?: SiteInfo()
        val siteInfo = siteInfoRaw.copy(
          featuredSongs = siteInfoRaw.featuredSongs.filterNot { it.id in blocked },
        )
        val charts = ((chartsRes as? ApiResult.Success)?.data ?: emptyList())
          .map { sec -> sec.copy(songs = sec.songs.filterNot { it.id in blocked }) }
          .filter { it.songs.isNotEmpty() }
        val playlists = (playlistsRes as? ApiResult.Success)?.data ?: emptyList()
        val albums = (albumsRes as? ApiResult.Success)?.data ?: emptyList()
        val artists = (artistsRes as? ApiResult.Success)?.data ?: emptyList()
        val songs = ((songsRes as? ApiResult.Success)?.data ?: emptyList())
          .filterNot { it.id in blocked }
        val latestSongs = ((latestSongsRes as? ApiResult.Success)?.data ?: emptyList())
          .filterNot { it.id in blocked }
          .ifEmpty {
            if (songs.any { it.createdAtMs > 0L }) songs.sortedByDescending { it.createdAtMs } else songs.reversed()
          }

        val discoveredGenres = buildList {
          addAll(siteInfo.genres)
          songs.flatMap { it.genre.split(",") }
            .map { it.trim() }
            .filter { it.isNotBlank() }
            .forEach { add(it) }
          albums.mapNotNull { it.genre?.takeIf { g -> g.isNotBlank() } }.forEach { add(it) }
        }.distinct()

        _exploreState.update { exp ->
          exp.copy(availableGenres = (exp.availableGenres + discoveredGenres).distinct())
        }

        val firstError = errors.firstOrNull()
        _discoverState.update {
          DiscoverUiState(
            isLoading = false,
            siteInfo = siteInfo,
            chartSections = charts,
            playlists = playlists,
            albums = albums,
            artists = artists,
            popularSongs = songs,
            latestSongs = latestSongs,
            errorMessage = if (!anySuccess) firstError?.message else null,
            isMissingApiKey = (!anySuccess && (firstError?.isMissingApiKey == true || !ApiClient.isApiKeyConfigured())),
          )
        }
      }
      unlockPurchasedAudioUrls()
    }
  }

  fun updateSearchQuery(query: String) {
    _exploreState.update { it.copy(query = query) }
    searchDebounceJob?.cancel()
    searchDebounceJob = viewModelScope.launch {
      delay(320L)
      loadExploreSongs()
    }
  }

  fun selectGenre(genre: String) {
    val nextGenre = if (_exploreState.value.selectedGenre == genre) "" else genre
    _exploreState.update { it.copy(selectedGenre = nextGenre) }
    loadExploreSongs()
  }

  fun selectPaidFilter(filter: PaidFilter) {
    _exploreState.update { it.copy(paidFilter = filter) }
    loadExploreSongs()
  }

  fun selectSort(sort: SongSort) {
    _exploreState.update { it.copy(sortOrder = sort) }
    loadExploreSongs()
  }

  fun loadExploreSongs(silent: Boolean = false) {
    val snapshot = _exploreState.value
    viewModelScope.launch {
      if (!silent || snapshot.songs.isEmpty()) {
        _exploreState.update { it.copy(isLoading = true, errorMessage = null) }
      }
      when (
        val result = repository.fetchSongs(
          query = snapshot.query,
          genre = snapshot.selectedGenre,
          paid = snapshot.paidFilter.apiValue,
          sort = snapshot.sortOrder.apiValue,
        )
      ) {
        is ApiResult.Success -> {
          val blocked = blockedSongIds.value
          val visibleSongs = result.data.filterNot { it.id in blocked }
          val extraGenres = visibleSongs
            .flatMap { it.genre.split(",") }
            .map { it.trim() }
            .filter { it.isNotBlank() }
          _exploreState.update { current ->
            current.copy(
              isLoading = false,
              songs = visibleSongs,
              availableGenres = (current.availableGenres + extraGenres).distinct(),
              errorMessage = null,
              isMissingApiKey = false,
            )
          }
        }
        is ApiResult.Error -> {
          _exploreState.update { current ->
            current.copy(
              isLoading = false,
              errorMessage = if (silent && current.songs.isNotEmpty()) current.errorMessage else result.message,
              isMissingApiKey = if (silent && current.songs.isNotEmpty()) current.isMissingApiKey else result.isMissingApiKey,
            )
          }
        }
      }
    }
  }

  fun loadAlbumDetail(albumId: String) {
    viewModelScope.launch {
      _albumDetailState.value = DetailLoadState.Loading
      when (val result = repository.fetchAlbumDetail(albumId)) {
        is ApiResult.Success -> {
          val album = result.data ?: _discoverState.value.albums.firstOrNull { it.id == albumId }
          _albumDetailState.value = if (album != null) {
            DetailLoadState.Success(album)
          } else {
            DetailLoadState.Error("Không tìm thấy thông tin album.")
          }
        }
        is ApiResult.Error -> {
          val cached = _discoverState.value.albums.firstOrNull { it.id == albumId }
          _albumDetailState.value = if (cached != null && cached.songs.isNotEmpty()) {
            DetailLoadState.Success(cached)
          } else {
            DetailLoadState.Error(result.message)
          }
        }
      }
    }
  }

  fun loadArtistDetail(artistId: String) {
    viewModelScope.launch {
      _artistDetailState.value = DetailLoadState.Loading
      when (val result = repository.fetchArtistDetail(artistId)) {
        is ApiResult.Success -> {
          val artist = result.data ?: _discoverState.value.artists.firstOrNull { it.id == artistId }
          _artistDetailState.value = if (artist != null) {
            DetailLoadState.Success(artist)
          } else {
            DetailLoadState.Error("Không tìm thấy thông tin nghệ sĩ.")
          }
        }
        is ApiResult.Error -> {
          val cached = _discoverState.value.artists.firstOrNull { it.id == artistId }
          _artistDetailState.value = if (cached != null) {
            DetailLoadState.Success(cached)
          } else {
            DetailLoadState.Error(result.message)
          }
        }
      }
    }
  }

  fun loadPlaylistDetail(playlistId: String) {
    viewModelScope.launch {
      _playlistDetailState.value = DetailLoadState.Loading
      val cached = _discoverState.value.playlists.firstOrNull { it.id == playlistId }
      when (val result = repository.fetchPlaylistDetail(playlistId)) {
        is ApiResult.Success -> {
          val playlist = result.data ?: cached
          _playlistDetailState.value = if (playlist != null) {
            DetailLoadState.Success(playlist)
          } else {
            DetailLoadState.Error("Không tìm thấy playlist.")
          }
        }
        is ApiResult.Error -> {
          _playlistDetailState.value = if (cached != null) {
            DetailLoadState.Success(cached)
          } else {
            DetailLoadState.Error(result.message)
          }
        }
      }
    }
  }

  fun playSong(song: Song, queue: List<Song> = listOf(song), shuffle: Boolean = false) {
    viewModelScope.launch {
      val freshSession = accountRepository.ensureFreshSession()
      val freshToken = freshSession?.idToken ?: _authState.value.session?.idToken
      val ownedIds = purchasedIds.value
      val admin = isAdminUser
      val hasPaidAccess = song.id in ownedIds || admin

      val resolvedUrl = if (hasPaidAccess) {
        val masterUrl = repository.fetchSongStreamUrl(song.id, freshToken, preferFullMaster = true)
        if (!masterUrl.isNullOrBlank() && !XkJsonParser.looksLikeDemoUrl(masterUrl)) {
          verifiedMasterIds.add(song.id)
        }
        masterUrl ?: song.audioUrl?.takeIf { it.isNotBlank() }
      } else {
        song.audioUrl?.takeIf { it.isNotBlank() }
          ?: repository.fetchSongStreamUrl(song.id, freshToken, preferFullMaster = false)
      }

      val fullSong = if (!resolvedUrl.isNullOrBlank()) {
        song.copy(audioUrl = resolvedUrl)
      } else {
        (repository.fetchSongDetail(song.id) as? ApiResult.Success)?.data ?: song
      }

      if (fullSong.audioUrl.isNullOrBlank() && fullSong.isPaid && !hasPaidAccess) {
        openPurchaseDialog(fullSong)
        return@launch
      }

      val baseQueue = queue.ifEmpty { listOf(fullSong) }
      // Hydrate full/master URLs for any other purchased/admin songs in the queue so skipNext/auto-next plays full tracks
      val extraResolved = coroutineScope {
        baseQueue
          .filter { qSong ->
            qSong.id != fullSong.id &&
              (qSong.id in ownedIds || admin) &&
              qSong.id !in verifiedMasterIds
          }
          .distinctBy { it.id }
          .map { qSong ->
            async {
              val url = repository.fetchSongStreamUrl(qSong.id, freshToken, preferFullMaster = true)
              if (!url.isNullOrBlank() && !XkJsonParser.looksLikeDemoUrl(url)) {
                verifiedMasterIds.add(qSong.id)
                qSong.id to url
              } else {
                null
              }
            }
          }
          .awaitAll()
          .filterNotNull()
          .toMap()
      }

      val updatedQueue = baseQueue.map { item ->
        when {
          item.id == fullSong.id -> fullSong
          item.id in extraResolved -> item.copy(audioUrl = extraResolved[item.id])
          else -> item
        }
      }
      val idx = updatedQueue.indexOfFirst { it.id == fullSong.id }.coerceAtLeast(0)
      playbackManager.playQueue(updatedQueue, idx, shuffle)
    }
  }

  private suspend fun verifyFullStreamIfPurchased(song: Song) {
    val hasPaidAccess = song.id in purchasedIds.value || isAdminUser
    if (!hasPaidAccess || (!song.isPaid && !XkJsonParser.looksLikeDemoUrl(song.audioUrl))) return
    if (song.id in verifiedMasterIds && !XkJsonParser.looksLikeDemoUrl(song.audioUrl)) return

    val freshToken = accountRepository.ensureFreshSession()?.idToken ?: _authState.value.session?.idToken
    val masterUrl = repository.fetchSongStreamUrl(song.id, freshToken, preferFullMaster = true) ?: return
    if (!XkJsonParser.looksLikeDemoUrl(masterUrl)) {
      verifiedMasterIds.add(song.id)
    }
    if (masterUrl != song.audioUrl) {
      playbackManager.replaceResolvedSongs(mapOf(song.id to song.copy(audioUrl = masterUrl)))
    }
  }

  fun playAll(songs: List<Song>, shuffle: Boolean = false) {
    if (songs.isEmpty()) return
    val startIndex = if (shuffle) songs.indices.random() else 0
    playSong(songs[startIndex], songs, shuffle)
  }

  private suspend fun enrichSongDetail(song: Song) {
    if (!song.lyrics.isNullOrBlank() && !song.description.isNullOrBlank()) return
    when (val detail = repository.fetchSongDetail(song.id)) {
      is ApiResult.Success -> {
        val fetched = detail.data ?: return
        val merged = song.copy(
          lyrics = fetched.lyrics ?: song.lyrics,
          description = fetched.description ?: song.description,
          playCount = maxOf(song.playCount, fetched.playCount),
          albumTitle = fetched.albumTitle ?: song.albumTitle,
          albumId = fetched.albumId ?: song.albumId,
          artistId = fetched.artistId ?: song.artistId,
          coverUrl = fetched.coverUrl ?: song.coverUrl,
        )
        playbackManager.updateCurrentSongMetadata(merged)
      }
      is ApiResult.Error -> Unit
    }
  }

  fun toggleFavorite(song: Song) {
    viewModelScope.launch {
      val nowFav = repository.toggleFavorite(song)
      val currentIds = favoriteIds.value.toMutableSet().apply {
        if (nowFav) add(song.id) else remove(song.id)
      }.toList()
      accountRepository.syncLike(song, nowFav, currentIds)
    }
  }

  fun toggleAlbumFavorite(album: Album) {
    viewModelScope.launch {
      val nowLiked = repository.toggleFavoriteAlbumId(album.id)
      accountRepository.syncAlbumLike(album, nowLiked)
      _snackbarMessage.value = if (nowLiked) {
        "Đã thêm album \"${album.title}\" vào yêu thích."
      } else {
        "Đã bỏ yêu thích album \"${album.title}\"."
      }
    }
  }

  fun blockSong(song: Song) {
    viewModelScope.launch {
      accountRepository.blockSong(song.id)
      if (playbackState.value.currentSong?.id == song.id && playbackState.value.queue.size > 1) {
        skipNext()
      }
      refreshHome()
      loadExploreSongs()
      _snackbarMessage.value = "Đã chặn bài hát \"${song.title}\"."
    }
  }

  fun unblockSong(songId: String) {
    viewModelScope.launch {
      accountRepository.unblockSong(songId)
      refreshHome()
      loadExploreSongs()
      _snackbarMessage.value = "Đã bỏ chặn bài hát."
    }
  }

  fun reportSong(song: Song, reason: String, detail: String) {
    viewModelScope.launch {
      when (val res = repository.reportSong(song.id, reason, detail)) {
        is ApiResult.Success -> _snackbarMessage.value = res.data
        is ApiResult.Error -> _snackbarMessage.value = res.message
      }
    }
  }

  fun downloadSong(song: Song) {
    viewModelScope.launch {
      val session = _authState.value.session
      val hasPaidAccess = song.id in purchasedIds.value || isAdminUser
      if (song.isPaid && !hasPaidAccess) {
        openPurchaseDialog(song)
        return@launch
      }
      val url = repository.fetchSongDownloadUrl(song.id, session?.idToken)
      if (url.isNullOrBlank()) {
        _snackbarMessage.value = "Chưa có liên kết tải xuống cho bài hát này."
        return@launch
      }
      val started = runCatching {
        val dm = getApplication<Application>().getSystemService(Context.DOWNLOAD_SERVICE) as? DownloadManager
          ?: return@runCatching false
        val safeName = "${song.title} - ${song.artistName}"
          .replace(Regex("[^\\p{L}\\p{N}\\s._-]"), "_")
          .take(64)
        val req = DownloadManager.Request(Uri.parse(url))
          .setTitle(song.title)
          .setDescription("Đang tải từ XK Music")
          .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
          .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "XKMusic/$safeName.mp3")
        if (url.contains("xuanken.name.vn")) {
          val apiKey = ApiClient.currentApiKey()
          if (apiKey.isNotEmpty()) req.addRequestHeader("x-api-key", apiKey)
          val token = session?.idToken
          if (!token.isNullOrBlank()) {
            req.addRequestHeader("x-user-token", token)
            req.addRequestHeader("Authorization", "Bearer $token")
          }
        }
        dm.enqueue(req)
        true
      }.getOrDefault(false)
      _snackbarMessage.value = if (started) {
        "Đang tải xuống \"${song.title}\" vào thư mục Downloads/XKMusic."
      } else {
        "Không thể khởi tạo trình tải xuống trên thiết bị này."
      }
    }
  }

  fun updateDisplayName(newName: String) {
    viewModelScope.launch {
      _authState.update { it.copy(isUpdatingProfile = true) }
      when (val res = accountRepository.updateMe(newName)) {
        is ApiResult.Success -> {
          _authState.update { state ->
            state.copy(
              isUpdatingProfile = false,
              session = state.session?.copy(user = res.data),
            )
          }
          _snackbarMessage.value = "Đã cập nhật tên hiển thị thành \"${res.data.displayName}\"."
        }
        is ApiResult.Error -> {
          _authState.update { it.copy(isUpdatingProfile = false) }
          _snackbarMessage.value = res.message
        }
      }
    }
  }

  private suspend fun syncRemoteSettingsAndBlocks() {
    val settings = accountRepository.fetchSettings()
    if (settings != null) {
      settings.themeMode?.let { raw ->
        runCatching { ThemeMode.valueOf(raw) }.getOrNull()?.let { localStore.setThemeMode(it) }
      }
      settings.colorPreset?.let { raw ->
        runCatching { RhythmColorPreset.valueOf(raw) }.getOrNull()?.let { localStore.setColorPreset(it) }
      }
      settings.amoledMode?.let { localStore.setAmoledMode(it) }
      settings.useDynamicColor?.let { localStore.setDynamicColor(it) }
      if (settings.likedAlbumIds.isNotEmpty()) {
        repository.mergeFavoriteAlbumIds(settings.likedAlbumIds)
      }
      if (settings.blockedSongIds.isNotEmpty()) {
        repository.setBlockedSongIds(settings.blockedSongIds)
      }
    }
    val remoteBlocks = accountRepository.fetchBlockedSongIds()
    if (remoteBlocks.isNotEmpty()) {
      repository.setBlockedSongIds(remoteBlocks)
    }
  }

  // --- Account Auth / Profile / Purchases / Vouchers ---

  fun login(email: String, password: String) {
    if (email.isBlank() || password.isBlank()) {
      _authState.update { it.copy(errorMessage = "Vui lòng nhập đầy đủ email và mật khẩu.") }
      return
    }
    viewModelScope.launch {
      _authState.update { it.copy(isLoading = true, errorMessage = null) }
      when (val res = accountRepository.login(email, password)) {
        is ApiResult.Success -> {
          _authState.update { it.copy(session = res.data, isLoading = false, errorMessage = null) }
          repository.mergeRemoteFavorites(res.data.user.likedSongIds)
          loadPurchasesInternal()
          refreshPlaylistsAndEntitlements()
          _snackbarMessage.value = "Đăng nhập thành công: ${res.data.user.displayName}"
        }
        is ApiResult.Error -> {
          _authState.update { it.copy(isLoading = false, errorMessage = res.message) }
        }
      }
    }
  }

  fun register(email: String, password: String, displayName: String) {
    if (email.isBlank() || password.length < 6) {
      _authState.update {
        it.copy(errorMessage = "Vui lòng nhập email hợp lệ và mật khẩu tối thiểu 6 ký tự.")
      }
      return
    }
    viewModelScope.launch {
      _authState.update { it.copy(isLoading = true, errorMessage = null) }
      when (val res = accountRepository.register(email, password, displayName)) {
        is ApiResult.Success -> {
          _authState.update { it.copy(session = res.data, isLoading = false, errorMessage = null) }
          refreshPlaylistsAndEntitlements()
          _snackbarMessage.value = "Đăng ký tài khoản thành công!"
        }
        is ApiResult.Error -> {
          _authState.update { it.copy(isLoading = false, errorMessage = res.message) }
        }
      }
    }
  }

  fun refreshProfile(silent: Boolean = false) {
    viewModelScope.launch {
      if (!silent) _authState.update { it.copy(isLoading = true, errorMessage = null) }
      val refreshRes = accountRepository.refreshSession()
      val meRes = accountRepository.fetchMe()
      when (meRes) {
        is ApiResult.Success -> {
          _authState.update {
            it.copy(
              session = it.session?.copy(user = meRes.data),
              isLoading = false,
              errorMessage = null,
            )
          }
          repository.mergeRemoteFavorites(meRes.data.likedSongIds)
          loadPurchasesInternal()
          refreshPlaylistsAndEntitlements()
          if (!silent) _snackbarMessage.value = "Đã đồng bộ thông tin tài khoản."
        }
        is ApiResult.Error -> {
          _authState.update {
            it.copy(
              isLoading = false,
              errorMessage = if (silent) null else (refreshRes as? ApiResult.Error)?.message ?: meRes.message,
            )
          }
        }
      }
    }
  }

  fun logout() {
    viewModelScope.launch {
      verifiedMasterIds.clear()
      lastSyncedUid = null
      accountRepository.logout()
      _authState.value = AuthUiState()
      refreshHome()
      _snackbarMessage.value = "Đã đăng xuất tài khoản."
    }
  }

  fun clearAuthError() {
    _authState.update { it.copy(errorMessage = null) }
  }

  private suspend fun loadPurchasesInternal() {
    _authState.update { it.copy(isLoadingPurchases = true) }
    val lookup = repository.getSongsLookupMap()
    when (val res = accountRepository.fetchPurchases(lookup)) {
      is ApiResult.Success -> {
        _authState.update { it.copy(purchases = res.data, isLoadingPurchases = false) }
      }
      is ApiResult.Error -> {
        _authState.update { it.copy(isLoadingPurchases = false) }
      }
    }
  }

  private suspend fun refreshPlaylistsOnly() {
    val res = repository.fetchPlaylists(userId = null, authToken = null, isAdmin = false)
    if (res is ApiResult.Success) {
      _discoverState.update { it.copy(playlists = res.data) }
    }
  }

  private suspend fun refreshPlaylistsAndEntitlements() {
    val session = accountRepository.ensureFreshSession() ?: _authState.value.session
    val res = repository.fetchPlaylists(
      userId = session?.user?.uid,
      authToken = session?.idToken,
      isAdmin = isAdminUser,
    )
    if (res is ApiResult.Success) {
      _discoverState.update { it.copy(playlists = res.data) }
    }
    unlockPurchasedAudioUrls()
  }

  private suspend fun unlockPurchasedAudioUrls() {
    val session = accountRepository.ensureFreshSession() ?: _authState.value.session ?: return
    val idsToUnlock = purchasedIds.value.toList()
    if (idsToUnlock.isEmpty() && !isAdminUser) return
    val unlocked = repository.fetchAuthorizedMasterUrls(
      songIds = idsToUnlock,
      authToken = session.idToken,
      isAdmin = isAdminUser,
    )
    if (unlocked.isEmpty()) return

    verifiedMasterIds.addAll(unlocked.keys)

    fun List<Song>.patchUrls(): List<Song> = map { song ->
      val fullUrl = unlocked[song.id]
      if (!fullUrl.isNullOrBlank()) song.copy(audioUrl = fullUrl) else song
    }

    _discoverState.update { state ->
      state.copy(
        popularSongs = state.popularSongs.patchUrls(),
        latestSongs = state.latestSongs.patchUrls(),
        chartSections = state.chartSections.map { sec -> sec.copy(songs = sec.songs.patchUrls()) },
        albums = state.albums.map { alb -> alb.copy(songs = alb.songs.patchUrls()) },
        playlists = state.playlists.map { pl -> pl.copy(songs = pl.songs.patchUrls()) },
        siteInfo = state.siteInfo.copy(featuredSongs = state.siteInfo.featuredSongs.patchUrls()),
      )
    }
    _exploreState.update { state ->
      state.copy(songs = state.songs.patchUrls())
    }
    _albumDetailState.update { detail ->
      if (detail is DetailLoadState.Success) {
        DetailLoadState.Success(detail.data.copy(songs = detail.data.songs.patchUrls()))
      } else {
        detail
      }
    }
    _artistDetailState.update { detail ->
      if (detail is DetailLoadState.Success) {
        DetailLoadState.Success(detail.data.copy(songs = detail.data.songs.patchUrls()))
      } else {
        detail
      }
    }
    _playlistDetailState.update { detail ->
      if (detail is DetailLoadState.Success) {
        DetailLoadState.Success(detail.data.copy(songs = detail.data.songs.patchUrls()))
      } else {
        detail
      }
    }

    // Also update active player queue / current song immediately
    val activeQueue = playbackState.value.queue
    val patchedForPlayer = activeQueue
      .mapNotNull { qSong ->
        val fullUrl = unlocked[qSong.id]
        if (!fullUrl.isNullOrBlank() && fullUrl != qSong.audioUrl) {
          qSong.id to qSong.copy(audioUrl = fullUrl)
        } else {
          null
        }
      }
      .toMap()
    if (patchedForPlayer.isNotEmpty()) {
      playbackManager.replaceResolvedSongs(patchedForPlayer)
    }
  }

  fun playPurchasedSong(songId: String) {
    viewModelScope.launch {
      val lookup = repository.getSongsLookupMap()
      val song = lookup[songId] ?: (repository.fetchSongDetail(songId) as? ApiResult.Success)?.data
      if (song != null) {
        playSong(song, listOf(song))
      } else {
        _snackbarMessage.value = "Không tìm thấy dữ liệu bài hát này."
      }
    }
  }

  fun openPurchaseDialog(song: Song) {
    _purchaseDialogState.value = PurchaseDialogState(song = song)
    viewModelScope.launch {
      val vouchers = accountRepository.fetchAvailableVouchers()
      if (vouchers.isNotEmpty()) {
        _purchaseDialogState.update { current ->
          if (current?.song?.id == song.id) current.copy(availableVouchers = vouchers) else current
        }
      }
    }
  }

  fun dismissPurchaseDialog() {
    _purchaseDialogState.value = null
  }

  fun updateVoucherInput(code: String) {
    _purchaseDialogState.update { it?.copy(voucherCode = code, errorMessage = null) }
  }

  fun validateVoucherForDialog() {
    val state = _purchaseDialogState.value ?: return
    val basePrice = parsePriceVnd(state.song.priceText)
    viewModelScope.launch {
      _purchaseDialogState.update { it?.copy(isCheckingVoucher = true, errorMessage = null) }
      when (val res = accountRepository.validateVoucher(state.voucherCode, state.song.id, basePrice)) {
        is ApiResult.Success -> {
          _purchaseDialogState.update {
            it?.copy(
              isCheckingVoucher = false,
              voucherValidation = res.data,
              errorMessage = if (!res.data.valid) res.data.message else null,
            )
          }
        }
        is ApiResult.Error -> {
          _purchaseDialogState.update { it?.copy(isCheckingVoucher = false, errorMessage = res.message) }
        }
      }
    }
  }

  fun confirmPurchaseSong() {
    val state = _purchaseDialogState.value ?: return
    val basePrice = parsePriceVnd(state.song.priceText)
    val finalPrice = state.voucherValidation?.takeIf { it.valid }?.finalPrice ?: basePrice
    val appliedCode = state.voucherValidation?.takeIf { it.valid }?.code
    viewModelScope.launch {
      _purchaseDialogState.update { it?.copy(isPurchasing = true, errorMessage = null) }
      when (val res = accountRepository.purchaseSong(state.song, appliedCode, finalPrice)) {
        is ApiResult.Success -> {
          val purchasedSong = state.song
          _purchaseDialogState.value = null
          loadPurchasesInternal()
          refreshPlaylistsAndEntitlements()
          if (playbackState.value.currentSong?.id == purchasedSong.id) {
            playSong(purchasedSong, playbackState.value.queue)
          }
          _snackbarMessage.value = "Đã mở khóa bài hát \"${purchasedSong.title}\"!"
        }
        is ApiResult.Error -> {
          _purchaseDialogState.update { it?.copy(isPurchasing = false, errorMessage = res.message) }
        }
      }
    }
  }

  // --- Playlist CRUD ---

  fun createPlaylist(title: String, description: String) {
    viewModelScope.launch {
      val session = _authState.value.session
      when (
        val res = repository.createPlaylist(
          title = title,
          description = description,
          userId = session?.user?.uid,
          userName = session?.user?.displayName,
          authToken = session?.idToken,
        )
      ) {
        is ApiResult.Success -> {
          _snackbarMessage.value = "Đã tạo playlist \"${res.data.title}\"."
          refreshHome()
        }
        is ApiResult.Error -> {
          _snackbarMessage.value = res.message
        }
      }
    }
  }

  fun updatePlaylist(playlistId: String, title: String, description: String) {
    viewModelScope.launch {
      val session = _authState.value.session
      when (
        val res = repository.updatePlaylist(
          playlistId = playlistId,
          title = title,
          description = description,
          authToken = session?.idToken,
        )
      ) {
        is ApiResult.Success -> {
          _snackbarMessage.value = "Đã cập nhật playlist."
          loadPlaylistDetail(playlistId)
          refreshHome()
        }
        is ApiResult.Error -> {
          _snackbarMessage.value = res.message
        }
      }
    }
  }

  fun deletePlaylist(playlistId: String, onDeleted: () -> Unit = {}) {
    viewModelScope.launch {
      val session = _authState.value.session
      when (val res = repository.deletePlaylist(playlistId, session?.idToken)) {
        is ApiResult.Success -> {
          _snackbarMessage.value = "Đã xóa playlist."
          refreshHome()
          onDeleted()
        }
        is ApiResult.Error -> {
          _snackbarMessage.value = res.message
        }
      }
    }
  }

  fun addSongToPlaylist(playlist: Playlist, song: Song) {
    viewModelScope.launch {
      val session = _authState.value.session
      val currentIds = playlist.songs.map { it.id }.distinct()
      if (song.id in currentIds) {
        _snackbarMessage.value = "Bài hát đã có trong \"${playlist.title}\"."
        return@launch
      }
      val nextIds = currentIds + song.id
      when (
        val res = repository.updatePlaylist(
          playlistId = playlist.id,
          title = playlist.title,
          description = playlist.description.orEmpty(),
          songIds = nextIds,
          authToken = session?.idToken,
        )
      ) {
        is ApiResult.Success -> {
          _snackbarMessage.value = "Đã thêm \"${song.title}\" vào \"${playlist.title}\"."
          loadPlaylistDetail(playlist.id)
          refreshPlaylistsAndEntitlements()
        }
        is ApiResult.Error -> {
          _snackbarMessage.value = res.message
        }
      }
    }
  }

  // --- Sleep Timer (Hẹn giờ tắt nhạc) ---

  fun startSleepTimer(minutes: Int) {
    val safeMinutes = minutes.coerceIn(1, 240)
    sleepTimerJob?.cancel()
    playbackManager.setVolume(1.0f)
    playbackManager.setPauseAfterCurrentTrack(false)
    val totalSec = safeMinutes * 60L
    _sleepTimerState.value = SleepTimerUiState(
      isActive = true,
      stopAfterCurrentSong = false,
      remainingSeconds = totalSec,
      totalSeconds = totalSec,
      label = "$safeMinutes phút",
    )
    sleepTimerJob = viewModelScope.launch {
      var remaining = totalSec
      while (isActive && remaining > 0L) {
        delay(1000L)
        remaining -= 1L
        if (personalizationSettings.value.sleepTimerFadeOut && remaining in 1L..3L) {
          playbackManager.setVolume(remaining / 4f)
        }
        _sleepTimerState.update { it.copy(remainingSeconds = remaining) }
      }
      if (isActive) {
        playbackManager.pause()
        playbackManager.setVolume(1.0f)
        _sleepTimerState.value = SleepTimerUiState()
        _snackbarMessage.value = "Hẹn giờ tắt nhạc đã kết thúc, nhạc đã tạm dừng."
      }
    }
  }

  fun startSleepAfterCurrentTrack() {
    sleepTimerJob?.cancel()
    playbackManager.setVolume(1.0f)
    playbackManager.setPauseAfterCurrentTrack(true)
    _sleepTimerState.value = SleepTimerUiState(
      isActive = true,
      stopAfterCurrentSong = true,
      remainingSeconds = 0L,
      totalSeconds = 0L,
      label = "Hết bài hiện tại",
    )
    _snackbarMessage.value = "Nhạc sẽ tự động dừng khi phát hết bài hát hiện tại."
  }

  fun cancelSleepTimer() {
    sleepTimerJob?.cancel()
    sleepTimerJob = null
    playbackManager.setVolume(1.0f)
    playbackManager.setPauseAfterCurrentTrack(false)
    _sleepTimerState.value = SleepTimerUiState()
  }

  fun clearSnackbarMessage() {
    _snackbarMessage.value = null
  }

  fun setThemeMode(mode: ThemeMode) {
    viewModelScope.launch {
      localStore.setThemeMode(mode)
      accountRepository.patchSettings(themeMode = mode.name)
    }
  }

  fun setDynamicColor(enabled: Boolean) {
    viewModelScope.launch {
      localStore.setDynamicColor(enabled)
      accountRepository.patchSettings(useDynamicColor = enabled)
    }
  }

  fun setColorPreset(preset: RhythmColorPreset) {
    viewModelScope.launch {
      localStore.setColorPreset(preset)
      accountRepository.patchSettings(colorPreset = preset.name)
    }
  }

  fun setAmoledMode(enabled: Boolean) {
    viewModelScope.launch {
      localStore.setAmoledMode(enabled)
      accountRepository.patchSettings(amoledMode = enabled)
    }
  }

  private fun updatePersonalization(transform: (PersonalizationSettings) -> PersonalizationSettings) {
    viewModelScope.launch {
      localStore.updatePersonalization(transform)
    }
  }

  fun setPaletteStyle(style: RhythmPaletteStyle) =
    updatePersonalization { it.copy(paletteStyle = style) }

  fun setSleepTimerFadeOut(enabled: Boolean) =
    updatePersonalization { it.copy(sleepTimerFadeOut = enabled) }

  fun setPlaybackSpeed(speed: Float) {
    val clamped = speed.coerceIn(0.5f, 2.0f)
    playbackManager.setPlaybackSpeed(clamped)
    updatePersonalization { it.copy(playbackSpeed = clamped) }
  }

  fun setRotateArtwork(enabled: Boolean) =
    updatePersonalization { it.copy(rotateArtwork = enabled) }

  fun setUseWavySeekbar(enabled: Boolean) =
    updatePersonalization { it.copy(useWavySeekbar = enabled) }

  fun setShowMiniPlayerProgress(enabled: Boolean) =
    updatePersonalization { it.copy(showMiniPlayerProgress = enabled) }

  fun setKeepScreenOnPlayer(enabled: Boolean) =
    updatePersonalization { it.copy(keepScreenOnPlayer = enabled) }

  fun setSkipSilenceEnabled(enabled: Boolean) {
    PlaybackAudioConfig.setSkipSilenceEnabled(enabled)
    updatePersonalization { it.copy(skipSilenceEnabled = enabled) }
  }

  fun setShowSeek10sButtons(enabled: Boolean) =
    updatePersonalization { it.copy(showSeek10sButtons = enabled) }

  fun setAlbumArtShapeId(shapeId: String) =
    updatePersonalization { it.copy(albumArtShapeId = shapeId) }

  fun setSongArtShapeId(shapeId: String) =
    updatePersonalization { it.copy(songArtShapeId = shapeId) }

  fun setPlaylistArtShapeId(shapeId: String) =
    updatePersonalization { it.copy(playlistArtShapeId = shapeId) }

  fun setMiniPlayerShapeId(shapeId: String) =
    updatePersonalization { it.copy(miniPlayerShapeId = shapeId) }

  fun resetAllShapes() =
    updatePersonalization {
      it.copy(
        albumArtShapeId = "GHOSTISH",
        songArtShapeId = "CLOVER_8_LEAF",
        playlistArtShapeId = "CLOVER_4_LEAF",
        miniPlayerShapeId = "COOKIE_4",
      )
    }

  fun setFontOption(option: AppFontOption) =
    updatePersonalization { it.copy(fontOption = option) }

  fun setFontScale(scale: FontScaleOption) =
    updatePersonalization { it.copy(fontScale = scale) }

  fun setFloatingNavBarEnabled(enabled: Boolean) =
    updatePersonalization { it.copy(floatingNavBarEnabled = enabled) }

  fun setNavBarLabelBehavior(behavior: NavBarLabelBehavior) =
    updatePersonalization { it.copy(navBarLabelBehavior = behavior) }

  fun setShowDetachedSearchFab(enabled: Boolean) =
    updatePersonalization { it.copy(showDetachedSearchFab = enabled) }

  fun setFestiveThemeMode(mode: FestiveThemeMode) =
    updatePersonalization { it.copy(festiveThemeMode = mode) }

  fun setFestiveParticlesEnabled(enabled: Boolean) =
    updatePersonalization { it.copy(festiveParticlesEnabled = enabled) }

  fun setSwipeDownToDismissPlayer(enabled: Boolean) =
    updatePersonalization { it.copy(swipeDownToDismissPlayer = enabled) }

  fun setSwipeArtworkToSkip(enabled: Boolean) =
    updatePersonalization { it.copy(swipeArtworkToSkip = enabled) }

  fun setTapArtworkForLyrics(enabled: Boolean) =
    updatePersonalization { it.copy(tapArtworkForLyrics = enabled) }

  fun setMiniPlayerGesturesEnabled(enabled: Boolean) =
    updatePersonalization { it.copy(miniPlayerGesturesEnabled = enabled) }

  fun setHapticFeedbackEnabled(enabled: Boolean) =
    updatePersonalization { it.copy(hapticFeedbackEnabled = enabled) }

  fun setEqualizerEnabled(enabled: Boolean) =
    updatePersonalization { it.copy(equalizerEnabled = enabled) }

  fun selectEqualizerPreset(preset: EqualizerPreset) =
    updatePersonalization {
      it.copy(
        equalizerEnabled = true,
        equalizerPreset = preset,
        equalizerBandsDb = if (preset == EqualizerPreset.CUSTOM) it.equalizerBandsDb else preset.bandsDb,
      )
    }

  fun setEqualizerBand(bandIndex: Int, gainDb: Float) =
    updatePersonalization { current ->
      val updated = current.equalizerBandsDb.toMutableList()
      while (updated.size < 5) updated.add(0f)
      if (bandIndex in updated.indices) {
        updated[bandIndex] = gainDb.coerceIn(-12f, 12f)
      }
      current.copy(
        equalizerEnabled = true,
        equalizerPreset = EqualizerPreset.CUSTOM,
        equalizerBandsDb = updated,
      )
    }

  fun setBassBoostLevel(level: Int) =
    updatePersonalization { it.copy(bassBoostLevel = level.coerceIn(0, 1000)) }

  fun setVirtualizerLevel(level: Int) =
    updatePersonalization { it.copy(virtualizerLevel = level.coerceIn(0, 1000)) }

  fun setLyricsAutoScroll(enabled: Boolean) =
    updatePersonalization { it.copy(lyricsAutoScroll = enabled) }

  fun setLyricsAlignment(alignment: LyricsAlignment) =
    updatePersonalization { it.copy(lyricsAlignment = alignment) }

  fun setLyricsFontSize(size: LyricsFontSize) =
    updatePersonalization { it.copy(lyricsFontSize = size) }

  fun setLyricsDimInactive(enabled: Boolean) =
    updatePersonalization { it.copy(lyricsDimInactive = enabled) }

  fun setLyricsTapToSeek(enabled: Boolean) =
    updatePersonalization { it.copy(lyricsTapToSeek = enabled) }

  private fun parsePriceVnd(priceText: String?): Long {
    val digits = priceText.orEmpty().filter { it.isDigit() }
    return digits.toLongOrNull() ?: 0L
  }

  private suspend fun resolvePlayableSong(song: Song): Song? {
    val freshSession = accountRepository.ensureFreshSession()
    val freshToken = freshSession?.idToken ?: _authState.value.session?.idToken
    val ownedIds = purchasedIds.value
    val admin = isAdminUser
    val hasPaidAccess = song.id in ownedIds || admin

    val resolvedUrl = if (hasPaidAccess) {
      val masterUrl = repository.fetchSongStreamUrl(song.id, freshToken, preferFullMaster = true)
      if (!masterUrl.isNullOrBlank() && !XkJsonParser.looksLikeDemoUrl(masterUrl)) {
        verifiedMasterIds.add(song.id)
      }
      masterUrl ?: song.audioUrl?.takeIf { it.isNotBlank() }
    } else {
      song.audioUrl?.takeIf { it.isNotBlank() }
        ?: repository.fetchSongStreamUrl(song.id, freshToken, preferFullMaster = false)
    }

    val fullSong = if (!resolvedUrl.isNullOrBlank()) {
      song.copy(audioUrl = resolvedUrl)
    } else {
      (repository.fetchSongDetail(song.id) as? ApiResult.Success)?.data ?: song
    }

    if (fullSong.audioUrl.isNullOrBlank() && fullSong.isPaid && !hasPaidAccess) {
      openPurchaseDialog(fullSong)
      return null
    }
    return fullSong
  }

  fun playNext(song: Song) {
    viewModelScope.launch {
      val resolved = resolvePlayableSong(song) ?: return@launch
      if (resolved.audioUrl.isNullOrBlank()) {
        _snackbarMessage.value = "Chưa tìm thấy nguồn phát cho bài hát này."
        return@launch
      }
      playbackManager.playNext(resolved)
      _snackbarMessage.value = "Sẽ phát tiếp theo: \"${resolved.title}\""
    }
  }

  fun addToQueue(song: Song) {
    viewModelScope.launch {
      val resolved = resolvePlayableSong(song) ?: return@launch
      if (resolved.audioUrl.isNullOrBlank()) {
        _snackbarMessage.value = "Chưa tìm thấy nguồn phát cho bài hát này."
        return@launch
      }
      playbackManager.addToQueue(resolved)
      _snackbarMessage.value = "Đã thêm \"${resolved.title}\" vào danh sách chờ"
    }
  }

  fun removeFromQueue(index: Int) = playbackManager.removeFromQueue(index)
  fun moveQueueItem(fromIndex: Int, toIndex: Int) = playbackManager.moveQueueItem(fromIndex, toIndex)
  fun shuffleUpcomingQueue() {
    playbackManager.shuffleUpcomingQueue()
    _snackbarMessage.value = "Đã xáo trộn các bài tiếp theo trong hàng đợi."
  }
  fun clearUpcomingQueue() {
    playbackManager.clearUpcomingQueue()
    _snackbarMessage.value = "Đã xóa các bài tiếp theo khỏi hàng đợi."
  }

  fun togglePlayPause() = playbackManager.togglePlayPause()
  fun skipNext() = playbackManager.skipNext()
  fun skipPrevious() = playbackManager.skipPrevious()
  fun seekTo(positionMs: Long) = playbackManager.seekTo(positionMs)
  fun seekRelative(deltaMs: Long) = playbackManager.seekRelative(deltaMs)
  fun toggleShuffle() = playbackManager.toggleShuffle()
  fun cycleRepeatMode() = playbackManager.cycleRepeatMode()
  fun clearPlaybackError() = playbackManager.clearError()
  fun stopAndDismissPlayer() {
    sleepTimerJob?.cancel()
    playbackManager.stopAndClear()
    _sleepTimerState.value = SleepTimerUiState()
  }

  override fun onCleared() {
    sleepTimerJob?.cancel()
    playbackManager.release()
    super.onCleared()
  }
}
