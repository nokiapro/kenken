package com.example.ui

import androidx.compose.runtime.Immutable
import com.example.model.Album
import com.example.model.Artist
import com.example.model.AuthSession
import com.example.model.ChartSection
import com.example.model.Playlist
import com.example.model.PurchaseRecord
import com.example.model.SiteInfo
import com.example.model.Song
import com.example.model.VoucherInfo
import com.example.model.VoucherValidation
import kotlinx.serialization.Serializable

enum class PaidFilter(val apiValue: Boolean?, val label: String) {
  ALL(null, "Tất cả"),
  FREE(false, "Miễn phí"),
  PAID(true, "Trả phí"),
}

enum class SongSort(val apiValue: String, val label: String) {
  POPULAR("popular", "Phổ biến"),
  LATEST("latest", "Mới nhất"),
}

@Immutable
data class ActiveTrackMeta(
  val songId: String? = null,
  val isPlaying: Boolean = false,
)

@Immutable
data class DiscoverUiState(
  val isLoading: Boolean = true,
  val siteInfo: SiteInfo = SiteInfo(),
  val chartSections: List<ChartSection> = emptyList(),
  val playlists: List<Playlist> = emptyList(),
  val albums: List<Album> = emptyList(),
  val artists: List<Artist> = emptyList(),
  val popularSongs: List<Song> = emptyList(),
  val latestSongs: List<Song> = emptyList(),
  val errorMessage: String? = null,
  val isMissingApiKey: Boolean = false,
)

@Immutable
data class ExploreUiState(
  val isLoading: Boolean = false,
  val query: String = "",
  val selectedGenre: String = "",
  val paidFilter: PaidFilter = PaidFilter.ALL,
  val sortOrder: SongSort = SongSort.POPULAR,
  val availableGenres: List<String> = emptyList(),
  val songs: List<Song> = emptyList(),
  val errorMessage: String? = null,
  val isMissingApiKey: Boolean = false,
)

@Immutable
sealed interface DetailLoadState<out T> {
  data object Loading : DetailLoadState<Nothing>
  data class Success<T>(val data: T) : DetailLoadState<T>
  data class Error(val message: String) : DetailLoadState<Nothing>
}

@Immutable
data class AuthUiState(
  val session: AuthSession? = null,
  val isLoading: Boolean = false,
  val isUpdatingProfile: Boolean = false,
  val errorMessage: String? = null,
  val purchases: List<PurchaseRecord> = emptyList(),
  val isLoadingPurchases: Boolean = false,
)

@Immutable
data class PurchaseDialogState(
  val song: Song,
  val voucherCode: String = "",
  val voucherValidation: VoucherValidation? = null,
  val availableVouchers: List<VoucherInfo> = emptyList(),
  val isCheckingVoucher: Boolean = false,
  val isPurchasing: Boolean = false,
  val errorMessage: String? = null,
)

enum class ThemeMode(val label: String) {
  SYSTEM("Hệ thống"),
  LIGHT("Ánh sáng"),
  DARK("Bóng tối"),
}

enum class RhythmColorPreset(val label: String, val seedHex: Long) {
  DEFAULT("Mặc định (Tím)", 0xFF6750A4),
  WARM("Ấm áp", 0xFFFF6B35),
  COOL("Xanh dịu", 0xFF1E88E5),
  FOREST("Rừng xanh", 0xFF2E7D32),
  ROSE("Hoa hồng", 0xFFE91E63),
  LAVENDER("Oải hương", 0xFF7C4DFF),
  OCEAN("Đại dương", 0xFF006064),
  CRIMSON("Đỏ thẫm", 0xFFB71C1C),
}

enum class RhythmPaletteStyle(val apiKey: String, val label: String) {
  TONAL_SPOT("TONAL_SPOT", "Tonal Spot (Mặc định)"),
  VIBRANT("VIBRANT", "Sống động"),
  EXPRESSIVE("EXPRESSIVE", "Biểu cảm"),
  FIDELITY("FIDELITY", "Trung thực"),
  MONOCHROME("MONOCHROME", "Đơn sắc"),
}

enum class AppFontOption(val label: String, val sampleSubtitle: String) {
  PLUS_JAKARTA_SANS("Plus Jakarta Sans", "Mặc định Rhythm"),
  BE_VIETNAM_PRO("Be Vietnam Pro", "Cân đối tiếng Việt"),
  SPACE_GROTESK("Space Grotesk", "Hiện đại cá tính"),
  GEOM("Geom", "Hình học gọn gàng"),
  PLAYFAIR_DISPLAY("Playfair Display", "Serif cổ điển"),
  JETBRAINS_MONO("JetBrains Mono", "Đơn cách kỹ thuật"),
  SYSTEM("Hệ thống", "Font mặc định thiết bị"),
}

enum class FontScaleOption(val label: String, val scale: Float) {
  SMALL("Nhỏ", 0.90f),
  NORMAL("Tiêu chuẩn", 1.00f),
  LARGE("Lớn", 1.10f),
  EXTRA_LARGE("Rất lớn", 1.20f),
}

enum class NavBarLabelBehavior(val label: String) {
  SELECTED_ONLY("Chỉ tab đang chọn"),
  ALWAYS("Luôn hiển thị"),
  ICONS_ONLY("Chỉ biểu tượng"),
}

enum class FestiveThemeMode(val label: String, val description: String) {
  NONE("Tắt", "Giao diện chuẩn không hiệu ứng lễ hội"),
  AUTO("Tự động theo mùa", "Tự nhận diện Tết, Valentine, Halloween, Giáng Sinh"),
  TET("Tết Nguyên Đán", "Hoa mai, hoa đào rơi nhẹ & sắc vàng ấm"),
  VALENTINE("Valentine", "Trái tim bay nhẹ & sắc hồng lãng mạn"),
  HALLOWEEN("Halloween", "Ánh đốm cam huyền bí & đêm lễ hội"),
  CHRISTMAS("Giáng Sinh", "Bông tuyết rơi nhẹ & không khí Noel"),
  NEW_YEAR("Năm Mới", "Ánh sao pháo hoa lấp lánh"),
}

enum class LyricsAlignment(val label: String) {
  START("Căn trái"),
  CENTER("Căn giữa"),
  END("Căn phải"),
}

enum class LyricsFontSize(val label: String, val scale: Float) {
  SMALL("Nhỏ", 0.85f),
  MEDIUM("Vừa", 1.00f),
  LARGE("Lớn", 1.18f),
  EXTRA_LARGE("Cực lớn", 1.35f),
}

enum class EqualizerPreset(val label: String, val bandsDb: List<Float>) {
  FLAT("Phẳng (Flat)", listOf(0f, 0f, 0f, 0f, 0f)),
  BASS_BOOST("Tăng Bass", listOf(6f, 4f, 0f, -1f, 0f)),
  POP("Pop", listOf(-1f, 3f, 5f, 2f, -1f)),
  ROCK("Rock", listOf(5f, 3f, -1f, 3f, 5f)),
  JAZZ("Jazz", listOf(3f, 1f, -2f, 2f, 4f)),
  CLASSICAL("Cổ điển", listOf(4f, 2f, -1f, 2f, 5f)),
  BALLAD("Ballad / Acoustic", listOf(2f, 1f, 3f, 2f, 1f)),
  EDM("EDM / Dance", listOf(6f, 3f, -2f, 3f, 5f)),
  VOCAL("Tôn giọng hát", listOf(-2f, 0f, 5f, 4f, 1f)),
  HARMAN("AutoEQ Harman", listOf(3.5f, 1f, -1f, 2f, 3f)),
  CUSTOM("Tùy chỉnh", listOf(0f, 0f, 0f, 0f, 0f)),
}

enum class PersonalizationSection(val title: String) {
  SLEEP_TIMER("Hẹn giờ ngủ"),
  PLAYER_CONTROLS("Điều khiển người chơi"),
  COLOR_CUSTOMIZATION("Tùy chỉnh màu sắc"),
  SHAPE_CUSTOMIZATION("Tùy chỉnh hình dáng"),
  FONT_CUSTOMIZATION("Tùy chỉnh font chữ"),
  FLOATING_NAV_BAR("Floating Navigation Bar"),
  FESTIVE_THEME("Chủ đề lễ hội"),
  GESTURES("Cử chỉ"),
  EQUALIZER("Bộ chỉnh âm"),
  LYRICS("Lời bài hát"),
}

@Immutable
data class AppearanceSettings(
  val themeMode: ThemeMode = ThemeMode.DARK,
  val useDynamicColor: Boolean = false,
  val colorPreset: RhythmColorPreset = RhythmColorPreset.DEFAULT,
  val amoledMode: Boolean = false,
)

@Immutable
@Serializable
data class PersonalizationSettings(
  val paletteStyle: RhythmPaletteStyle = RhythmPaletteStyle.TONAL_SPOT,
  val sleepTimerFadeOut: Boolean = true,
  val playbackSpeed: Float = 1.0f,
  val rotateArtwork: Boolean = true,
  val useWavySeekbar: Boolean = true,
  val showMiniPlayerProgress: Boolean = true,
  val keepScreenOnPlayer: Boolean = false,
  val skipSilenceEnabled: Boolean = false,
  val showSeek10sButtons: Boolean = true,
  val albumArtShapeId: String = "GHOSTISH",
  val songArtShapeId: String = "CLOVER_8_LEAF",
  val playlistArtShapeId: String = "CLOVER_4_LEAF",
  val miniPlayerShapeId: String = "COOKIE_4",
  val fontOption: AppFontOption = AppFontOption.PLUS_JAKARTA_SANS,
  val fontScale: FontScaleOption = FontScaleOption.NORMAL,
  val floatingNavBarEnabled: Boolean = true,
  val navBarLabelBehavior: NavBarLabelBehavior = NavBarLabelBehavior.SELECTED_ONLY,
  val showDetachedSearchFab: Boolean = true,
  val festiveThemeMode: FestiveThemeMode = FestiveThemeMode.NONE,
  val festiveParticlesEnabled: Boolean = true,
  val swipeDownToDismissPlayer: Boolean = true,
  val swipeArtworkToSkip: Boolean = true,
  val tapArtworkForLyrics: Boolean = true,
  val miniPlayerGesturesEnabled: Boolean = true,
  val hapticFeedbackEnabled: Boolean = true,
  val equalizerEnabled: Boolean = false,
  val equalizerPreset: EqualizerPreset = EqualizerPreset.FLAT,
  val equalizerBandsDb: List<Float> = listOf(0f, 0f, 0f, 0f, 0f),
  val bassBoostLevel: Int = 0,
  val virtualizerLevel: Int = 0,
  val lyricsAutoScroll: Boolean = true,
  val lyricsAlignment: LyricsAlignment = LyricsAlignment.START,
  val lyricsFontSize: LyricsFontSize = LyricsFontSize.MEDIUM,
  val lyricsDimInactive: Boolean = true,
  val lyricsTapToSeek: Boolean = true,
)

