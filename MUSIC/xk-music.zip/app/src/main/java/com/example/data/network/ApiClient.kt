package com.example.data.network

import com.example.BuildConfig
import okhttp3.Interceptor
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import java.util.concurrent.TimeUnit

object ApiClient {
  const val BASE_URL = "https://xkmu.xuanken.name.vn/"
  const val RTDB_BASE_URL = "https://newmusic-5625b-default-rtdb.asia-southeast1.firebasedatabase.app/"
  const val FIREBASE_IDENTITY_URL = "https://identitytoolkit.googleapis.com/"
  const val FIREBASE_TOKEN_URL = "https://securetoken.googleapis.com/"
  const val WEB_FIREBASE_API_KEY = "AIzaSyCELRyno2Oa7j-ZaPL9A-kRLnsqGv9bqbc"
  private const val PLACEHOLDER_KEY = "MY_XKMU_API_KEY"

  @Volatile
  private var activeUserToken: String? = null

  fun setUserToken(token: String?) {
    activeUserToken = token?.trim()?.takeIf { it.isNotEmpty() }
  }

  fun currentUserToken(): String? = activeUserToken

  fun currentApiKey(): String = BuildConfig.XKMU_API_KEY.trim()

  fun isApiKeyConfigured(): Boolean {
    val key = currentApiKey()
    return key.isNotEmpty() && key != PLACEHOLDER_KEY
  }

  private val authInterceptor = Interceptor { chain ->
    val original = chain.request()
    val builder = original.newBuilder()
      .header("Accept", "application/json")

    if (original.url.host.contains("xuanken.name.vn")) {
      val key = currentApiKey()
      if (key.isNotEmpty() && key != PLACEHOLDER_KEY) {
        builder.header("x-api-key", key)
      }
      val userToken = activeUserToken
      if (!userToken.isNullOrBlank()) {
        builder
          .header("x-user-token", userToken)
          .header("Authorization", "Bearer $userToken")
      } else if (key.isNotEmpty() && key != PLACEHOLDER_KEY) {
        builder.header("Authorization", "Bearer $key")
      }
    }
    chain.proceed(builder.build())
  }

  private val loggingInterceptor = HttpLoggingInterceptor().apply {
    level = if (BuildConfig.DEBUG) {
      HttpLoggingInterceptor.Level.BASIC
    } else {
      HttpLoggingInterceptor.Level.NONE
    }
  }

  val okHttpClient: OkHttpClient by lazy {
    OkHttpClient.Builder()
      .addInterceptor(authInterceptor)
      .addInterceptor(loggingInterceptor)
      .connectTimeout(20, TimeUnit.SECONDS)
      .readTimeout(25, TimeUnit.SECONDS)
      .writeTimeout(20, TimeUnit.SECONDS)
      .build()
  }

  val apiService: XkMusicApiService by lazy {
    Retrofit.Builder()
      .baseUrl(BASE_URL)
      .client(okHttpClient)
      .build()
      .create(XkMusicApiService::class.java)
  }

  val rtdbService: XkRtdbApiService by lazy {
    Retrofit.Builder()
      .baseUrl(RTDB_BASE_URL)
      .client(okHttpClient)
      .build()
      .create(XkRtdbApiService::class.java)
  }

  val firebaseAuthService: FirebaseAuthApiService by lazy {
    Retrofit.Builder()
      .baseUrl(FIREBASE_IDENTITY_URL)
      .client(okHttpClient)
      .build()
      .create(FirebaseAuthApiService::class.java)
  }

  val firebaseTokenService: FirebaseTokenApiService by lazy {
    Retrofit.Builder()
      .baseUrl(FIREBASE_TOKEN_URL)
      .client(okHttpClient)
      .build()
      .create(FirebaseTokenApiService::class.java)
  }
}
