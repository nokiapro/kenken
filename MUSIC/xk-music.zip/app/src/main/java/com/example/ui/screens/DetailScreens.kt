package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.LocalIndication
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.LargeTopAppBar
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.rememberTopAppBarState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.util.lerp
import com.example.model.Album
import com.example.model.Artist
import com.example.model.Playlist
import com.example.model.Song
import com.example.ui.ActiveTrackMeta
import com.example.ui.DetailLoadState
import com.example.ui.FormatUtils
import com.example.ui.components.ArtworkImage
import com.example.ui.components.LoadingSkeletonList
import com.example.ui.components.PlaylistEditorDialog
import com.example.ui.components.RhythmCollapsibleHeaderScreen
import com.example.ui.components.RhythmDetailActionButton
import com.example.ui.components.RhythmHeaderAction
import com.example.ui.components.RhythmSectionHeader
import com.example.ui.components.SongInfoDialog
import com.example.ui.components.SongRowItem
import com.example.ui.components.StatusMessageCard
import com.example.ui.components.horizontalEdgeBlend
import com.example.ui.components.rhythmPressScale
import com.example.ui.components.shareSongIntent
import com.example.ui.rhythm.ExpressiveShapeTarget
import com.example.ui.rhythm.RhythmIcons
import com.example.ui.rhythm.RhythmSymbolIcon
import com.example.ui.rhythm.rememberExpressiveShapeFor
import com.example.ui.theme.RhythmShapes

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AlbumDetailScreen(
  state: DetailLoadState<Album>,
  activeTrack: ActiveTrackMeta,
  favoriteIds: Set<String>,
  purchasedIds: Set<String>,
  bottomOverlayPadding: PaddingValues,
  isAlbumFavorite: Boolean = false,
  onToggleAlbumFavorite: () -> Unit = {},
  onBack: () -> Unit,
  onRetry: () -> Unit,
  onPlaySong: (Song, List<Song>) -> Unit,
  onPlayAll: (List<Song>, Boolean) -> Unit,
  onToggleFavorite: (Song) -> Unit,
  onPurchaseSong: (Song) -> Unit,
  onOpenArtist: (String) -> Unit,
  onPlayNext: (Song) -> Unit = {},
  onAddToQueue: (Song) -> Unit = {},
  playCounts: Map<String, Int> = emptyMap(),
) {
  val context = LocalContext.current
  var infoSong by remember { mutableStateOf<Song?>(null) }
  val loadedAlbum = (state as? DetailLoadState.Success)?.data
  val albumTitle = loadedAlbum?.title ?: "Album"
  val scrollBehavior = TopAppBarDefaults.exitUntilCollapsedScrollBehavior(
    rememberTopAppBarState(),
    canScroll = { true },
  )
  val collapsedFraction = scrollBehavior.state.collapsedFraction
  val expandedAlpha = ((0.65f - collapsedFraction) / 0.4f).coerceIn(0f, 1f)
  val backgroundColor = MaterialTheme.colorScheme.background

  BoxWithConstraints(modifier = Modifier.fillMaxSize().background(backgroundColor)) {
    val heroHeight = (maxHeight * 0.44f).coerceIn(270.dp, 400.dp)
    // Full-bleed Rhythm AlbumDetail hero backdrop with zoom + parallax + bottom gradient fade
    if (loadedAlbum != null && expandedAlpha > 0.01f) {
      val totalSec = remember(loadedAlbum.songs) { loadedAlbum.songs.sumOf { it.durationSeconds.coerceAtLeast(0) } }
      val metaText = buildString {
        append("${loadedAlbum.songs.size} bài hát")
        if (totalSec > 0) {
          append(" • ${FormatUtils.formatDurationMs(totalSec * 1000L)}")
        }
        if (!loadedAlbum.genre.isNullOrBlank()) {
          append(" • ${loadedAlbum.genre}")
        }
      }

      Box(
        modifier = Modifier
          .fillMaxWidth()
          .height(heroHeight)
          .clipToBounds()
          .graphicsLayer {
            alpha = expandedAlpha
            scaleX = 1f + collapsedFraction * 0.15f
            scaleY = 1f + collapsedFraction * 0.15f
          },
      ) {
        Box(
          modifier = Modifier
            .fillMaxSize()
            .graphicsLayer(compositingStrategy = CompositingStrategy.Offscreen),
        ) {
          ArtworkImage(
            imageUrl = loadedAlbum.coverUrl ?: loadedAlbum.songs.firstOrNull()?.coverUrl,
            contentDescription = loadedAlbum.title,
            shape = RoundedCornerShape(0.dp),
            sizePx = 960,
            modifier = Modifier.fillMaxSize(),
          )

          Box(
            modifier = Modifier
              .fillMaxSize()
              .background(
                Brush.verticalGradient(
                  colors = listOf(
                    backgroundColor.copy(alpha = 0.25f),
                    Color.Transparent,
                    backgroundColor.copy(alpha = 0.62f),
                    backgroundColor,
                  ),
                ),
              ),
          )
        }

        Column(
          modifier = Modifier
            .align(Alignment.BottomStart)
            .fillMaxWidth()
            .padding(24.dp)
            .graphicsLayer {
              translationY = -collapsedFraction * 120f
            },
        ) {
          Text(
            text = loadedAlbum.title,
            style = MaterialTheme.typography.displaySmall.copy(fontWeight = FontWeight.Black),
            color = MaterialTheme.colorScheme.onBackground,
            maxLines = 3,
            overflow = TextOverflow.Ellipsis,
          )
          Spacer(Modifier.height(6.dp))
          Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
          ) {
            Column(
              modifier = Modifier
                .weight(1f)
                .clickable(enabled = !loadedAlbum.artistId.isNullOrBlank()) {
                  loadedAlbum.artistId?.takeIf { it.isNotBlank() }?.let(onOpenArtist)
                },
            ) {
              Text(
                text = loadedAlbum.artistName,
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = MaterialTheme.colorScheme.primary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
              )
              Spacer(Modifier.height(4.dp))
              Text(
                text = metaText,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.72f),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
              )
            }
            if (!loadedAlbum.releaseYear.isNullOrBlank()) {
              Spacer(Modifier.width(12.dp))
              Text(
                text = loadedAlbum.releaseYear,
                style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Black),
                color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.32f),
              )
            }
          }
        }
      }
    }

    Scaffold(
      modifier = Modifier
        .fillMaxSize()
        .nestedScroll(scrollBehavior.nestedScrollConnection),
      containerColor = Color.Transparent,
      contentWindowInsets = WindowInsets(0, 0, 0, 0),
      topBar = {
        Column {
          Spacer(Modifier.height(8.dp))
          LargeTopAppBar(
            title = {
              val titleAlpha = if (loadedAlbum != null) {
                ((collapsedFraction - 0.2f) / 0.4f).coerceIn(0f, 1f)
              } else {
                1f
              }
              if (titleAlpha > 0.01f) {
                Text(
                  text = albumTitle,
                  style = MaterialTheme.typography.headlineLarge.copy(
                    fontWeight = FontWeight.Bold,
                    fontSize = lerp(32f, 24f, collapsedFraction).sp,
                  ),
                  maxLines = 1,
                  overflow = TextOverflow.Ellipsis,
                  modifier = Modifier
                    .padding(start = 6.dp)
                    .graphicsLayer { alpha = titleAlpha },
                )
              }
            },
            navigationIcon = {
              FilledIconButton(
                onClick = onBack,
                colors = IconButtonDefaults.filledIconButtonColors(
                  containerColor = MaterialTheme.colorScheme.surfaceContainerHigh,
                  contentColor = MaterialTheme.colorScheme.onSurface,
                ),
                modifier = Modifier
                  .padding(start = 12.dp)
                  .size(40.dp)
                  .testTag("detail_back_button"),
              ) {
                RhythmSymbolIcon(
                  icon = RhythmIcons.Back,
                  contentDescription = "Quay lại",
                  size = 22.dp,
                  modifier = Modifier.size(22.dp),
                )
              }
            },
            actions = {
              if (loadedAlbum != null) {
                FilledIconButton(
                  onClick = onToggleAlbumFavorite,
                  colors = IconButtonDefaults.filledIconButtonColors(
                    containerColor = MaterialTheme.colorScheme.surfaceContainerHigh,
                    contentColor = if (isAlbumFavorite) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
                  ),
                  modifier = Modifier
                    .padding(end = 12.dp)
                    .size(40.dp)
                    .testTag("album_favorite_button"),
                ) {
                  RhythmSymbolIcon(
                    icon = if (isAlbumFavorite) RhythmIcons.FavoriteFilled else RhythmIcons.Favorite,
                    contentDescription = if (isAlbumFavorite) "Bỏ yêu thích album" else "Yêu thích album",
                    size = 20.dp,
                    modifier = Modifier.size(20.dp),
                  )
                }
              }
            },
            scrollBehavior = scrollBehavior,
            windowInsets = WindowInsets(0, 0, 0, 0),
            colors = TopAppBarDefaults.largeTopAppBarColors(
              containerColor = Color.Transparent,
              scrolledContainerColor = backgroundColor.copy(alpha = 0.94f),
              titleContentColor = MaterialTheme.colorScheme.onBackground,
            ),
          )
        }
      },
    ) { paddingValues ->
      val collapsedTopPadding = paddingValues.calculateTopPadding()
      val dynamicTopPadding = if (loadedAlbum != null) {
        (heroHeight + (collapsedTopPadding - heroHeight) * collapsedFraction).coerceAtLeast(collapsedTopPadding)
      } else {
        collapsedTopPadding
      }

      when (state) {
        is DetailLoadState.Loading -> BoxLoading(Modifier.padding(top = dynamicTopPadding), bottomOverlayPadding)
        is DetailLoadState.Error -> BoxError(Modifier.padding(top = dynamicTopPadding), bottomOverlayPadding, state.message, onRetry)
        is DetailLoadState.Success -> {
          val album = state.data
          LazyColumn(
            modifier = Modifier
              .fillMaxSize()
              .padding(top = dynamicTopPadding),
            contentPadding = PaddingValues(bottom = bottomOverlayPadding.calculateBottomPadding() + 28.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp),
          ) {
            item(key = "album_split_actions") {
              AnimatedVisibility(
                visible = album.songs.isNotEmpty(),
                enter = expandVertically(spring(dampingRatio = Spring.DampingRatioMediumBouncy)) + fadeIn(tween(280)),
                exit = shrinkVertically() + fadeOut(tween(180)),
              ) {
                Row(
                  modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp)
                    .padding(top = 10.dp, bottom = 12.dp),
                  horizontalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                  RhythmDetailActionButton(
                    text = "Phát tất cả",
                    icon = RhythmIcons.Play,
                    filled = true,
                    isFirst = true,
                    isLast = false,
                    height = 52.dp,
                    onClick = { onPlayAll(album.songs, false) },
                  )
                  RhythmDetailActionButton(
                    text = "Trộn bài",
                    icon = RhythmIcons.Shuffle,
                    filled = false,
                    isFirst = false,
                    isLast = true,
                    height = 52.dp,
                    onClick = { onPlayAll(album.songs, true) },
                  )
                }
              }
            }

            itemsIndexed(
              items = album.songs,
              key = { idx, s -> "alb_s_${s.id}_$idx" },
              contentType = { _, _ -> "song_row" },
            ) { idx, song ->
              SongRowItem(
                song = song,
                rankIndex = idx + 1,
                isCurrentSong = activeTrack.songId == song.id,
                isPlaying = activeTrack.songId == song.id && activeTrack.isPlaying,
                isFavorite = song.id in favoriteIds,
                isPurchased = song.id in purchasedIds || !song.isPaid,
                onClick = { onPlaySong(song, album.songs) },
                onToggleFavorite = { onToggleFavorite(song) },
                onPurchaseClick = { onPurchaseSong(song) },
                onPlayNext = { onPlayNext(song) },
                onAddToQueue = { onAddToQueue(song) },
                onShowInfo = { infoSong = song },
                onShareSong = { shareSongIntent(context, song) },
                modifier = Modifier.padding(horizontal = 8.dp),
              )
            }
          }
        }
      }
    }
  }

  infoSong?.let { selected ->
    SongInfoDialog(
      song = selected,
      isPurchased = selected.id in purchasedIds || !selected.isPaid,
      playCountOnDevice = playCounts[selected.id] ?: 0,
      onShareClick = { shareSongIntent(context, selected) },
      onDismiss = { infoSong = null },
    )
  }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ArtistDetailScreen(
  state: DetailLoadState<Artist>,
  activeTrack: ActiveTrackMeta,
  favoriteIds: Set<String>,
  purchasedIds: Set<String>,
  bottomOverlayPadding: PaddingValues,
  onBack: () -> Unit,
  onRetry: () -> Unit,
  onPlaySong: (Song, List<Song>) -> Unit,
  onPlayAll: (List<Song>, Boolean) -> Unit,
  onToggleFavorite: (Song) -> Unit,
  onPurchaseSong: (Song) -> Unit,
  onOpenAlbum: (String) -> Unit,
  onPlayNext: (Song) -> Unit = {},
  onAddToQueue: (Song) -> Unit = {},
  playCounts: Map<String, Int> = emptyMap(),
) {
  val context = LocalContext.current
  var infoSong by remember { mutableStateOf<Song?>(null) }
  val loadedArtist = (state as? DetailLoadState.Success)?.data
  val artistTitle = loadedArtist?.name ?: "Nghệ sĩ"
  val scrollBehavior = TopAppBarDefaults.exitUntilCollapsedScrollBehavior(
    rememberTopAppBarState(),
    canScroll = { true },
  )
  val collapsedFraction = scrollBehavior.state.collapsedFraction
  val expandedAlpha = ((0.65f - collapsedFraction) / 0.4f).coerceIn(0f, 1f)
  val backgroundColor = MaterialTheme.colorScheme.background

  BoxWithConstraints(modifier = Modifier.fillMaxSize().background(backgroundColor)) {
    val heroHeight = (maxHeight * 0.44f).coerceIn(270.dp, 400.dp)
    if (loadedArtist != null && expandedAlpha > 0.01f) {
      val totalSec = remember(loadedArtist.songs) { loadedArtist.songs.sumOf { it.durationSeconds.coerceAtLeast(0) } }
      val metaText = buildString {
        append("${loadedArtist.albums.size} album • ${loadedArtist.songs.size} bài hát")
        if (totalSec > 0) {
          append(" • ${FormatUtils.formatDurationMs(totalSec * 1000L)}")
        }
      }

      Box(
        modifier = Modifier
          .fillMaxWidth()
          .height(heroHeight)
          .clipToBounds()
          .graphicsLayer {
            alpha = expandedAlpha
            scaleX = 1f + collapsedFraction * 0.15f
            scaleY = 1f + collapsedFraction * 0.15f
          },
      ) {
        Box(
          modifier = Modifier
            .fillMaxSize()
            .graphicsLayer(compositingStrategy = CompositingStrategy.Offscreen),
        ) {
          ArtworkImage(
            imageUrl = loadedArtist.avatarUrl ?: loadedArtist.songs.firstOrNull()?.coverUrl,
            contentDescription = loadedArtist.name,
            shape = RoundedCornerShape(0.dp),
            sizePx = 960,
            modifier = Modifier.fillMaxSize(),
          )

          Box(
            modifier = Modifier
              .fillMaxSize()
              .background(
                Brush.verticalGradient(
                  colors = listOf(
                    backgroundColor.copy(alpha = 0.25f),
                    Color.Transparent,
                    backgroundColor.copy(alpha = 0.62f),
                    backgroundColor,
                  ),
                ),
              ),
          )
        }

        Column(
          modifier = Modifier
            .align(Alignment.BottomStart)
            .fillMaxWidth()
            .padding(24.dp)
            .graphicsLayer {
              translationY = -collapsedFraction * 120f
            },
        ) {
          Text(
            text = loadedArtist.name,
            style = MaterialTheme.typography.displaySmall.copy(fontWeight = FontWeight.Black),
            color = MaterialTheme.colorScheme.onBackground,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
          )
          Spacer(Modifier.height(6.dp))
          Text(
            text = metaText,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.78f),
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
          )
          if (!loadedArtist.bio.isNullOrBlank()) {
            Spacer(Modifier.height(4.dp))
            Text(
              text = loadedArtist.bio,
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.68f),
              maxLines = 2,
              overflow = TextOverflow.Ellipsis,
            )
          }
        }
      }
    }

    Scaffold(
      modifier = Modifier
        .fillMaxSize()
        .nestedScroll(scrollBehavior.nestedScrollConnection),
      containerColor = Color.Transparent,
      contentWindowInsets = WindowInsets(0, 0, 0, 0),
      topBar = {
        Column {
          Spacer(Modifier.height(8.dp))
          LargeTopAppBar(
            title = {
              val titleAlpha = if (loadedArtist != null) {
                ((collapsedFraction - 0.2f) / 0.4f).coerceIn(0f, 1f)
              } else {
                1f
              }
              if (titleAlpha > 0.01f) {
                Text(
                  text = artistTitle,
                  style = MaterialTheme.typography.headlineLarge.copy(
                    fontWeight = FontWeight.Bold,
                    fontSize = lerp(32f, 24f, collapsedFraction).sp,
                  ),
                  maxLines = 1,
                  overflow = TextOverflow.Ellipsis,
                  modifier = Modifier
                    .padding(start = 6.dp)
                    .graphicsLayer { alpha = titleAlpha },
                )
              }
            },
            navigationIcon = {
              FilledIconButton(
                onClick = onBack,
                colors = IconButtonDefaults.filledIconButtonColors(
                  containerColor = MaterialTheme.colorScheme.surfaceContainerHigh,
                  contentColor = MaterialTheme.colorScheme.onSurface,
                ),
                modifier = Modifier
                  .padding(start = 12.dp)
                  .size(40.dp)
                  .testTag("detail_back_button"),
              ) {
                RhythmSymbolIcon(
                  icon = RhythmIcons.Back,
                  contentDescription = "Quay lại",
                  size = 22.dp,
                  modifier = Modifier.size(22.dp),
                )
              }
            },
            scrollBehavior = scrollBehavior,
            windowInsets = WindowInsets(0, 0, 0, 0),
            colors = TopAppBarDefaults.largeTopAppBarColors(
              containerColor = Color.Transparent,
              scrolledContainerColor = backgroundColor.copy(alpha = 0.94f),
              titleContentColor = MaterialTheme.colorScheme.onBackground,
            ),
          )
        }
      },
    ) { paddingValues ->
      val collapsedTopPadding = paddingValues.calculateTopPadding()
      val dynamicTopPadding = if (loadedArtist != null) {
        (heroHeight + (collapsedTopPadding - heroHeight) * collapsedFraction).coerceAtLeast(collapsedTopPadding)
      } else {
        collapsedTopPadding
      }

      when (state) {
        is DetailLoadState.Loading -> BoxLoading(Modifier.padding(top = dynamicTopPadding), bottomOverlayPadding)
        is DetailLoadState.Error -> BoxError(Modifier.padding(top = dynamicTopPadding), bottomOverlayPadding, state.message, onRetry)
        is DetailLoadState.Success -> {
          val artist = state.data
          LazyColumn(
            modifier = Modifier
              .fillMaxSize()
              .padding(top = dynamicTopPadding),
            contentPadding = PaddingValues(bottom = bottomOverlayPadding.calculateBottomPadding() + 28.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
          ) {
            if (artist.songs.isNotEmpty()) {
              item(key = "artist_split_actions") {
                Row(
                  modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp)
                    .padding(top = 10.dp, bottom = 6.dp),
                  horizontalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                  RhythmDetailActionButton(
                    text = "Phát tất cả",
                    icon = RhythmIcons.Play,
                    filled = true,
                    isFirst = true,
                    isLast = false,
                    height = 52.dp,
                    onClick = { onPlayAll(artist.songs, false) },
                  )
                  RhythmDetailActionButton(
                    text = "Trộn bài",
                    icon = RhythmIcons.Shuffle,
                    filled = false,
                    isFirst = false,
                    isLast = true,
                    height = 52.dp,
                    onClick = { onPlayAll(artist.songs, true) },
                  )
                }
              }
            }

            if (artist.albums.isNotEmpty()) {
              item(key = "artist_albums", contentType = "albums_row") {
                val rowState = rememberLazyListState()
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                  RhythmSectionHeader(title = "Album phát hành")
                  LazyRow(
                    state = rowState,
                    modifier = Modifier.horizontalEdgeBlend(rowState),
                    contentPadding = PaddingValues(horizontal = 20.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                  ) {
                    items(artist.albums, key = { "art_alb_${it.id}" }, contentType = { "album_card" }) { album ->
                      val cardInteraction = remember { MutableInteractionSource() }
                      Card(
                        onClick = { onOpenAlbum(album.id) },
                        interactionSource = cardInteraction,
                        shape = RhythmShapes.SquircleLarge,
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerHigh),
                        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp),
                        modifier = Modifier
                          .width(154.dp)
                          .rhythmPressScale(cardInteraction),
                      ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                          Box {
                            val albumCoverShape = rememberExpressiveShapeFor(ExpressiveShapeTarget.ALBUM_ART)
                            ArtworkImage(
                              imageUrl = album.coverUrl,
                              contentDescription = album.title,
                              shape = albumCoverShape,
                              sizePx = 400,
                              modifier = Modifier
                                .fillMaxWidth()
                                .aspectRatio(1f),
                            )
                            FilledIconButton(
                              onClick = {
                                if (album.songs.isNotEmpty()) {
                                  onPlayAll(album.songs, false)
                                } else {
                                  onOpenAlbum(album.id)
                                }
                              },
                              colors = IconButtonDefaults.filledIconButtonColors(
                                containerColor = MaterialTheme.colorScheme.primaryContainer,
                                contentColor = MaterialTheme.colorScheme.onPrimaryContainer,
                              ),
                              modifier = Modifier
                                .align(Alignment.BottomEnd)
                                .padding(8.dp)
                                .size(36.dp),
                            ) {
                              RhythmSymbolIcon(
                                icon = RhythmIcons.Play,
                                contentDescription = "Phát ${album.title}",
                                size = 18.dp,
                                modifier = Modifier.size(18.dp),
                              )
                            }
                          }
                          Spacer(Modifier.height(8.dp))
                          Text(
                            text = album.title,
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.SemiBold),
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis,
                            lineHeight = 18.sp,
                          )
                          if (!album.releaseYear.isNullOrBlank()) {
                            Spacer(Modifier.height(2.dp))
                            Text(
                              text = album.releaseYear,
                              style = MaterialTheme.typography.bodySmall,
                              color = MaterialTheme.colorScheme.onSurfaceVariant,
                              maxLines = 1,
                            )
                          }
                        }
                      }
                    }
                  }
                }
              }
            }

            if (artist.songs.isNotEmpty()) {
              item(key = "artist_songs_hdr") {
                RhythmSectionHeader(title = "Bài hát nổi bật")
              }
              itemsIndexed(
                items = artist.songs,
                key = { idx, s -> "art_s_${s.id}_$idx" },
                contentType = { _, _ -> "song_row" },
              ) { idx, song ->
                SongRowItem(
                  song = song,
                  rankIndex = idx + 1,
                  isCurrentSong = activeTrack.songId == song.id,
                  isPlaying = activeTrack.songId == song.id && activeTrack.isPlaying,
                  isFavorite = song.id in favoriteIds,
                  isPurchased = song.id in purchasedIds || !song.isPaid,
                  onClick = { onPlaySong(song, artist.songs) },
                  onToggleFavorite = { onToggleFavorite(song) },
                  onPurchaseClick = { onPurchaseSong(song) },
                  onPlayNext = { onPlayNext(song) },
                  onAddToQueue = { onAddToQueue(song) },
                  onShowInfo = { infoSong = song },
                  onShareSong = { shareSongIntent(context, song) },
                  modifier = Modifier.padding(horizontal = 8.dp),
                )
              }
            }
          }
        }
      }
    }
  }

  infoSong?.let { selected ->
    SongInfoDialog(
      song = selected,
      isPurchased = selected.id in purchasedIds || !selected.isPaid,
      playCountOnDevice = playCounts[selected.id] ?: 0,
      onShareClick = { shareSongIntent(context, selected) },
      onDismiss = { infoSong = null },
    )
  }
}

@Composable
fun PlaylistDetailScreen(
  state: DetailLoadState<Playlist>,
  currentUserId: String?,
  activeTrack: ActiveTrackMeta,
  favoriteIds: Set<String>,
  purchasedIds: Set<String>,
  bottomOverlayPadding: PaddingValues,
  onBack: () -> Unit,
  onRetry: () -> Unit,
  onPlaySong: (Song, List<Song>) -> Unit,
  onPlayAll: (List<Song>, Boolean) -> Unit,
  onToggleFavorite: (Song) -> Unit,
  onPurchaseSong: (Song) -> Unit,
  onUpdatePlaylist: (playlistId: String, title: String, description: String) -> Unit,
  onDeletePlaylist: (playlistId: String) -> Unit,
  onPlayNext: (Song) -> Unit = {},
  onAddToQueue: (Song) -> Unit = {},
  playCounts: Map<String, Int> = emptyMap(),
) {
  val context = LocalContext.current
  var infoSong by remember { mutableStateOf<Song?>(null) }
  val playlist = (state as? DetailLoadState.Success)?.data
  val isOwner = playlist != null && currentUserId != null && playlist.curatorId == currentUserId

  var showEditDialog by remember { mutableStateOf(false) }
  var showDeleteConfirm by remember { mutableStateOf(false) }

  RhythmCollapsibleHeaderScreen(
    title = playlist?.title ?: "Playlist",
    showBackButton = true,
    onBackClick = onBack,
    headerActions = if (isOwner) {
      listOf(
        RhythmHeaderAction(
          icon = RhythmIcons.Edit,
          contentDescription = "Sửa playlist",
          onClick = { showEditDialog = true },
        ),
        RhythmHeaderAction(
          icon = RhythmIcons.Delete,
          contentDescription = "Xóa playlist",
          onClick = { showDeleteConfirm = true },
        ),
      )
    } else emptyList(),
  ) { scaffoldModifier ->
    when (state) {
      is DetailLoadState.Loading -> BoxLoading(scaffoldModifier, bottomOverlayPadding)
      is DetailLoadState.Error -> BoxError(scaffoldModifier, bottomOverlayPadding, state.message, onRetry)
      is DetailLoadState.Success -> {
        LazyColumn(
          modifier = scaffoldModifier.fillMaxSize(),
          contentPadding = PaddingValues(bottom = bottomOverlayPadding.calculateBottomPadding() + 28.dp),
          verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
          item(key = "pl_hero") {
            val pl = playlist!!
            val playlistHeroShape = rememberExpressiveShapeFor(ExpressiveShapeTarget.PLAYLIST_ART)
            Column(
              modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 24.dp, vertical = 10.dp),
              horizontalAlignment = Alignment.CenterHorizontally,
              verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
              Surface(
                shape = playlistHeroShape,
                color = MaterialTheme.colorScheme.surfaceContainerHigh,
                tonalElevation = 2.dp,
                modifier = Modifier.size(164.dp),
              ) {
                ArtworkImage(
                  imageUrl = pl.coverUrl ?: pl.songs.firstOrNull()?.coverUrl,
                  contentDescription = pl.title,
                  shape = playlistHeroShape,
                  sizePx = 560,
                  modifier = Modifier.fillMaxSize(),
                )
              }

              val subText = pl.description?.takeIf { it.isNotBlank() }
                ?: (pl.curator ?: "Playlist XK Music")
              Text(
                text = subText,
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.primary,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
              )

              Surface(
                shape = CircleShape,
                color = MaterialTheme.colorScheme.secondaryContainer,
              ) {
                Text(
                  text = "${pl.songs.size} bài hát" + if (isOwner) " • Cá nhân" else "",
                  style = MaterialTheme.typography.labelMedium,
                  color = MaterialTheme.colorScheme.onSecondaryContainer,
                  modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp),
                )
              }

              if (pl.songs.isNotEmpty()) {
                Row(
                  modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 4.dp),
                  horizontalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                  RhythmDetailActionButton(
                    text = "Phát tất cả",
                    icon = RhythmIcons.Play,
                    filled = true,
                    isFirst = true,
                    isLast = false,
                    height = 50.dp,
                    onClick = { onPlayAll(pl.songs, false) },
                  )
                  RhythmDetailActionButton(
                    text = "Trộn bài",
                    icon = RhythmIcons.Shuffle,
                    filled = false,
                    isFirst = false,
                    isLast = true,
                    height = 50.dp,
                    onClick = { onPlayAll(pl.songs, true) },
                  )
                }
              }
            }
          }

          if (playlist!!.songs.isEmpty()) {
            item(key = "pl_empty") {
              StatusMessageCard(
                title = "Playlist chưa có bài hát",
                message = "Danh sách phát này hiện chưa có bài hát nào.",
              )
            }
          } else {
            itemsIndexed(
              items = playlist.songs,
              key = { idx, s -> "pl_s_${s.id}_$idx" },
              contentType = { _, _ -> "song_row" },
            ) { idx, song ->
              SongRowItem(
                song = song,
                rankIndex = idx + 1,
                isCurrentSong = activeTrack.songId == song.id,
                isPlaying = activeTrack.songId == song.id && activeTrack.isPlaying,
                isFavorite = song.id in favoriteIds,
                isPurchased = song.id in purchasedIds || !song.isPaid,
                onClick = { onPlaySong(song, playlist.songs) },
                onToggleFavorite = { onToggleFavorite(song) },
                onPurchaseClick = { onPurchaseSong(song) },
                onPlayNext = { onPlayNext(song) },
                onAddToQueue = { onAddToQueue(song) },
                onShowInfo = { infoSong = song },
                onShareSong = { shareSongIntent(context, song) },
                modifier = Modifier.padding(horizontal = 8.dp),
              )
            }
          }
        }
      }
    }
  }

  infoSong?.let { selected ->
    SongInfoDialog(
      song = selected,
      isPurchased = selected.id in purchasedIds || !selected.isPaid,
      playCountOnDevice = playCounts[selected.id] ?: 0,
      onShareClick = { shareSongIntent(context, selected) },
      onDismiss = { infoSong = null },
    )
  }

  if (showEditDialog && playlist != null) {
    PlaylistEditorDialog(
      dialogTitle = "Chỉnh sửa playlist",
      initialTitle = playlist.title,
      initialDescription = playlist.description.orEmpty(),
      confirmLabel = "Cập nhật",
      onConfirm = { newTitle, newDesc ->
        onUpdatePlaylist(playlist.id, newTitle, newDesc)
        showEditDialog = false
      },
      onDismiss = { showEditDialog = false },
    )
  }

  if (showDeleteConfirm && playlist != null) {
    AlertDialog(
      onDismissRequest = { showDeleteConfirm = false },
      title = { Text("Xóa playlist?") },
      text = { Text("Bạn chắc chắn muốn xóa \"${playlist.title}\"? Hành động này không thể hoàn tác.") },
      confirmButton = {
        TextButton(
          onClick = {
            showDeleteConfirm = false
            onDeletePlaylist(playlist.id)
          },
        ) {
          Text("Xóa", color = MaterialTheme.colorScheme.error)
        }
      },
      dismissButton = {
        TextButton(onClick = { showDeleteConfirm = false }) { Text("Hủy") }
      },
    )
  }
}

@Composable
private fun BoxLoading(
  modifier: Modifier,
  bottomOverlayPadding: PaddingValues,
) {
  LazyColumn(
    modifier = modifier.fillMaxSize(),
    contentPadding = PaddingValues(top = 16.dp, bottom = bottomOverlayPadding.calculateBottomPadding() + 24.dp),
  ) {
    item { LoadingSkeletonList(itemCount = 6) }
  }
}

@Composable
private fun BoxError(
  modifier: Modifier,
  bottomOverlayPadding: PaddingValues,
  message: String,
  onRetry: () -> Unit,
) {
  LazyColumn(
    modifier = modifier.fillMaxSize(),
    contentPadding = PaddingValues(top = 16.dp, bottom = bottomOverlayPadding.calculateBottomPadding() + 24.dp),
  ) {
    item {
      StatusMessageCard(
        title = "Không thể tải nội dung",
        message = message,
        actionLabel = "Thử lại",
        onAction = onRetry,
      )
    }
  }
}

@Composable
fun AllArtistsScreen(
  artists: List<Artist>,
  bottomOverlayPadding: PaddingValues,
  onBack: () -> Unit,
  onOpenArtist: (String) -> Unit,
) {
  RhythmCollapsibleHeaderScreen(
    title = "Nghệ sĩ nổi bật",
    showBackButton = true,
    onBackClick = onBack,
  ) { scaffoldModifier ->
    if (artists.isEmpty()) {
      Box(
        modifier = scaffoldModifier
          .fillMaxSize()
          .padding(bottom = bottomOverlayPadding.calculateBottomPadding()),
        contentAlignment = Alignment.Center,
      ) {
        StatusMessageCard(
          title = "Chưa có dữ liệu nghệ sĩ",
          message = "Danh sách nghệ sĩ hiện đang trống.",
        )
      }
    } else {
      LazyVerticalGrid(
        columns = GridCells.Fixed(3),
        modifier = scaffoldModifier
          .fillMaxSize()
          .testTag("all_artists_grid"),
        contentPadding = PaddingValues(
          start = 16.dp,
          end = 16.dp,
          top = 12.dp,
          bottom = bottomOverlayPadding.calculateBottomPadding() + 28.dp,
        ),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp),
      ) {
        items(
          items = artists,
          key = { "grid_artist_${it.id}" },
          contentType = { "artist_grid_item" },
        ) { artist ->
          val artistInteraction = remember { MutableInteractionSource() }
          Column(
            modifier = Modifier
              .fillMaxWidth()
              .rhythmPressScale(artistInteraction)
              .clip(RoundedCornerShape(18.dp))
              .clickable(
                interactionSource = artistInteraction,
                indication = LocalIndication.current,
              ) { onOpenArtist(artist.id) }
              .padding(4.dp)
              .testTag("all_artist_${artist.id}"),
            horizontalAlignment = Alignment.CenterHorizontally,
          ) {
            Box(
              modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(1f),
            ) {
              ArtworkImage(
                imageUrl = artist.avatarUrl,
                contentDescription = artist.name,
                shape = CircleShape,
                sizePx = 280,
                modifier = Modifier.fillMaxSize(),
              )
              FilledIconButton(
                onClick = { onOpenArtist(artist.id) },
                colors = IconButtonDefaults.filledIconButtonColors(
                  containerColor = MaterialTheme.colorScheme.primaryContainer,
                  contentColor = MaterialTheme.colorScheme.onPrimaryContainer,
                ),
                modifier = Modifier
                  .size(30.dp)
                  .align(Alignment.BottomEnd),
              ) {
                RhythmSymbolIcon(
                  icon = RhythmIcons.Play,
                  contentDescription = "Nghe ${artist.name}",
                  size = 16.dp,
                  modifier = Modifier.size(16.dp),
                )
              }
            }
            Spacer(Modifier.height(8.dp))
            Text(
              text = artist.name,
              style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.SemiBold),
              color = MaterialTheme.colorScheme.onSurface,
              maxLines = 2,
              minLines = 2,
              overflow = TextOverflow.Ellipsis,
              textAlign = TextAlign.Center,
              lineHeight = 18.sp,
            )
          }
        }
      }
    }
  }
}
