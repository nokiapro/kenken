@file:OptIn(ExperimentalMaterial3ExpressiveApi::class, ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)

package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.Crossfade
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandHorizontally
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkHorizontally
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.MarqueeSpacing
import androidx.compose.foundation.background
import androidx.compose.foundation.basicMarquee
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularWavyProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExperimentalMaterial3ExpressiveApi
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.LargeTopAppBar
import androidx.compose.material3.LocalTextStyle
import androidx.compose.material3.MaterialShapes
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.material3.rememberTopAppBarState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.Outline
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp as colorLerp
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.layout.SubcomposeLayout
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.role
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.TextLayoutResult
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.util.lerp
import com.example.ui.FestiveThemeMode
import com.example.ui.NavBarLabelBehavior
import com.example.ui.rhythm.AnyIcon
import com.example.ui.rhythm.ExpressiveMaterialShape
import com.example.ui.rhythm.MaterialSymbolIcon
import com.example.ui.rhythm.RhythmIcons
import com.example.ui.rhythm.RhythmSymbolIcon
import com.example.ui.rhythm.rememberExpressiveShape
import com.example.ui.rhythm.toComposeShape
import com.example.ui.theme.LocalRhythmHapticsEnabled
import com.example.ui.theme.resolveEffectiveFestiveTheme
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.Calendar
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

// ---------------------------------------------------------------------------
// 1. CollapsibleHeaderScreen — Rhythm's LargeTopAppBar with 24.dp vertical blend
// ---------------------------------------------------------------------------

@Immutable
data class RhythmHeaderAction(
  val icon: Any,
  val contentDescription: String,
  val testTag: String? = null,
  val onClick: () -> Unit,
)

@Composable
fun RhythmCollapsibleHeaderScreen(
  title: String,
  modifier: Modifier = Modifier,
  showBackButton: Boolean = false,
  onBackClick: () -> Unit = {},
  leadingBadgeIcon: Any? = null,
  compactSingleRowHeader: Boolean = false,
  headerActions: List<RhythmHeaderAction> = emptyList(),
  filterContent: (@Composable () -> Unit)? = null,
  floatingActionButton: @Composable () -> Unit = {},
  content: @Composable (Modifier) -> Unit,
) {
  val scrollBehavior = if (compactSingleRowHeader) {
    TopAppBarDefaults.pinnedScrollBehavior(rememberTopAppBarState())
  } else {
    TopAppBarDefaults.exitUntilCollapsedScrollBehavior(rememberTopAppBarState())
  }
  val collapsedFraction = scrollBehavior.state.collapsedFraction
  val titleSize = lerp(32f, 24f, collapsedFraction).sp
  val headerBlendHeight = if (compactSingleRowHeader) 10.dp else 24.dp
  val headerBaseColor = MaterialTheme.colorScheme.background

  Scaffold(
    modifier = modifier
      .fillMaxSize()
      .nestedScroll(scrollBehavior.nestedScrollConnection),
    containerColor = Color.Transparent,
    contentWindowInsets = WindowInsets(0, 0, 0, 0),
    floatingActionButton = floatingActionButton,
    topBar = {
      Column {
        Column(modifier = Modifier.background(headerBaseColor)) {
          if (compactSingleRowHeader) {
            Spacer(modifier = Modifier.height(4.dp))
            TopAppBar(
              title = {
                Row(
                  verticalAlignment = Alignment.CenterVertically,
                  horizontalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                  if (leadingBadgeIcon != null) {
                    Surface(
                      shape = CircleShape,
                      color = MaterialTheme.colorScheme.primaryContainer,
                      modifier = Modifier.size(34.dp),
                    ) {
                      Box(contentAlignment = Alignment.Center) {
                        AnyIcon(
                          icon = leadingBadgeIcon,
                          contentDescription = null,
                          tint = MaterialTheme.colorScheme.onPrimaryContainer,
                          size = 20.dp,
                          modifier = Modifier.size(20.dp),
                        )
                      }
                    }
                  }
                  Text(
                    text = title,
                    fontSize = 21.sp,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                  )
                }
              },
              navigationIcon = {
                if (showBackButton) {
                  FilledIconButton(
                    onClick = onBackClick,
                    colors = IconButtonDefaults.filledIconButtonColors(
                      containerColor = MaterialTheme.colorScheme.surfaceContainerHigh,
                      contentColor = MaterialTheme.colorScheme.onSurface,
                    ),
                    modifier = Modifier
                      .padding(start = 12.dp)
                      .size(40.dp)
                      .testTag("detail_back_button"),
                  ) {
                    RhythmSymbolIcon(
                      icon = RhythmIcons.Back,
                      contentDescription = "Quay lại",
                      size = 22.dp,
                      modifier = Modifier.size(22.dp),
                    )
                  }
                }
              },
              actions = {
                if (headerActions.isNotEmpty()) {
                  Row(
                    modifier = Modifier.padding(end = 12.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                  ) {
                    headerActions.forEach { action ->
                      FilledIconButton(
                        onClick = action.onClick,
                        colors = IconButtonDefaults.filledIconButtonColors(
                          containerColor = MaterialTheme.colorScheme.surfaceContainerHigh,
                          contentColor = MaterialTheme.colorScheme.onSurface,
                        ),
                        modifier = Modifier
                          .size(40.dp)
                          .then(
                            if (!action.testTag.isNullOrBlank()) {
                              Modifier.testTag(action.testTag)
                            } else {
                              Modifier
                            },
                          ),
                      ) {
                        AnyIcon(
                          icon = action.icon,
                          contentDescription = action.contentDescription,
                          size = 20.dp,
                          modifier = Modifier.size(20.dp),
                        )
                      }
                    }
                  }
                }
              },
              colors = TopAppBarDefaults.topAppBarColors(
                containerColor = headerBaseColor,
                scrolledContainerColor = headerBaseColor,
                titleContentColor = MaterialTheme.colorScheme.onBackground,
              ),
              windowInsets = WindowInsets(0, 0, 0, 0),
              scrollBehavior = scrollBehavior,
            )
          } else {
            Spacer(modifier = Modifier.height(8.dp))
            LargeTopAppBar(
              title = {
                Row(
                  verticalAlignment = Alignment.CenterVertically,
                  horizontalArrangement = Arrangement.spacedBy(8.dp),
                  modifier = Modifier.padding(start = 6.dp),
                ) {
                  if (leadingBadgeIcon != null) {
                    Surface(
                      shape = CircleShape,
                      color = MaterialTheme.colorScheme.primaryContainer,
                      modifier = Modifier.size(if (collapsedFraction < 0.5f) 34.dp else 28.dp),
                    ) {
                      Box(contentAlignment = Alignment.Center) {
                        AnyIcon(
                          icon = leadingBadgeIcon,
                          contentDescription = null,
                          tint = MaterialTheme.colorScheme.onPrimaryContainer,
                          size = if (collapsedFraction < 0.5f) 20.dp else 16.dp,
                          modifier = Modifier.size(if (collapsedFraction < 0.5f) 20.dp else 16.dp),
                        )
                      }
                    }
                  }
                  Text(
                    text = title,
                    fontSize = titleSize,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                  )
                }
              },
              navigationIcon = {
                if (showBackButton) {
                  FilledIconButton(
                    onClick = onBackClick,
                    colors = IconButtonDefaults.filledIconButtonColors(
                      containerColor = MaterialTheme.colorScheme.surfaceContainerHigh,
                      contentColor = MaterialTheme.colorScheme.onSurface,
                    ),
                    modifier = Modifier
                      .padding(start = 12.dp)
                      .size(40.dp)
                      .testTag("detail_back_button"),
                  ) {
                    RhythmSymbolIcon(
                      icon = RhythmIcons.Back,
                      contentDescription = "Quay lại",
                      size = 22.dp,
                      modifier = Modifier.size(22.dp),
                    )
                  }
                }
              },
              actions = {
                if (headerActions.isNotEmpty()) {
                  Row(
                    modifier = Modifier.padding(end = 12.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                  ) {
                    headerActions.forEach { action ->
                      FilledIconButton(
                        onClick = action.onClick,
                        colors = IconButtonDefaults.filledIconButtonColors(
                          containerColor = MaterialTheme.colorScheme.surfaceContainerHigh,
                          contentColor = MaterialTheme.colorScheme.onSurface,
                        ),
                        modifier = Modifier
                          .size(40.dp)
                          .then(
                            if (!action.testTag.isNullOrBlank()) {
                              Modifier.testTag(action.testTag)
                            } else {
                              Modifier
                            },
                          ),
                      ) {
                        AnyIcon(
                          icon = action.icon,
                          contentDescription = action.contentDescription,
                          size = 20.dp,
                          modifier = Modifier.size(20.dp),
                        )
                      }
                    }
                  }
                }
              },
              colors = TopAppBarDefaults.largeTopAppBarColors(
                containerColor = headerBaseColor,
                scrolledContainerColor = headerBaseColor,
                titleContentColor = MaterialTheme.colorScheme.onBackground,
              ),
              windowInsets = WindowInsets(0, 0, 0, 0),
              scrollBehavior = scrollBehavior,
            )
          }
          if (filterContent != null) {
            filterContent()
          }
        }
        Box(
          modifier = Modifier
            .fillMaxWidth()
            .height(headerBlendHeight)
            .background(
              Brush.verticalGradient(
                colors = listOf(
                  headerBaseColor,
                  headerBaseColor.copy(alpha = 0.72f),
                  headerBaseColor.copy(alpha = 0.32f),
                  Color.Transparent,
                ),
              ),
            ),
        )
      }
    },
  ) { innerPadding ->
    val topContentPadding = (innerPadding.calculateTopPadding() - headerBlendHeight).coerceAtLeast(0.dp)
    content(Modifier.padding(top = topContentPadding))
  }
}

// ---------------------------------------------------------------------------
// 2. RhythmFloatingNavBarWithSearch — Rhythm's Pill Nav + Detached Search FAB
// ---------------------------------------------------------------------------

@Immutable
data class RhythmNavItem(
  val route: Any,
  val label: String,
  val selectedIcon: Any,
  val unselectedIcon: Any,
  val testTag: String,
)

@Composable
fun RhythmFloatingNavBarWithSearch(
  items: List<RhythmNavItem>,
  selectedPredicate: (RhythmNavItem) -> Boolean,
  onSelect: (RhythmNavItem) -> Unit,
  isSearchSelected: Boolean,
  onSearchClick: () -> Unit,
  modifier: Modifier = Modifier,
  searchTestTag: String = "nav_explore",
  labelBehavior: NavBarLabelBehavior = NavBarLabelBehavior.SELECTED_ONLY,
  showDetachedSearchFab: Boolean = true,
) {
  val haptic = LocalHapticFeedback.current
  val hapticsEnabled = LocalRhythmHapticsEnabled.current
  val searchInteraction = remember { MutableInteractionSource() }
  val isSearchPressed by searchInteraction.collectIsPressedAsState()
  val searchScale by animateFloatAsState(
    targetValue = if (isSearchPressed) 0.88f else 1f,
    animationSpec = spring(
      dampingRatio = Spring.DampingRatioMediumBouncy,
      stiffness = Spring.StiffnessMedium,
    ),
    label = "rhythm_search_fab_scale",
  )

  val displayItems = remember(items, showDetachedSearchFab) {
    if (showDetachedSearchFab) {
      items
    } else {
      items + RhythmNavItem(
        route = "__search_inline__",
        label = "Tìm kiếm",
        selectedIcon = RhythmIcons.SearchFilled,
        unselectedIcon = RhythmIcons.Search,
        testTag = searchTestTag,
      )
    }
  }

  Box(
    modifier = modifier
      .fillMaxWidth()
      .windowInsetsPadding(WindowInsets.navigationBars)
      .padding(horizontal = 16.dp, vertical = 8.dp),
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .height(64.dp),
      horizontalArrangement = Arrangement.spacedBy(12.dp),
      verticalAlignment = Alignment.CenterVertically,
    ) {
      Surface(
        modifier = Modifier
          .weight(1f)
          .height(64.dp),
        shape = CircleShape,
        color = MaterialTheme.colorScheme.surfaceContainer,
        shadowElevation = 0.dp,
        tonalElevation = 3.dp,
      ) {
        Row(
          modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 10.dp),
          horizontalArrangement = Arrangement.SpaceEvenly,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          displayItems.forEach { item ->
            val isInlineSearch = item.route == "__search_inline__"
            val selected = if (isInlineSearch) isSearchSelected else selectedPredicate(item)
            val showLabel = when (labelBehavior) {
              NavBarLabelBehavior.SELECTED_ONLY -> selected
              NavBarLabelBehavior.ALWAYS -> true
              NavBarLabelBehavior.ICONS_ONLY -> false
            }
            val interactionSource = remember(item.testTag) { MutableInteractionSource() }
            val isPressed by interactionSource.collectIsPressedAsState()

            val pressScale by animateFloatAsState(
              targetValue = if (isPressed) 0.90f else 1f,
              animationSpec = spring(
                dampingRatio = Spring.DampingRatioMediumBouncy,
                stiffness = Spring.StiffnessMedium,
              ),
              label = "nav_scale_${item.testTag}",
            )

            val targetWeight = when (labelBehavior) {
              NavBarLabelBehavior.SELECTED_ONLY -> if (selected) 1.9f else 0.95f
              NavBarLabelBehavior.ALWAYS -> 1f
              NavBarLabelBehavior.ICONS_ONLY -> 1f
            }
            val itemWeight by animateFloatAsState(
              targetValue = targetWeight,
              animationSpec = spring(
                dampingRatio = Spring.DampingRatioMediumBouncy,
                stiffness = Spring.StiffnessLow,
              ),
              label = "nav_weight_${item.testTag}",
            )

            val pillBgColor by animateColorAsState(
              targetValue = if (selected) {
                MaterialTheme.colorScheme.primaryContainer
              } else {
                Color.Transparent
              },
              animationSpec = tween(220),
              label = "nav_bg_${item.testTag}",
            )

            val iconTint by animateColorAsState(
              targetValue = if (selected) {
                MaterialTheme.colorScheme.onPrimaryContainer
              } else {
                MaterialTheme.colorScheme.onSurfaceVariant
              },
              animationSpec = tween(220),
              label = "nav_tint_${item.testTag}",
            )

            Box(
              modifier = Modifier
                .weight(itemWeight)
                .height(48.dp)
                .graphicsLayer {
                  scaleX = pressScale
                  scaleY = pressScale
                }
                .clip(CircleShape)
                .background(pillBgColor)
                .clickable(
                  interactionSource = interactionSource,
                  indication = null,
                  role = Role.Tab,
                  onClick = {
                    if (hapticsEnabled) {
                      haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                    }
                    if (isInlineSearch) onSearchClick() else onSelect(item)
                  },
                )
                .testTag(item.testTag),
              contentAlignment = Alignment.Center,
            ) {
              if (labelBehavior == NavBarLabelBehavior.ALWAYS) {
                Column(
                  horizontalAlignment = Alignment.CenterHorizontally,
                  verticalArrangement = Arrangement.Center,
                  modifier = Modifier.padding(horizontal = 4.dp),
                ) {
                  AnyIcon(
                    icon = if (selected) item.selectedIcon else item.unselectedIcon,
                    contentDescription = item.label,
                    tint = iconTint,
                    size = 20.dp,
                    modifier = Modifier.size(20.dp),
                  )
                  Text(
                    text = item.label,
                    style = MaterialTheme.typography.labelSmall.copy(
                      fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                      fontSize = 10.sp,
                    ),
                    color = iconTint,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                  )
                }
              } else {
                Row(
                  modifier = Modifier.padding(horizontal = if (showLabel) 12.dp else 4.dp),
                  verticalAlignment = Alignment.CenterVertically,
                  horizontalArrangement = Arrangement.Center,
                ) {
                  Crossfade(
                    targetState = selected,
                    animationSpec = spring(
                      dampingRatio = Spring.DampingRatioMediumBouncy,
                      stiffness = Spring.StiffnessVeryLow,
                    ),
                    label = "nav_icon_${item.testTag}",
                  ) { isSel ->
                    AnyIcon(
                      icon = if (isSel) item.selectedIcon else item.unselectedIcon,
                      contentDescription = item.label,
                      tint = iconTint,
                      size = 22.dp,
                      modifier = Modifier.size(22.dp),
                    )
                  }

                  AnimatedVisibility(
                    visible = showLabel,
                    enter = fadeIn(
                      animationSpec = spring(
                        dampingRatio = Spring.DampingRatioMediumBouncy,
                        stiffness = Spring.StiffnessVeryLow,
                      ),
                    ) + expandHorizontally(
                      animationSpec = spring(
                        dampingRatio = Spring.DampingRatioMediumBouncy,
                        stiffness = Spring.StiffnessLow,
                      ),
                    ),
                    exit = fadeOut(tween(120)) + shrinkHorizontally(tween(180)),
                  ) {
                    Text(
                      text = item.label,
                      style = MaterialTheme.typography.labelLarge.copy(
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 12.5.sp,
                      ),
                      color = MaterialTheme.colorScheme.onPrimaryContainer,
                      maxLines = 1,
                      overflow = TextOverflow.Ellipsis,
                      modifier = Modifier.padding(start = 6.dp),
                    )
                  }
                }
              }
            }
          }
        }
      }

      if (showDetachedSearchFab) {
        val fabContainer by animateColorAsState(
          targetValue = if (isSearchSelected) {
            MaterialTheme.colorScheme.primary
          } else {
            MaterialTheme.colorScheme.primaryContainer
          },
          animationSpec = tween(220),
          label = "search_fab_bg",
        )
        val fabContent by animateColorAsState(
          targetValue = if (isSearchSelected) {
            MaterialTheme.colorScheme.onPrimary
          } else {
            MaterialTheme.colorScheme.onPrimaryContainer
          },
          animationSpec = tween(220),
          label = "search_fab_fg",
        )

        FilledIconButton(
          onClick = {
            if (hapticsEnabled) {
              haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
            }
            onSearchClick()
          },
          interactionSource = searchInteraction,
          shape = CircleShape,
          colors = IconButtonDefaults.filledIconButtonColors(
            containerColor = fabContainer,
            contentColor = fabContent,
          ),
          modifier = Modifier
            .size(64.dp)
            .graphicsLayer {
              scaleX = searchScale
              scaleY = searchScale
            }
            .testTag(searchTestTag),
        ) {
          RhythmSymbolIcon(
            icon = if (isSearchSelected) RhythmIcons.SearchFilled else RhythmIcons.Search,
            contentDescription = "Tìm kiếm",
            size = 25.dp,
            modifier = Modifier.size(25.dp),
          )
        }
      }
    }
  }
}

@Composable
fun RhythmDockedNavBar(
  items: List<RhythmNavItem>,
  selectedPredicate: (RhythmNavItem) -> Boolean,
  onSelect: (RhythmNavItem) -> Unit,
  isSearchSelected: Boolean,
  onSearchClick: () -> Unit,
  modifier: Modifier = Modifier,
  searchTestTag: String = "nav_explore",
  labelBehavior: NavBarLabelBehavior = NavBarLabelBehavior.SELECTED_ONLY,
) {
  val haptic = LocalHapticFeedback.current
  val hapticsEnabled = LocalRhythmHapticsEnabled.current
  val allItems = remember(items) {
    items + RhythmNavItem(
      route = "__search_docked__",
      label = "Tìm kiếm",
      selectedIcon = RhythmIcons.SearchFilled,
      unselectedIcon = RhythmIcons.Search,
      testTag = searchTestTag,
    )
  }

  NavigationBar(
    modifier = modifier.fillMaxWidth(),
    containerColor = MaterialTheme.colorScheme.surfaceContainer,
    windowInsets = WindowInsets.navigationBars,
  ) {
    allItems.forEach { item ->
      val isSearch = item.route == "__search_docked__"
      val selected = if (isSearch) isSearchSelected else selectedPredicate(item)
      val alwaysShow = labelBehavior == NavBarLabelBehavior.ALWAYS
      val showLabel = labelBehavior != NavBarLabelBehavior.ICONS_ONLY
      NavigationBarItem(
        selected = selected,
        onClick = {
          if (hapticsEnabled) {
            haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
          }
          if (isSearch) onSearchClick() else onSelect(item)
        },
        icon = {
          AnyIcon(
            icon = if (selected) item.selectedIcon else item.unselectedIcon,
            contentDescription = item.label,
            size = 22.dp,
            modifier = Modifier.size(22.dp),
          )
        },
        label = if (showLabel) {
          {
            Text(
              text = item.label,
              maxLines = 1,
              overflow = TextOverflow.Ellipsis,
            )
          }
        } else {
          null
        },
        alwaysShowLabel = alwaysShow,
        colors = NavigationBarItemDefaults.colors(
          selectedIconColor = MaterialTheme.colorScheme.onPrimaryContainer,
          selectedTextColor = MaterialTheme.colorScheme.primary,
          indicatorColor = MaterialTheme.colorScheme.primaryContainer,
        ),
        modifier = Modifier.testTag(item.testTag),
      )
    }
  }
}

@Composable
fun FestiveParticlesOverlay(
  festiveThemeMode: FestiveThemeMode,
  enabled: Boolean,
  modifier: Modifier = Modifier,
) {
  val effective = remember(festiveThemeMode) { resolveEffectiveFestiveTheme(festiveThemeMode) }
  if (!enabled || effective == FestiveThemeMode.NONE) return

  data class Particle(val xSeed: Float, val yOffset: Float, val speed: Float, val radiusDp: Float, val drift: Float, val variant: Int)

  val particles = remember(effective) {
    List(28) { i ->
      val idx = i + 1
      Particle(
        xSeed = ((idx * 41 + 17) % 100) / 100f,
        yOffset = ((idx * 67 + 23) % 100) / 100f,
        speed = 0.6f + (idx % 4) * 0.25f,
        radiusDp = 2.0f + (idx % 3) * 1.1f,
        drift = ((idx % 5) - 2) * 0.04f,
        variant = idx % 3,
      )
    }
  }

  val transition = rememberInfiniteTransition(label = "festive_particles")
  val phase by transition.animateFloat(
    initialValue = 0f,
    targetValue = 1f,
    animationSpec = infiniteRepeatable(
      animation = tween(durationMillis = 10_000, easing = LinearEasing),
      repeatMode = RepeatMode.Restart,
    ),
    label = "festive_phase",
  )

  val colors = when (effective) {
    FestiveThemeMode.TET -> listOf(Color(0xFFFFD54F), Color(0xFFFF80AB), Color(0xFFFF7043))
    FestiveThemeMode.VALENTINE -> listOf(Color(0xFFFF4081), Color(0xFFFF80AB), Color(0xFFF48FB1))
    FestiveThemeMode.HALLOWEEN -> listOf(Color(0xFFFF6D00), Color(0xFFAB47BC), Color(0xFFFFAB40))
    FestiveThemeMode.CHRISTMAS -> listOf(Color(0xFFFFFFFF), Color(0xFFE0F7FA), Color(0xFFFFCDD2))
    FestiveThemeMode.NEW_YEAR -> listOf(Color(0xFFFFD740), Color(0xFF40C4FF), Color(0xFFFF80AB))
    else -> emptyList()
  }
  if (colors.isEmpty()) return

  Canvas(modifier = modifier.fillMaxSize()) {
    particles.forEach { p ->
      val progressY = (p.yOffset + phase * p.speed) % 1f
      val xFrac = (p.xSeed + sin((progressY * 2f * PI + p.variant).toDouble()).toFloat() * p.drift).coerceIn(0.02f, 0.98f)
      val center = Offset(x = xFrac * size.width, y = progressY * size.height)
      val color = colors[p.variant % colors.size].copy(alpha = 0.38f)
      val r = p.radiusDp.dp.toPx()
      drawCircle(color = color, radius = r, center = center)
    }
  }
}

// ---------------------------------------------------------------------------
// 3. Genuine Rhythm Expressive Play / Control / Grouped / Split Action Buttons
// ---------------------------------------------------------------------------

/**
 * Genuine Rhythm `RhythmPlayButton` (`RhythmControlButton.kt` in v5.5.499.1302-stable):
 * Large wide capsule showing bold single text label ("Tạm dừng" / "Phát") or M3 buffering loader,
 * with corner collapse (`size / 2 -> size / 2 - 18.dp`) and spring bounce on press.
 */
@Composable
fun RhythmPlayButton(
  isPlaying: Boolean,
  onClick: () -> Unit,
  modifier: Modifier = Modifier,
  showBuffering: Boolean = false,
  size: Dp = 64.dp,
  containerColor: Color = MaterialTheme.colorScheme.primaryContainer,
  contentColor: Color = MaterialTheme.colorScheme.onPrimaryContainer,
  playingLabel: String = "Đang phát",
  pausedLabel: String = "Phát nhạc",
) {
  val interactionSource = remember { MutableInteractionSource() }
  val isPressed by interactionSource.collectIsPressedAsState()
  val haptic = LocalHapticFeedback.current
  val scope = rememberCoroutineScope()
  var isTapped by remember { mutableStateOf(false) }
  val visualActive = isPressed || isTapped

  val animCorner by animateDpAsState(
    targetValue = if (visualActive) 18.dp else 0.dp,
    animationSpec = spring(
      dampingRatio = Spring.DampingRatioNoBouncy,
      stiffness = Spring.StiffnessMedium,
    ),
    label = "playBtnCorner",
  )

  val scale by animateFloatAsState(
    targetValue = if (visualActive) 0.97f else 1f,
    animationSpec = spring(
      dampingRatio = Spring.DampingRatioMediumBouncy,
      stiffness = Spring.StiffnessMedium,
    ),
    label = "playBtnScale",
  )

  Surface(
    onClick = {
      scope.launch {
        isTapped = true
        delay(120)
        isTapped = false
      }
      haptic.performHapticFeedback(HapticFeedbackType.LongPress)
      onClick()
    },
    modifier = modifier
      .height(size)
      .graphicsLayer {
        scaleX = scale
        scaleY = scale
      },
    shape = RoundedCornerShape((size / 2 - animCorner).coerceAtLeast(12.dp)),
    color = containerColor,
    contentColor = contentColor,
    interactionSource = interactionSource,
  ) {
    Box(
      modifier = Modifier
        .fillMaxSize()
        .padding(horizontal = 24.dp),
      contentAlignment = Alignment.Center,
    ) {
      if (showBuffering) {
        CircularWavyProgressIndicator(
          color = contentColor,
          modifier = Modifier.size(34.dp),
        )
      } else {
        Text(
          text = if (isPlaying) playingLabel else pausedLabel,
          style = MaterialTheme.typography.headlineMedium.copy(
            fontWeight = FontWeight.Bold,
            fontSize = if (size < 60.dp) 21.sp else 26.sp,
          ),
          color = contentColor,
          maxLines = 1,
        )
      }
    }
  }
}

/**
 * Expressive capsule play/pause button used in Rhythm's NowPlaying player ("Tạm dừng" / "Phát").
 */
@Composable
fun RhythmExpressiveCapsulePlayButton(
  isPlaying: Boolean,
  onClick: () -> Unit,
  modifier: Modifier = Modifier,
  height: Dp = 66.dp,
  showBuffering: Boolean = false,
  containerColor: Color = MaterialTheme.colorScheme.primary,
  contentColor: Color = MaterialTheme.colorScheme.onPrimary,
  playingLabel: String = "Tạm dừng",
  pausedLabel: String = "Phát",
) {
  RhythmPlayButton(
    isPlaying = isPlaying,
    onClick = onClick,
    modifier = modifier,
    showBuffering = showBuffering,
    size = height,
    containerColor = containerColor,
    contentColor = contentColor,
    playingLabel = playingLabel,
    pausedLabel = pausedLabel,
  )
}

/**
 * Genuine Rhythm `RhythmControlButton`: supports `MaterialShapes.Sunny` / arbitrary expressive shape
 * with spring bounce & darkened press feedback.
 */
@Composable
fun RhythmControlButton(
  onClick: () -> Unit,
  modifier: Modifier = Modifier,
  shape: Shape = rememberExpressiveShape(ExpressiveMaterialShape.SUNNY),
  size: Dp = 66.dp,
  containerColor: Color = MaterialTheme.colorScheme.secondaryContainer,
  contentColor: Color = MaterialTheme.colorScheme.onSecondaryContainer,
  enabled: Boolean = true,
  content: @Composable () -> Unit,
) {
  val interactionSource = remember { MutableInteractionSource() }
  val isPressed by interactionSource.collectIsPressedAsState()
  val haptic = LocalHapticFeedback.current
  val scope = rememberCoroutineScope()
  var isTapped by remember { mutableStateOf(false) }
  val visualActive = isPressed || isTapped

  val animScale by animateFloatAsState(
    targetValue = if (visualActive && enabled) 0.92f else 1f,
    animationSpec = spring(
      dampingRatio = Spring.DampingRatioMediumBouncy,
      stiffness = Spring.StiffnessLow,
    ),
    label = "ctrlBtnScale",
  )

  val animCorner by animateDpAsState(
    targetValue = if (visualActive && enabled) 16.dp else 0.dp,
    animationSpec = spring(
      dampingRatio = Spring.DampingRatioNoBouncy,
      stiffness = Spring.StiffnessMedium,
    ),
    label = "ctrlBtnCorner",
  )

  val pressedBg = colorLerp(containerColor, Color.Black, 0.18f)
  val animBg by animateColorAsState(
    targetValue = if (visualActive && enabled) pressedBg else containerColor,
    animationSpec = spring(
      dampingRatio = Spring.DampingRatioNoBouncy,
      stiffness = Spring.StiffnessMedium,
    ),
    label = "ctrlBtnBg",
  )

  val resolvedShape = if (shape is RoundedCornerShape) {
    RoundedCornerShape(if (visualActive && enabled) (size / 2 - animCorner) else size / 2)
  } else {
    shape
  }

  Surface(
    onClick = {
      if (enabled) {
        scope.launch {
          isTapped = true
          delay(120)
          isTapped = false
        }
        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
        onClick()
      }
    },
    modifier = modifier
      .size(size)
      .minimumInteractiveComponentSize()
      .graphicsLayer {
        scaleX = animScale
        scaleY = animScale
      },
    shape = resolvedShape,
    color = animBg,
    contentColor = contentColor,
    interactionSource = interactionSource,
  ) {
    Box(
      modifier = Modifier.fillMaxSize(),
      contentAlignment = Alignment.Center,
    ) {
      content()
    }
  }
}

/**
 * Genuine M3 `MaterialShapes.Sunny` button matching Rhythm's SkipNext/SkipPrevious buttons.
 */
@Composable
fun RhythmScallopedPolygonButton(
  onClick: () -> Unit,
  modifier: Modifier = Modifier,
  size: Dp = 66.dp,
  lobes: Int = 10,
  containerColor: Color = MaterialTheme.colorScheme.secondaryContainer,
  contentColor: Color = MaterialTheme.colorScheme.onSecondaryContainer,
  content: @Composable () -> Unit,
) {
  val sunnyShape = remember(lobes) { MaterialShapes.Sunny.toComposeShape() }
  RhythmControlButton(
    onClick = onClick,
    modifier = modifier,
    shape = sunnyShape,
    size = size,
    containerColor = containerColor,
    contentColor = contentColor,
    content = content,
  )
}

/**
 * Genuine Rhythm `RhythmGroupedButton` horizontal pill dock container.
 */
@Composable
fun RhythmSegmentedDockRow(
  modifier: Modifier = Modifier,
  spacing: Dp = 3.dp,
  content: @Composable RowScope.() -> Unit,
) {
  Row(
    modifier = modifier.fillMaxWidth(),
    horizontalArrangement = Arrangement.spacedBy(spacing),
    verticalAlignment = Alignment.CenterVertically,
    content = content,
  )
}

@Composable
fun RowScope.RhythmSegmentedDockButton(
  icon: Any,
  contentDescription: String,
  isFirst: Boolean,
  isLast: Boolean,
  selected: Boolean,
  containerColor: Color,
  selectedContainerColor: Color,
  contentColor: Color,
  selectedContentColor: Color,
  onClick: () -> Unit,
  modifier: Modifier = Modifier,
  height: Dp = 44.dp,
  badgeText: String? = null,
) {
  val haptic = LocalHapticFeedback.current
  val interactionSource = remember { MutableInteractionSource() }
  val isPressed by interactionSource.collectIsPressedAsState()
  val scope = rememberCoroutineScope()
  var isTapped by remember { mutableStateOf(false) }
  val visualActive = isPressed || isTapped

  val hasBadge = !badgeText.isNullOrBlank()
  val animWeight by animateFloatAsState(
    targetValue = when {
      visualActive -> 1.24f
      hasBadge -> 1.32f
      selected -> 1.08f
      else -> 1f
    },
    animationSpec = spring(
      dampingRatio = Spring.DampingRatioNoBouncy,
      stiffness = Spring.StiffnessHigh,
    ),
    label = "dock_btn_weight",
  )

  val halfR = height / 2
  val innerR = 9.dp
  val animOuterCorner by animateDpAsState(
    targetValue = if (visualActive) height * 0.3f else halfR,
    animationSpec = spring(stiffness = Spring.StiffnessHigh),
    label = "dock_outer_corner",
  )
  val animInnerCorner by animateDpAsState(
    targetValue = if (visualActive) halfR else innerR,
    animationSpec = spring(stiffness = Spring.StiffnessHigh),
    label = "dock_inner_corner",
  )

  val shape = RoundedCornerShape(
    topStart = if (isFirst) animOuterCorner else animInnerCorner,
    bottomStart = if (isFirst) animOuterCorner else animInnerCorner,
    topEnd = if (isLast) animOuterCorner else animInnerCorner,
    bottomEnd = if (isLast) animOuterCorner else animInnerCorner,
  )

  val bg = if (selected) selectedContainerColor else containerColor
  val fg = if (selected) selectedContentColor else contentColor

  Surface(
    onClick = {
      scope.launch {
        isTapped = true
        delay(85)
        isTapped = false
      }
      haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
      onClick()
    },
    interactionSource = interactionSource,
    shape = shape,
    color = bg,
    contentColor = fg,
    modifier = modifier
      .weight(animWeight)
      .height(height)
      .minimumInteractiveComponentSize(),
  ) {
    Row(
      modifier = Modifier
        .fillMaxSize()
        .padding(horizontal = if (hasBadge) 4.dp else 0.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.Center,
    ) {
      val iconSize = if (hasBadge) 16.dp else 20.dp
      AnyIcon(
        icon = icon,
        contentDescription = contentDescription,
        tint = fg,
        size = iconSize,
        modifier = Modifier.size(iconSize),
      )
      if (!badgeText.isNullOrBlank()) {
        Spacer(Modifier.width(3.dp))
        Text(
          text = badgeText,
          style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, fontSize = 10.sp),
          color = fg,
          maxLines = 1,
          overflow = TextOverflow.Clip,
        )
      }
    }
  }
}

/**
 * Genuine Rhythm split action button (`RhythmDetailActionButton`).
 */
@Composable
fun RowScope.RhythmDetailActionButton(
  text: String,
  icon: Any,
  onClick: () -> Unit,
  isFirst: Boolean,
  isLast: Boolean,
  modifier: Modifier = Modifier,
  filled: Boolean = false,
  height: Dp = 50.dp,
  weight: Float = 1f,
) {
  val haptic = LocalHapticFeedback.current
  val interactionSource = remember { MutableInteractionSource() }
  val isPressed by interactionSource.collectIsPressedAsState()
  val scope = rememberCoroutineScope()
  var isTapped by remember { mutableStateOf(false) }
  val active = isPressed || isTapped

  val animWeight by animateFloatAsState(
    targetValue = if (active) weight * 1.10f else weight,
    animationSpec = spring(
      dampingRatio = Spring.DampingRatioNoBouncy,
      stiffness = Spring.StiffnessHigh,
    ),
    label = "detail_btn_weight",
  )

  val outerR by animateDpAsState(
    targetValue = if (active) height * 0.32f else height / 2,
    animationSpec = spring(stiffness = Spring.StiffnessHigh),
    label = "detail_outer_r",
  )
  val innerR by animateDpAsState(
    targetValue = if (active) height / 2 else 9.dp,
    animationSpec = spring(stiffness = Spring.StiffnessHigh),
    label = "detail_inner_r",
  )
  val scale by animateFloatAsState(
    targetValue = if (active) 0.97f else 1f,
    animationSpec = spring(
      dampingRatio = Spring.DampingRatioNoBouncy,
      stiffness = Spring.StiffnessHigh,
    ),
    label = "detail_btn_scale",
  )

  val shape = RoundedCornerShape(
    topStart = if (isFirst) outerR else innerR,
    bottomStart = if (isFirst) outerR else innerR,
    topEnd = if (isLast) outerR else innerR,
    bottomEnd = if (isLast) outerR else innerR,
  )

  val containerColor = if (filled) {
    MaterialTheme.colorScheme.primary
  } else {
    MaterialTheme.colorScheme.secondaryContainer
  }
  val contentColor = if (filled) {
    MaterialTheme.colorScheme.onPrimary
  } else {
    MaterialTheme.colorScheme.onSecondaryContainer
  }

  Surface(
    onClick = {
      scope.launch {
        isTapped = true
        delay(120)
        isTapped = false
      }
      haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
      onClick()
    },
    interactionSource = interactionSource,
    shape = shape,
    color = containerColor,
    contentColor = contentColor,
    modifier = modifier
      .weight(animWeight)
      .height(height)
      .minimumInteractiveComponentSize()
      .graphicsLayer {
        scaleX = scale
        scaleY = scale
      },
  ) {
    Row(
      modifier = Modifier
        .fillMaxSize()
        .padding(horizontal = 14.dp),
      horizontalArrangement = Arrangement.Center,
      verticalAlignment = Alignment.CenterVertically,
    ) {
      AnyIcon(
        icon = icon,
        contentDescription = null,
        tint = contentColor,
        size = 20.dp,
        modifier = Modifier.size(20.dp),
      )
      Spacer(modifier = Modifier.width(8.dp))
      Text(
        text = text,
        style = MaterialTheme.typography.titleSmall.copy(
          fontWeight = if (filled) FontWeight.Bold else FontWeight.SemiBold,
        ),
        maxLines = 1,
        overflow = TextOverflow.Ellipsis,
      )
    }
  }
}

// ---------------------------------------------------------------------------
// 4. RhythmMorphingPlayPauseButton — Rotating expressive polygon morph
// ---------------------------------------------------------------------------

@Composable
fun RhythmMorphingPlayPauseButton(
  isPlaying: Boolean,
  onClick: () -> Unit,
  modifier: Modifier = Modifier,
  size: Dp = 56.dp,
  containerColor: Color = MaterialTheme.colorScheme.primary,
  iconColor: Color = MaterialTheme.colorScheme.onPrimary,
) {
  val haptic = LocalHapticFeedback.current
  val interactionSource = remember { MutableInteractionSource() }
  val isPressed by interactionSource.collectIsPressedAsState()

  val morphProgress by animateFloatAsState(
    targetValue = if (isPlaying) 1f else 0f,
    animationSpec = spring(
      dampingRatio = Spring.DampingRatioMediumBouncy,
      stiffness = Spring.StiffnessMediumLow,
    ),
    label = "morph_play_pause",
  )

  val pressScale by animateFloatAsState(
    targetValue = if (isPressed) 0.90f else 1f,
    animationSpec = spring(
      dampingRatio = Spring.DampingRatioMediumBouncy,
      stiffness = Spring.StiffnessMedium,
    ),
    label = "morph_press",
  )

  val infiniteTransition = rememberInfiniteTransition(label = "scallop_rotation")
  val rotation by infiniteTransition.animateFloat(
    initialValue = 0f,
    targetValue = if (isPlaying) 360f else 0f,
    animationSpec = infiniteRepeatable(
      animation = tween(durationMillis = 12000, easing = LinearEasing),
      repeatMode = RepeatMode.Restart,
    ),
    label = "rotation_angle",
  )

  Box(
    modifier = modifier
      .size(size)
      .minimumInteractiveComponentSize()
      .graphicsLayer {
        scaleX = pressScale
        scaleY = pressScale
      }
      .clickable(
        interactionSource = interactionSource,
        indication = null,
        role = Role.Button,
        onClick = {
          haptic.performHapticFeedback(HapticFeedbackType.LongPress)
          onClick()
        },
      ),
    contentAlignment = Alignment.Center,
  ) {
    Canvas(modifier = Modifier.fillMaxSize()) {
      val radius = this.size.minDimension / 2f
      val center = Offset(this.size.width / 2f, this.size.height / 2f)
      val lobes = 9
      val amplitude = radius * 0.11f * morphProgress
      val baseRadius = radius - amplitude
      val rotRad = Math.toRadians((rotation * morphProgress).toDouble()).toFloat()

      val path = androidx.compose.ui.graphics.Path()
      val steps = 72
      for (i in 0..steps) {
        val theta = (i.toFloat() / steps) * (2f * PI.toFloat())
        val r = baseRadius + amplitude * cos(lobes * theta)
        val angle = theta + rotRad
        val x = center.x + r * cos(angle)
        val y = center.y + r * sin(angle)
        if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
      }
      path.close()
      drawPath(path = path, color = containerColor)
    }

    Crossfade(
      targetState = isPlaying,
      animationSpec = tween(160),
      label = "play_pause_glyph",
    ) { playing ->
      val iconSize = size * 0.48f
      RhythmSymbolIcon(
        icon = if (playing) RhythmIcons.Pause else RhythmIcons.Play,
        contentDescription = if (playing) "Tạm dừng" else "Phát",
        tint = iconColor,
        size = iconSize,
        modifier = Modifier.size(iconSize),
      )
    }
  }
}

// ---------------------------------------------------------------------------
// 5. RhythmEqualizerIndicator & Expressive Cookie Empty State
// ---------------------------------------------------------------------------

@Composable
fun RhythmEqualizerIndicator(
  isPlaying: Boolean,
  modifier: Modifier = Modifier,
  color: Color = MaterialTheme.colorScheme.primary,
) {
  if (!isPlaying) {
    RhythmSymbolIcon(
      icon = RhythmIcons.GraphicEq,
      contentDescription = null,
      tint = color,
      size = 18.dp,
      modifier = modifier.size(18.dp),
    )
    return
  }

  val infiniteTransition = rememberInfiniteTransition(label = "eq_bars")
  val b1 by infiniteTransition.animateFloat(
    initialValue = 0.25f,
    targetValue = 0.95f,
    animationSpec = infiniteRepeatable(tween(420), RepeatMode.Reverse),
    label = "eq1",
  )
  val b2 by infiniteTransition.animateFloat(
    initialValue = 0.85f,
    targetValue = 0.30f,
    animationSpec = infiniteRepeatable(tween(340), RepeatMode.Reverse),
    label = "eq2",
  )
  val b3 by infiniteTransition.animateFloat(
    initialValue = 0.35f,
    targetValue = 1.0f,
    animationSpec = infiniteRepeatable(tween(500), RepeatMode.Reverse),
    label = "eq3",
  )

  Canvas(modifier = modifier.size(18.dp)) {
    val barWidth = size.width / 5f
    val heights = listOf(b1, b2, b3)
    heights.forEachIndexed { idx, frac ->
      val barH = size.height * frac
      val left = idx * barWidth * 1.7f + barWidth * 0.3f
      drawRoundRect(
        color = color,
        topLeft = Offset(left, size.height - barH),
        size = Size(barWidth, barH),
        cornerRadius = CornerRadius(barWidth / 2f, barWidth / 2f),
      )
    }
  }
}

/**
 * Direct port of Rhythm `ExpressiveCookieEmptyState.kt` using M3 `MaterialShapes.Cookie12Sided`
 * and `MaterialShapes.Cookie6Sided` with authentic 3-chip floating layout.
 */
@Composable
fun ExpressiveCookieEmptyState(
  title: String,
  subtitle: String? = null,
  modifier: Modifier = Modifier,
  mainIcon: Any = RhythmIcons.MusicNote,
  accentIcon: Any = mainIcon,
  cornerIcon: Any = mainIcon,
  containerColor: Color = MaterialTheme.colorScheme.secondaryContainer,
  contentColor: Color = MaterialTheme.colorScheme.onSecondaryContainer,
) {
  val cookieShape = rememberExpressiveShape(ExpressiveMaterialShape.COOKIE_12)
  val smallCookieShape = rememberExpressiveShape(ExpressiveMaterialShape.COOKIE_6)

  Column(
    modifier = modifier.fillMaxWidth(),
    horizontalAlignment = Alignment.CenterHorizontally,
  ) {
    Box(
      modifier = Modifier.size(112.dp),
      contentAlignment = Alignment.Center,
    ) {
      Surface(
        shape = smallCookieShape,
        color = containerColor.copy(alpha = 0.45f),
        modifier = Modifier
          .size(36.dp)
          .align(Alignment.TopStart)
          .offset(x = (-4).dp, y = 8.dp),
      ) {
        Box(contentAlignment = Alignment.Center, modifier = Modifier.fillMaxSize()) {
          AnyIcon(
            icon = accentIcon,
            contentDescription = null,
            tint = contentColor.copy(alpha = 0.55f),
            size = 16.dp,
            modifier = Modifier.size(16.dp),
          )
        }
      }

      Surface(
        shape = smallCookieShape,
        color = containerColor.copy(alpha = 0.45f),
        modifier = Modifier
          .size(30.dp)
          .align(Alignment.BottomEnd)
          .offset(x = 6.dp, y = (-4).dp),
      ) {
        Box(contentAlignment = Alignment.Center, modifier = Modifier.fillMaxSize()) {
          AnyIcon(
            icon = cornerIcon,
            contentDescription = null,
            tint = contentColor.copy(alpha = 0.55f),
            size = 13.dp,
            modifier = Modifier.size(13.dp),
          )
        }
      }

      Surface(
        shape = cookieShape,
        color = containerColor,
        tonalElevation = 6.dp,
        modifier = Modifier.size(84.dp),
      ) {
        Box(contentAlignment = Alignment.Center, modifier = Modifier.fillMaxSize()) {
          AnyIcon(
            icon = mainIcon,
            contentDescription = null,
            tint = contentColor,
            size = 38.dp,
            modifier = Modifier.size(38.dp),
          )
        }
      }
    }

    Spacer(modifier = Modifier.height(12.dp))
    Text(
      text = title,
      style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.SemiBold),
      color = MaterialTheme.colorScheme.onSurface,
      textAlign = TextAlign.Center,
    )
    if (subtitle != null) {
      Spacer(modifier = Modifier.height(6.dp))
      Text(
        text = subtitle,
        style = MaterialTheme.typography.bodyLarge,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        textAlign = TextAlign.Center,
        modifier = Modifier.padding(horizontal = 32.dp),
      )
    }
  }
}

// ---------------------------------------------------------------------------
// 6. Material3SettingsGroup — Rhythm's Pixel/M3 Expressive Card Stack
// ---------------------------------------------------------------------------

@Immutable
data class SettingsBadgePalette(
  val container: Color,
  val tint: Color,
)

object SettingsPalettes {
  val Amber = SettingsBadgePalette(container = Color(0xFFFFDCBE), tint = Color(0xFF7C4113))
  val Yellow = SettingsBadgePalette(container = Color(0xFFFFF0A4), tint = Color(0xFF624F00))
  val Emerald = SettingsBadgePalette(container = Color(0xFFC4EED0), tint = Color(0xFF18532A))
  val Cyan = SettingsBadgePalette(container = Color(0xFFC0EAE6), tint = Color(0xFF006A6F))
  val SkyBlue = SettingsBadgePalette(container = Color(0xFFC2E7FF), tint = Color(0xFF004D77))
  val Indigo = SettingsBadgePalette(container = Color(0xFFD6E3FF), tint = Color(0xFF1D5FA9))
  val Purple = SettingsBadgePalette(container = Color(0xFFEEDCFF), tint = Color(0xFF5D367B))
  val Rose = SettingsBadgePalette(container = Color(0xFFF7D8EB), tint = Color(0xFF82276C))
  val Coral = SettingsBadgePalette(container = Color(0xFFFFD8E2), tint = Color(0xFF962846))
  val Lime = SettingsBadgePalette(container = Color(0xFFE0F3B8), tint = Color(0xFF3B5606))
  val Slate = SettingsBadgePalette(container = Color(0xFFE2E2E6), tint = Color(0xFF44474E))
  val Teal = SettingsBadgePalette(container = Color(0xFFBCEBEB), tint = Color(0xFF006874))
  val Orange = SettingsBadgePalette(container = Color(0xFFFFDAC5), tint = Color(0xFF763710))
}

@Immutable
data class Material3SettingsItem(
  val icon: Any,
  val title: String,
  val subtitle: String? = null,
  val palette: SettingsBadgePalette = SettingsPalettes.Purple,
  val trailingText: String? = null,
  val switchChecked: Boolean? = null,
  val onSwitchChange: ((Boolean) -> Unit)? = null,
  val showChevron: Boolean = false,
  val onClick: (() -> Unit)? = null,
  val testTag: String? = null,
  val customContent: (@Composable () -> Unit)? = null,
)

@Composable
fun Material3SettingsGroup(
  title: String? = null,
  items: List<Material3SettingsItem>,
  modifier: Modifier = Modifier,
  containerColor: Color = MaterialTheme.colorScheme.surfaceContainer,
) {
  Column(modifier = modifier.fillMaxWidth()) {
    if (!title.isNullOrBlank()) {
      Text(
        text = title,
        style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.SemiBold),
        color = MaterialTheme.colorScheme.primary,
        modifier = Modifier.padding(start = 6.dp, top = 16.dp, bottom = 8.dp),
      )
    }

    Column(
      modifier = Modifier.fillMaxWidth(),
      verticalArrangement = Arrangement.spacedBy(4.dp),
    ) {
      items.forEachIndexed { index, item ->
        val shape = when {
          items.size == 1 -> RoundedCornerShape(24.dp)
          index == 0 -> RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp, bottomStart = 6.dp, bottomEnd = 6.dp)
          index == items.lastIndex -> RoundedCornerShape(topStart = 6.dp, topEnd = 6.dp, bottomStart = 24.dp, bottomEnd = 24.dp)
          else -> RoundedCornerShape(6.dp)
        }

        Card(
          modifier = Modifier
            .fillMaxWidth()
            .then(if (!item.testTag.isNullOrBlank()) Modifier.testTag(item.testTag) else Modifier),
          shape = shape,
          colors = CardDefaults.cardColors(containerColor = containerColor),
          elevation = CardDefaults.cardElevation(defaultElevation = 0.dp),
        ) {
          Column(
            modifier = Modifier
              .fillMaxWidth()
              .then(
                if (item.onClick != null) {
                  Modifier.clickable(onClick = item.onClick)
                } else if (item.onSwitchChange != null && item.switchChecked != null) {
                  Modifier.clickable { item.onSwitchChange.invoke(!item.switchChecked) }
                } else {
                  Modifier
                },
              )
              .padding(horizontal = 16.dp, vertical = 14.dp),
          ) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              verticalAlignment = Alignment.CenterVertically,
            ) {
              Surface(
                shape = CircleShape,
                color = item.palette.container,
                modifier = Modifier.size(40.dp),
              ) {
                Box(contentAlignment = Alignment.Center) {
                  AnyIcon(
                    icon = item.icon,
                    contentDescription = null,
                    tint = item.palette.tint,
                    size = 21.dp,
                    modifier = Modifier.size(21.dp),
                  )
                }
              }

              Spacer(modifier = Modifier.width(14.dp))

              Column(modifier = Modifier.weight(1f)) {
                Text(
                  text = item.title,
                  style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.SemiBold),
                  color = MaterialTheme.colorScheme.onSurface,
                  maxLines = 2,
                  overflow = TextOverflow.Ellipsis,
                )
                if (!item.subtitle.isNullOrBlank()) {
                  Text(
                    text = item.subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                  )
                }
              }

              if (!item.trailingText.isNullOrBlank()) {
                Text(
                  text = item.trailingText,
                  style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.SemiBold),
                  color = MaterialTheme.colorScheme.primary,
                  modifier = Modifier.padding(start = 8.dp),
                )
              }

              if (item.switchChecked != null && item.onSwitchChange != null) {
                Spacer(modifier = Modifier.width(8.dp))
                Switch(
                  checked = item.switchChecked,
                  onCheckedChange = item.onSwitchChange,
                )
              } else if (item.showChevron) {
                Spacer(modifier = Modifier.width(4.dp))
                RhythmSymbolIcon(
                  icon = RhythmIcons.ChevronRight,
                  contentDescription = null,
                  tint = MaterialTheme.colorScheme.onSurfaceVariant,
                  size = 20.dp,
                  modifier = Modifier.size(20.dp),
                )
              }
            }

            if (item.customContent != null) {
              Spacer(modifier = Modifier.height(12.dp))
              item.customContent.invoke()
            }
          }
        }
      }
    }
  }
}

// ---------------------------------------------------------------------------
// 7. Authentic M3 Expressive Polygon Shapes + MarqueeText + EdgeBlend + Greeting
// ---------------------------------------------------------------------------

/**
 * Genuine M3 `MaterialShapes.Bun` silhouette matching Rhythm's ExpressivePlayerScreen artwork mask.
 */
object RhythmPeanutShape : Shape {
  private val delegate by lazy { MaterialShapes.Bun.toComposeShape() }
  override fun createOutline(
    size: Size,
    layoutDirection: LayoutDirection,
    density: Density,
  ): Outline = delegate.createOutline(size, layoutDirection, density)
}

/**
 * Genuine M3 `MaterialShapes.Sunny` silhouette matching Rhythm's SkipNext/SkipPrevious controls.
 */
class RhythmScallopedShape(
  @Suppress("unused") private val lobes: Int = 10,
  @Suppress("unused") private val depthFraction: Float = 0.08f,
) : Shape {
  private val delegate by lazy { MaterialShapes.Sunny.toComposeShape() }
  override fun createOutline(
    size: Size,
    layoutDirection: LayoutDirection,
    density: Density,
  ): Outline = delegate.createOutline(size, layoutDirection, density)
}

/**
 * Direct port of Rhythm's `AutoScrollingTextOnDemand` from `MarqueeText.kt`.
 */
@Composable
fun AutoScrollingTextOnDemand(
  text: String,
  gradientEdgeColor: Color,
  modifier: Modifier = Modifier,
  style: TextStyle = LocalTextStyle.current,
  enabled: Boolean = true,
  textAlign: TextAlign = TextAlign.Start,
) {
  var overflow by remember(text, enabled) { mutableStateOf(false) }
  if (!overflow || !enabled) {
    Text(
      text = text,
      style = style,
      maxLines = 1,
      softWrap = false,
      textAlign = textAlign,
      onTextLayout = { res: TextLayoutResult -> overflow = res.hasVisualOverflow },
      modifier = modifier,
    )
  } else {
    AutoScrollingText(
      text = text,
      style = style,
      textAlign = textAlign,
      gradientEdgeColor = gradientEdgeColor,
      modifier = modifier,
    )
  }
}

@Composable
fun AutoScrollingText(
  text: String,
  modifier: Modifier = Modifier,
  style: TextStyle = LocalTextStyle.current,
  textAlign: TextAlign? = null,
  gradientEdgeColor: Color,
  gradientWidth: Dp = 24.dp,
  initialDelayMillis: Int = 1500,
  velocity: Dp = 25.dp,
) {
  SubcomposeLayout(modifier = modifier.clipToBounds()) { constraints ->
    val textPlaceable = subcompose("text") {
      Text(text = text, style = style, maxLines = 1)
    }[0].measure(constraints.copy(maxWidth = Int.MAX_VALUE))
    val isOverflowing = textPlaceable.width > constraints.maxWidth
    val content = @Composable {
      if (isOverflowing) {
        var isScrolling by remember { mutableStateOf(false) }
        LaunchedEffect(Unit) {
          isScrolling = false
          delay(initialDelayMillis.toLong())
          isScrolling = true
        }
        val animatedLeftGradientStartColor by animateColorAsState(
          targetValue = if (isScrolling) Color.Transparent else gradientEdgeColor,
          animationSpec = tween(durationMillis = 500),
          label = "LeftGradientStartColor",
        )
        Box(
          modifier = Modifier
            .graphicsLayer { compositingStrategy = CompositingStrategy.Offscreen }
            .drawWithContent {
              drawContent()
              val gradientWidthPx = gradientWidth.toPx()
              drawRect(
                brush = Brush.horizontalGradient(
                  colors = listOf(animatedLeftGradientStartColor, gradientEdgeColor),
                  startX = 0f,
                  endX = gradientWidthPx,
                ),
                blendMode = BlendMode.DstIn,
              )
              drawRect(
                brush = Brush.horizontalGradient(
                  colors = listOf(gradientEdgeColor, Color.Transparent),
                  startX = size.width - gradientWidthPx,
                  endX = size.width,
                ),
                blendMode = BlendMode.DstIn,
              )
            },
        ) {
          Text(
            text = text,
            style = style,
            textAlign = textAlign,
            maxLines = 1,
            modifier = Modifier.basicMarquee(
              iterations = Int.MAX_VALUE,
              spacing = MarqueeSpacing(gradientWidth + 6.dp),
              velocity = velocity,
              initialDelayMillis = initialDelayMillis,
            ),
          )
        }
      } else {
        Text(
          text = text,
          style = style,
          textAlign = textAlign,
          maxLines = 1,
        )
      }
    }
    val contentPlaceable = subcompose("content", content)[0].measure(constraints)
    layout(contentPlaceable.width, contentPlaceable.height) {
      contentPlaceable.place(0, 0)
    }
  }
}

@Suppress("UNUSED_PARAMETER")
fun Modifier.horizontalEdgeBlend(
  lazyListState: LazyListState,
  fadeWidth: Dp = 16.dp,
): Modifier = this

fun vietnameseGreetingText(): String {
  val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
  return when (hour) {
    in 5..10 -> "Chào buổi sáng"
    in 11..13 -> "Chào buổi trưa"
    in 14..17 -> "Chào buổi chiều"
    in 18..22 -> "Chào buổi tối"
    else -> "Chào buổi đêm"
  }
}
