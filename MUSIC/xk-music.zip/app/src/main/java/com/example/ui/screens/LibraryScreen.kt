package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.model.Playlist
import com.example.model.Song
import com.example.ui.ActiveTrackMeta
import com.example.ui.components.ArtworkImage
import com.example.ui.components.ExpressiveCookieEmptyState
import com.example.ui.components.PlaylistEditorDialog
import com.example.ui.components.RhythmCollapsibleHeaderScreen
import com.example.ui.components.RhythmDetailActionButton
import com.example.ui.components.RhythmHeaderAction
import com.example.ui.components.SongInfoDialog
import com.example.ui.components.SongRowItem
import com.example.ui.components.rhythmPressScale
import com.example.ui.components.shareSongIntent
import com.example.ui.rhythm.ExpressiveShapeTarget
import com.example.ui.rhythm.RhythmIcons
import com.example.ui.rhythm.RhythmSymbolIcon
import com.example.ui.rhythm.rememberExpressiveShapeFor
import kotlinx.coroutines.launch
import java.text.Collator
import java.util.Locale

@Composable
fun LibraryScreen(
  favorites: List<Song>,
  recentSongs: List<Song>,
  playlists: List<Playlist>,
  activeTrack: ActiveTrackMeta,
  favoriteIds: Set<String>,
  purchasedIds: Set<String>,
  currentUserId: String?,
  bottomOverlayPadding: PaddingValues,
  onPlaySong: (Song, List<Song>) -> Unit,
  onPlayAll: (List<Song>, Boolean) -> Unit,
  onToggleFavorite: (Song) -> Unit,
  onPurchaseSong: (Song) -> Unit,
  onOpenPlaylist: (String) -> Unit,
  onCreatePlaylist: (title: String, description: String) -> Unit,
  onPlayNext: (Song) -> Unit = {},
  onAddToQueue: (Song) -> Unit = {},
  playCounts: Map<String, Int> = emptyMap(),
) {
  val context = LocalContext.current
  val tabs = remember { listOf("Yêu thích", "Gần đây", "Playlist") }
  val pagerState = rememberPagerState(pageCount = { tabs.size })
  val coroutineScope = rememberCoroutineScope()
  var showCreatePlaylistDialog by remember { mutableStateOf(false) }
  var infoSong by remember { mutableStateOf<Song?>(null) }

  RhythmCollapsibleHeaderScreen(
    title = "Thư viện",
    headerActions = listOf(
      RhythmHeaderAction(
        icon = RhythmIcons.Add,
        contentDescription = "Tạo playlist",
        testTag = "library_create_playlist_action",
        onClick = { showCreatePlaylistDialog = true },
      ),
    ),
    filterContent = {
      Surface(
        shape = CircleShape,
        color = MaterialTheme.colorScheme.surfaceContainer,
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 20.dp, vertical = 8.dp),
      ) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(4.dp),
          horizontalArrangement = Arrangement.spacedBy(4.dp),
        ) {
          tabs.forEachIndexed { index, label ->
            val selected = pagerState.currentPage == index
            val icon = when (index) {
              0 -> RhythmIcons.FavoriteFilled
              1 -> RhythmIcons.History
              else -> RhythmIcons.Playlist
            }
            val pillColor by animateColorAsState(
              targetValue = if (selected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceContainer,
              animationSpec = tween(100),
              label = "lib_tab_bg_$index",
            )
            val textColor by animateColorAsState(
              targetValue = if (selected) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurfaceVariant,
              animationSpec = tween(100),
              label = "lib_tab_fg_$index",
            )
            Surface(
              onClick = {
                coroutineScope.launch { pagerState.animateScrollToPage(index) }
              },
              shape = CircleShape,
              color = pillColor,
              contentColor = textColor,
              modifier = Modifier
                .weight(1f)
                .height(42.dp),
            ) {
              Row(
                modifier = Modifier.fillMaxSize(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center,
              ) {
                RhythmSymbolIcon(
                  icon = icon,
                  contentDescription = null,
                  size = 16.dp,
                  modifier = Modifier.size(16.dp),
                )
                Spacer(Modifier.width(6.dp))
                Text(
                  text = label,
                  style = MaterialTheme.typography.labelLarge.copy(
                    fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                  ),
                  maxLines = 1,
                  overflow = TextOverflow.Ellipsis,
                )
              }
            }
          }
        }
      }
    },
    floatingActionButton = {
      AnimatedVisibility(
        visible = pagerState.currentPage == 2,
        enter = scaleIn(initialScale = 0.8f) + fadeIn(),
        exit = scaleOut(targetScale = 0.8f) + fadeOut(),
      ) {
        ExtendedFloatingActionButton(
          onClick = { showCreatePlaylistDialog = true },
          icon = {
            RhythmSymbolIcon(
              icon = RhythmIcons.Add,
              contentDescription = null,
              size = 20.dp,
              modifier = Modifier.size(20.dp),
            )
          },
          text = { Text("Tạo playlist") },
          containerColor = MaterialTheme.colorScheme.primaryContainer,
          contentColor = MaterialTheme.colorScheme.onPrimaryContainer,
          modifier = Modifier
            .padding(bottom = bottomOverlayPadding.calculateBottomPadding())
            .testTag("create_playlist_fab"),
        )
      }
    },
  ) { scaffoldModifier ->
    HorizontalPager(
      state = pagerState,
      modifier = scaffoldModifier.fillMaxSize(),
    ) { page ->
      when (page) {
        0 -> LibrarySongsTab(
          songs = favorites,
          emptyTitle = "Chưa có bài hát yêu thích",
          emptyMessage = "Nhấn biểu tượng trái tim ở bài hát bất kỳ để lưu vào đây.",
          activeTrack = activeTrack,
          favoriteIds = favoriteIds,
          purchasedIds = purchasedIds,
          bottomOverlayPadding = bottomOverlayPadding,
          onPlaySong = onPlaySong,
          onPlayAll = onPlayAll,
          onToggleFavorite = onToggleFavorite,
          onPurchaseSong = onPurchaseSong,
          onPlayNext = onPlayNext,
          onAddToQueue = onAddToQueue,
          onShowInfo = { infoSong = it },
          onShareSong = { shareSongIntent(context, it) },
        )
        1 -> LibrarySongsTab(
          songs = recentSongs,
          emptyTitle = "Chưa có lịch sử phát",
          emptyMessage = "Các bài hát bạn đã nghe gần đây sẽ tự động lưu tại đây.",
          activeTrack = activeTrack,
          favoriteIds = favoriteIds,
          purchasedIds = purchasedIds,
          bottomOverlayPadding = bottomOverlayPadding,
          onPlaySong = onPlaySong,
          onPlayAll = onPlayAll,
          onToggleFavorite = onToggleFavorite,
          onPurchaseSong = onPurchaseSong,
          onPlayNext = onPlayNext,
          onAddToQueue = onAddToQueue,
          onShowInfo = { infoSong = it },
          onShareSong = { shareSongIntent(context, it) },
        )
        else -> LibraryPlaylistsTab(
          playlists = playlists,
          currentUserId = currentUserId,
          bottomOverlayPadding = bottomOverlayPadding,
          onOpenPlaylist = onOpenPlaylist,
          onCreatePlaylistClick = { showCreatePlaylistDialog = true },
        )
      }
    }
  }

  if (showCreatePlaylistDialog) {
    PlaylistEditorDialog(
      dialogTitle = "Tạo playlist mới",
      confirmLabel = "Tạo ngay",
      onConfirm = { title, desc ->
        onCreatePlaylist(title, desc)
        showCreatePlaylistDialog = false
      },
      onDismiss = { showCreatePlaylistDialog = false },
    )
  }

  val selected = infoSong
  if (selected != null) {
    SongInfoDialog(
      song = selected,
      isPurchased = selected.id in purchasedIds || !selected.isPaid,
      playCountOnDevice = playCounts[selected.id] ?: 0,
      onShareClick = { shareSongIntent(context, selected) },
      onDismiss = { infoSong = null },
    )
  }
}

@Composable
private fun LibrarySongsTab(
  songs: List<Song>,
  emptyTitle: String,
  emptyMessage: String,
  activeTrack: ActiveTrackMeta,
  favoriteIds: Set<String>,
  purchasedIds: Set<String>,
  bottomOverlayPadding: PaddingValues,
  onPlaySong: (Song, List<Song>) -> Unit,
  onPlayAll: (List<Song>, Boolean) -> Unit,
  onToggleFavorite: (Song) -> Unit,
  onPurchaseSong: (Song) -> Unit,
  onPlayNext: (Song) -> Unit,
  onAddToQueue: (Song) -> Unit,
  onShowInfo: (Song) -> Unit,
  onShareSong: (Song) -> Unit,
) {
  LazyColumn(
    modifier = Modifier.fillMaxSize(),
    contentPadding = PaddingValues(
      top = 8.dp,
      bottom = bottomOverlayPadding.calculateBottomPadding() + 28.dp,
    ),
    verticalArrangement = Arrangement.spacedBy(6.dp),
  ) {
    if (songs.isEmpty()) {
      item(key = "lib_empty", contentType = "empty") {
        ExpressiveCookieEmptyState(
          title = emptyTitle,
          subtitle = emptyMessage,
          mainIcon = RhythmIcons.MusicNote,
          accentIcon = RhythmIcons.FavoriteFilled,
          cornerIcon = RhythmIcons.History,
          modifier = Modifier.padding(vertical = 28.dp),
        )
      }
    } else {
      item(key = "lib_actions", contentType = "actions") {
        Column(
          modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 6.dp),
          verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
          Text(
            text = "${songs.size} bài hát",
            style = MaterialTheme.typography.titleSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
          )
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
          ) {
            RhythmDetailActionButton(
              text = "Phát tất cả",
              icon = RhythmIcons.Play,
              filled = true,
              isFirst = true,
              isLast = false,
              height = 48.dp,
              onClick = { onPlayAll(songs, false) },
            )
            RhythmDetailActionButton(
              text = "Trộn bài",
              icon = RhythmIcons.Shuffle,
              filled = false,
              isFirst = false,
              isLast = true,
              height = 48.dp,
              onClick = { onPlayAll(songs, true) },
            )
          }
        }
      }

      items(songs, key = { "lib_song_${it.id}" }, contentType = { "song_row" }) { song ->
        SongRowItem(
          song = song,
          isCurrentSong = activeTrack.songId == song.id,
          isPlaying = activeTrack.songId == song.id && activeTrack.isPlaying,
          isFavorite = song.id in favoriteIds,
          isPurchased = song.id in purchasedIds || !song.isPaid,
          onClick = { onPlaySong(song, songs) },
          onToggleFavorite = { onToggleFavorite(song) },
          onPurchaseClick = { onPurchaseSong(song) },
          onPlayNext = { onPlayNext(song) },
          onAddToQueue = { onAddToQueue(song) },
          onShowInfo = { onShowInfo(song) },
          onShareSong = { onShareSong(song) },
          modifier = Modifier.padding(horizontal = 8.dp),
        )
      }
    }
  }
}

@Composable
private fun LibraryPlaylistsTab(
  playlists: List<Playlist>,
  currentUserId: String?,
  bottomOverlayPadding: PaddingValues,
  onOpenPlaylist: (String) -> Unit,
  onCreatePlaylistClick: () -> Unit,
) {
  val sortedPlaylists = remember(playlists, currentUserId) {
    if (currentUserId.isNullOrBlank()) {
      emptyList()
    } else {
      val collator = Collator.getInstance(Locale.forLanguageTag("vi-VN")).apply {
        strength = Collator.PRIMARY
      }
      playlists
        .filter { it.curatorId == currentUserId }
        .sortedWith { a, b -> collator.compare(a.title.trim(), b.title.trim()) }
    }
  }

  val playlistShape = rememberExpressiveShapeFor(ExpressiveShapeTarget.PLAYLIST_ART)

  LazyColumn(
    modifier = Modifier
      .fillMaxSize()
      .testTag("library_playlists_list"),
    contentPadding = PaddingValues(
      top = 8.dp,
      bottom = bottomOverlayPadding.calculateBottomPadding() + 92.dp,
    ),
    verticalArrangement = Arrangement.spacedBy(10.dp),
  ) {
    if (sortedPlaylists.isEmpty()) {
      item(key = "playlists_empty", contentType = "empty") {
        Column(
          modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 28.dp),
          horizontalAlignment = Alignment.CenterHorizontally,
          verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
          ExpressiveCookieEmptyState(
            title = if (currentUserId.isNullOrBlank()) {
              "Đăng nhập để xem playlist cá nhân"
            } else {
              "Chưa có playlist cá nhân"
            },
            subtitle = if (currentUserId.isNullOrBlank()) {
              "Vui lòng đăng nhập ở mục Cá nhân để tạo và quản lý playlist riêng của bạn."
            } else {
              "Tạo playlist cá nhân đầu tiên của bạn để lưu giữ danh sách phát yêu thích."
            },
            mainIcon = RhythmIcons.Playlist,
            accentIcon = RhythmIcons.MusicNote,
            cornerIcon = RhythmIcons.Add,
          )
          if (!currentUserId.isNullOrBlank()) {
            Button(onClick = onCreatePlaylistClick, shape = CircleShape) {
              Text("Tạo playlist")
            }
          }
        }
      }
    } else {
      items(sortedPlaylists, key = { "lib_pl_${it.id}" }, contentType = { "playlist_card" }) { playlist ->
        val isMine = currentUserId != null && playlist.curatorId == currentUserId
        val cardInteraction = remember { MutableInteractionSource() }
        Card(
          onClick = { onOpenPlaylist(playlist.id) },
          interactionSource = cardInteraction,
          shape = RoundedCornerShape(24.dp),
          colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceContainer,
          ),
          elevation = CardDefaults.cardElevation(defaultElevation = 0.dp),
          modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp)
            .rhythmPressScale(cardInteraction, pressedScale = 0.97f),
        ) {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp),
          ) {
            ArtworkImage(
              imageUrl = playlist.coverUrl ?: playlist.songs.firstOrNull()?.coverUrl,
              contentDescription = playlist.title,
              shape = playlistShape,
              sizePx = 180,
              modifier = Modifier.size(58.dp),
            )

            Column(modifier = Modifier.weight(1f)) {
              Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp),
              ) {
                Text(
                  text = playlist.title,
                  style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.SemiBold),
                  maxLines = 1,
                  overflow = TextOverflow.Ellipsis,
                  modifier = Modifier.weight(1f, fill = false),
                )
                if (isMine) {
                  Surface(
                    shape = CircleShape,
                    color = MaterialTheme.colorScheme.primaryContainer,
                  ) {
                    Text(
                      text = "Của tôi",
                      style = MaterialTheme.typography.labelSmall,
                      color = MaterialTheme.colorScheme.onPrimaryContainer,
                      modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp),
                    )
                  }
                  RhythmSymbolIcon(
                    icon = RhythmIcons.Lock,
                    contentDescription = "Riêng tư",
                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                    size = 14.dp,
                    modifier = Modifier.size(14.dp),
                  )
                }
              }
              Text(
                text = "${playlist.songs.size} bài hát" + (playlist.curator?.let { " • $it" } ?: ""),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
              )
            }

            RhythmSymbolIcon(
              icon = RhythmIcons.ChevronRight,
              contentDescription = null,
              tint = MaterialTheme.colorScheme.onSurfaceVariant,
              size = 20.dp,
              modifier = Modifier.size(20.dp),
            )
          }
        }
      }
    }
  }
}
