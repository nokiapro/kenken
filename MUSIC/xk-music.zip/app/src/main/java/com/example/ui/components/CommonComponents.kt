package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.InteractionSource
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import kotlinx.coroutines.launch
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.model.Song
import com.example.ui.FormatUtils
import com.example.ui.rhythm.ExpressiveShapeTarget
import com.example.ui.rhythm.RhythmIcons
import com.example.ui.rhythm.RhythmSymbolIcon
import com.example.ui.rhythm.rememberExpressiveShapeFor
import com.example.ui.theme.LocalRhythmHapticsEnabled
import com.example.ui.theme.MonoNumericStyle

/**
 * Rhythm tactile spring scale on press for interactive cards and tiles.
 */
fun Modifier.rhythmPressScale(
  interactionSource: InteractionSource,
  pressedScale: Float = 0.96f,
): Modifier = composed {
  val isPressed by interactionSource.collectIsPressedAsState()
  val scale by animateFloatAsState(
    targetValue = if (isPressed) pressedScale else 1f,
    animationSpec = spring(
      dampingRatio = Spring.DampingRatioNoBouncy,
      stiffness = Spring.StiffnessHigh,
    ),
    label = "rhythm_press_scale",
  )
  this.graphicsLayer {
    scaleX = scale
    scaleY = scale
  }
}

/**
 * Diagonal Rhythm shimmer brush for loading skeletons.
 */
@Composable
fun rememberRhythmShimmerBrush(): Brush {
  val baseColor = MaterialTheme.colorScheme.surfaceContainerHigh
  val highlightColor = MaterialTheme.colorScheme.surfaceContainerHighest
  val transition = rememberInfiniteTransition(label = "rhythm_shimmer")
  val shift by transition.animateFloat(
    initialValue = -260f,
    targetValue = 900f,
    animationSpec = infiniteRepeatable(
      animation = tween(durationMillis = 1250, easing = LinearEasing),
      repeatMode = RepeatMode.Restart,
    ),
    label = "rhythm_shimmer_shift",
  )
  return Brush.linearGradient(
    colors = listOf(baseColor, highlightColor, baseColor),
    start = Offset(shift, 0f),
    end = Offset(shift + 320f, 180f),
  )
}

/**
 * Optimized Coil artwork loader matching Rhythm `M3ImageUtils`.
 */
@Composable
fun ArtworkImage(
  imageUrl: String?,
  contentDescription: String?,
  modifier: Modifier = Modifier,
  shape: Shape = RoundedCornerShape(14.dp),
  sizePx: Int = 420,
  placeholderColor: Color = MaterialTheme.colorScheme.surfaceContainerHigh,
  placeholderTint: Color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.45f),
) {
  val context = LocalContext.current
  val trimmed = imageUrl?.trim()?.takeIf { it.isNotEmpty() }

  Box(
    modifier = modifier
      .clip(shape)
      .background(placeholderColor),
    contentAlignment = Alignment.Center,
  ) {
    RhythmSymbolIcon(
      icon = RhythmIcons.MusicNote,
      contentDescription = null,
      tint = placeholderTint,
      size = 28.dp,
      modifier = Modifier.size(28.dp),
    )

    if (trimmed != null) {
      val request = remember(trimmed, sizePx) {
        ImageRequest.Builder(context)
          .data(trimmed)
          .crossfade(140)
          .size(sizePx)
          .allowRgb565(true)
          .build()
      }
      AsyncImage(
        model = request,
        contentDescription = contentDescription,
        contentScale = ContentScale.Crop,
        modifier = Modifier.fillMaxSize(),
      )
    }
  }
}

/**
 * Rhythm Section Header using Material Symbols chevron icon.
 */
@Composable
fun RhythmSectionHeader(
  title: String,
  modifier: Modifier = Modifier,
  subtitle: String? = null,
  actionLabel: String? = null,
  onActionClick: (() -> Unit)? = null,
) {
  Row(
    modifier = modifier
      .fillMaxWidth()
      .padding(horizontal = 20.dp),
    verticalAlignment = Alignment.CenterVertically,
    horizontalArrangement = Arrangement.SpaceBetween,
  ) {
    Column(modifier = Modifier.weight(1f)) {
      Text(
        text = title,
        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
        color = MaterialTheme.colorScheme.onBackground,
        maxLines = 1,
        overflow = TextOverflow.Ellipsis,
      )
      if (!subtitle.isNullOrBlank()) {
        Text(
          text = subtitle,
          style = MaterialTheme.typography.bodySmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis,
        )
      }
    }

    if (actionLabel != null && onActionClick != null) {
      TextButton(
        onClick = onActionClick,
        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
        modifier = Modifier.minimumInteractiveComponentSize(),
      ) {
        Text(
          text = actionLabel,
          style = MaterialTheme.typography.labelLarge,
          color = MaterialTheme.colorScheme.primary,
        )
        RhythmSymbolIcon(
          icon = RhythmIcons.ChevronRight,
          contentDescription = null,
          tint = MaterialTheme.colorScheme.primary,
          size = 18.dp,
          modifier = Modifier.size(18.dp),
        )
      }
    }
  }
}

/**
 * Rhythm track row item matching Rhythm's ListItem / SongItem visual identity.
 * Hides paid price badge immediately once the user owns the track (`isPurchased == true`).
 */
@Composable
fun SongRowItem(
  song: Song,
  isCurrentSong: Boolean,
  isPlaying: Boolean,
  isFavorite: Boolean,
  isPurchased: Boolean = false,
  onClick: () -> Unit,
  onToggleFavorite: () -> Unit,
  onPurchaseClick: (() -> Unit)? = null,
  onPlayNext: (() -> Unit)? = null,
  onAddToQueue: (() -> Unit)? = null,
  onShowInfo: (() -> Unit)? = null,
  onShareSong: (() -> Unit)? = null,
  modifier: Modifier = Modifier,
  rankIndex: Int? = null,
  showCardContainer: Boolean = false,
) {
  val haptic = LocalHapticFeedback.current
  val hapticsEnabled = LocalRhythmHapticsEnabled.current
  val songShape = rememberExpressiveShapeFor(ExpressiveShapeTarget.SONG_ART)

  val containerColor = when {
    isCurrentSong -> MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.55f)
    showCardContainer -> MaterialTheme.colorScheme.surfaceContainerLow
    else -> Color.Transparent
  }
  val titleColor = if (isCurrentSong) {
    MaterialTheme.colorScheme.primary
  } else {
    MaterialTheme.colorScheme.onSurface
  }

  val favScale = remember { androidx.compose.animation.core.Animatable(1f) }
  val favScope = rememberCoroutineScope()

  val hasOverflowActions = onPlayNext != null || onAddToQueue != null || onShowInfo != null || onShareSong != null
  var menuExpanded by remember { mutableStateOf(false) }

  Surface(
    modifier = modifier
      .fillMaxWidth()
      .clip(RoundedCornerShape(18.dp))
      .clickable(onClick = onClick)
      .testTag("song_row_${song.id}"),
    shape = RoundedCornerShape(18.dp),
    color = containerColor,
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 14.dp, vertical = 10.dp),
      verticalAlignment = Alignment.CenterVertically,
    ) {
      if (rankIndex != null) {
        Text(
          text = rankIndex.toString(),
          style = MonoNumericStyle.copy(fontWeight = FontWeight.Bold),
          color = when (rankIndex) {
            1 -> MaterialTheme.colorScheme.primary
            2, 3 -> MaterialTheme.colorScheme.tertiary
            else -> MaterialTheme.colorScheme.onSurfaceVariant
          },
          modifier = Modifier.width(26.dp),
        )
      }

      Box(modifier = Modifier.size(52.dp)) {
        ArtworkImage(
          imageUrl = song.coverUrl,
          contentDescription = song.title,
          shape = songShape,
          sizePx = 180,
          modifier = Modifier.fillMaxSize(),
        )
        if (isCurrentSong) {
          Box(
            modifier = Modifier
              .fillMaxSize()
              .clip(songShape)
              .background(MaterialTheme.colorScheme.scrim.copy(alpha = 0.45f)),
            contentAlignment = Alignment.Center,
          ) {
            RhythmEqualizerIndicator(
              isPlaying = isPlaying,
              color = MaterialTheme.colorScheme.primary,
            )
          }
        }
      }

      Spacer(modifier = Modifier.width(14.dp))

      Column(
        modifier = Modifier.weight(1f),
        verticalArrangement = Arrangement.spacedBy(2.dp),
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(6.dp),
        ) {
          Text(
            text = song.title,
            style = MaterialTheme.typography.titleMedium.copy(
              fontWeight = if (isCurrentSong) FontWeight.Bold else FontWeight.Medium,
            ),
            color = titleColor,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.weight(1f, fill = false),
          )
          if (song.isPaid && !isPurchased) {
            PaidPricePill(
              priceText = song.priceText ?: "Trả phí",
              onClick = onPurchaseClick,
            )
          }
        }

        val secondaryMeta = buildString {
          append(song.artistName)
          if (song.durationSeconds > 0) {
            append(" • ")
            append(FormatUtils.formatDurationSeconds(song.durationSeconds))
          }
        }
        Text(
          text = secondaryMeta,
          style = MaterialTheme.typography.bodyMedium,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis,
        )
      }

      IconButton(
        onClick = {
          if (hapticsEnabled) haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
          favScope.launch {
            favScale.snapTo(1f)
            favScale.animateTo(1.22f, tween(80))
            favScale.animateTo(1f, tween(120))
          }
          onToggleFavorite()
        },
        modifier = Modifier
          .minimumInteractiveComponentSize()
          .testTag("fav_button_${song.id}"),
      ) {
        RhythmSymbolIcon(
          icon = if (isFavorite) RhythmIcons.FavoriteFilled else RhythmIcons.Favorite,
          contentDescription = if (isFavorite) "Bỏ yêu thích" else "Yêu thích",
          tint = if (isFavorite) {
            MaterialTheme.colorScheme.tertiary
          } else {
            MaterialTheme.colorScheme.onSurfaceVariant
          },
          size = 20.dp,
          modifier = Modifier
            .size(20.dp)
            .graphicsLayer {
              val s = favScale.value
              scaleX = s
              scaleY = s
            },
        )
      }

      if (hasOverflowActions) {
        Box {
          IconButton(
            onClick = { menuExpanded = true },
            modifier = Modifier
              .minimumInteractiveComponentSize()
              .testTag("song_more_${song.id}"),
          ) {
            RhythmSymbolIcon(
              icon = RhythmIcons.More,
              contentDescription = "Tùy chọn bài hát",
              tint = MaterialTheme.colorScheme.onSurfaceVariant,
              size = 20.dp,
              modifier = Modifier.size(20.dp),
            )
          }
          DropdownMenu(
            expanded = menuExpanded,
            onDismissRequest = { menuExpanded = false },
          ) {
            if (onPlayNext != null) {
              DropdownMenuItem(
                text = { Text("Phát tiếp theo") },
                leadingIcon = {
                  RhythmSymbolIcon(icon = RhythmIcons.PlayCircle, contentDescription = null, size = 20.dp)
                },
                onClick = {
                  menuExpanded = false
                  onPlayNext()
                },
              )
            }
            if (onAddToQueue != null) {
              DropdownMenuItem(
                text = { Text("Thêm vào danh sách chờ") },
                leadingIcon = {
                  RhythmSymbolIcon(icon = RhythmIcons.Queue, contentDescription = null, size = 20.dp)
                },
                onClick = {
                  menuExpanded = false
                  onAddToQueue()
                },
              )
            }
            if (onShowInfo != null) {
              DropdownMenuItem(
                text = { Text("Thông tin bài hát") },
                leadingIcon = {
                  RhythmSymbolIcon(icon = RhythmIcons.Actions.Info, contentDescription = null, size = 20.dp)
                },
                onClick = {
                  menuExpanded = false
                  onShowInfo()
                },
              )
            }
            if (onShareSong != null) {
              DropdownMenuItem(
                text = { Text("Chia sẻ bài hát") },
                leadingIcon = {
                  RhythmSymbolIcon(icon = RhythmIcons.Actions.Share, contentDescription = null, size = 20.dp)
                },
                onClick = {
                  menuExpanded = false
                  onShareSong()
                },
              )
            }
          }
        }
      }
    }
  }
}

@Composable
fun PaidPricePill(
  priceText: String,
  onClick: (() -> Unit)? = null,
  modifier: Modifier = Modifier,
) {
  Surface(
    shape = CircleShape,
    color = MaterialTheme.colorScheme.tertiaryContainer,
    modifier = modifier.then(
      if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier,
    ),
  ) {
    Row(
      modifier = Modifier.padding(horizontal = 7.dp, vertical = 2.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(3.dp),
    ) {
      RhythmSymbolIcon(
        icon = RhythmIcons.Lock,
        contentDescription = null,
        tint = MaterialTheme.colorScheme.onTertiaryContainer,
        size = 11.dp,
        modifier = Modifier.size(11.dp),
      )
      Text(
        text = priceText,
        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
        color = MaterialTheme.colorScheme.onTertiaryContainer,
      )
    }
  }
}

@Composable
fun StatusMessageCard(
  title: String,
  message: String,
  actionLabel: String? = null,
  onAction: (() -> Unit)? = null,
  modifier: Modifier = Modifier,
) {
  Card(
    modifier = modifier
      .fillMaxWidth()
      .padding(horizontal = 20.dp),
    shape = RoundedCornerShape(24.dp),
    colors = CardDefaults.cardColors(
      containerColor = MaterialTheme.colorScheme.surfaceContainer,
    ),
    elevation = CardDefaults.cardElevation(defaultElevation = 0.dp),
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(20.dp),
      verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
      Text(
        text = title,
        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
        color = MaterialTheme.colorScheme.onSurface,
      )
      Text(
        text = message,
        style = MaterialTheme.typography.bodyMedium,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
      )
      if (actionLabel != null && onAction != null) {
        Button(
          onClick = onAction,
          shape = CircleShape,
          colors = ButtonDefaults.buttonColors(
            containerColor = MaterialTheme.colorScheme.primaryContainer,
            contentColor = MaterialTheme.colorScheme.onPrimaryContainer,
          ),
          modifier = Modifier.minimumInteractiveComponentSize(),
        ) {
          RhythmSymbolIcon(
            icon = RhythmIcons.Refresh,
            contentDescription = null,
            size = 18.dp,
            modifier = Modifier.size(18.dp),
          )
          Spacer(Modifier.width(6.dp))
          Text(actionLabel, fontWeight = FontWeight.SemiBold)
        }
      }
    }
  }
}

@Composable
fun LoadingSkeletonList(
  itemCount: Int = 5,
  horizontalPadding: Dp = 20.dp,
) {
  val shimmerBrush = rememberRhythmShimmerBrush()
  Column(
    modifier = Modifier
      .fillMaxWidth()
      .padding(horizontal = horizontalPadding),
    verticalArrangement = Arrangement.spacedBy(10.dp),
  ) {
    repeat(itemCount) {
      Surface(
        modifier = Modifier
          .fillMaxWidth()
          .height(68.dp),
        shape = RoundedCornerShape(18.dp),
        color = MaterialTheme.colorScheme.surfaceContainerLow,
      ) {
        Row(
          modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 14.dp),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(14.dp),
        ) {
          Box(
            modifier = Modifier
              .size(48.dp)
              .clip(RoundedCornerShape(14.dp))
              .background(shimmerBrush),
          )
          Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Box(
              modifier = Modifier
                .width(150.dp)
                .height(14.dp)
                .clip(CircleShape)
                .background(shimmerBrush),
            )
            Box(
              modifier = Modifier
                .width(96.dp)
                .height(10.dp)
                .clip(CircleShape)
                .background(shimmerBrush),
            )
          }
        }
      }
    }
  }
}
