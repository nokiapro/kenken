package com.example.ui.screens

import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.material3.ripple
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.Album
import com.example.model.Artist
import com.example.model.ListeningStats
import com.example.model.Song
import com.example.ui.ActiveTrackMeta
import com.example.ui.DiscoverUiState
import com.example.ui.FormatUtils
import com.example.ui.components.ArtworkImage
import com.example.ui.components.LoadingSkeletonList
import com.example.ui.components.RhythmCollapsibleHeaderScreen
import com.example.ui.components.RhythmHeaderAction
import com.example.ui.components.RhythmSectionHeader
import com.example.ui.components.SongInfoDialog
import com.example.ui.components.SongRowItem
import com.example.ui.components.StatusMessageCard
import com.example.ui.components.horizontalEdgeBlend
import com.example.ui.components.rhythmPressScale
import com.example.ui.components.shareSongIntent
import com.example.ui.components.vietnameseGreetingText
import com.example.ui.rhythm.ExpressiveShapeTarget
import com.example.ui.rhythm.RhythmIcons
import com.example.ui.rhythm.RhythmSymbolIcon
import com.example.ui.rhythm.rememberExpressiveShapeFor
import com.example.ui.theme.RhythmShapes

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DiscoverScreen(
  uiState: DiscoverUiState,
  activeTrack: ActiveTrackMeta,
  favoriteIds: Set<String>,
  purchasedIds: Set<String>,
  bottomOverlayPadding: PaddingValues,
  onRefresh: () -> Unit,
  onOpenSearch: () -> Unit,
  onOpenCharts: () -> Unit = {},
  onPlaySong: (Song, List<Song>) -> Unit,
  onToggleFavorite: (Song) -> Unit,
  onPurchaseSong: (Song) -> Unit,
  onOpenAlbum: (String) -> Unit,
  onOpenArtist: (String) -> Unit,
  onOpenPlaylist: (String) -> Unit = {},
  userName: String? = null,
  listeningStats: ListeningStats = ListeningStats(),
  onOpenAllArtists: () -> Unit = {},
  onPlayNext: (Song) -> Unit = {},
  onAddToQueue: (Song) -> Unit = {},
) {
  @Suppress("UNUSED_VARIABLE")
  val unusedCharts = onOpenCharts
  @Suppress("UNUSED_VARIABLE")
  val unusedPlaylist = onOpenPlaylist

  val context = LocalContext.current
  var infoSong by remember { mutableStateOf<Song?>(null) }
  var showListeningInsights by remember { mutableStateOf(false) }

  val featuredArtists = remember(uiState.artists) {
    uiState.artists.shuffled().take(10)
  }
  val recommendedSongs = remember(uiState.popularSongs, uiState.latestSongs) {
    (uiState.popularSongs + uiState.latestSongs)
      .distinctBy { it.id }
      .shuffled()
      .take(10)
  }
  val trendingSongs = remember(uiState.popularSongs) {
    uiState.popularSongs.take(10)
  }
  val newlyAddedSongs = remember(uiState.latestSongs, uiState.popularSongs) {
    uiState.latestSongs
      .ifEmpty {
        if (uiState.popularSongs.any { it.createdAtMs > 0L }) {
          uiState.popularSongs.sortedByDescending { it.createdAtMs }
        } else {
          uiState.popularSongs.reversed()
        }
      }
      .take(5)
  }

  RhythmCollapsibleHeaderScreen(
    title = uiState.siteInfo.siteName.ifBlank { "XuanKen Music" },
    leadingBadgeIcon = RhythmIcons.GraphicEq,
    compactSingleRowHeader = true,
    headerActions = emptyList(),
  ) { scaffoldModifier ->
    val greeting = remember(userName) {
      val base = vietnameseGreetingText()
      val clean = userName?.trim().orEmpty()
      if (clean.isNotBlank()) "$base, $clean" else base
    }

    LazyColumn(
      modifier = scaffoldModifier
        .fillMaxSize()
        .testTag("discover_list"),
      contentPadding = PaddingValues(
        top = 4.dp,
        bottom = bottomOverlayPadding.calculateBottomPadding() + 28.dp,
      ),
      verticalArrangement = Arrangement.spacedBy(22.dp),
    ) {
      item(key = "greeting_pill", contentType = "greeting") {
        GreetingStripRow(
          greeting = greeting,
          songCount = uiState.popularSongs.size,
        )
      }

      if (uiState.isLoading && uiState.popularSongs.isEmpty() && uiState.albums.isEmpty()) {
        item(key = "loading_skeleton", contentType = "skeleton") {
          LoadingSkeletonList(itemCount = 6)
        }
      } else if (uiState.errorMessage != null && uiState.popularSongs.isEmpty()) {
        item(key = "error_card", contentType = "error") {
          StatusMessageCard(
            title = if (uiState.isMissingApiKey) "Cần cấu hình API Key" else "Không thể tải dữ liệu",
            message = uiState.errorMessage,
            actionLabel = "Thử lại",
            onAction = onRefresh,
          )
        }
      } else {
        // 1. Nghệ sĩ nổi bật — 10 nghệ sĩ ngẫu nhiên + nút Xem thêm sang màn lưới 3 cột
        if (featuredArtists.isNotEmpty()) {
          item(key = "artists_carousel", contentType = "artists_row") {
            val rowState = rememberLazyListState()
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
              RhythmSectionHeader(
                title = "Nghệ sĩ nổi bật",
                actionLabel = "Xem thêm",
                onActionClick = onOpenAllArtists,
              )
              LazyRow(
                state = rowState,
                modifier = Modifier.horizontalEdgeBlend(rowState),
                contentPadding = PaddingValues(horizontal = 20.dp),
                horizontalArrangement = Arrangement.spacedBy(16.dp),
              ) {
                items(
                  items = featuredArtists,
                  key = { "artist_${it.id}" },
                  contentType = { "artist_card" },
                ) { artist ->
                  ModernArtistCard(
                    artist = artist,
                    onClick = { onOpenArtist(artist.id) },
                  )
                }
              }
            }
          }
        }

        // 2. Album tuyển chọn
        if (uiState.albums.isNotEmpty()) {
          item(key = "albums_carousel", contentType = "albums_row") {
            val rowState = rememberLazyListState()
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
              RhythmSectionHeader(title = "Album tuyển chọn")
              LazyRow(
                state = rowState,
                modifier = Modifier.horizontalEdgeBlend(rowState),
                contentPadding = PaddingValues(horizontal = 20.dp),
                horizontalArrangement = Arrangement.spacedBy(14.dp),
              ) {
                items(
                  items = uiState.albums,
                  key = { "album_${it.id}" },
                  contentType = { "album_card" },
                ) { album ->
                  ModernAlbumCard(
                    album = album,
                    onClick = { onOpenAlbum(album.id) },
                    onPlayClick = {
                      if (album.songs.isNotEmpty()) {
                        onPlaySong(album.songs.first(), album.songs)
                      } else {
                        onOpenAlbum(album.id)
                      }
                    },
                  )
                }
              }
            }
          }
        }

        // 3. Gợi ý hôm nay — 10 bài ngẫu nhiên
        if (recommendedSongs.isNotEmpty()) {
          item(key = "recommended_showcase", contentType = "recommended_card") {
            ModernRecommendedSection(
              recommendedSongs = recommendedSongs,
              onPlayClick = { songs ->
                if (songs.isNotEmpty()) onPlaySong(songs.first(), songs)
              },
            )
          }
        }

        // 4. Bài hát thịnh hành — Giới hạn 10 bài
        if (trendingSongs.isNotEmpty()) {
          item(key = "popular_header", contentType = "section_header") {
            RhythmSectionHeader(
              title = "Bài hát thịnh hành",
              actionLabel = "Xem tất cả",
              onActionClick = onOpenSearch,
            )
          }
          itemsIndexed(
            items = trendingSongs,
            key = { _, s -> "pop_${s.id}" },
            contentType = { _, _ -> "song_row" },
          ) { index, song ->
            SongRowItem(
              song = song,
              rankIndex = index + 1,
              isCurrentSong = activeTrack.songId == song.id,
              isPlaying = activeTrack.songId == song.id && activeTrack.isPlaying,
              isFavorite = song.id in favoriteIds,
              isPurchased = song.id in purchasedIds || !song.isPaid,
              onClick = { onPlaySong(song, trendingSongs) },
              onToggleFavorite = { onToggleFavorite(song) },
              onPurchaseClick = { onPurchaseSong(song) },
              onPlayNext = { onPlayNext(song) },
              onAddToQueue = { onAddToQueue(song) },
              onShowInfo = { infoSong = song },
              onShareSong = { shareSongIntent(context, song) },
              modifier = Modifier.padding(horizontal = 8.dp),
            )
          }
        }

        // 5. Những bài hát mới thêm — Giới hạn 5 bài
        if (newlyAddedSongs.isNotEmpty()) {
          item(key = "newly_added_header", contentType = "section_header") {
            RhythmSectionHeader(
              title = "Những bài hát mới thêm",
              actionLabel = "Xem tất cả",
              onActionClick = onOpenSearch,
            )
          }
          itemsIndexed(
            items = newlyAddedSongs,
            key = { _, s -> "latest_${s.id}" },
            contentType = { _, _ -> "song_row" },
          ) { _, song ->
            SongRowItem(
              song = song,
              isCurrentSong = activeTrack.songId == song.id,
              isPlaying = activeTrack.songId == song.id && activeTrack.isPlaying,
              isFavorite = song.id in favoriteIds,
              isPurchased = song.id in purchasedIds || !song.isPaid,
              onClick = { onPlaySong(song, newlyAddedSongs) },
              onToggleFavorite = { onToggleFavorite(song) },
              onPurchaseClick = { onPurchaseSong(song) },
              onPlayNext = { onPlayNext(song) },
              onAddToQueue = { onAddToQueue(song) },
              onShowInfo = { infoSong = song },
              onShareSong = { shareSongIntent(context, song) },
              modifier = Modifier.padding(horizontal = 8.dp),
            )
          }
        }

        // 6. Thống kê tổng thời gian đã nghe nhạc
        item(key = "listening_stats_card", contentType = "listening_stats") {
          ModernListeningStatsSection(
            stats = listeningStats,
            onClick = { showListeningInsights = true },
          )
        }
      }
    }
  }

  val selectedInfo = infoSong
  if (selectedInfo != null) {
    SongInfoDialog(
      song = selectedInfo,
      isPurchased = selectedInfo.id in purchasedIds || !selectedInfo.isPaid,
      playCountOnDevice = listeningStats.songPlayCounts[selectedInfo.id] ?: 0,
      onShareClick = { shareSongIntent(context, selectedInfo) },
      onDismiss = { infoSong = null },
    )
  }

  if (showListeningInsights) {
    val allSongs = remember(uiState) {
      (uiState.popularSongs + uiState.latestSongs + uiState.chartSections.flatMap { it.songs })
        .distinctBy { it.id }
    }
    val topPlayed = remember(listeningStats.songPlayCounts, allSongs) {
      val byId = allSongs.associateBy { it.id }
      listeningStats.songPlayCounts.entries
        .sortedByDescending { it.value }
        .mapNotNull { (id, count) -> byId[id]?.let { it to count } }
        .take(5)
    }
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    ModalBottomSheet(
      onDismissRequest = { showListeningInsights = false },
      sheetState = sheetState,
      containerColor = MaterialTheme.colorScheme.surfaceContainerLow,
    ) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .heightIn(max = 520.dp)
          .padding(horizontal = 20.dp)
          .padding(bottom = 28.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
      ) {
        Text(
          text = "Thống kê nghe nhạc Rhythm",
          style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
        )
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
          Surface(
            shape = RoundedCornerShape(20.dp),
            color = MaterialTheme.colorScheme.primaryContainer,
            modifier = Modifier.weight(1f),
          ) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
              Text(
                text = "Tổng thời gian",
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f),
              )
              Text(
                text = FormatUtils.formatListeningDuration(listeningStats.totalListeningTimeMs),
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = MaterialTheme.colorScheme.onPrimaryContainer,
              )
            }
          }
          Surface(
            shape = RoundedCornerShape(20.dp),
            color = MaterialTheme.colorScheme.secondaryContainer,
            modifier = Modifier.weight(1f),
          ) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
              Text(
                text = "Lượt phát",
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSecondaryContainer.copy(alpha = 0.8f),
              )
              Text(
                text = "${listeningStats.songsPlayedCount} bài",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = MaterialTheme.colorScheme.onSecondaryContainer,
              )
            }
          }
        }

        Text(
          text = "Nghe nhiều nhất trên thiết bị",
          style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.SemiBold),
        )

        if (topPlayed.isEmpty()) {
          Text(
            text = "Hãy phát vài ca khúc để thống kê các bài hát bạn nghe nhiều nhất.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
          )
        } else {
          LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            itemsIndexed(topPlayed, key = { idx, pair -> "top_played_${pair.first.id}_$idx" }) { idx, (song, count) ->
              Surface(
                onClick = {
                  showListeningInsights = false
                  onPlaySong(song, topPlayed.map { it.first })
                },
                shape = RoundedCornerShape(16.dp),
                color = MaterialTheme.colorScheme.surfaceContainer,
                modifier = Modifier.testTag("insights_song_${song.id}"),
              ) {
                Row(
                  modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 10.dp),
                  verticalAlignment = Alignment.CenterVertically,
                  horizontalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                  Text(
                    text = "#${idx + 1}",
                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.primary,
                  )
                  ArtworkImage(
                    imageUrl = song.coverUrl,
                    contentDescription = song.title,
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.size(44.dp),
                  )
                  Column(modifier = Modifier.weight(1f)) {
                    Text(
                      text = song.title,
                      style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.SemiBold),
                      maxLines = 1,
                      overflow = TextOverflow.Ellipsis,
                    )
                    Text(
                      text = song.artistName,
                      style = MaterialTheme.typography.bodySmall,
                      color = MaterialTheme.colorScheme.onSurfaceVariant,
                      maxLines = 1,
                      overflow = TextOverflow.Ellipsis,
                    )
                  }
                  Text(
                    text = "$count lượt",
                    style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.primary,
                  )
                }
              }
            }
          }
        }
      }
    }
  }
}

@Composable
private fun GreetingStripRow(
  greeting: String,
  songCount: Int,
) {
  Row(
    modifier = Modifier
      .fillMaxWidth()
      .padding(horizontal = 20.dp)
      .testTag("discover_greeting_row"),
    verticalAlignment = Alignment.CenterVertically,
    horizontalArrangement = Arrangement.SpaceBetween,
  ) {
    Surface(
      shape = CircleShape,
      color = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.78f),
    ) {
      Text(
        text = greeting,
        style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.SemiBold),
        color = MaterialTheme.colorScheme.onSecondaryContainer,
        maxLines = 1,
        overflow = TextOverflow.Ellipsis,
        modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp),
      )
    }
    if (songCount > 0) {
      Spacer(Modifier.width(8.dp))
      Text(
        text = "${songCount}+ bài hát",
        style = MaterialTheme.typography.labelMedium,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
      )
    }
  }
}

@Composable
private fun ModernArtistCard(
  artist: Artist,
  onClick: () -> Unit,
) {
  val interactionSource = remember { MutableInteractionSource() }
  Column(
    modifier = Modifier
      .width(106.dp)
      .rhythmPressScale(interactionSource, pressedScale = 0.94f)
      .clip(RoundedCornerShape(18.dp))
      .clickable(
        interactionSource = interactionSource,
        indication = ripple(),
        onClick = onClick,
      )
      .padding(4.dp),
    horizontalAlignment = Alignment.CenterHorizontally,
  ) {
    Box(modifier = Modifier.size(96.dp)) {
      ArtworkImage(
        imageUrl = artist.avatarUrl,
        contentDescription = artist.name,
        shape = CircleShape,
        sizePx = 280,
        modifier = Modifier.fillMaxSize(),
      )
      FilledIconButton(
        onClick = onClick,
        colors = IconButtonDefaults.filledIconButtonColors(
          containerColor = MaterialTheme.colorScheme.primaryContainer,
          contentColor = MaterialTheme.colorScheme.onPrimaryContainer,
        ),
        modifier = Modifier
          .size(32.dp)
          .align(Alignment.BottomEnd),
      ) {
        RhythmSymbolIcon(
          icon = RhythmIcons.Play,
          contentDescription = "Nghe ${artist.name}",
          size = 18.dp,
          modifier = Modifier.size(18.dp),
        )
      }
    }
    Spacer(Modifier.height(8.dp))
    Text(
      text = artist.name,
      style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.SemiBold),
      color = MaterialTheme.colorScheme.onSurface,
      maxLines = 2,
      minLines = 2,
      overflow = TextOverflow.Ellipsis,
      textAlign = TextAlign.Center,
      lineHeight = 18.sp,
    )
  }
}

@Composable
private fun ModernAlbumCard(
  album: Album,
  onClick: () -> Unit,
  onPlayClick: () -> Unit,
) {
  val interactionSource = remember { MutableInteractionSource() }
  Card(
    onClick = onClick,
    interactionSource = interactionSource,
    shape = RhythmShapes.SquircleLarge,
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerHigh),
    elevation = CardDefaults.cardElevation(defaultElevation = 0.dp),
    modifier = Modifier
      .width(160.dp)
      .height(240.dp)
      .rhythmPressScale(interactionSource, pressedScale = 0.96f),
  ) {
    Column(modifier = Modifier.padding(12.dp)) {
      Box {
        val albumCoverShape = rememberExpressiveShapeFor(ExpressiveShapeTarget.ALBUM_ART)
        ArtworkImage(
          imageUrl = album.coverUrl,
          contentDescription = album.title,
          shape = albumCoverShape,
          sizePx = 420,
          modifier = Modifier
            .fillMaxWidth()
            .aspectRatio(1f),
        )
        FilledIconButton(
          onClick = onPlayClick,
          colors = IconButtonDefaults.filledIconButtonColors(
            containerColor = MaterialTheme.colorScheme.primaryContainer,
            contentColor = MaterialTheme.colorScheme.onPrimaryContainer,
          ),
          modifier = Modifier
            .align(Alignment.BottomEnd)
            .padding(10.dp)
            .size(40.dp),
        ) {
          RhythmSymbolIcon(
            icon = RhythmIcons.Play,
            contentDescription = "Phát ${album.title}",
            size = 20.dp,
            modifier = Modifier.size(20.dp),
          )
        }
      }

      Spacer(Modifier.height(10.dp))

      Text(
        text = album.title,
        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.SemiBold),
        color = MaterialTheme.colorScheme.onSurface,
        maxLines = 2,
        overflow = TextOverflow.Ellipsis,
        lineHeight = 18.sp,
      )
      Spacer(Modifier.height(2.dp))
      Text(
        text = album.artistName,
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        maxLines = 1,
        overflow = TextOverflow.Ellipsis,
      )
    }
  }
}

@Composable
private fun ModernRecommendedSection(
  recommendedSongs: List<Song>,
  onPlayClick: (List<Song>) -> Unit,
) {
  val lead = recommendedSongs.firstOrNull() ?: return
  val cardBg = MaterialTheme.colorScheme.tertiaryContainer
  val onCardBg = MaterialTheme.colorScheme.onTertiaryContainer

  Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
    RhythmSectionHeader(title = "Gợi ý hôm nay")

    val recInteraction = remember { MutableInteractionSource() }
    Card(
      onClick = { onPlayClick(recommendedSongs) },
      interactionSource = recInteraction,
      shape = RoundedCornerShape(28.dp),
      colors = CardDefaults.cardColors(containerColor = cardBg),
      elevation = CardDefaults.cardElevation(defaultElevation = 0.dp),
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 20.dp)
        .height(216.dp)
        .rhythmPressScale(recInteraction, pressedScale = 0.97f)
        .testTag("recommended_section_card"),
    ) {
      Box(
        modifier = Modifier
          .fillMaxSize()
          .padding(20.dp),
      ) {
        Column(
          modifier = Modifier
            .align(Alignment.TopStart)
            .fillMaxWidth(0.56f),
          verticalArrangement = Arrangement.spacedBy(4.dp),
        ) {
          Text(
            text = lead.artistName,
            style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold),
            color = onCardBg,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
          )
          Text(
            text = "Mix tuyển chọn ${recommendedSongs.size} bài",
            style = MaterialTheme.typography.bodySmall,
            color = onCardBg.copy(alpha = 0.78f),
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
          )
        }

        ArtworkImage(
          imageUrl = lead.coverUrl,
          contentDescription = lead.title,
          shape = RoundedCornerShape(22.dp),
          sizePx = 420,
          modifier = Modifier
            .align(Alignment.CenterEnd)
            .padding(bottom = 26.dp)
            .size(118.dp),
        )

        Row(
          modifier = Modifier
            .align(Alignment.BottomStart)
            .fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy((-10).dp),
          ) {
            recommendedSongs.take(4).forEach { song ->
              Box(
                modifier = Modifier
                  .size(42.dp)
                  .border(1.5.dp, cardBg, RoundedCornerShape(12.dp))
                  .clip(RoundedCornerShape(12.dp)),
              ) {
                ArtworkImage(
                  imageUrl = song.coverUrl,
                  contentDescription = song.title,
                  shape = RoundedCornerShape(12.dp),
                  sizePx = 120,
                  modifier = Modifier.fillMaxSize(),
                )
              }
            }
          }

          Button(
            onClick = { onPlayClick(recommendedSongs) },
            shape = RoundedCornerShape(24.dp),
            colors = ButtonDefaults.buttonColors(
              containerColor = MaterialTheme.colorScheme.primaryContainer,
              contentColor = MaterialTheme.colorScheme.onPrimaryContainer,
            ),
            contentPadding = PaddingValues(horizontal = 26.dp, vertical = 12.dp),
          ) {
            Text(
              text = "Phát",
              style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
            )
          }
        }
      }
    }
  }
}

@Composable
private fun ModernListeningStatsSection(
  stats: ListeningStats,
  onClick: () -> Unit = {},
) {
  val interactionSource = remember { MutableInteractionSource() }
  Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
    RhythmSectionHeader(title = "Thống kê nghe nhạc")

    Card(
      onClick = onClick,
      interactionSource = interactionSource,
      shape = RoundedCornerShape(24.dp),
      colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerHigh),
      elevation = CardDefaults.cardElevation(defaultElevation = 0.dp),
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 20.dp)
        .rhythmPressScale(interactionSource, pressedScale = 0.97f)
        .testTag("discover_listening_stats"),
    ) {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(18.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(16.dp),
      ) {
        Surface(
          shape = CircleShape,
          color = MaterialTheme.colorScheme.primaryContainer,
          modifier = Modifier.size(52.dp),
        ) {
          Box(contentAlignment = Alignment.Center) {
            RhythmSymbolIcon(
              icon = RhythmIcons.History,
              contentDescription = null,
              tint = MaterialTheme.colorScheme.onPrimaryContainer,
              size = 26.dp,
              modifier = Modifier.size(26.dp),
            )
          }
        }

        Column(
          modifier = Modifier.weight(1f),
          verticalArrangement = Arrangement.spacedBy(4.dp),
        ) {
          Text(
            text = "Tổng thời gian đã nghe",
            style = MaterialTheme.typography.labelLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
          )
          Text(
            text = FormatUtils.formatListeningDuration(stats.totalListeningTimeMs),
            style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold),
            color = MaterialTheme.colorScheme.onSurface,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
          )
          Text(
            text = "${stats.songsPlayedCount} lượt phát • Chạm xem chi tiết",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.primary,
          )
        }

        RhythmSymbolIcon(
          icon = RhythmIcons.ChevronRight,
          contentDescription = null,
          tint = MaterialTheme.colorScheme.onSurfaceVariant,
          size = 20.dp,
          modifier = Modifier.size(20.dp),
        )
      }
    }
  }
}
