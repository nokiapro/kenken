package com.example.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import com.example.ui.rhythm.RhythmIcons
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.model.Song
import com.example.ui.ActiveTrackMeta
import com.example.ui.DiscoverUiState
import com.example.ui.components.LoadingSkeletonList
import com.example.ui.components.RhythmCollapsibleHeaderScreen
import com.example.ui.components.RhythmDetailActionButton
import com.example.ui.components.RhythmHeaderAction
import com.example.ui.components.SongInfoDialog
import com.example.ui.components.SongRowItem
import com.example.ui.components.StatusMessageCard
import com.example.ui.components.horizontalEdgeBlend
import com.example.ui.components.shareSongIntent

@Composable
fun ChartsScreen(
  discoverState: DiscoverUiState,
  activeTrack: ActiveTrackMeta,
  favoriteIds: Set<String>,
  purchasedIds: Set<String>,
  bottomOverlayPadding: PaddingValues,
  onRetry: () -> Unit,
  onPlaySong: (Song, List<Song>) -> Unit,
  onPlayAll: (List<Song>, Boolean) -> Unit,
  onToggleFavorite: (Song) -> Unit,
  onPurchaseSong: (Song) -> Unit,
  onPlayNext: (Song) -> Unit = {},
  onAddToQueue: (Song) -> Unit = {},
  playCounts: Map<String, Int> = emptyMap(),
) {
  val context = LocalContext.current
  var infoSong by remember { mutableStateOf<Song?>(null) }
  val sections = discoverState.chartSections
  var selectedSectionIndex by remember(sections.size) { mutableIntStateOf(0) }
  val activeSection = sections.getOrNull(selectedSectionIndex)
  val topSongs = remember(activeSection) { activeSection?.songs?.take(10).orEmpty() }

  RhythmCollapsibleHeaderScreen(
    title = "Bảng xếp hạng",
    headerActions = listOf(
      RhythmHeaderAction(
        icon = RhythmIcons.Refresh,
        contentDescription = "Làm mới BXH",
        onClick = onRetry,
      ),
    ),
    filterContent = if (sections.size > 1) {
      {
        val chipRowState = rememberLazyListState()
        LazyRow(
          state = chipRowState,
          modifier = Modifier.horizontalEdgeBlend(chipRowState),
          contentPadding = PaddingValues(horizontal = 20.dp, vertical = 6.dp),
          horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
          itemsIndexed(sections, key = { idx, sec -> "chart_tab_${idx}_${sec.title}" }) { index, section ->
            FilterChip(
              selected = index == selectedSectionIndex,
              onClick = { selectedSectionIndex = index },
              label = { Text(section.title.ifBlank { "BXH ${index + 1}" }) },
              shape = CircleShape,
              colors = FilterChipDefaults.filterChipColors(
                selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                selectedLabelColor = MaterialTheme.colorScheme.onPrimaryContainer,
              ),
            )
          }
        }
      }
    } else null,
  ) { scaffoldModifier ->
    LazyColumn(
      modifier = scaffoldModifier
        .fillMaxSize()
        .testTag("charts_list"),
      contentPadding = PaddingValues(
        top = 8.dp,
        bottom = bottomOverlayPadding.calculateBottomPadding() + 28.dp,
      ),
      verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
      when {
        discoverState.isLoading && sections.isEmpty() -> {
          item(key = "charts_loading", contentType = "skeleton") {
            LoadingSkeletonList(itemCount = 6)
          }
        }
        activeSection == null || topSongs.isEmpty() -> {
          item(key = "charts_empty", contentType = "empty") {
            StatusMessageCard(
              title = "Chưa có dữ liệu bảng xếp hạng",
              message = discoverState.errorMessage ?: "Kéo hoặc nhấn làm mới để cập nhật bảng xếp hạng mới nhất.",
              actionLabel = "Tải lại",
              onAction = onRetry,
            )
          }
        }
        else -> {
          item(key = "charts_summary_banner", contentType = "banner") {
            Column(
              modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 6.dp),
              verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
              Card(
                shape = RoundedCornerShape(28.dp),
                colors = CardDefaults.cardColors(
                  containerColor = MaterialTheme.colorScheme.primaryContainer,
                ),
                elevation = CardDefaults.cardElevation(defaultElevation = 0.dp),
                modifier = Modifier.fillMaxWidth(),
              ) {
                Column(
                  modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                  verticalArrangement = Arrangement.spacedBy(4.dp),
                ) {
                  Text(
                    text = activeSection.title.ifBlank { "Top Tuần XK Music" },
                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onPrimaryContainer,
                  )
                  Text(
                    text = "Top ${topSongs.size} ca khúc dẫn đầu tuần này",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f),
                  )
                }
              }

              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
              ) {
                RhythmDetailActionButton(
                  text = "Phát tất cả",
                  icon = RhythmIcons.Play,
                  filled = true,
                  isFirst = true,
                  isLast = false,
                  height = 48.dp,
                  onClick = { onPlayAll(topSongs, false) },
                )
                RhythmDetailActionButton(
                  text = "Trộn bài",
                  icon = RhythmIcons.Shuffle,
                  filled = false,
                  isFirst = false,
                  isLast = true,
                  height = 48.dp,
                  onClick = { onPlayAll(topSongs, true) },
                )
              }
            }
          }

          itemsIndexed(
            items = topSongs,
            key = { idx, s -> "chart_${selectedSectionIndex}_${s.id}_$idx" },
            contentType = { _, _ -> "song_row" },
          ) { idx, song ->
            SongRowItem(
              song = song,
              rankIndex = idx + 1,
              isCurrentSong = activeTrack.songId == song.id,
              isPlaying = activeTrack.songId == song.id && activeTrack.isPlaying,
              isFavorite = song.id in favoriteIds,
              isPurchased = song.id in purchasedIds || !song.isPaid,
              onClick = { onPlaySong(song, topSongs) },
              onToggleFavorite = { onToggleFavorite(song) },
              onPurchaseClick = { onPurchaseSong(song) },
              onPlayNext = { onPlayNext(song) },
              onAddToQueue = { onAddToQueue(song) },
              onShowInfo = { infoSong = song },
              onShareSong = { shareSongIntent(context, song) },
              modifier = Modifier.padding(horizontal = 8.dp),
            )
          }
        }
      }
    }
  }

  val selected = infoSong
  if (selected != null) {
    SongInfoDialog(
      song = selected,
      isPurchased = selected.id in purchasedIds || !selected.isPaid,
      playCountOnDevice = playCounts[selected.id] ?: 0,
      onShareClick = { shareSongIntent(context, selected) },
      onDismiss = { infoSong = null },
    )
  }
}
