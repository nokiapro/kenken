package com.example.data.repository

import com.example.data.network.ApiClient
import com.example.data.network.FirebaseAuthApiService
import com.example.data.network.FirebaseTokenApiService
import com.example.data.network.XkFirestoreHelper
import com.example.data.network.XkJsonParser
import com.example.data.network.XkMusicApiService
import com.example.data.network.XkRtdbApiService
import com.example.model.Album
import com.example.model.ApiResult
import com.example.model.AuthSession
import com.example.model.PurchaseRecord
import com.example.model.Song
import com.example.model.UserProfile
import com.example.model.UserSettings
import com.example.model.VoucherInfo
import com.example.model.VoucherValidation
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.time.Instant

class AccountRepository(
  private val api: XkMusicApiService = ApiClient.apiService,
  private val rtdb: XkRtdbApiService = ApiClient.rtdbService,
  private val firebaseAuth: FirebaseAuthApiService = ApiClient.firebaseAuthService,
  private val firebaseToken: FirebaseTokenApiService = ApiClient.firebaseTokenService,
  private val localStore: LocalLibraryStore,
) {
  private val jsonMediaType = "application/json; charset=utf-8".toMediaType()
  private val refreshMutex = Mutex()

  val authSessionFlow: Flow<AuthSession?> = localStore.authSessionFlow

  suspend fun restoreTokenIntoClient() {
    val session = localStore.authSessionFlow.first()
    ApiClient.setUserToken(session?.idToken)
  }

  suspend fun ensureFreshSession(forceRefresh: Boolean = false): AuthSession? = withContext(Dispatchers.IO) {
    val current = localStore.authSessionFlow.first() ?: return@withContext null
    val now = System.currentTimeMillis()
    val isExpiringSoon = current.idToken.isBlank() ||
      current.expiresAtEpochMs <= 0L ||
      current.expiresAtEpochMs <= now + 120_000L

    if (!forceRefresh && !isExpiringSoon) {
      ApiClient.setUserToken(current.idToken)
      return@withContext current
    }

    refreshMutex.withLock {
      val latest = localStore.authSessionFlow.first() ?: return@withLock null
      val stillNeedsRefresh = forceRefresh ||
        latest.idToken.isBlank() ||
        latest.expiresAtEpochMs <= 0L ||
        latest.expiresAtEpochMs <= System.currentTimeMillis() + 120_000L

      if (!stillNeedsRefresh) {
        ApiClient.setUserToken(latest.idToken)
        return@withLock latest
      }
      if (latest.refreshToken.isBlank()) {
        ApiClient.setUserToken(latest.idToken)
        return@withLock latest
      }
      when (val refreshed = performTokenRefresh(latest)) {
        is ApiResult.Success -> refreshed.data
        is ApiResult.Error -> {
          ApiClient.setUserToken(latest.idToken)
          latest
        }
      }
    }
  }

  suspend fun login(email: String, password: String): ApiResult<AuthSession> = withContext(Dispatchers.IO) {
    val cleanEmail = email.trim()
    val payload = JSONObject().apply {
      put("email", cleanEmail)
      put("password", password)
    }.toString().toRequestBody(jsonMediaType)

    // 1. Try POST /api/v1/auth/login first
    val primaryRes = runCatching { api.login(payload) }.getOrNull()
    if (primaryRes != null) {
      val body = primaryRes.body()?.string()?.trim().orEmpty()
      val errBody = primaryRes.errorBody()?.string()?.trim().orEmpty()
      if (primaryRes.isSuccessful && isJsonBody(body)) {
        val parsed = XkJsonParser.parseAuthSession(body, fallbackEmail = cleanEmail)
        if (parsed != null) {
          return@withContext finalizeAuthenticatedSession(parsed)
        }
      } else if (primaryRes.code() != 404 && isJsonBody(errBody)) {
        val msg = XkJsonParser.parseErrorMessage(errBody) ?: "Đăng nhập thất bại (${primaryRes.code()})."
        return@withContext ApiResult.Error(msg, isUnauthorized = primaryRes.code() == 401)
      }
    }

    // 2. Fallback: Shared Web Firebase Auth (identitytoolkit)
    val fbPayload = JSONObject().apply {
      put("email", cleanEmail)
      put("password", password)
      put("returnSecureToken", true)
    }.toString().toRequestBody(jsonMediaType)

    return@withContext try {
      val res = firebaseAuth.signInWithPassword(ApiClient.WEB_FIREBASE_API_KEY, fbPayload)
      val body = res.body()?.string().orEmpty()
      if (res.isSuccessful) {
        val session = XkJsonParser.parseAuthSession(body, fallbackEmail = cleanEmail)
          ?: return@withContext ApiResult.Error("Không đọc được phiên đăng nhập từ máy chủ.")
        finalizeAuthenticatedSession(session)
      } else {
        val errRaw = res.errorBody()?.string()
        ApiResult.Error(mapFirebaseAuthError(XkJsonParser.parseErrorMessage(errRaw)))
      }
    } catch (e: Exception) {
      ApiResult.Error(e.localizedMessage ?: "Không thể kết nối máy chủ đăng nhập.")
    }
  }

  suspend fun register(
    email: String,
    password: String,
    displayName: String,
  ): ApiResult<AuthSession> = withContext(Dispatchers.IO) {
    val cleanEmail = email.trim()
    val cleanName = displayName.trim().ifBlank { cleanEmail.substringBefore("@") }

    val payload = JSONObject().apply {
      put("email", cleanEmail)
      put("password", password)
      put("displayName", cleanName)
    }.toString().toRequestBody(jsonMediaType)

    // 1. Try POST /api/v1/auth/register first
    val primaryRes = runCatching { api.register(payload) }.getOrNull()
    if (primaryRes != null) {
      val body = primaryRes.body()?.string()?.trim().orEmpty()
      val errBody = primaryRes.errorBody()?.string()?.trim().orEmpty()
      if (primaryRes.isSuccessful && isJsonBody(body)) {
        val parsed = XkJsonParser.parseAuthSession(body, fallbackEmail = cleanEmail, fallbackDisplayName = cleanName)
        if (parsed != null) {
          return@withContext finalizeAuthenticatedSession(parsed)
        }
      } else if (primaryRes.code() != 404 && isJsonBody(errBody)) {
        val msg = XkJsonParser.parseErrorMessage(errBody) ?: "Đăng ký thất bại (${primaryRes.code()})."
        return@withContext ApiResult.Error(msg)
      }
    }

    // 2. Fallback: Firebase Auth signUp + create RTDB member record matching web app
    val fbPayload = JSONObject().apply {
      put("email", cleanEmail)
      put("password", password)
      put("returnSecureToken", true)
    }.toString().toRequestBody(jsonMediaType)

    return@withContext try {
      val res = firebaseAuth.signUp(ApiClient.WEB_FIREBASE_API_KEY, fbPayload)
      val body = res.body()?.string().orEmpty()
      if (res.isSuccessful) {
        val baseSession = XkJsonParser.parseAuthSession(
          rawJson = body,
          fallbackEmail = cleanEmail,
          fallbackDisplayName = cleanName,
        ) ?: return@withContext ApiResult.Error("Không thể tạo phiên đăng ký.")

        // Update Firebase Auth displayName
        val updateBody = JSONObject().apply {
          put("idToken", baseSession.idToken)
          put("displayName", cleanName)
          put("returnSecureToken", false)
        }.toString().toRequestBody(jsonMediaType)
        runCatching { firebaseAuth.updateProfile(ApiClient.WEB_FIREBASE_API_KEY, updateBody) }

        // Initialize /members/{uid} on RTDB if permitted
        if (baseSession.user.uid.isNotBlank()) {
          val memberInit = JSONObject().apply {
            put("uid", baseSession.user.uid)
            put("email", cleanEmail)
            put("displayName", cleanName)
            put("balance", 0L)
            put("role", "member")
          }.toString().toRequestBody(jsonMediaType)
          runCatching { rtdb.patchMember(baseSession.user.uid, baseSession.idToken, memberInit) }
        }

        finalizeAuthenticatedSession(
          baseSession.copy(
            user = baseSession.user.copy(displayName = cleanName),
          ),
        )
      } else {
        val errRaw = res.errorBody()?.string()
        ApiResult.Error(mapFirebaseAuthError(XkJsonParser.parseErrorMessage(errRaw)))
      }
    } catch (e: Exception) {
      ApiResult.Error(e.localizedMessage ?: "Không thể kết nối máy chủ đăng ký.")
    }
  }

  suspend fun refreshSession(): ApiResult<AuthSession> = withContext(Dispatchers.IO) {
    refreshMutex.withLock {
      val current = localStore.authSessionFlow.first()
        ?: return@withLock ApiResult.Error("Bạn chưa đăng nhập.", isUnauthorized = true)
      if (current.refreshToken.isBlank()) {
        return@withLock ApiResult.Error("Phiên đăng nhập hiện tại không có refresh token.")
      }
      performTokenRefresh(current)
    }
  }

  private suspend fun performTokenRefresh(current: AuthSession): ApiResult<AuthSession> {
    val payload = JSONObject().apply {
      put("refreshToken", current.refreshToken)
      put("refresh_token", current.refreshToken)
    }.toString().toRequestBody(jsonMediaType)

    // 1. Try POST /api/v1/auth/refresh
    val primaryRes = runCatching { api.refreshToken(payload) }.getOrNull()
    if (primaryRes != null) {
      val body = primaryRes.body()?.string()?.trim().orEmpty()
      if (primaryRes.isSuccessful && isJsonBody(body)) {
        val refreshed = XkJsonParser.parseAuthSession(
          rawJson = body,
          fallbackEmail = current.user.email,
          fallbackDisplayName = current.user.displayName,
        )
        if (refreshed != null) {
          val safeExpires = if (refreshed.expiresAtEpochMs > System.currentTimeMillis()) {
            refreshed.expiresAtEpochMs
          } else {
            System.currentTimeMillis() + 3_600_000L
          }
          val merged = refreshed.copy(
            expiresAtEpochMs = safeExpires,
            refreshToken = refreshed.refreshToken.ifBlank { current.refreshToken },
            user = current.user.copy(
              displayName = refreshed.user.displayName.ifBlank { current.user.displayName },
              avatarUrl = refreshed.user.avatarUrl ?: current.user.avatarUrl,
            ),
          )
          ApiClient.setUserToken(merged.idToken)
          localStore.saveAuthSession(merged)
          return ApiResult.Success(merged)
        }
      }
    }

    // 2. Fallback: Firebase securetoken refresh
    return try {
      val res = firebaseToken.refreshIdToken(
        apiKey = ApiClient.WEB_FIREBASE_API_KEY,
        refreshToken = current.refreshToken,
      )
      val body = res.body()?.string().orEmpty()
      if (res.isSuccessful && isJsonBody(body)) {
        val root = JSONObject(body)
        val newIdToken = root.optString("id_token")
        val newRefresh = root.optString("refresh_token").ifBlank { current.refreshToken }
        val expiresIn = root.optString("expires_in").toLongOrNull() ?: 3600L
        if (newIdToken.isNotBlank()) {
          val updated = current.copy(
            idToken = newIdToken,
            refreshToken = newRefresh,
            expiresAtEpochMs = System.currentTimeMillis() + expiresIn * 1000L,
          )
          ApiClient.setUserToken(updated.idToken)
          localStore.saveAuthSession(updated)
          ApiResult.Success(updated)
        } else {
          ApiResult.Error("Không thể làm mới token.")
        }
      } else {
        ApiResult.Error("Phiên đăng nhập đã hết hạn, vui lòng đăng nhập lại.")
      }
    } catch (e: Exception) {
      ApiResult.Error(e.localizedMessage ?: "Lỗi làm mới phiên đăng nhập.")
    }
  }

  suspend fun logout() = withContext(Dispatchers.IO) {
    ApiClient.setUserToken(null)
    localStore.saveAuthSession(null)
  }

  suspend fun fetchMe(): ApiResult<UserProfile> = withContext(Dispatchers.IO) {
    var current = ensureFreshSession()
      ?: return@withContext ApiResult.Error("Chưa đăng nhập tài khoản.", isUnauthorized = true)

    ApiClient.setUserToken(current.idToken)

    // 1. Try GET /api/v1/me (retry once after forced token refresh if 401)
    var primaryRes = runCatching { api.getMe() }.getOrNull()
    if (primaryRes?.code() == 401) {
      current = ensureFreshSession(forceRefresh = true) ?: current
      primaryRes = runCatching { api.getMe() }.getOrNull()
    }

    val apiProfile = if (primaryRes != null && primaryRes.isSuccessful) {
      val body = primaryRes.body()?.string()?.trim().orEmpty()
      if (isJsonBody(body)) {
        XkJsonParser.parseUserProfile(
          rawJson = body,
          fallbackUid = current.user.uid,
          fallbackEmail = current.user.email,
          fallbackDisplayName = current.user.displayName,
        )
      } else null
    } else null

    val uid = (apiProfile?.uid ?: current.user.uid).trim()
    var resolved = apiProfile ?: current.user

    if (uid.isNotBlank()) {
      coroutineScope {
        val rtdbMemberDef = async {
          runCatching { rtdb.getMember(uid, current.idToken) }.getOrNull()
            ?.takeIf { it.isSuccessful }?.body()?.string()?.trim().orEmpty()
        }
        val fsMemberDef = async {
          XkFirestoreHelper.fetchMemberProfile(
            uid = uid,
            idToken = current.idToken,
            fallbackEmail = resolved.email,
            fallbackName = resolved.displayName,
          )
        }
        val adminDef = async {
          runCatching { rtdb.getAdminRecord(uid, current.idToken) }.getOrNull()
            ?.takeIf { it.isSuccessful }?.body()?.string()?.trim().orEmpty()
        }
        val rtdbPurchasesDef = async {
          runCatching { rtdb.getUserPurchases(uid, current.idToken) }.getOrNull()
            ?.takeIf { it.isSuccessful }?.body()?.string()?.trim().orEmpty()
        }
        val fsPurchasesDef = async {
          XkFirestoreHelper.fetchUserPurchases(uid, current.idToken)
        }
        val likesDef = async {
          runCatching { rtdb.getUserLikedSongs(uid, current.idToken) }.getOrNull()
            ?.takeIf { it.isSuccessful }?.body()?.string()?.trim().orEmpty()
        }

        val rtdbMemberBody = rtdbMemberDef.await()
        val rtdbMember = if (rtdbMemberBody.startsWith("{")) {
          XkJsonParser.parseUserProfile(
            rawJson = rtdbMemberBody,
            fallbackUid = uid,
            fallbackEmail = resolved.email,
            fallbackDisplayName = resolved.displayName,
          )
        } else {
          null
        }
        val fsMember = fsMemberDef.await()

        if (apiProfile == null) {
          val baseProfile = rtdbMember ?: fsMember
          if (baseProfile != null) {
            resolved = baseProfile
          } else {
            val lookupBody = JSONObject().apply { put("idToken", current.idToken) }
              .toString().toRequestBody(jsonMediaType)
            val lookupRaw = runCatching { firebaseAuth.lookupAccount(ApiClient.WEB_FIREBASE_API_KEY, lookupBody) }
              .getOrNull()?.takeIf { it.isSuccessful }?.body()?.string()?.trim().orEmpty()
            if (lookupRaw.startsWith("{")) {
              XkJsonParser.parseUserProfile(
                rawJson = lookupRaw,
                fallbackUid = uid,
                fallbackEmail = current.user.email,
                fallbackDisplayName = current.user.displayName,
              )?.let { resolved = it }
            }
          }
        }

        val adminBody = adminDef.await()
        val isAdmin = (adminBody.isNotEmpty() && adminBody != "null") ||
          resolved.role.equals("admin", ignoreCase = true) ||
          rtdbMember?.role.equals("admin", ignoreCase = true) ||
          fsMember?.role.equals("admin", ignoreCase = true)

        val purchaseMapBody = rtdbPurchasesDef.await()
        val userPurchaseIds = if (purchaseMapBody.startsWith("{") || purchaseMapBody.startsWith("[")) {
          XkJsonParser.parsePurchasesList(purchaseMapBody).map { it.songId }
        } else {
          emptyList()
        }
        val fsPurchaseIds = fsPurchasesDef.await()

        val mergedPurchasedIds = (
          resolved.purchasedSongIds +
            rtdbMember?.purchasedSongIds.orEmpty() +
            fsMember?.purchasedSongIds.orEmpty() +
            userPurchaseIds +
            fsPurchaseIds
          ).filter { it.isNotBlank() }.distinct()

        val likesBody = likesDef.await()
        val rtdbLikedSongsNode = buildList {
          if (likesBody.startsWith("{")) {
            runCatching {
              val obj = JSONObject(likesBody)
              val arr = obj.optJSONArray("likedSongIds")
              if (arr != null) {
                for (i in 0 until arr.length()) {
                  arr.optString(i).takeIf { it.isNotBlank() }?.let { add(it) }
                }
              }
            }
          }
        }
        val mergedLikes = (
          resolved.likedSongIds +
            rtdbMember?.likedSongIds.orEmpty() +
            fsMember?.likedSongIds.orEmpty() +
            rtdbLikedSongsNode
          ).filter { it.isNotBlank() }.distinct()

        resolved = resolved.copy(
          role = if (isAdmin) "admin" else resolved.role,
          purchasedSongIds = mergedPurchasedIds,
          likedSongIds = mergedLikes,
        )
      }
    }

    localStore.saveAuthSession(current.copy(user = resolved))
    ApiResult.Success(resolved)
  }

  suspend fun updateMe(displayName: String, avatarUrl: String? = null): ApiResult<UserProfile> = withContext(Dispatchers.IO) {
    val current = ensureFreshSession()
      ?: return@withContext ApiResult.Error("Vui lòng đăng nhập để cập nhật hồ sơ.", isUnauthorized = true)
    val cleanName = displayName.trim()
    if (cleanName.isEmpty()) return@withContext ApiResult.Error("Tên hiển thị không được để trống.")
    ApiClient.setUserToken(current.idToken)

    val payload = JSONObject().apply {
      put("displayName", cleanName)
      put("display_name", cleanName)
      if (!avatarUrl.isNullOrBlank()) put("avatarUrl", avatarUrl.trim())
    }.toString().toRequestBody(jsonMediaType)

    val primaryRes = runCatching { api.updateMe(payload) }.getOrNull()
    if (primaryRes != null && primaryRes.isSuccessful) {
      val body = primaryRes.body()?.string()?.trim().orEmpty()
      val updatedUser = if (isJsonBody(body)) {
        XkJsonParser.parseUserProfile(
          rawJson = body,
          fallbackUid = current.user.uid,
          fallbackEmail = current.user.email,
          fallbackDisplayName = cleanName,
        )?.copy(displayName = cleanName) ?: current.user.copy(displayName = cleanName)
      } else {
        current.user.copy(displayName = cleanName)
      }
      localStore.saveAuthSession(current.copy(user = updatedUser))
      return@withContext ApiResult.Success(updatedUser)
    }

    // Fallback: Firebase Auth updateProfile + RTDB member patch
    val fbUpdate = JSONObject().apply {
      put("idToken", current.idToken)
      put("displayName", cleanName)
      put("returnSecureToken", false)
    }.toString().toRequestBody(jsonMediaType)
    runCatching { firebaseAuth.updateProfile(ApiClient.WEB_FIREBASE_API_KEY, fbUpdate) }
    if (current.user.uid.isNotBlank()) {
      runCatching { rtdb.patchMember(current.user.uid, current.idToken, payload) }
    }
    val updated = current.user.copy(displayName = cleanName)
    localStore.saveAuthSession(current.copy(user = updated))
    ApiResult.Success(updated)
  }

  suspend fun fetchSettings(): UserSettings? = withContext(Dispatchers.IO) {
    val current = ensureFreshSession() ?: return@withContext null
    ApiClient.setUserToken(current.idToken)
    val res = runCatching { api.getMeSettings() }.getOrNull() ?: return@withContext null
    val body = res.body()?.string()?.trim().orEmpty()
    if (res.isSuccessful && isJsonBody(body)) {
      XkJsonParser.parseUserSettings(body)
    } else {
      null
    }
  }

  suspend fun patchSettings(
    themeMode: String? = null,
    colorPreset: String? = null,
    amoledMode: Boolean? = null,
    useDynamicColor: Boolean? = null,
  ) = withContext(Dispatchers.IO) {
    val current = ensureFreshSession() ?: return@withContext
    ApiClient.setUserToken(current.idToken)
    val payload = JSONObject().apply {
      if (!themeMode.isNullOrBlank()) put("themeMode", themeMode)
      if (!colorPreset.isNullOrBlank()) put("colorPreset", colorPreset)
      if (amoledMode != null) put("amoledMode", amoledMode)
      if (useDynamicColor != null) put("useDynamicColor", useDynamicColor)
    }.toString().toRequestBody(jsonMediaType)
    runCatching { api.updateMeSettings(payload) }
  }

  suspend fun syncLike(song: Song, isNowLiked: Boolean, allLikedIds: List<String>) = withContext(Dispatchers.IO) {
    val current = ensureFreshSession() ?: return@withContext
    ApiClient.setUserToken(current.idToken)

    val payload = JSONObject().apply {
      put("type", "song")
      put("songId", song.id)
      put("liked", isNowLiked)
      put("action", if (isNowLiked) "like" else "unlike")
    }.toString().toRequestBody(jsonMediaType)

    val primaryRes = runCatching { api.toggleLike(payload) }.getOrNull()
    if (primaryRes != null && primaryRes.isSuccessful) {
      val body = primaryRes.body()?.string()?.trim().orEmpty()
      if (isJsonBody(body)) return@withContext
    }

    // Fallback: sync likedSongIds to RTDB matching web app
    val uid = current.user.uid
    if (uid.isNotBlank()) {
      val arr = JSONArray(allLikedIds)
      val rtdbBody = JSONObject().apply {
        put("likedSongIds", arr)
        put("updatedAt", System.currentTimeMillis())
      }.toString().toRequestBody(jsonMediaType)
      runCatching { rtdb.putUserLikedSongs(uid, current.idToken, rtdbBody) }

      val memberPatch = JSONObject().apply {
        put("likedSongIds", arr)
      }.toString().toRequestBody(jsonMediaType)
      runCatching { rtdb.patchMember(uid, current.idToken, memberPatch) }
    }
  }

  suspend fun syncAlbumLike(album: Album, isNowLiked: Boolean) = withContext(Dispatchers.IO) {
    val current = ensureFreshSession() ?: return@withContext
    ApiClient.setUserToken(current.idToken)

    val albumPayload = JSONObject().apply {
      put("albumId", album.id)
      put("liked", isNowLiked)
      put("action", if (isNowLiked) "like" else "unlike")
    }.toString().toRequestBody(jsonMediaType)

    val res = runCatching { api.toggleAlbumLike(albumPayload) }.getOrNull()
    if (res != null && res.isSuccessful) return@withContext

    // Fallback via POST /api/v1/me/likes with type="album"
    val likesPayload = JSONObject().apply {
      put("type", "album")
      put("albumId", album.id)
      put("targetId", album.id)
      put("liked", isNowLiked)
      put("action", if (isNowLiked) "like" else "unlike")
    }.toString().toRequestBody(jsonMediaType)
    runCatching { api.toggleLike(likesPayload) }
  }

  suspend fun fetchBlockedSongIds(): List<String> = withContext(Dispatchers.IO) {
    val current = ensureFreshSession() ?: return@withContext emptyList()
    ApiClient.setUserToken(current.idToken)
    val res = runCatching { api.getBlockedSongs() }.getOrNull() ?: return@withContext emptyList()
    val body = res.body()?.string()?.trim().orEmpty()
    if (res.isSuccessful && isJsonBody(body)) {
      XkJsonParser.parseBlockedSongIds(body)
    } else {
      emptyList()
    }
  }

  suspend fun blockSong(songId: String): Boolean = withContext(Dispatchers.IO) {
    localStore.addBlockedSongId(songId)
    val current = ensureFreshSession() ?: return@withContext true
    ApiClient.setUserToken(current.idToken)
    val payload = JSONObject().apply {
      put("songId", songId)
    }.toString().toRequestBody(jsonMediaType)
    val res = runCatching { api.blockSong(payload) }.getOrNull()
    res?.isSuccessful ?: true
  }

  suspend fun unblockSong(songId: String): Boolean = withContext(Dispatchers.IO) {
    localStore.removeBlockedSongId(songId)
    val current = ensureFreshSession() ?: return@withContext true
    ApiClient.setUserToken(current.idToken)
    val res = runCatching { api.unblockSong(songId) }.getOrNull()
    res?.isSuccessful ?: true
  }

  suspend fun fetchAvailableVouchers(): List<VoucherInfo> = withContext(Dispatchers.IO) {
    val primaryRes = runCatching { api.getVouchers() }.getOrNull()
    if (primaryRes != null && primaryRes.isSuccessful) {
      val body = primaryRes.body()?.string()?.trim().orEmpty()
      if (isJsonBody(body)) {
        val list = XkJsonParser.parseVouchersList(body)
        if (list.isNotEmpty()) return@withContext list
      }
    }
    val rtdbRes = runCatching { rtdb.getVouchers() }.getOrNull()
    val raw = rtdbRes?.body()?.string()?.trim().orEmpty()
    if (rtdbRes != null && rtdbRes.isSuccessful && isJsonBody(raw)) {
      XkJsonParser.parseVouchersList(raw)
    } else {
      emptyList()
    }
  }

  suspend fun fetchPurchases(songsLookup: Map<String, Song>): ApiResult<List<PurchaseRecord>> = withContext(Dispatchers.IO) {
    var current = ensureFreshSession()
      ?: return@withContext ApiResult.Error("Cần đăng nhập để xem lịch sử mua nhạc.", isUnauthorized = true)
    ApiClient.setUserToken(current.idToken)

    var primaryRes = runCatching { api.getPurchases() }.getOrNull()
    if (primaryRes?.code() == 401) {
      current = ensureFreshSession(forceRefresh = true) ?: current
      primaryRes = runCatching { api.getPurchases() }.getOrNull()
    }
    val apiRecords = if (primaryRes != null && primaryRes.isSuccessful) {
      val body = primaryRes.body()?.string()?.trim().orEmpty()
      if (isJsonBody(body)) XkJsonParser.parsePurchasesList(body, songsLookup) else emptyList()
    } else {
      emptyList()
    }

    val uid = current.user.uid
    if (uid.isBlank()) return@withContext ApiResult.Success(apiRecords)

    return@withContext try {
      val res = runCatching { rtdb.getUserPurchases(uid, current.idToken) }.getOrNull()
      val raw = res?.body()?.string()?.trim().orEmpty()
      val rtdbRecords = if (res != null && res.isSuccessful && (raw.startsWith("{") || raw.startsWith("["))) {
        XkJsonParser.parsePurchasesList(raw, songsLookup)
      } else {
        emptyList()
      }

      val fsPurchaseIds = XkFirestoreHelper.fetchUserPurchases(uid, current.idToken)
      val mergedBySongId = linkedMapOf<String, PurchaseRecord>()
      apiRecords.forEach { record ->
        if (record.songId.isNotBlank() && (songsLookup.isEmpty() || record.songId in songsLookup)) {
          mergedBySongId[record.songId] = record
        }
      }
      rtdbRecords.forEach { record ->
        if (
          record.songId.isNotBlank() &&
          record.songId !in mergedBySongId &&
          (songsLookup.isEmpty() || record.songId in songsLookup)
        ) {
          mergedBySongId[record.songId] = record
        }
      }

      val combinedMemberPurchasedIds = (current.user.purchasedSongIds + fsPurchaseIds).distinct()
      combinedMemberPurchasedIds
        .filter { it.isNotBlank() && it !in mergedBySongId }
        .forEach { sid ->
          val s = songsLookup[sid] ?: return@forEach
          mergedBySongId[sid] = PurchaseRecord(
            id = "member_$sid",
            songId = sid,
            songTitle = s.title,
            artistName = s.artistName,
            coverUrl = s.coverUrl,
            price = s.priceText?.filter { it.isDigit() }?.toLongOrNull() ?: 0L,
          )
        }

      ApiResult.Success(mergedBySongId.values.toList())
    } catch (e: Exception) {
      if (apiRecords.isNotEmpty()) {
        val validApi = if (songsLookup.isNotEmpty()) {
          apiRecords.filter { it.songId in songsLookup }
        } else {
          apiRecords
        }
        ApiResult.Success(validApi)
      } else {
        ApiResult.Error(e.localizedMessage ?: "Không thể tải danh sách bài hát đã mua.")
      }
    }
  }

  suspend fun validateVoucher(
    code: String,
    songId: String,
    originalPrice: Long,
  ): ApiResult<VoucherValidation> = withContext(Dispatchers.IO) {
    val cleanCode = code.trim()
    if (cleanCode.isEmpty()) {
      return@withContext ApiResult.Error("Vui lòng nhập mã voucher.")
    }

    val primaryRes = runCatching { api.validateVoucher(cleanCode, songId) }.getOrNull()
    if (primaryRes != null) {
      val body = primaryRes.body()?.string()?.trim().orEmpty()
      val errBody = primaryRes.errorBody()?.string()?.trim().orEmpty()
      if (primaryRes.isSuccessful && isJsonBody(body)) {
        val parsed = XkJsonParser.parseVoucherValidation(body, cleanCode, originalPrice)
        if (parsed != null) return@withContext ApiResult.Success(parsed)
      } else if (primaryRes.code() != 404 && isJsonBody(errBody)) {
        return@withContext ApiResult.Error(
          XkJsonParser.parseErrorMessage(errBody) ?: "Mã voucher không hợp lệ.",
        )
      }
    }

    // Fallback: check RTDB /vouchers.json
    return@withContext try {
      val res = rtdb.getVouchers()
      val raw = res.body()?.string().orEmpty()
      if (res.isSuccessful && raw.isNotBlank()) {
        val validation = XkJsonParser.validateVoucherFromRtdb(raw, cleanCode, originalPrice)
        ApiResult.Success(validation)
      } else {
        ApiResult.Error("Không thể kiểm tra mã voucher.")
      }
    } catch (e: Exception) {
      ApiResult.Error(e.localizedMessage ?: "Lỗi kiểm tra voucher.")
    }
  }

  suspend fun purchaseSong(
    song: Song,
    voucherCode: String?,
    expectedPrice: Long,
  ): ApiResult<PurchaseRecord> = withContext(Dispatchers.IO) {
    val current = ensureFreshSession()
      ?: return@withContext ApiResult.Error("Vui lòng đăng nhập trong mục Cá nhân để mua bài hát.", isUnauthorized = true)
    ApiClient.setUserToken(current.idToken)

    val cleanVoucher = voucherCode?.trim()?.takeIf { it.isNotEmpty() }
    val bodyJson = JSONObject().apply {
      put("songId", song.id)
      if (cleanVoucher != null) put("voucherCode", cleanVoucher)
      put("price", expectedPrice)
    }.toString().toRequestBody(jsonMediaType)

    // 1. Try POST /api/v1/songs/:id/purchase
    val primaryRes = runCatching { api.purchaseSong(song.id, bodyJson) }.getOrNull()
    if (primaryRes != null) {
      val body = primaryRes.body()?.string()?.trim().orEmpty()
      val errBody = primaryRes.errorBody()?.string()?.trim().orEmpty()
      if (primaryRes.isSuccessful && isJsonBody(body)) {
        val record = XkJsonParser.parsePurchasesList("[$body]", mapOf(song.id to song)).firstOrNull()
          ?: PurchaseRecord(
            id = "pur_${System.currentTimeMillis()}",
            songId = song.id,
            songTitle = song.title,
            artistName = song.artistName,
            coverUrl = song.coverUrl,
            price = expectedPrice,
            voucherCode = cleanVoucher,
            purchasedAt = Instant.now().toString(),
          )
        fetchMe()
        return@withContext ApiResult.Success(record)
      } else if (primaryRes.code() != 404 && isJsonBody(errBody)) {
        return@withContext ApiResult.Error(
          XkJsonParser.parseErrorMessage(errBody) ?: "Mua bài hát thất bại (${primaryRes.code()}).",
        )
      }
    }

    // 2. Also try POST /api/v1/purchases if route exists
    val altRes = runCatching { api.createPurchase(bodyJson) }.getOrNull()
    if (altRes != null && altRes.isSuccessful) {
      val altBody = altRes.body()?.string()?.trim().orEmpty()
      if (isJsonBody(altBody)) {
        val record = PurchaseRecord(
          id = "pur_${System.currentTimeMillis()}",
          songId = song.id,
          songTitle = song.title,
          artistName = song.artistName,
          coverUrl = song.coverUrl,
          price = expectedPrice,
          voucherCode = cleanVoucher,
          purchasedAt = Instant.now().toString(),
        )
        fetchMe()
        return@withContext ApiResult.Success(record)
      }
    }

    // 3. Fallback: RTDB user_purchases/{uid}/{songId} & purchases/{id}
    val uid = current.user.uid
    if (uid.isBlank()) {
      return@withContext ApiResult.Error("Không xác định được UID người dùng.")
    }
    if (expectedPrice > current.user.balance && expectedPrice > 0L) {
      return@withContext ApiResult.Error(
        "Số dư tài khoản (${current.user.balance}đ) không đủ để mua bài hát (${expectedPrice}đ). Vui lòng nạp thêm trên web xkmu.xuanken.name.vn.",
      )
    }

    val purchaseId = "pur_${System.currentTimeMillis()}_${song.id.take(8)}"
    val timestamp = Instant.now().toString()
    val entitlementJson = JSONObject().apply {
      put("songId", song.id)
      put("purchaseId", purchaseId)
      put("price", expectedPrice)
      put("purchasedAt", timestamp)
    }.toString().toRequestBody(jsonMediaType)

    val purchaseDocJson = JSONObject().apply {
      put("id", purchaseId)
      put("userId", uid)
      put("songId", song.id)
      put("songTitle", song.title)
      put("price", expectedPrice)
      if (cleanVoucher != null) put("voucherCode", cleanVoucher)
      put("timestamp", timestamp)
    }.toString().toRequestBody(jsonMediaType)

    return@withContext try {
      val entRes = rtdb.putUserPurchase(uid, song.id, current.idToken, entitlementJson)
      if (!entRes.isSuccessful) {
        return@withContext ApiResult.Error("Máy chủ từ chối giao dịch (${entRes.code()}). Vui lòng thực hiện trên web hoặc thử lại.")
      }
      runCatching { rtdb.putPurchase(purchaseId, current.idToken, purchaseDocJson) }

      val nextBalance = (current.user.balance - expectedPrice).coerceAtLeast(0L)
      val nextPurchased = (current.user.purchasedSongIds + song.id).distinct()
      val memberPatch = JSONObject().apply {
        put("balance", nextBalance)
        put("purchasedSongIds", JSONArray(nextPurchased))
      }.toString().toRequestBody(jsonMediaType)
      runCatching { rtdb.patchMember(uid, current.idToken, memberPatch) }

      localStore.saveAuthSession(
        current.copy(
          user = current.user.copy(
            balance = nextBalance,
            purchasedSongIds = nextPurchased,
          ),
        ),
      )

      ApiResult.Success(
        PurchaseRecord(
          id = purchaseId,
          songId = song.id,
          songTitle = song.title,
          artistName = song.artistName,
          coverUrl = song.coverUrl,
          price = expectedPrice,
          voucherCode = cleanVoucher,
          purchasedAt = timestamp,
        ),
      )
    } catch (e: Exception) {
      ApiResult.Error(e.localizedMessage ?: "Lỗi thực hiện giao dịch mua bài hát.")
    }
  }

  private suspend fun finalizeAuthenticatedSession(session: AuthSession): ApiResult<AuthSession> {
    ApiClient.setUserToken(session.idToken)
    localStore.saveAuthSession(session)
    val profileRes = fetchMe()
    val finalUser = (profileRes as? ApiResult.Success)?.data ?: session.user
    val finalSession = session.copy(user = finalUser)
    localStore.saveAuthSession(finalSession)
    return ApiResult.Success(finalSession)
  }

  private fun isJsonBody(body: String): Boolean = body.startsWith("{") || body.startsWith("[")

  private fun mapFirebaseAuthError(raw: String?): String {
    val upper = raw.orEmpty().uppercase()
    return when {
      "INVALID_LOGIN_CREDENTIALS" in upper || "INVALID_PASSWORD" in upper || "EMAIL_NOT_FOUND" in upper ->
        "Email hoặc mật khẩu không chính xác."
      "EMAIL_EXISTS" in upper ->
        "Email này đã được đăng ký tài khoản trên XK Music."
      "WEAK_PASSWORD" in upper ->
        "Mật khẩu quá yếu (cần ít nhất 6 ký tự)."
      "INVALID_EMAIL" in upper ->
        "Địa chỉ email không hợp lệ."
      "TOO_MANY_ATTEMPTS" in upper ->
        "Thử lại quá nhiều lần. Vui lòng đợi ít phút."
      "USER_DISABLED" in upper ->
        "Tài khoản này đã bị vô hiệu hóa."
      !raw.isNullOrBlank() -> raw
      else -> "Không thể xác thực tài khoản."
    }
  }
}
