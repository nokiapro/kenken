package com.example.ui

import java.util.Locale

object FormatUtils {

  fun formatDurationMs(ms: Long): String {
    if (ms <= 0L) return "0:00"
    val totalSeconds = (ms / 1000L).toInt()
    return formatDurationSeconds(totalSeconds)
  }

  fun formatDurationSeconds(seconds: Int): String {
    if (seconds <= 0) return "--:--"
    val mins = seconds / 60
    val secs = seconds % 60
    return String.format(Locale.US, "%d:%02d", mins, secs)
  }

  fun formatCompactCount(count: Long): String {
    return when {
      count >= 1_000_000L -> String.format(Locale.US, "%.1fM", count / 1_000_000.0)
      count >= 1_000L -> String.format(Locale.US, "%.1fK", count / 1_000.0)
      else -> count.toString()
    }
  }

  fun formatListeningDuration(durationMs: Long): String {
    val totalSeconds = (durationMs / 1000L).coerceAtLeast(0L)
    if (totalSeconds <= 0L) return "0 phút"
    val hours = totalSeconds / 3600L
    val minutes = (totalSeconds % 3600L) / 60L
    val seconds = totalSeconds % 60L
    return when {
      hours > 0L && minutes > 0L -> "$hours giờ $minutes phút"
      hours > 0L -> "$hours giờ"
      minutes > 0L && seconds > 0L -> "$minutes phút $seconds giây"
      minutes > 0L -> "$minutes phút"
      else -> "$seconds giây"
    }
  }
}
