package com.example.data.network

import com.example.model.Album
import com.example.model.Artist
import com.example.model.AuthSession
import com.example.model.ChartSection
import com.example.model.HomeFeedBundle
import com.example.model.Playlist
import com.example.model.PurchaseRecord
import com.example.model.SearchBundle
import com.example.model.SiteInfo
import com.example.model.Song
import com.example.model.UserProfile
import com.example.model.UserSettings
import com.example.model.VoucherInfo
import com.example.model.VoucherValidation
import org.json.JSONArray
import org.json.JSONObject
import org.json.JSONTokener
import java.text.NumberFormat
import java.util.Locale

data class ParsedStreamInfo(
  val url: String?,
  val isDemo: Boolean = false,
)

object XkJsonParser {

  private const val BASE_HOST = "https://xkmu.xuanken.name.vn"
  private val DEMO_URL_REGEX = Regex("""(^|[/?&_=-])(demo|preview|sample)($|[/?&_=.])""", RegexOption.IGNORE_CASE)

  fun looksLikeDemoUrl(url: String?): Boolean {
    if (url.isNullOrBlank()) return false
    return DEMO_URL_REGEX.containsMatchIn(url)
  }

  fun parseSongsList(rawJson: String): List<Song> {
    val root = parseTokener(rawJson) ?: return emptyList()
    val array = extractArray(root, listOf("songs", "tracks", "data", "items", "results"))
    if (array != null) return mapSongsArray(array)
    if (root is JSONObject) return mapObjectValues(root) { key, obj -> mapSong(obj, fallbackId = key) }
    return emptyList()
  }

  fun parseSongDetail(rawJson: String): Song? {
    val root = parseTokener(rawJson) ?: return null
    val obj = extractObject(root, listOf("song", "track", "data", "item", "result")) ?: return null
    return mapSong(obj)
  }

  fun parseAlbumsList(rawJson: String): List<Album> {
    val root = parseTokener(rawJson) ?: return emptyList()
    val array = extractArray(root, listOf("albums", "data", "items", "results"))
    if (array != null) {
      return buildList {
        for (i in 0 until array.length()) {
          val obj = array.optJSONObject(i) ?: continue
          add(mapAlbum(obj))
        }
      }
    }
    if (root is JSONObject) return mapObjectValues(root) { key, obj -> mapAlbum(obj, fallbackId = key) }
    return emptyList()
  }

  fun parseAlbumDetail(rawJson: String): Album? {
    val root = parseTokener(rawJson) ?: return null
    val obj = extractObject(root, listOf("album", "data", "item", "result")) ?: return null
    val baseAlbum = mapAlbum(obj)
    val embeddedSongs = if (baseAlbum.songs.isNotEmpty()) {
      baseAlbum.songs
    } else if (root is JSONObject) {
      val rootSongs = root.optJSONArray("songs") ?: root.optJSONArray("tracks")
      if (rootSongs != null) mapSongsArray(rootSongs) else emptyList()
    } else {
      emptyList()
    }
    return baseAlbum.copy(
      songs = embeddedSongs,
      trackCount = maxOf(baseAlbum.trackCount, embeddedSongs.size),
    )
  }

  fun parseArtistsList(rawJson: String): List<Artist> {
    val root = parseTokener(rawJson) ?: return emptyList()
    val array = extractArray(root, listOf("artists", "data", "items", "results"))
    if (array != null) {
      return buildList {
        for (i in 0 until array.length()) {
          val obj = array.optJSONObject(i) ?: continue
          add(mapArtist(obj))
        }
      }
    }
    if (root is JSONObject) return mapObjectValues(root) { key, obj -> mapArtist(obj, fallbackId = key) }
    return emptyList()
  }

  fun parseArtistDetail(rawJson: String): Artist? {
    val root = parseTokener(rawJson) ?: return null
    val obj = extractObject(root, listOf("artist", "data", "item", "result")) ?: return null
    val baseArtist = mapArtist(obj)
    val rootObj = root as? JSONObject
    val songs = if (baseArtist.songs.isNotEmpty()) {
      baseArtist.songs
    } else {
      val arr = rootObj?.optJSONArray("songs") ?: rootObj?.optJSONArray("top_songs")
      if (arr != null) mapSongsArray(arr) else emptyList()
    }
    val albums = if (baseArtist.albums.isNotEmpty()) {
      baseArtist.albums
    } else {
      val arr = rootObj?.optJSONArray("albums")
      if (arr != null) {
        buildList {
          for (i in 0 until arr.length()) {
            arr.optJSONObject(i)?.let { add(mapAlbum(it)) }
          }
        }
      } else {
        emptyList()
      }
    }
    return baseArtist.copy(
      songs = songs,
      albums = albums,
      songCount = maxOf(baseArtist.songCount, songs.size),
    )
  }

  fun parsePlaylistsList(rawJson: String, songsLookup: Map<String, Song> = emptyMap()): List<Playlist> {
    val root = parseTokener(rawJson) ?: return emptyList()
    val array = extractArray(root, listOf("playlists", "data", "items", "results"))
    if (array != null) {
      return buildList {
        for (i in 0 until array.length()) {
          val obj = array.optJSONObject(i) ?: continue
          add(mapPlaylist(obj, songsLookup = songsLookup))
        }
      }
    }
    if (root is JSONObject) {
      return mapObjectValues(root) { key, obj -> mapPlaylist(obj, fallbackId = key, songsLookup = songsLookup) }
    }
    return emptyList()
  }

  fun parsePlaylistDetail(rawJson: String, songsLookup: Map<String, Song> = emptyMap()): Playlist? {
    val root = parseTokener(rawJson) ?: return null
    val obj = extractObject(root, listOf("playlist", "data", "item", "result")) ?: return null
    val base = mapPlaylist(obj, songsLookup = songsLookup)
    val songs = if (base.songs.isNotEmpty()) {
      base.songs
    } else if (root is JSONObject) {
      val arr = root.optJSONArray("songs") ?: root.optJSONArray("tracks")
      if (arr != null) mapSongsArray(arr) else emptyList()
    } else {
      emptyList()
    }
    return base.copy(
      songs = songs,
      songCount = maxOf(base.songCount, songs.size),
    )
  }

  fun parseWeeklyCharts(rawJson: String, allSongs: List<Song>): List<ChartSection> {
    val songMap = allSongs.associateBy { it.id }
    val root = parseTokener(rawJson) as? JSONObject
    val sections = mutableListOf<ChartSection>()

    if (root != null) {
      val weekKeys = root.keys().asSequence().toList().sortedDescending()
      val latestWeek = weekKeys.firstOrNull()
      if (latestWeek != null) {
        val countsObj = root.optJSONObject(latestWeek)
        if (countsObj != null) {
          val ranked = countsObj.keys().asSequence()
            .mapNotNull { songId ->
              val song = songMap[songId] ?: return@mapNotNull null
              val weeklyPlays = countsObj.optLong(songId, 0L)
              song to weeklyPlays
            }
            .sortedByDescending { it.second }
            .mapIndexed { idx, (song, weeklyPlays) ->
              song.copy(
                rank = idx + 1,
                playCount = maxOf(song.playCount, weeklyPlays),
              )
            }
            .toList()
          if (ranked.isNotEmpty()) {
            sections.add(
              ChartSection(
                title = "BXH Tuần $latestWeek",
                updatedAt = latestWeek,
                songs = ranked,
              ),
            )
          }
        }
      }
    }

    val allTimeTop = allSongs
      .sortedByDescending { it.playCount }
      .take(30)
      .mapIndexed { idx, s -> s.copy(rank = idx + 1) }

    if (allTimeTop.isNotEmpty()) {
      sections.add(
        ChartSection(
          title = "Thịnh hành mọi thời đại",
          songs = allTimeTop,
        ),
      )
    }
    return sections
  }

  fun parseCharts(rawJson: String): List<ChartSection> {
    val root = parseTokener(rawJson) ?: return emptyList()
    if (root is JSONArray) {
      val songs = mapSongsArray(root).mapIndexed { index, s ->
        s.copy(rank = s.rank ?: (index + 1))
      }
      return if (songs.isEmpty()) emptyList() else listOf(ChartSection("Bảng xếp hạng Thịnh hành", songs = songs))
    }
    if (root !is JSONObject) return emptyList()

    val container = root.optJSONObject("data") ?: root

    val directArray = container.optJSONArray("charts")
      ?: container.optJSONArray("songs")
      ?: container.optJSONArray("tracks")
      ?: container.optJSONArray("top")
      ?: container.optJSONArray("trending")
      ?: container.optJSONArray("items")
      ?: root.optJSONArray("data")

    if (directArray != null && directArray.length() > 0) {
      val firstObj = directArray.optJSONObject(0)
      val looksLikeSection = firstObj != null && (firstObj.has("songs") || firstObj.has("tracks"))
      if (looksLikeSection) {
        return buildList {
          for (i in 0 until directArray.length()) {
            val sec = directArray.optJSONObject(i) ?: continue
            val secSongs = mapSongsArray(sec.optJSONArray("songs") ?: sec.optJSONArray("tracks") ?: JSONArray())
              .mapIndexed { idx, s -> s.copy(rank = s.rank ?: (idx + 1)) }
            if (secSongs.isNotEmpty()) {
              add(
                ChartSection(
                  title = sec.firstString("title", "name", "label") ?: "Bảng xếp hạng #${i + 1}",
                  updatedAt = sec.firstString("updated_at", "updatedAt"),
                  songs = secSongs,
                ),
              )
            }
          }
        }
      } else {
        val songs = mapSongsArray(directArray).mapIndexed { idx, s ->
          s.copy(rank = s.rank ?: (idx + 1))
        }
        if (songs.isNotEmpty()) {
          return listOf(
            ChartSection(
              title = container.firstString("title", "name") ?: "Top Thịnh Hành",
              updatedAt = container.firstString("updated_at", "updatedAt"),
              songs = songs,
            ),
          )
        }
      }
    }

    val sections = mutableListOf<ChartSection>()
    val keys = container.keys()
    while (keys.hasNext()) {
      val key = keys.next()
      val arr = container.optJSONArray(key)
      if (arr != null && arr.length() > 0) {
        val songs = mapSongsArray(arr).mapIndexed { idx, s ->
          s.copy(rank = s.rank ?: (idx + 1))
        }
        if (songs.isNotEmpty()) {
          sections.add(ChartSection(title = prettifyChartKey(key), songs = songs))
        }
      }
    }
    return sections
  }

  fun parseSiteInfo(rawJson: String): SiteInfo {
    val root = parseTokener(rawJson) as? JSONObject ?: return SiteInfo()
    val obj = root.optJSONObject("site") ?: root.optJSONObject("data") ?: root
    val genresArr = obj.optJSONArray("genres") ?: root.optJSONArray("genres") ?: obj.optJSONArray("categories")
    val genres = buildList {
      if (genresArr != null) {
        for (i in 0 until genresArr.length()) {
          val item = genresArr.opt(i)
          when (item) {
            is String -> if (item.isNotBlank()) add(item)
            is JSONObject -> item.firstString("name", "title", "label")?.let { add(it) }
          }
        }
      }
    }
    val featuredArr = obj.optJSONArray("featured_songs")
      ?: obj.optJSONArray("featured")
      ?: root.optJSONArray("featured_songs")
    val featuredSongs = if (featuredArr != null) mapSongsArray(featuredArr) else emptyList()

    return SiteInfo(
      siteName = obj.firstString("site_name", "siteName", "name", "title") ?: "XuanKen Music",
      tagline = obj.firstString("tagline", "slogan", "subtitle") ?: "Nền tảng nghe nhạc trực tuyến chất lượng cao",
      description = obj.firstString("description", "about"),
      logoUrl = normalizeUrl(obj.firstString("logo_url", "logoUrl", "logo", "icon")),
      bannerUrl = normalizeUrl(obj.firstString("banner_url", "bannerUrl", "banner", "hero_image", "cover", "coverImage")),
      genres = genres,
      featuredSongs = featuredSongs,
    )
  }

  fun parseArtistBios(rawJson: String): Map<String, Pair<String?, String?>> {
    val root = parseTokener(rawJson) as? JSONObject ?: return emptyMap()
    val result = mutableMapOf<String, Pair<String?, String?>>()
    val keys = root.keys()
    while (keys.hasNext()) {
      val k = keys.next()
      val v = root.opt(k)
      when (v) {
        is String -> result[k] = v to null
        is JSONObject -> {
          val bio = v.firstString("bio", "description", "about")
          val avatar = normalizeUrl(v.firstString("avatarUrl", "avatar_url", "avatar", "coverImage", "image"))
          result[v.firstString("name") ?: k] = bio to avatar
        }
      }
    }
    return result
  }

  fun parseErrorMessage(rawJson: String?): String? {
    if (rawJson.isNullOrBlank()) return null
    val root = parseTokener(rawJson) as? JSONObject ?: return null
    val errObj = root.optJSONObject("error")
    return errObj?.firstString("message", "error", "detail")
      ?: root.firstString("message", "error", "detail", "msg")
  }

  fun parseAuthSession(rawJson: String, fallbackEmail: String = "", fallbackDisplayName: String = ""): AuthSession? {
    val root = parseTokener(rawJson) as? JSONObject ?: return null
    val container = root.optJSONObject("data") ?: root
    val idToken = container.firstString("idToken", "id_token", "accessToken", "access_token", "token")
      ?: return null
    val refreshToken = container.firstString("refreshToken", "refresh_token").orEmpty()
    val expiresInSec = container.firstLong("expiresIn", "expires_in")
    val expiresAtEpochMs = if (expiresInSec > 0L) {
      System.currentTimeMillis() + expiresInSec * 1000L
    } else {
      container.firstLong("expiresAt", "expires_at")
    }

    val userObj = container.optJSONObject("user") ?: container
    val uid = userObj.firstString("uid", "localId", "user_id", "id")
      ?: container.firstString("localId", "user_id", "uid")
      ?: ""
    val email = userObj.firstString("email") ?: fallbackEmail
    val displayName = userObj.firstString("displayName", "display_name", "name", "username")
      ?: fallbackDisplayName.ifBlank { email.substringBefore("@").ifBlank { "Thành viên XK" } }
    val avatar = normalizeUrl(userObj.firstString("avatarUrl", "avatar_url", "photoUrl", "avatar"))
    val balance = userObj.firstLong("balance", "wallet_balance", "coins")
    val role = userObj.firstString("role", "tier")

    return AuthSession(
      idToken = idToken,
      refreshToken = refreshToken,
      expiresAtEpochMs = expiresAtEpochMs,
      user = UserProfile(
        uid = uid,
        email = email,
        displayName = displayName,
        avatarUrl = avatar,
        balance = balance,
        role = role,
      ),
    )
  }

  fun parseUserProfile(
    rawJson: String,
    fallbackUid: String = "",
    fallbackEmail: String = "",
    fallbackDisplayName: String = "",
  ): UserProfile? {
    val root = parseTokener(rawJson) as? JSONObject ?: return null
    val obj = root.optJSONObject("user")
      ?: root.optJSONObject("profile")
      ?: root.optJSONObject("data")
      ?: root.optJSONArray("users")?.optJSONObject(0)
      ?: root

    val uid = obj.firstString("uid", "localId", "userId", "id") ?: fallbackUid
    val email = obj.firstString("email") ?: fallbackEmail
    val displayName = obj.firstString("displayName", "display_name", "name", "username")
      ?: fallbackDisplayName.ifBlank { email.substringBefore("@").ifBlank { "Thành viên XK" } }

    val purchasedIds = extractIdList(
      obj,
      "purchasedSongIds",
      "purchased_song_ids",
      "unlockedSongIds",
      "unlocked_song_ids",
      "ownedSongIds",
      "owned_song_ids",
      "boughtSongIds",
      "purchasedSongs",
      "purchases",
    )
    val likedIds = extractIdList(
      obj,
      "likedSongIds",
      "liked_song_ids",
      "likedSongs",
      "likes",
    )

    return UserProfile(
      uid = uid,
      email = email,
      displayName = displayName,
      avatarUrl = normalizeUrl(obj.firstString("avatarUrl", "avatar_url", "photoUrl", "avatar")),
      balance = obj.firstLong("balance", "wallet_balance", "coins"),
      role = obj.firstString("role", "tier"),
      purchasedSongIds = purchasedIds,
      likedSongIds = likedIds,
    )
  }

  fun parseStreamInfo(rawJson: String): ParsedStreamInfo? {
    val root = parseTokener(rawJson) as? JSONObject ?: return null
    val container = root.optJSONObject("data") ?: root.optJSONObject("result") ?: root

    val masterKeys = arrayOf(
      "masterUrl", "master_url", "fullUrl", "full_url",
      "signedUrl", "signed_url", "mp3Url", "mp3_url",
      "wavUrl", "wav_url", "flacUrl", "flac_url",
    )
    val streamKeys = arrayOf(
      "streamUrl", "stream_url", "audioUrl", "audio_url",
      "fileUrl", "file_url", "url", "src",
    )
    val demoKeys = arrayOf("demoUrl", "demo_url", "previewUrl", "preview_url")

    val masterUrl = normalizeUrl(container.firstString(*masterKeys) ?: root.firstString(*masterKeys))
    val streamUrl = normalizeUrl(container.firstString(*streamKeys) ?: root.firstString(*streamKeys))
    val demoUrl = normalizeUrl(container.firstString(*demoKeys) ?: root.firstString(*demoKeys))

    val accessMode = (container.firstString("access", "type", "mode", "tier")
      ?: root.firstString("access", "type", "mode", "tier"))
      .orEmpty()
      .lowercase()
    val explicitDemo = hasTrueFlag(container, root, "isDemo", "is_demo", "isPreview", "is_preview", "demo") ||
      hasFalseFlag(container, root, "isFull", "is_full", "full", "unlocked", "purchased") ||
      accessMode == "demo" || accessMode == "preview"

    if (masterUrl != null && !looksLikeDemoUrl(masterUrl)) {
      return ParsedStreamInfo(url = masterUrl, isDemo = false)
    }
    if (streamUrl != null) {
      val isStreamDemo = explicitDemo || (demoUrl != null && streamUrl == demoUrl) || looksLikeDemoUrl(streamUrl)
      return ParsedStreamInfo(url = streamUrl, isDemo = isStreamDemo)
    }
    if (masterUrl != null) {
      return ParsedStreamInfo(url = masterUrl, isDemo = explicitDemo || looksLikeDemoUrl(masterUrl))
    }
    if (demoUrl != null) {
      return ParsedStreamInfo(url = demoUrl, isDemo = true)
    }
    return null
  }

  fun parseStreamUrl(rawJson: String): String? = parseStreamInfo(rawJson)?.url

  fun parseDownloadUrl(rawJson: String): String? {
    val root = parseTokener(rawJson) as? JSONObject ?: return null
    val container = root.optJSONObject("data") ?: root.optJSONObject("result") ?: root
    return normalizeUrl(
      container.firstString(
        "downloadUrl", "download_url", "masterUrl", "master_url",
        "fullUrl", "full_url", "signedUrl", "signed_url",
        "fileUrl", "file_url", "mp3Url", "mp3_url",
        "wavUrl", "wav_url", "flacUrl", "flac_url",
        "streamUrl", "stream_url", "url",
      ) ?: root.firstString(
        "downloadUrl", "download_url", "masterUrl", "master_url",
        "fullUrl", "full_url", "url", "mp3Url", "wavUrl",
      ),
    )
  }

  fun parseHomeBundle(rawJson: String): HomeFeedBundle? {
    val root = parseTokener(rawJson) as? JSONObject ?: return null
    val container = root.optJSONObject("data") ?: root
    val siteObj = container.optJSONObject("site") ?: container.optJSONObject("siteInfo") ?: container
    val siteInfo = parseSiteInfo(siteObj.toString())

    val songsArr = container.optJSONArray("popularSongs")
      ?: container.optJSONArray("popular_songs")
      ?: container.optJSONArray("songs")
      ?: container.optJSONArray("tracks")
      ?: container.optJSONArray("trending")
    val popularSongs = if (songsArr != null) mapSongsArray(songsArr) else emptyList()

    val featuredArr = container.optJSONArray("featuredSongs")
      ?: container.optJSONArray("featured_songs")
      ?: container.optJSONArray("featured")
    val featuredSongs = if (featuredArr != null) mapSongsArray(featuredArr) else siteInfo.featuredSongs

    val albumsArr = container.optJSONArray("albums") ?: container.optJSONArray("exclusiveAlbums")
    val albums = if (albumsArr != null) parseAlbumsList(albumsArr.toString()) else emptyList()

    val artistsArr = container.optJSONArray("artists")
    val artists = if (artistsArr != null) parseArtistsList(artistsArr.toString()) else emptyList()

    val songsLookup = popularSongs.associateBy { it.id }
    val playlistsArr = container.optJSONArray("playlists")
    val playlists = if (playlistsArr != null) parsePlaylistsList(playlistsArr.toString(), songsLookup) else emptyList()

    val chartsToken = container.opt("charts") ?: container.opt("chartSections") ?: container.opt("chart_sections")
    val chartSections = when (chartsToken) {
      is JSONArray, is JSONObject -> parseCharts(chartsToken.toString())
      else -> emptyList()
    }

    val latestArr = container.optJSONArray("latestSongs")
      ?: container.optJSONArray("latest_songs")
      ?: container.optJSONArray("newSongs")
      ?: container.optJSONArray("new_songs")
      ?: container.optJSONArray("recentSongs")
    val latestSongs = if (latestArr != null) mapSongsArray(latestArr) else emptyList()

    if (popularSongs.isEmpty() && latestSongs.isEmpty() && albums.isEmpty() && playlists.isEmpty() && chartSections.isEmpty()) {
      return null
    }
    return HomeFeedBundle(
      siteInfo = siteInfo.copy(featuredSongs = featuredSongs),
      chartSections = chartSections,
      playlists = playlists,
      albums = albums,
      artists = artists,
      popularSongs = popularSongs,
      latestSongs = latestSongs,
    )
  }

  fun parseSearchBundle(rawJson: String): SearchBundle? {
    val root = parseTokener(rawJson) ?: return null
    if (root is JSONArray) {
      return SearchBundle(songs = mapSongsArray(root))
    }
    if (root !is JSONObject) return null
    val container = root.optJSONObject("data") ?: root.optJSONObject("results") ?: root
    val songsArr = container.optJSONArray("songs") ?: container.optJSONArray("tracks")
    val albumsArr = container.optJSONArray("albums")
    val artistsArr = container.optJSONArray("artists")
    val playlistsArr = container.optJSONArray("playlists")
    val songs = if (songsArr != null) mapSongsArray(songsArr) else emptyList()
    val lookup = songs.associateBy { it.id }
    val albums = if (albumsArr != null) parseAlbumsList(albumsArr.toString()) else emptyList()
    val artists = if (artistsArr != null) parseArtistsList(artistsArr.toString()) else emptyList()
    val playlists = if (playlistsArr != null) parsePlaylistsList(playlistsArr.toString(), lookup) else emptyList()
    return SearchBundle(
      songs = songs,
      albums = albums,
      artists = artists,
      playlists = playlists,
    )
  }

  fun parseUserSettings(rawJson: String): UserSettings? {
    val root = parseTokener(rawJson) as? JSONObject ?: return null
    val obj = root.optJSONObject("settings") ?: root.optJSONObject("data") ?: root
    return UserSettings(
      themeMode = obj.firstString("themeMode", "theme_mode", "theme"),
      colorPreset = obj.firstString("colorPreset", "color_preset", "accentPreset"),
      amoledMode = if (obj.has("amoledMode") || obj.has("amoled_mode")) {
        parseBoolean(obj.opt("amoledMode") ?: obj.opt("amoled_mode"))
      } else null,
      useDynamicColor = if (obj.has("useDynamicColor") || obj.has("use_dynamic_color") || obj.has("dynamicColor")) {
        parseBoolean(obj.opt("useDynamicColor") ?: obj.opt("use_dynamic_color") ?: obj.opt("dynamicColor"))
      } else null,
      audioQuality = obj.firstString("audioQuality", "audio_quality", "quality"),
      likedAlbumIds = extractIdList(obj, "likedAlbumIds", "liked_album_ids", "likedAlbums"),
      blockedSongIds = extractIdList(obj, "blockedSongIds", "blocked_song_ids", "blocks"),
    )
  }

  fun parseBlockedSongIds(rawJson: String): List<String> {
    val root = parseTokener(rawJson) ?: return emptyList()
    if (root is JSONArray) {
      return buildList {
        for (i in 0 until root.length()) {
          when (val item = root.opt(i)) {
            is String -> if (item.isNotBlank()) add(item.trim())
            is JSONObject -> item.firstString("songId", "song_id", "id")?.let { add(it) }
          }
        }
      }.distinct()
    }
    if (root is JSONObject) {
      val container = root.optJSONObject("data") ?: root
      val extracted = extractIdList(container, "blocks", "blockedSongIds", "blocked_song_ids", "songs", "items", "results")
      if (extracted.isNotEmpty()) return extracted
      return extractIdList(root, "blocks", "blockedSongIds", "blocked_song_ids", "songs", "data")
    }
    return emptyList()
  }

  fun parseVouchersList(rawJson: String): List<VoucherInfo> {
    val root = parseTokener(rawJson) ?: return emptyList()
    val objects = mutableListOf<JSONObject>()
    val array = extractArray(root, listOf("vouchers", "data", "items", "results"))
    if (array != null) {
      for (i in 0 until array.length()) {
        array.optJSONObject(i)?.let { objects.add(it) }
      }
    } else if (root is JSONObject) {
      val keys = root.keys()
      while (keys.hasNext()) {
        root.optJSONObject(keys.next())?.let { objects.add(it) }
      }
    }
    return objects.mapNotNull { obj ->
      val code = obj.firstString("code")?.trim()?.uppercase() ?: return@mapNotNull null
      val isActive = if (obj.has("isActive")) {
        parseBoolean(obj.opt("isActive"))
      } else if (obj.has("is_active")) {
        parseBoolean(obj.opt("is_active"))
      } else {
        true
      }
      if (!isActive) return@mapNotNull null
      VoucherInfo(
        code = code,
        description = obj.firstString("description", "desc"),
        discountType = obj.firstString("discountType", "discount_type", "type") ?: "percent",
        discountValue = obj.firstLong("discountValue", "discount_value", "value", "amount"),
        isActive = true,
      )
    }
  }

  fun parsePurchasesList(
    rawJson: String,
    songsLookup: Map<String, Song> = emptyMap(),
  ): List<PurchaseRecord> {
    val root = parseTokener(rawJson) ?: return emptyList()
    val array = extractArray(root, listOf("purchases", "items", "data", "results"))
    if (array != null) {
      return buildList {
        for (i in 0 until array.length()) {
          val obj = array.optJSONObject(i) ?: continue
          add(mapPurchase(obj, fallbackId = "p_$i", songsLookup = songsLookup))
        }
      }.sortedByDescending { it.purchasedAt.orEmpty() }
    }
    if (root is JSONObject) {
      return mapObjectValues(root) { key, obj ->
        mapPurchase(obj, fallbackId = key, songsLookup = songsLookup)
      }.sortedByDescending { it.purchasedAt.orEmpty() }
    }
    return emptyList()
  }

  fun parseVoucherValidation(
    rawJson: String,
    fallbackCode: String,
    originalPrice: Long,
  ): VoucherValidation? {
    val root = parseTokener(rawJson) as? JSONObject ?: return null
    val container = root.optJSONObject("voucher") ?: root.optJSONObject("data") ?: root
    val valid = if (root.has("valid") || container.has("valid")) {
      parseBoolean(container.opt("valid") ?: root.opt("valid"))
    } else if (root.has("success")) {
      parseBoolean(root.opt("success"))
    } else {
      true
    }
    val discountType = container.firstString("discountType", "discount_type", "type") ?: "percent"
    val discountValue = container.firstLong("discountValue", "discount_value", "value", "amount")
    val computedFinal = computeDiscountedPrice(originalPrice, discountType, discountValue)
    val apiFinalPrice = container.firstLong("finalPrice", "final_price", "discountedPrice", "discounted_price")
    return VoucherValidation(
      valid = valid,
      code = container.firstString("code") ?: fallbackCode,
      discountType = discountType,
      discountValue = discountValue,
      originalPrice = originalPrice,
      finalPrice = if (container.has("finalPrice") || container.has("final_price") || container.has("discountedPrice")) {
        apiFinalPrice
      } else {
        computedFinal
      },
      description = container.firstString("description", "desc"),
      message = root.firstString("message", "msg") ?: container.firstString("message"),
    )
  }

  fun validateVoucherFromRtdb(
    rawJson: String,
    code: String,
    originalPrice: Long,
  ): VoucherValidation {
    val cleanCode = code.trim().uppercase()
    val vouchers = mutableListOf<JSONObject>()
    val root = parseTokener(rawJson)
    when (root) {
      is JSONArray -> {
        for (i in 0 until root.length()) {
          root.optJSONObject(i)?.let { vouchers.add(it) }
        }
      }
      is JSONObject -> {
        val keys = root.keys()
        while (keys.hasNext()) {
          root.optJSONObject(keys.next())?.let { vouchers.add(it) }
        }
      }
    }

    val matched = vouchers.firstOrNull {
      it.firstString("code")?.trim()?.uppercase() == cleanCode
    } ?: return VoucherValidation(
      valid = false,
      code = cleanCode,
      originalPrice = originalPrice,
      finalPrice = originalPrice,
      message = "Mã giảm giá \"$cleanCode\" không tồn tại hoặc đã hết hạn.",
    )

    val isActive = if (matched.has("isActive")) parseBoolean(matched.opt("isActive")) else true
    if (!isActive) {
      return VoucherValidation(
        valid = false,
        code = cleanCode,
        originalPrice = originalPrice,
        finalPrice = originalPrice,
        message = "Mã giảm giá \"$cleanCode\" hiện không còn hiệu lực.",
      )
    }

    val discountType = matched.firstString("discountType", "discount_type") ?: "percent"
    val discountValue = matched.firstLong("discountValue", "discount_value", "value")
    val finalPrice = computeDiscountedPrice(originalPrice, discountType, discountValue)
    return VoucherValidation(
      valid = true,
      code = cleanCode,
      discountType = discountType,
      discountValue = discountValue,
      originalPrice = originalPrice,
      finalPrice = finalPrice,
      description = matched.firstString("description"),
      message = "Áp dụng mã thành công!",
    )
  }

  private fun computeDiscountedPrice(originalPrice: Long, discountType: String, discountValue: Long): Long {
    if (originalPrice <= 0L) return 0L
    return when (discountType.lowercase()) {
      "fixed", "amount" -> (originalPrice - discountValue).coerceAtLeast(0L)
      else -> {
        val pct = discountValue.coerceIn(0L, 100L)
        (originalPrice * (100L - pct) / 100L).coerceAtLeast(0L)
      }
    }
  }

  private fun mapPurchase(
    obj: JSONObject,
    fallbackId: String,
    songsLookup: Map<String, Song>,
  ): PurchaseRecord {
    val songObj = obj.optJSONObject("song")
    val songId = obj.firstString("songId", "song_id")
      ?: songObj?.firstString("id")
      ?: fallbackId
    val song = songsLookup[songId]
    return PurchaseRecord(
      id = obj.firstString("purchaseId", "purchase_id", "id") ?: fallbackId,
      songId = songId,
      songTitle = obj.firstString("songTitle", "song_title", "title")
        ?: songObj?.firstString("title")
        ?: song?.title
        ?: "Bài hát #$songId",
      artistName = obj.firstString("artistName", "artist_name", "artists")
        ?: songObj?.firstString("artists", "artistName")
        ?: song?.artistName
        ?: "XuanKen Music",
      coverUrl = normalizeUrl(obj.firstString("coverImage", "coverUrl", "cover_url"))
        ?: song?.coverUrl,
      price = obj.firstLong("price", "amount", "paidAmount"),
      voucherCode = obj.firstString("voucherCode", "voucher_code"),
      purchasedAt = obj.firstString("purchasedAt", "purchased_at", "timestamp", "createdAt"),
    )
  }

  private fun <T> mapObjectValues(obj: JSONObject, mapper: (String, JSONObject) -> T): List<T> {
    val result = mutableListOf<T>()
    val keys = obj.keys()
    while (keys.hasNext()) {
      val k = keys.next()
      val item = obj.optJSONObject(k) ?: continue
      result.add(mapper(k, item))
    }
    return result
  }

  private fun mapSongsArray(array: JSONArray): List<Song> = buildList {
    for (i in 0 until array.length()) {
      val obj = array.optJSONObject(i) ?: continue
      add(mapSong(obj))
    }
  }

  private fun mapSong(obj: JSONObject, fallbackId: String? = null): Song {
    val artistObj = obj.optJSONObject("artist") ?: obj.optJSONArray("artists")?.optJSONObject(0)
    val albumObj = obj.optJSONObject("album")
    val genreObj = obj.optJSONObject("genre")

    val artistName = obj.firstString("artist_name", "artistName", "artists", "singer", "composer", "author")
      ?: artistObj?.firstString("name", "title")
      ?: (obj.opt("artist") as? String)?.takeIf { it.isNotBlank() }
      ?: "XuanKen"

    val artistId = obj.firstString("artist_id", "artistId")
      ?: artistObj?.firstString("id", "_id", "slug")
      ?: artistName.split(",", "&").firstOrNull()?.trim()?.lowercase()?.replace(Regex("[^a-z0-9]+"), "-")

    val albumTitle = obj.firstString("album_title", "albumTitle", "album_name")
      ?: albumObj?.firstString("title", "name")
      ?: (obj.opt("album") as? String)?.takeIf { it.isNotBlank() }

    val albumId = obj.firstString("album_id", "albumId")
      ?: albumObj?.firstString("id", "_id", "slug")

    val genre = obj.firstString("genre_name", "genreName", "category")
      ?: genreObj?.firstString("name", "title")
      ?: (obj.opt("genre") as? String)?.takeIf { it.isNotBlank() }
      ?: ""

    val rawCover = obj.firstString(
      "coverImage", "cover_url", "coverUrl", "cover", "artwork_url", "artwork",
      "thumbnail", "thumb", "image_url", "image", "poster",
    ) ?: albumObj?.firstString("coverImage", "cover_url", "coverUrl", "cover", "image")

    val rawAudio = obj.firstString(
      "masterUrl", "master_url", "fullUrl", "full_url", "signedUrl", "signed_url",
      "mp3Url", "mp3_url", "wavUrl", "wav_url", "flacUrl", "flac_url",
      "audio_url", "audioUrl", "stream_url", "streamUrl",
      "file_url", "fileUrl", "demoUrl", "demo_url",
      "music_url", "src", "url", "audio", "track_url",
    )

    val durationSec = parseDurationSeconds(
      obj.opt("duration_seconds")
        ?: obj.opt("durationSeconds")
        ?: obj.opt("duration")
        ?: obj.opt("length"),
    )

    val priceNumber = obj.firstLong("price")
    val explicitPaid = obj.opt("paid") ?: obj.opt("is_paid") ?: obj.opt("isPaid") ?: obj.opt("is_premium") ?: obj.opt("vip")
    val isPaid = if (explicitPaid != null && explicitPaid != JSONObject.NULL) {
      parseBoolean(explicitPaid)
    } else {
      priceNumber > 0L
    }

    val priceVal = obj.firstString("price_formatted", "priceText")
      ?: if (priceNumber > 0L) formatVnd(priceNumber) else null

    val lrcRaw = obj.firstString("lrcRaw", "lyrics", "lyric", "lrc")
    val lrcUrl = normalizeUrl(obj.firstString("lrcUrl", "lrc_url"))

    return Song(
      id = obj.firstString("id", "_id", "song_id", "slug") ?: fallbackId ?: "${obj.hashCode()}",
      title = obj.firstString("title", "name", "song_name") ?: "Không rõ tên bài hát",
      artistName = artistName,
      artistId = artistId,
      albumTitle = albumTitle,
      albumId = albumId,
      genre = genre,
      coverUrl = normalizeUrl(rawCover),
      audioUrl = normalizeUrl(rawAudio),
      durationSeconds = durationSec,
      isPaid = isPaid,
      priceText = priceVal,
      playCount = obj.firstLong("playCount", "play_count", "playsCount", "views", "listens", "listen_count"),
      lyrics = lrcRaw ?: lrcUrl?.let { "LRC_URL:$it" },
      description = obj.firstString("description", "desc", "about", "provider")?.let {
        val release = obj.firstString("releaseDate", "release_year")
        if (!release.isNullOrBlank() && !it.contains(release)) "$it • $release" else it
      },
      rank = obj.firstIntOrNull("rank", "position", "chart_rank"),
      createdAtMs = parseTimestampMs(
        obj.opt("createdAt")
          ?: obj.opt("created_at")
          ?: obj.opt("uploadedAt")
          ?: obj.opt("uploaded_at")
          ?: obj.opt("updatedAt")
          ?: obj.opt("timestamp"),
      ),
    )
  }

  private fun mapAlbum(obj: JSONObject, fallbackId: String? = null): Album {
    val artistObj = obj.optJSONObject("artist")
    val artistName = obj.firstString("artist_name", "artistName", "artists")
      ?: artistObj?.firstString("name", "title")
      ?: (obj.opt("artist") as? String)?.takeIf { it.isNotBlank() }
      ?: "XuanKen Music"

    val songsList = mutableListOf<Song>()
    val songsArr = obj.optJSONArray("songs") ?: obj.optJSONArray("tracks")
    if (songsArr != null) {
      songsList.addAll(mapSongsArray(songsArr))
    } else {
      val songsObj = obj.optJSONObject("songs") ?: obj.optJSONObject("tracks")
      if (songsObj != null) {
        songsList.addAll(mapObjectValues(songsObj) { k, sObj -> mapSong(sObj, fallbackId = k) })
      }
    }

    val albumId = obj.firstString("id", "_id", "album_id", "slug") ?: fallbackId ?: "${obj.hashCode()}"
    val albumTitle = obj.firstString("title", "name", "album_name") ?: "Album Độc Quyền"
    val albumCover = normalizeUrl(
      obj.firstString("coverImage", "cover_url", "coverUrl", "cover", "artwork_url", "thumbnail", "image_url", "image"),
    )

    val hydratedSongs = songsList.map { s ->
      s.copy(
        albumId = s.albumId ?: albumId,
        albumTitle = s.albumTitle ?: albumTitle,
        coverUrl = s.coverUrl ?: albumCover,
      )
    }

    return Album(
      id = albumId,
      title = albumTitle,
      artistName = artistName,
      artistId = obj.firstString("artist_id", "artistId")
        ?: artistObj?.firstString("id", "_id")
        ?: artistName.split(",", "&").firstOrNull()?.trim()?.lowercase()?.replace(Regex("[^a-z0-9]+"), "-"),
      coverUrl = albumCover,
      releaseYear = obj.firstString("releaseYear", "release_year", "year", "released_at"),
      genre = obj.firstString("genre", "genre_name", "category"),
      description = obj.firstString("description", "desc", "about"),
      trackCount = maxOf(obj.firstInt("track_count", "trackCount", "song_count", "songs_count"), hydratedSongs.size),
      songs = hydratedSongs,
    )
  }

  private fun mapArtist(obj: JSONObject, fallbackId: String? = null): Artist {
    val songsArr = obj.optJSONArray("songs") ?: obj.optJSONArray("top_songs") ?: obj.optJSONArray("tracks")
    val songs = if (songsArr != null) mapSongsArray(songsArr) else emptyList()
    val albumsArr = obj.optJSONArray("albums")
    val albums = buildList {
      if (albumsArr != null) {
        for (i in 0 until albumsArr.length()) {
          albumsArr.optJSONObject(i)?.let { add(mapAlbum(it)) }
        }
      }
    }
    return Artist(
      id = obj.firstString("id", "_id", "artist_id", "slug") ?: fallbackId ?: "${obj.hashCode()}",
      name = obj.firstString("name", "title", "artist_name") ?: "Nghệ sĩ",
      avatarUrl = normalizeUrl(
        obj.firstString("avatarUrl", "avatar_url", "avatar", "photo_url", "image_url", "image", "coverImage", "cover_url", "cover"),
      ),
      coverUrl = normalizeUrl(
        obj.firstString("banner_url", "coverImage", "cover_url", "coverUrl", "cover", "image_url", "image", "avatar_url"),
      ),
      bio = obj.firstString("bio", "biography", "description", "about"),
      genre = obj.firstString("genre", "primary_genre", "style"),
      followerCount = obj.firstLong("followers", "follower_count", "followerCount", "fans"),
      songCount = maxOf(obj.firstInt("song_count", "songCount", "songs_count", "tracks_count"), songs.size),
      songs = songs,
      albums = albums,
    )
  }

  private fun mapPlaylist(
    obj: JSONObject,
    fallbackId: String? = null,
    songsLookup: Map<String, Song> = emptyMap(),
  ): Playlist {
    val songsList = mutableListOf<Song>()
    val songsArr = obj.optJSONArray("songs") ?: obj.optJSONArray("tracks")
    val songIdsList = extractIdList(obj, "songIds", "song_ids", "trackIds", "tracks_ids")
    if (songsArr != null) {
      songsList.addAll(mapSongsArray(songsArr))
    } else {
      val songsObj = obj.optJSONObject("songs") ?: obj.optJSONObject("tracks")
      if (songsObj != null) {
        songsList.addAll(mapObjectValues(songsObj) { k, sObj -> mapSong(sObj, fallbackId = k) })
      } else if (songsLookup.isNotEmpty() && songIdsList.isNotEmpty()) {
        songIdsList.forEach { sid ->
          songsLookup[sid]?.let { songsList.add(it) }
        }
      }
    }
    val idsCount = songIdsList.size
    return Playlist(
      id = obj.firstString("id", "_id", "playlist_id", "slug") ?: fallbackId ?: "${obj.hashCode()}",
      title = obj.firstString("title", "name", "playlist_name") ?: "Playlist",
      description = obj.firstString("description", "desc", "subtitle"),
      coverUrl = normalizeUrl(
        obj.firstString("coverImage", "cover_url", "coverUrl", "cover", "thumbnail", "image_url", "image"),
      ) ?: songsList.firstOrNull { !it.coverUrl.isNullOrBlank() }?.coverUrl,
      curator = obj.firstString("curator", "creator", "author", "owner_name", "user_name", "userName") ?: "XuanKen Music",
      curatorId = obj.firstString("userId", "user_id", "curatorId", "ownerId", "owner_id", "uid"),
      songCount = maxOf(obj.firstInt("song_count", "songCount", "tracks_count", "total"), idsCount, songsList.size),
      songs = songsList,
    )
  }

  private fun extractIdList(obj: JSONObject, vararg keys: String): List<String> {
    val result = linkedSetOf<String>()
    for (k in keys) {
      if (!obj.has(k) || obj.isNull(k)) continue
      when (val raw = obj.opt(k)) {
        is JSONArray -> {
          for (i in 0 until raw.length()) {
            when (val item = raw.opt(i)) {
              is String -> if (item.isNotBlank() && item != "null") result.add(item.trim())
              is JSONObject -> item.firstString("songId", "song_id", "id")?.let { result.add(it) }
            }
          }
        }
        is JSONObject -> {
          val subKeys = raw.keys()
          while (subKeys.hasNext()) {
            val sk = subKeys.next()
            val sv = raw.opt(sk)
            if (sv == false || sv == JSONObject.NULL) continue
            if (sv is JSONObject) {
              val idFromObj = sv.firstString("songId", "song_id", "id") ?: sk
              if (idFromObj.isNotBlank()) result.add(idFromObj)
            } else if (sk.isNotBlank()) {
              result.add(sk)
            }
          }
        }
        is String -> {
          raw.split(",").map { it.trim() }.filter { it.isNotBlank() }.forEach { result.add(it) }
        }
      }
    }
    return result.toList()
  }

  private fun formatVnd(amount: Long): String {
    val nf = NumberFormat.getNumberInstance(Locale.forLanguageTag("vi-VN"))
    return "${nf.format(amount)}đ"
  }

  private fun parseTokener(raw: String): Any? {
    val trimmed = raw.trim()
    if (trimmed.isEmpty() || trimmed == "null") return null
    return runCatching { JSONTokener(trimmed).nextValue() }.getOrNull()
  }

  private fun extractArray(root: Any, candidateKeys: List<String>): JSONArray? {
    if (root is JSONArray) return root
    if (root !is JSONObject) return null
    for (key in candidateKeys) {
      val arr = root.optJSONArray(key)
      if (arr != null) return arr
    }
    val dataObj = root.optJSONObject("data") ?: root.optJSONObject("result")
    if (dataObj != null) {
      for (key in candidateKeys) {
        val arr = dataObj.optJSONArray(key)
        if (arr != null) return arr
      }
    }
    return null
  }

  private fun extractObject(root: Any, candidateKeys: List<String>): JSONObject? {
    if (root is JSONArray) return root.optJSONObject(0)
    if (root !is JSONObject) return null
    for (key in candidateKeys) {
      val nested = root.optJSONObject(key)
      if (nested != null) return nested
    }
    return root
  }

  private fun normalizeUrl(raw: String?): String? {
    val clean = raw?.trim()?.takeIf { it.isNotEmpty() && it != "null" } ?: return null
    return when {
      clean.startsWith("http://") || clean.startsWith("https://") -> clean
      clean.startsWith("//") -> "https:$clean"
      clean.startsWith("/") -> "$BASE_HOST$clean"
      else -> "$BASE_HOST/$clean"
    }
  }

  private fun parseDurationSeconds(value: Any?): Int {
    if (value == null || value == JSONObject.NULL) return 0
    return when (value) {
      is Number -> {
        val n = value.toInt()
        if (n > 36_000) n / 1000 else maxOf(0, n)
      }
      is String -> {
        val s = value.trim()
        if (s.contains(":")) {
          val parts = s.split(":").mapNotNull { it.toIntOrNull() }
          when (parts.size) {
            2 -> parts[0] * 60 + parts[1]
            3 -> parts[0] * 3600 + parts[1] * 60 + parts[2]
            else -> 0
          }
        } else {
          val n = s.toDoubleOrNull()?.toInt() ?: 0
          if (n > 36_000) n / 1000 else maxOf(0, n)
        }
      }
      else -> 0
    }
  }

  private fun parseBoolean(value: Any?): Boolean {
    return when (value) {
      is Boolean -> value
      is Number -> value.toInt() != 0
      is String -> value.equals("true", ignoreCase = true) || value == "1"
      else -> false
    }
  }

  private fun hasTrueFlag(primary: JSONObject, secondary: JSONObject, vararg keys: String): Boolean {
    for (k in keys) {
      if (primary.has(k) && !primary.isNull(k) && parseBoolean(primary.opt(k))) return true
      if (secondary.has(k) && !secondary.isNull(k) && parseBoolean(secondary.opt(k))) return true
    }
    return false
  }

  private fun hasFalseFlag(primary: JSONObject, secondary: JSONObject, vararg keys: String): Boolean {
    for (k in keys) {
      if (primary.has(k) && !primary.isNull(k) && !parseBoolean(primary.opt(k))) return true
      if (secondary.has(k) && !secondary.isNull(k) && !parseBoolean(secondary.opt(k))) return true
    }
    return false
  }

  private fun prettifyChartKey(key: String): String = when (key.lowercase()) {
    "trending" -> "Thịnh hành"
    "popular", "top", "top_songs" -> "Phổ biến nhất"
    "new", "new_releases", "latest" -> "Mới phát hành"
    "paid", "top_paid", "premium" -> "Độc quyền trả phí"
    "free", "top_free" -> "Miễn phí nổi bật"
    else -> key.replace("_", " ").replaceFirstChar { it.uppercase() }
  }

  private fun JSONObject.firstString(vararg keys: String): String? {
    for (k in keys) {
      if (!has(k) || isNull(k)) continue
      val v = opt(k)
      if (v is String && v.isNotBlank() && v != "null") return v.trim()
      if (v is Number) return v.toString()
    }
    return null
  }

  private fun JSONObject.firstLong(vararg keys: String): Long {
    for (k in keys) {
      if (!has(k) || isNull(k)) continue
      val v = opt(k)
      when (v) {
        is Number -> return v.toLong()
        is String -> v.toLongOrNull()?.let { return it }
      }
    }
    return 0L
  }

  private fun JSONObject.firstInt(vararg keys: String): Int = firstIntOrNull(*keys) ?: 0

  private fun parseTimestampMs(value: Any?): Long {
    if (value == null || value == JSONObject.NULL) return 0L
    return when (value) {
      is Number -> {
        val raw = value.toLong()
        if (raw in 1_000_000_000L..99_999_999_999L) raw * 1000L else raw.coerceAtLeast(0L)
      }
      is String -> {
        val clean = value.trim()
        clean.toLongOrNull()?.let { raw ->
          return if (raw in 1_000_000_000L..99_999_999_999L) raw * 1000L else raw.coerceAtLeast(0L)
        }
        val patterns = listOf(
          "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'",
          "yyyy-MM-dd'T'HH:mm:ss'Z'",
          "yyyy-MM-dd'T'HH:mm:ssXXX",
          "yyyy-MM-dd HH:mm:ss",
          "yyyy-MM-dd",
        )
        for (pattern in patterns) {
          val parsed = runCatching {
            java.text.SimpleDateFormat(pattern, Locale.US).apply {
              timeZone = java.util.TimeZone.getTimeZone("UTC")
            }.parse(clean)?.time
          }.getOrNull()
          if (parsed != null && parsed > 0L) return parsed
        }
        0L
      }
      else -> 0L
    }
  }

  private fun JSONObject.firstIntOrNull(vararg keys: String): Int? {
    for (k in keys) {
      if (!has(k) || isNull(k)) continue
      val v = opt(k)
      when (v) {
        is Number -> return v.toInt()
        is String -> v.toIntOrNull()?.let { return it }
      }
    }
    return null
  }
}
