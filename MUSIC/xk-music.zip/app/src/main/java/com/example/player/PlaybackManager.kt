package com.example.player

import android.content.ComponentName
import android.content.Context
import android.net.Uri
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.example.model.Song
import com.google.common.util.concurrent.ListenableFuture
import com.google.common.util.concurrent.MoreExecutors
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

enum class RepeatModeState {
  OFF,
  ALL,
  ONE,
}

data class PlaybackUiState(
  val currentSong: Song? = null,
  val queue: List<Song> = emptyList(),
  val currentIndex: Int = -1,
  val isPlaying: Boolean = false,
  val isBuffering: Boolean = false,
  val positionMs: Long = 0L,
  val durationMs: Long = 0L,
  val shuffleEnabled: Boolean = false,
  val repeatMode: RepeatModeState = RepeatModeState.OFF,
  val playbackError: String? = null,
)

class PlaybackManager(
  context: Context,
  private val onSongChanged: (Song) -> Unit = {},
  private val onSleepTimerAutoPaused: () -> Unit = {},
) {
  private val appContext = context.applicationContext
  private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

  private val _state = MutableStateFlow(PlaybackUiState())
  val state: StateFlow<PlaybackUiState> = _state.asStateFlow()

  private var controllerFuture: ListenableFuture<MediaController>? = null
  private var controller: MediaController? = null
  private var positionJob: Job? = null
  private var pendingPlayAction: (() -> Unit)? = null
  private var pauseAfterCurrentTrack: Boolean = false
  private var targetPlaybackSpeed: Float = 1.0f

  private val playerListener = object : Player.Listener {
    override fun onIsPlayingChanged(isPlaying: Boolean) {
      _state.update { it.copy(isPlaying = isPlaying) }
      if (isPlaying) startPositionTicker() else stopPositionTicker()
    }

    override fun onPlaybackStateChanged(playbackState: Int) {
      val buffering = playbackState == Player.STATE_BUFFERING
      val duration = controller?.duration?.takeIf { it > 0L }
        ?: (_state.value.currentSong?.durationSeconds?.toLong()?.times(1000L) ?: 0L)
      _state.update {
        it.copy(
          isBuffering = buffering,
          durationMs = duration,
        )
      }
      if (playbackState == Player.STATE_ENDED && pauseAfterCurrentTrack) {
        pauseAfterCurrentTrack = false
        controller?.pause()
        onSleepTimerAutoPaused()
      }
    }

    override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
      if (pauseAfterCurrentTrack && reason == Player.MEDIA_ITEM_TRANSITION_REASON_AUTO) {
        pauseAfterCurrentTrack = false
        controller?.pause()
        onSleepTimerAutoPaused()
        return
      }
      val index = controller?.currentMediaItemIndex ?: -1
      val queue = _state.value.queue
      val matchedSong = if (index in queue.indices) {
        queue[index]
      } else {
        queue.firstOrNull { it.id == mediaItem?.mediaId }
      }
      if (matchedSong != null) {
        _state.update {
          it.copy(
            currentSong = matchedSong,
            currentIndex = if (index >= 0) index else queue.indexOf(matchedSong),
            positionMs = 0L,
            durationMs = matchedSong.durationSeconds.toLong() * 1000L,
            playbackError = null,
          )
        }
        onSongChanged(matchedSong)
      }
    }

    override fun onShuffleModeEnabledChanged(shuffleModeEnabled: Boolean) {
      _state.update { it.copy(shuffleEnabled = shuffleModeEnabled) }
    }

    override fun onRepeatModeChanged(repeatMode: Int) {
      val mapped = when (repeatMode) {
        Player.REPEAT_MODE_ONE -> RepeatModeState.ONE
        Player.REPEAT_MODE_ALL -> RepeatModeState.ALL
        else -> RepeatModeState.OFF
      }
      _state.update { it.copy(repeatMode = mapped) }
    }

    override fun onPlayerError(error: PlaybackException) {
      _state.update {
        it.copy(
          isPlaying = false,
          isBuffering = false,
          playbackError = "Không thể phát bài hát này (${error.errorCodeName}).",
        )
      }
    }
  }

  init {
    connectController()
  }

  private fun connectController() {
    val sessionToken = SessionToken(appContext, ComponentName(appContext, PlaybackService::class.java))
    val future = MediaController.Builder(appContext, sessionToken).buildAsync()
    controllerFuture = future
    future.addListener(
      {
        val mediaController = runCatching { future.get() }.getOrNull() ?: return@addListener
        controller = mediaController
        mediaController.addListener(playerListener)
        syncFromController(mediaController)
        pendingPlayAction?.invoke()
        pendingPlayAction = null
      },
      MoreExecutors.directExecutor(),
    )
  }

  private fun syncFromController(mediaController: MediaController) {
    _state.update {
      it.copy(
        isPlaying = mediaController.isPlaying,
        isBuffering = mediaController.playbackState == Player.STATE_BUFFERING,
        positionMs = mediaController.currentPosition.coerceAtLeast(0L),
        durationMs = mediaController.duration.takeIf { d -> d > 0L } ?: it.durationMs,
        shuffleEnabled = mediaController.shuffleModeEnabled,
        repeatMode = when (mediaController.repeatMode) {
          Player.REPEAT_MODE_ONE -> RepeatModeState.ONE
          Player.REPEAT_MODE_ALL -> RepeatModeState.ALL
          else -> RepeatModeState.OFF
        },
      )
    }
    mediaController.setPlaybackSpeed(targetPlaybackSpeed)
    if (mediaController.isPlaying) startPositionTicker()
  }

  fun playQueue(songs: List<Song>, startIndex: Int = 0, shuffle: Boolean = false) {
    val playable = songs.filter { !it.audioUrl.isNullOrBlank() }
    if (playable.isEmpty()) {
      val target = songs.getOrNull(startIndex)
      _state.update {
        it.copy(
          currentSong = target ?: it.currentSong,
          playbackError = if (target?.isPaid == true) {
            "Bài hát trả phí chưa có liên kết phát trực tiếp."
          } else {
            "Không tìm thấy đường dẫn phát nhạc cho bài hát này."
          },
        )
      }
      return
    }

    val targetSong = songs.getOrNull(startIndex)
    val resolvedIndex = if (targetSong != null) {
      playable.indexOfFirst { it.id == targetSong.id }.coerceAtLeast(0)
    } else {
      0
    }
    val initialSong = playable[resolvedIndex]

    _state.update {
      it.copy(
        currentSong = initialSong,
        queue = playable,
        currentIndex = resolvedIndex,
        positionMs = 0L,
        durationMs = initialSong.durationSeconds.toLong() * 1000L,
        playbackError = null,
      )
    }
    onSongChanged(initialSong)

    val action = {
      val c = controller
      if (c != null) {
        val items = playable.map { it.toMediaItem() }
        c.shuffleModeEnabled = shuffle
        c.setPlaybackSpeed(targetPlaybackSpeed)
        c.setMediaItems(items, resolvedIndex, 0L)
        c.prepare()
        c.play()
      }
    }

    if (controller != null) {
      action()
    } else {
      pendingPlayAction = action
    }
  }

  fun updateCurrentSongMetadata(updatedSong: Song) {
    _state.update { current ->
      val newQueue = current.queue.map { if (it.id == updatedSong.id) updatedSong else it }
      val newCurrent = if (current.currentSong?.id == updatedSong.id) updatedSong else current.currentSong
      current.copy(currentSong = newCurrent, queue = newQueue)
    }
  }

  fun replaceResolvedSongs(resolvedById: Map<String, Song>) {
    if (resolvedById.isEmpty()) return
    _state.update { current ->
      val newQueue = current.queue.map { resolvedById[it.id] ?: it }
      val newCurrent = current.currentSong?.let { resolvedById[it.id] ?: it }
      current.copy(currentSong = newCurrent, queue = newQueue)
    }

    val c = controller ?: return
    val currentIdx = c.currentMediaItemIndex
    for (i in 0 until c.mediaItemCount) {
      val existingItem = c.getMediaItemAt(i)
      val replacement = resolvedById[existingItem.mediaId] ?: continue
      val newUri = replacement.audioUrl?.takeIf { it.isNotBlank() } ?: continue
      val oldUri = existingItem.localConfiguration?.uri?.toString().orEmpty()
      if (oldUri == newUri) continue

      if (i == currentIdx) {
        val resumePos = c.currentPosition.coerceAtLeast(0L)
        val wasPlaying = c.playWhenReady
        c.replaceMediaItem(i, replacement.toMediaItem())
        if (resumePos > 0L && (c.duration <= 0L || resumePos < c.duration)) {
          c.seekTo(i, resumePos)
        } else {
          c.seekTo(i, 0L)
        }
        c.prepare()
        if (wasPlaying) c.play()
      } else {
        c.replaceMediaItem(i, replacement.toMediaItem())
      }
    }
  }

  fun togglePlayPause() {
    val c = controller ?: return
    if (c.isPlaying) {
      c.pause()
    } else {
      if (c.playbackState == Player.STATE_IDLE || c.playbackState == Player.STATE_ENDED) {
        c.prepare()
      }
      c.play()
    }
  }

  fun pause() {
    pauseAfterCurrentTrack = false
    controller?.pause()
  }

  fun stopAndClear() {
    pauseAfterCurrentTrack = false
    stopPositionTicker()
    controller?.let { c ->
      c.stop()
      c.clearMediaItems()
    }
    _state.update {
      it.copy(
        currentSong = null,
        queue = emptyList(),
        isPlaying = false,
        positionMs = 0L,
        durationMs = 0L,
        playbackError = null,
      )
    }
  }

  fun setPauseAfterCurrentTrack(enabled: Boolean) {
    pauseAfterCurrentTrack = enabled
  }

  fun skipNext() {
    val c = controller ?: return
    if (c.hasNextMediaItem()) {
      c.seekToNextMediaItem()
    } else if (_state.value.queue.isNotEmpty()) {
      c.seekToDefaultPosition(0)
      c.play()
    }
  }

  fun skipPrevious() {
    val c = controller ?: return
    if (c.currentPosition > 3_000L) {
      c.seekTo(0L)
    } else if (c.hasPreviousMediaItem()) {
      c.seekToPreviousMediaItem()
    } else {
      c.seekTo(0L)
    }
  }

  fun seekTo(positionMs: Long) {
    controller?.seekTo(positionMs.coerceAtLeast(0L))
    _state.update { it.copy(positionMs = positionMs.coerceAtLeast(0L)) }
  }

  fun seekRelative(deltaMs: Long) {
    val current = controller?.currentPosition ?: _state.value.positionMs
    val dur = controller?.duration?.takeIf { it > 0L } ?: _state.value.durationMs
    val upper = if (dur > 0L) dur else Long.MAX_VALUE
    seekTo((current + deltaMs).coerceIn(0L, upper))
  }

  fun playNext(song: Song) {
    if (song.audioUrl.isNullOrBlank()) return
    val currentState = _state.value
    if (currentState.queue.isEmpty() || currentState.currentSong == null) {
      playQueue(listOf(song), 0, currentState.shuffleEnabled)
      return
    }
    val curIdx = currentState.currentIndex.coerceIn(0, currentState.queue.lastIndex)
    val mutable = currentState.queue.toMutableList()
    val existingUpcomingIdx = mutable.indexOfFirst { it.id == song.id }
    if (existingUpcomingIdx > curIdx) {
      mutable.removeAt(existingUpcomingIdx)
      controller?.let { c ->
        if (existingUpcomingIdx in 0 until c.mediaItemCount) {
          c.removeMediaItem(existingUpcomingIdx)
        }
      }
    }
    val insertIdx = (curIdx + 1).coerceIn(0, mutable.size)
    mutable.add(insertIdx, song)
    _state.update { it.copy(queue = mutable) }
    controller?.let { c ->
      val safeIdx = insertIdx.coerceIn(0, c.mediaItemCount)
      c.addMediaItem(safeIdx, song.toMediaItem())
    }
  }

  fun addToQueue(song: Song) {
    if (song.audioUrl.isNullOrBlank()) return
    val currentState = _state.value
    if (currentState.queue.isEmpty() || currentState.currentSong == null) {
      playQueue(listOf(song), 0, currentState.shuffleEnabled)
      return
    }
    val updated = currentState.queue + song
    _state.update { it.copy(queue = updated) }
    controller?.addMediaItem(song.toMediaItem())
  }

  fun removeFromQueue(index: Int) {
    val currentState = _state.value
    if (index !in currentState.queue.indices) return
    if (currentState.queue.size <= 1) {
      stopAndClear()
      return
    }
    val mutable = currentState.queue.toMutableList()
    mutable.removeAt(index)
    val curIdx = currentState.currentIndex
    val nextIdx = when {
      index < curIdx -> (curIdx - 1).coerceIn(0, mutable.lastIndex)
      index == curIdx -> curIdx.coerceIn(0, mutable.lastIndex)
      else -> curIdx.coerceIn(0, mutable.lastIndex)
    }
    val nextCurrent = mutable.getOrNull(nextIdx)
    _state.update {
      it.copy(
        queue = mutable,
        currentIndex = nextIdx,
        currentSong = if (index == curIdx) nextCurrent else it.currentSong,
      )
    }
    controller?.let { c ->
      if (index in 0 until c.mediaItemCount) {
        c.removeMediaItem(index)
      }
    }
  }

  fun moveQueueItem(fromIndex: Int, toIndex: Int) {
    val currentState = _state.value
    if (fromIndex !in currentState.queue.indices || toIndex !in currentState.queue.indices || fromIndex == toIndex) {
      return
    }
    val mutable = currentState.queue.toMutableList()
    val moved = mutable.removeAt(fromIndex)
    mutable.add(toIndex, moved)
    val curIdx = currentState.currentIndex
    val updatedCurIdx = when {
      curIdx == fromIndex -> toIndex
      fromIndex < curIdx && toIndex >= curIdx -> curIdx - 1
      fromIndex > curIdx && toIndex <= curIdx -> curIdx + 1
      else -> curIdx
    }
    _state.update {
      it.copy(
        queue = mutable,
        currentIndex = updatedCurIdx,
      )
    }
    controller?.let { c ->
      if (fromIndex in 0 until c.mediaItemCount && toIndex in 0 until c.mediaItemCount) {
        c.moveMediaItem(fromIndex, toIndex)
      }
    }
  }

  fun shuffleUpcomingQueue() {
    val currentState = _state.value
    val curIdx = currentState.currentIndex
    if (curIdx < 0 || curIdx >= currentState.queue.lastIndex) return
    val head = currentState.queue.subList(0, curIdx + 1)
    val upcoming = currentState.queue.subList(curIdx + 1, currentState.queue.size).shuffled()
    val newQueue = head + upcoming
    _state.update { it.copy(queue = newQueue) }
    controller?.let { c ->
      val upcomingStart = curIdx + 1
      if (upcomingStart < c.mediaItemCount) {
        c.removeMediaItems(upcomingStart, c.mediaItemCount)
        c.addMediaItems(upcomingStart, upcoming.map { it.toMediaItem() })
      }
    }
  }

  fun clearUpcomingQueue() {
    val currentState = _state.value
    val curIdx = currentState.currentIndex
    if (curIdx < 0 || curIdx >= currentState.queue.lastIndex) return
    val trimmed = currentState.queue.subList(0, curIdx + 1)
    _state.update { it.copy(queue = trimmed) }
    controller?.let { c ->
      val upcomingStart = curIdx + 1
      if (upcomingStart < c.mediaItemCount) {
        c.removeMediaItems(upcomingStart, c.mediaItemCount)
      }
    }
  }

  fun toggleShuffle() {
    val c = controller ?: return
    c.shuffleModeEnabled = !c.shuffleModeEnabled
  }

  fun cycleRepeatMode() {
    val c = controller ?: return
    c.repeatMode = when (c.repeatMode) {
      Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
      Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
      else -> Player.REPEAT_MODE_OFF
    }
  }

  fun setPlaybackSpeed(speed: Float) {
    val clamped = speed.coerceIn(0.5f, 2.0f)
    targetPlaybackSpeed = clamped
    controller?.setPlaybackSpeed(clamped)
  }

  fun setVolume(volume: Float) {
    controller?.volume = volume.coerceIn(0f, 1f)
  }

  fun clearError() {
    _state.update { it.copy(playbackError = null) }
  }

  private fun startPositionTicker() {
    if (positionJob?.isActive == true) return
    positionJob = scope.launch {
      while (isActive) {
        val c = controller
        if (c != null) {
          _state.update {
            it.copy(
              positionMs = c.currentPosition.coerceAtLeast(0L),
              durationMs = c.duration.takeIf { d -> d > 0L } ?: it.durationMs,
            )
          }
        }
        delay(250L)
      }
    }
  }

  private fun stopPositionTicker() {
    positionJob?.cancel()
    positionJob = null
  }

  fun release() {
    stopPositionTicker()
    controller?.removeListener(playerListener)
    controllerFuture?.let { MediaController.releaseFuture(it) }
    controllerFuture = null
    controller = null
  }

  private fun Song.toMediaItem(): MediaItem {
    val metadata = MediaMetadata.Builder()
      .setTitle(title)
      .setArtist(artistName)
      .setAlbumTitle(albumTitle)
      .apply {
        coverUrl?.let { setArtworkUri(Uri.parse(it)) }
      }
      .build()

    return MediaItem.Builder()
      .setMediaId(id)
      .setUri(audioUrl.orEmpty())
      .setMediaMetadata(metadata)
      .build()
  }
}
