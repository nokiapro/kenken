package com.example.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.model.Song
import com.example.ui.ActiveTrackMeta
import com.example.ui.ExploreUiState
import com.example.ui.PaidFilter
import com.example.ui.SongSort
import com.example.ui.components.ExpressiveCookieEmptyState
import com.example.ui.components.LoadingSkeletonList
import com.example.ui.components.RhythmCollapsibleHeaderScreen
import com.example.ui.components.RhythmDetailActionButton
import com.example.ui.components.RhythmHeaderAction
import com.example.ui.components.SongInfoDialog
import com.example.ui.components.SongRowItem
import com.example.ui.components.StatusMessageCard
import com.example.ui.components.horizontalEdgeBlend
import com.example.ui.components.shareSongIntent
import com.example.ui.rhythm.RhythmIcons
import com.example.ui.rhythm.RhythmSymbolIcon

@Composable
fun ExploreScreen(
  uiState: ExploreUiState,
  activeTrack: ActiveTrackMeta,
  favoriteIds: Set<String>,
  purchasedIds: Set<String>,
  bottomOverlayPadding: PaddingValues,
  onQueryChange: (String) -> Unit,
  onSelectGenre: (String) -> Unit,
  onSelectPaidFilter: (PaidFilter) -> Unit,
  onSelectSort: (SongSort) -> Unit,
  onRetry: () -> Unit,
  onPlaySong: (Song, List<Song>) -> Unit,
  onPlayAll: (List<Song>, Boolean) -> Unit,
  onToggleFavorite: (Song) -> Unit,
  onPurchaseSong: (Song) -> Unit,
  onPlayNext: (Song) -> Unit = {},
  onAddToQueue: (Song) -> Unit = {},
  playCounts: Map<String, Int> = emptyMap(),
) {
  val context = LocalContext.current
  var infoSong by remember { mutableStateOf<Song?>(null) }
  RhythmCollapsibleHeaderScreen(
    title = "Tìm kiếm",
    headerActions = listOf(
      RhythmHeaderAction(
        icon = RhythmIcons.Refresh,
        contentDescription = "Làm mới",
        onClick = onRetry,
      ),
    ),
    filterContent = {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .padding(bottom = 4.dp),
      ) {
        OutlinedTextField(
          value = uiState.query,
          onValueChange = onQueryChange,
          singleLine = true,
          placeholder = {
            Text(
              text = "Tìm bài hát, nghệ sĩ, thể loại…",
              color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
          },
          leadingIcon = {
            RhythmSymbolIcon(
              icon = RhythmIcons.Search,
              contentDescription = null,
              tint = MaterialTheme.colorScheme.onSurfaceVariant,
              size = 20.dp,
              modifier = Modifier.size(20.dp),
            )
          },
          trailingIcon = {
            if (uiState.query.isNotEmpty()) {
              IconButton(onClick = { onQueryChange("") }) {
                RhythmSymbolIcon(
                  icon = RhythmIcons.Close,
                  contentDescription = "Xóa từ khóa",
                  size = 20.dp,
                  modifier = Modifier.size(20.dp),
                )
              }
            }
          },
          shape = CircleShape,
          colors = OutlinedTextFieldDefaults.colors(
            focusedContainerColor = MaterialTheme.colorScheme.surfaceContainerHigh,
            unfocusedContainerColor = MaterialTheme.colorScheme.surfaceContainerHigh,
            focusedBorderColor = Color.Transparent,
            unfocusedBorderColor = Color.Transparent,
          ),
          modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp)
            .testTag("explore_search_input"),
        )
      }
    },
  ) { scaffoldModifier ->
    LazyColumn(
      modifier = scaffoldModifier.fillMaxSize(),
      contentPadding = PaddingValues(
        top = 4.dp,
        bottom = bottomOverlayPadding.calculateBottomPadding() + 28.dp,
      ),
      verticalArrangement = Arrangement.spacedBy(6.dp),
    ) {
      item(key = "explore_filters", contentType = "filters") {
        val chipRowState = rememberLazyListState()
        LazyRow(
          state = chipRowState,
          modifier = Modifier.horizontalEdgeBlend(chipRowState),
          contentPadding = PaddingValues(horizontal = 20.dp),
          horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
          items(PaidFilter.entries) { filter ->
            FilterChip(
              selected = uiState.paidFilter == filter,
              onClick = { onSelectPaidFilter(filter) },
              label = { Text(filter.label) },
              shape = CircleShape,
              colors = FilterChipDefaults.filterChipColors(
                selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                selectedLabelColor = MaterialTheme.colorScheme.onPrimaryContainer,
              ),
            )
          }

          items(SongSort.entries) { sort ->
            FilterChip(
              selected = uiState.sortOrder == sort,
              onClick = { onSelectSort(sort) },
              label = { Text(sort.label) },
              shape = CircleShape,
              colors = FilterChipDefaults.filterChipColors(
                selectedContainerColor = MaterialTheme.colorScheme.secondaryContainer,
                selectedLabelColor = MaterialTheme.colorScheme.onSecondaryContainer,
              ),
            )
          }

          items(uiState.availableGenres) { genre ->
            FilterChip(
              selected = uiState.selectedGenre == genre,
              onClick = { onSelectGenre(genre) },
              label = { Text(genre) },
              shape = CircleShape,
            )
          }
        }
      }

      if (uiState.songs.isNotEmpty()) {
        item(key = "explore_actions", contentType = "actions") {
          Column(
            modifier = Modifier
              .fillMaxWidth()
              .padding(horizontal = 20.dp, vertical = 6.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
          ) {
            Text(
              text = "${uiState.songs.size} kết quả",
              style = MaterialTheme.typography.titleSmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.spacedBy(12.dp),
            ) {
              RhythmDetailActionButton(
                text = "Phát tất cả",
                icon = RhythmIcons.Play,
                filled = true,
                isFirst = true,
                isLast = false,
                height = 48.dp,
                onClick = { onPlayAll(uiState.songs, false) },
              )
              RhythmDetailActionButton(
                text = "Trộn bài",
                icon = RhythmIcons.Shuffle,
                filled = false,
                isFirst = false,
                isLast = true,
                height = 48.dp,
                onClick = { onPlayAll(uiState.songs, true) },
              )
            }
          }
        }
      }

      when {
        uiState.isLoading && uiState.songs.isEmpty() -> {
          item(key = "explore_loading", contentType = "skeleton") {
            LoadingSkeletonList(itemCount = 6)
          }
        }
        uiState.errorMessage != null && uiState.songs.isEmpty() -> {
          item(key = "explore_error", contentType = "error") {
            StatusMessageCard(
              title = if (uiState.isMissingApiKey) "Thiếu API Key" else "Không thể tải danh sách",
              message = uiState.errorMessage,
              actionLabel = "Thử lại",
              onAction = onRetry,
            )
          }
        }
        uiState.songs.isEmpty() -> {
          item(key = "explore_empty", contentType = "empty") {
            ExpressiveCookieEmptyState(
              title = "Không tìm thấy bài hát",
              subtitle = "Thử từ khóa khác hoặc bỏ bớt bộ lọc thể loại.",
              mainIcon = RhythmIcons.SearchFilled,
              accentIcon = RhythmIcons.MusicNote,
              cornerIcon = RhythmIcons.Tune,
              modifier = Modifier.padding(vertical = 20.dp),
            )
          }
        }
        else -> {
          items(uiState.songs, key = { "exp_${it.id}" }, contentType = { "song_row" }) { song ->
            SongRowItem(
              song = song,
              isCurrentSong = activeTrack.songId == song.id,
              isPlaying = activeTrack.songId == song.id && activeTrack.isPlaying,
              isFavorite = song.id in favoriteIds,
              isPurchased = song.id in purchasedIds || !song.isPaid,
              onClick = { onPlaySong(song, uiState.songs) },
              onToggleFavorite = { onToggleFavorite(song) },
              onPurchaseClick = { onPurchaseSong(song) },
              onPlayNext = { onPlayNext(song) },
              onAddToQueue = { onAddToQueue(song) },
              onShowInfo = { infoSong = song },
              onShareSong = { shareSongIntent(context, song) },
              modifier = Modifier.padding(horizontal = 8.dp),
            )
          }
        }
      }
    }
  }

  val selected = infoSong
  if (selected != null) {
    SongInfoDialog(
      song = selected,
      isPurchased = selected.id in purchasedIds || !selected.isPaid,
      playCountOnDevice = playCounts[selected.id] ?: 0,
      onShareClick = { shareSongIntent(context, selected) },
      onDismiss = { infoSong = null },
    )
  }
}
