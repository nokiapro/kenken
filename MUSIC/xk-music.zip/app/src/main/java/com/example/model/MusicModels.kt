package com.example.model

import androidx.compose.runtime.Immutable
import kotlinx.serialization.Serializable

@Immutable
@Serializable
data class Song(
  val id: String,
  val title: String,
  val artistName: String,
  val artistId: String? = null,
  val albumTitle: String? = null,
  val albumId: String? = null,
  val genre: String = "",
  val coverUrl: String? = null,
  val audioUrl: String? = null,
  val durationSeconds: Int = 0,
  val isPaid: Boolean = false,
  val priceText: String? = null,
  val playCount: Long = 0,
  val lyrics: String? = null,
  val description: String? = null,
  val rank: Int? = null,
  val createdAtMs: Long = 0L,
)

@Immutable
@Serializable
data class Album(
  val id: String,
  val title: String,
  val artistName: String,
  val artistId: String? = null,
  val coverUrl: String? = null,
  val releaseYear: String? = null,
  val genre: String? = null,
  val description: String? = null,
  val trackCount: Int = 0,
  val songs: List<Song> = emptyList(),
)

@Immutable
@Serializable
data class Artist(
  val id: String,
  val name: String,
  val avatarUrl: String? = null,
  val coverUrl: String? = null,
  val bio: String? = null,
  val genre: String? = null,
  val followerCount: Long = 0,
  val songCount: Int = 0,
  val songs: List<Song> = emptyList(),
  val albums: List<Album> = emptyList(),
)

@Immutable
@Serializable
data class Playlist(
  val id: String,
  val title: String,
  val description: String? = null,
  val coverUrl: String? = null,
  val curator: String? = null,
  val curatorId: String? = null,
  val songCount: Int = 0,
  val songs: List<Song> = emptyList(),
)

@Immutable
@Serializable
data class ChartSection(
  val title: String,
  val updatedAt: String? = null,
  val songs: List<Song> = emptyList(),
)

@Immutable
@Serializable
data class SiteInfo(
  val siteName: String = "XuanKen Music",
  val tagline: String? = null,
  val description: String? = null,
  val logoUrl: String? = null,
  val bannerUrl: String? = null,
  val genres: List<String> = emptyList(),
  val featuredSongs: List<Song> = emptyList(),
)

@Immutable
@Serializable
data class UserProfile(
  val uid: String,
  val email: String,
  val displayName: String,
  val avatarUrl: String? = null,
  val balance: Long = 0L,
  val role: String? = null,
  val purchasedSongIds: List<String> = emptyList(),
  val likedSongIds: List<String> = emptyList(),
)

@Immutable
@Serializable
data class AuthSession(
  val idToken: String,
  val refreshToken: String = "",
  val expiresAtEpochMs: Long = 0L,
  val user: UserProfile,
)

@Immutable
@Serializable
data class PurchaseRecord(
  val id: String,
  val songId: String,
  val songTitle: String = "",
  val artistName: String = "",
  val coverUrl: String? = null,
  val price: Long = 0L,
  val voucherCode: String? = null,
  val purchasedAt: String? = null,
)

@Immutable
@Serializable
data class VoucherValidation(
  val valid: Boolean,
  val code: String,
  val discountType: String = "percent",
  val discountValue: Long = 0L,
  val originalPrice: Long = 0L,
  val finalPrice: Long = 0L,
  val description: String? = null,
  val message: String? = null,
)

@Immutable
data class SleepTimerUiState(
  val isActive: Boolean = false,
  val stopAfterCurrentSong: Boolean = false,
  val remainingSeconds: Long = 0L,
  val totalSeconds: Long = 0L,
  val label: String = "",
)

@Immutable
data class ListeningStats(
  val totalListeningTimeMs: Long = 0L,
  val songsPlayedCount: Int = 0,
  val songPlayCounts: Map<String, Int> = emptyMap(),
)

@Immutable
data class HomeFeedBundle(
  val siteInfo: SiteInfo = SiteInfo(),
  val chartSections: List<ChartSection> = emptyList(),
  val playlists: List<Playlist> = emptyList(),
  val albums: List<Album> = emptyList(),
  val artists: List<Artist> = emptyList(),
  val popularSongs: List<Song> = emptyList(),
  val latestSongs: List<Song> = emptyList(),
)

@Immutable
data class SearchBundle(
  val songs: List<Song> = emptyList(),
  val albums: List<Album> = emptyList(),
  val artists: List<Artist> = emptyList(),
  val playlists: List<Playlist> = emptyList(),
)

@Immutable
data class UserSettings(
  val themeMode: String? = null,
  val colorPreset: String? = null,
  val amoledMode: Boolean? = null,
  val useDynamicColor: Boolean? = null,
  val audioQuality: String? = null,
  val likedAlbumIds: List<String> = emptyList(),
  val blockedSongIds: List<String> = emptyList(),
)

@Immutable
data class VoucherInfo(
  val code: String,
  val description: String? = null,
  val discountType: String = "percent",
  val discountValue: Long = 0L,
  val isActive: Boolean = true,
)

sealed interface ApiResult<out T> {
  data class Success<T>(val data: T) : ApiResult<T>
  data class Error(
    val message: String,
    val isMissingApiKey: Boolean = false,
    val isUnauthorized: Boolean = false,
  ) : ApiResult<Nothing>
}
