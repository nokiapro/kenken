@file:OptIn(ExperimentalMaterial3ExpressiveApi::class)

package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.ExperimentalMaterial3ExpressiveApi
import androidx.compose.material3.LinearWavyProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ProgressIndicatorDefaults
import androidx.compose.material3.WavyProgressIndicatorDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.semantics.ProgressBarRangeInfo
import androidx.compose.ui.semantics.clearAndSetSemantics
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.progressBarRangeInfo
import androidx.compose.ui.semantics.setProgress
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.max
import kotlinx.coroutines.isActive
import kotlin.math.abs
import kotlin.math.roundToInt

/**
 * Direct port of Rhythm `WaveSlider.kt` powered by Material 3 Expressive's official
 * `LinearWavyProgressIndicator`, with frame-by-frame smooth interpolation,
 * amplitude flattening on pause/scrub, gap around thumb, and circle-to-pill thumb morph.
 */
@Composable
fun WaveSlider(
  value: Float,
  onValueChange: (Float) -> Unit,
  modifier: Modifier = Modifier,
  valueRange: ClosedFloatingPointRange<Float> = 0f..1f,
  onValueChangeFinished: (() -> Unit)? = null,
  onValueCommit: ((Float) -> Unit)? = null,
  enabled: Boolean = true,
  isPlaying: Boolean = true,
  activeTrackColor: Color = MaterialTheme.colorScheme.primary,
  inactiveTrackColor: Color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.2f),
  thumbColor: Color = activeTrackColor,
  wavelength: Dp = WavyProgressIndicatorDefaults.LinearDeterminateWavelength,
  waveSpeed: Dp = wavelength * 0.45f,
  strokeWidth: Dp = 4.dp,
  thumbRadius: Dp = 7.dp,
  trackEdgePadding: Dp = thumbRadius,
  thumbLineHeightWhenInteracting: Dp = 24.dp,
  semanticsLabel: String? = null,
) {
  val density = LocalDensity.current
  val hapticFeedback = LocalHapticFeedback.current

  val rangeSpan = (valueRange.endInclusive - valueRange.start).takeIf { it > 0f } ?: 1f
  val normalizedValue = ((value - valueRange.start) / rangeSpan).coerceIn(0f, 1f)
  val semanticSliderValue = value.coerceIn(valueRange.start, valueRange.endInclusive)

  val strokeWidthPx = with(density) { strokeWidth.toPx() }
  val thumbRadiusPx = with(density) { thumbRadius.toPx() }
  val trackEdgePaddingPx = with(density) { trackEdgePadding.coerceAtLeast(0.dp).toPx() }
  val thumbLineHeightPx = with(density) { thumbLineHeightWhenInteracting.toPx() }
  val stroke = remember(strokeWidthPx) { Stroke(width = strokeWidthPx, cap = StrokeCap.Round) }

  val latestOnValueChange by rememberUpdatedState(onValueChange)
  val latestOnValueChangeFinished by rememberUpdatedState(onValueChangeFinished)
  val latestOnValueCommit by rememberUpdatedState(onValueCommit)

  var isPointerSeeking by remember { mutableStateOf(false) }
  var lastHapticValue by remember { mutableIntStateOf(Int.MIN_VALUE) }
  val isInteracting = isPointerSeeking

  val thumbInteractionFraction by animateFloatAsState(
    targetValue = if (isInteracting) 1f else 0f,
    animationSpec = tween(250, easing = FastOutSlowInEasing),
    label = "ThumbInteractionAnim",
  )

  val animatedAmplitude by animateFloatAsState(
    targetValue = if (enabled && isPlaying && !isInteracting) 1f else 0f,
    animationSpec = ProgressIndicatorDefaults.ProgressAnimationSpec,
    label = "WaveAmplitude",
  )

  val renderedNormalizedProgress = remember { mutableFloatStateOf(normalizedValue) }
  var lastProgressUpdateNanos by remember { mutableLongStateOf(0L) }

  LaunchedEffect(normalizedValue, isInteracting, enabled) {
    val target = normalizedValue.coerceIn(0f, 1f)
    if (!enabled || isInteracting) {
      renderedNormalizedProgress.floatValue = target
      lastProgressUpdateNanos = System.nanoTime()
      return@LaunchedEffect
    }

    val nowNanos = System.nanoTime()
    val intervalMs = if (lastProgressUpdateNanos == 0L) {
      180L
    } else {
      ((nowNanos - lastProgressUpdateNanos) / 1_000_000L).coerceIn(16L, 450L)
    }
    lastProgressUpdateNanos = nowNanos

    val start = renderedNormalizedProgress.floatValue
    if (abs(start - target) <= 0.0001f || abs(start - target) > 0.15f) {
      renderedNormalizedProgress.floatValue = target
      return@LaunchedEffect
    }

    val durationNanos = (intervalMs * 900_000L).coerceAtLeast(1_000_000L)
    var startFrameNanos = 0L
    while (isActive) {
      val frameNanos = withFrameNanos { it }
      if (startFrameNanos == 0L) startFrameNanos = frameNanos
      val elapsedNanos = (frameNanos - startFrameNanos).coerceAtLeast(0L)
      val fraction = (elapsedNanos.toDouble() / durationNanos.toDouble()).toFloat().coerceIn(0f, 1f)
      renderedNormalizedProgress.floatValue = start + (target - start) * fraction
      if (fraction >= 1f) break
    }
    renderedNormalizedProgress.floatValue = target
  }

  val containerHeight = max(
    WavyProgressIndicatorDefaults.LinearContainerHeight,
    max(thumbRadius * 2, thumbLineHeightWhenInteracting),
  )

  Box(
    modifier = modifier
      .fillMaxWidth()
      .height(containerHeight)
      .clearAndSetSemantics {
        if (!semanticsLabel.isNullOrBlank()) contentDescription = semanticsLabel
        progressBarRangeInfo = ProgressBarRangeInfo(
          current = semanticSliderValue,
          range = valueRange.start..valueRange.endInclusive,
          steps = 0,
        )
        if (enabled) {
          setProgress { requested ->
            val coerced = requested.coerceIn(valueRange.start, valueRange.endInclusive)
            latestOnValueChange(coerced)
            latestOnValueCommit?.invoke(coerced) ?: latestOnValueChangeFinished?.invoke()
            true
          }
        }
      },
    contentAlignment = Alignment.Center,
  ) {
    LinearWavyProgressIndicator(
      progress = { renderedNormalizedProgress.floatValue },
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = trackEdgePadding.coerceAtLeast(0.dp))
        .clearAndSetSemantics { },
      color = activeTrackColor,
      trackColor = inactiveTrackColor,
      stroke = stroke,
      trackStroke = stroke,
      gapSize = thumbRadius + 4.dp,
      stopSize = 3.dp,
      amplitude = { progress -> if (progress > 0f) animatedAmplitude else 0f },
      wavelength = wavelength,
      waveSpeed = waveSpeed,
    )

    Canvas(modifier = Modifier.fillMaxSize()) {
      val edgePaddingPx = trackEdgePaddingPx.coerceIn(0f, size.width / 2f)
      val trackStart = edgePaddingPx
      val trackEnd = size.width - edgePaddingPx
      val trackWidth = (trackEnd - trackStart).coerceAtLeast(0f)
      val thumbY = size.height / 2f
      val renderedProgress = renderedNormalizedProgress.floatValue

      fun lerpFloat(start: Float, stop: Float, fraction: Float): Float =
        start + (stop - start) * fraction

      val currentWidth = lerpFloat(thumbRadiusPx * 2f, strokeWidthPx * 1.2f, thumbInteractionFraction)
      val currentHeight = lerpFloat(thumbRadiusPx * 2f, thumbLineHeightPx, thumbInteractionFraction)
      val rawThumbX = trackStart + (trackWidth * renderedProgress)
      val minThumbCenter = (currentWidth / 2f).coerceAtMost(size.width / 2f)
      val maxThumbCenter = (size.width - currentWidth / 2f).coerceAtLeast(minThumbCenter)
      val thumbX = rawThumbX.coerceIn(minThumbCenter, maxThumbCenter)

      drawRoundRect(
        color = thumbColor,
        topLeft = Offset(thumbX - currentWidth / 2f, thumbY - currentHeight / 2f),
        size = Size(currentWidth, currentHeight),
        cornerRadius = CornerRadius(currentWidth / 2f),
      )
    }

    Box(
      modifier = Modifier
        .fillMaxSize()
        .pointerInput(enabled, valueRange, trackEdgePaddingPx) {
          if (!enabled) return@pointerInput
          fun valueForX(rawX: Float): Float {
            val edgePadding = trackEdgePaddingPx.coerceIn(0f, size.width / 2f)
            val trackStart = edgePadding
            val trackEnd = size.width - edgePadding
            val trackWidth = (trackEnd - trackStart).coerceAtLeast(1f)
            val normalized = ((rawX - trackStart) / trackWidth).coerceIn(0f, 1f)
            return valueRange.start + normalized * (valueRange.endInclusive - valueRange.start)
          }

          awaitEachGesture {
            try {
              val down = awaitFirstDown(requireUnconsumed = false)
              isPointerSeeking = true
              down.consume()
              var latestGestureValue = valueForX(down.position.x)
              latestOnValueChange(latestGestureValue)
              lastHapticValue = (latestGestureValue * 20).roundToInt()
              hapticFeedback.performHapticFeedback(HapticFeedbackType.TextHandleMove)

              var pointerId = down.id
              while (true) {
                val event = awaitPointerEvent()
                val change = event.changes.firstOrNull { it.id == pointerId }
                  ?: event.changes.firstOrNull { it.pressed }
                  ?: break
                pointerId = change.id
                if (!change.pressed) {
                  change.consume()
                  break
                }
                if (change.position != change.previousPosition) {
                  change.consume()
                  latestGestureValue = valueForX(change.position.x)
                  latestOnValueChange(latestGestureValue)
                  val tick = (latestGestureValue * 20).roundToInt()
                  if (tick != lastHapticValue) {
                    hapticFeedback.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                    lastHapticValue = tick
                  }
                }
              }
              latestOnValueCommit?.invoke(latestGestureValue)
                ?: latestOnValueChangeFinished?.invoke()
            } finally {
              isPointerSeeking = false
            }
          }
        },
    )
  }
}

/**
 * Convenience wrapper connecting Rhythm's `WaveSlider` directly to millisecond player position.
 */
@Composable
fun RhythmWavySlider(
  valueMs: Long,
  durationMs: Long,
  isPlaying: Boolean,
  onSeekTo: (Long) -> Unit,
  modifier: Modifier = Modifier,
  activeColor: Color = MaterialTheme.colorScheme.primary,
  inactiveColor: Color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.2f),
) {
  val safeDuration = durationMs.coerceAtLeast(1L)
  val rawProgress = (valueMs.toFloat() / safeDuration.toFloat()).coerceIn(0f, 1f)
  var isDragging by remember { mutableStateOf(false) }
  var scrubProgress by remember { mutableFloatStateOf(rawProgress) }

  WaveSlider(
    value = if (isDragging) scrubProgress else rawProgress,
    onValueChange = { next ->
      isDragging = true
      scrubProgress = next
    },
    onValueCommit = { committed ->
      isDragging = false
      onSeekTo((committed * safeDuration).toLong())
    },
    enabled = durationMs > 0L,
    isPlaying = isPlaying,
    activeTrackColor = activeColor,
    inactiveTrackColor = inactiveColor,
    thumbColor = activeColor,
    semanticsLabel = "Thanh tiến trình phát nhạc",
    modifier = modifier,
  )
}
