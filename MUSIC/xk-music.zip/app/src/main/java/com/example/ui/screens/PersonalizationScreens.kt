@file:OptIn(ExperimentalMaterial3Api::class)

package com.example.ui.screens

import android.os.Build
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.SleepTimerUiState
import com.example.ui.AppFontOption
import com.example.ui.AppearanceSettings
import com.example.ui.EqualizerPreset
import com.example.ui.FestiveThemeMode
import com.example.ui.FontScaleOption
import com.example.ui.FormatUtils
import com.example.ui.LyricsAlignment
import com.example.ui.LyricsFontSize
import com.example.ui.NavBarLabelBehavior
import com.example.ui.PersonalizationSection
import com.example.ui.PersonalizationSettings
import com.example.ui.RhythmColorPreset
import com.example.ui.RhythmPaletteStyle
import com.example.ui.ThemeMode
import com.example.ui.components.Material3SettingsGroup
import com.example.ui.components.Material3SettingsItem
import com.example.ui.components.RhythmCollapsibleHeaderScreen
import com.example.ui.components.SettingsPalettes
import com.example.ui.components.horizontalEdgeBlend
import com.example.ui.rhythm.ExpressiveMaterialShape
import com.example.ui.rhythm.RhythmIcons
import com.example.ui.rhythm.RhythmSymbolIcon
import com.example.ui.rhythm.rememberExpressiveShape
import com.example.ui.rhythm.resolveExpressiveShapeEnum
import com.example.ui.theme.MonoNumericStyle
import com.example.ui.theme.fontFamilyForOption
import java.util.Locale
import kotlin.math.roundToInt

@Composable
fun PersonalizationDetailScreen(
  section: PersonalizationSection,
  appearanceSettings: AppearanceSettings,
  personalization: PersonalizationSettings,
  sleepTimerState: SleepTimerUiState,
  bottomOverlayPadding: PaddingValues,
  onBack: () -> Unit,
  onThemeModeChange: (ThemeMode) -> Unit,
  onColorPresetChange: (RhythmColorPreset) -> Unit,
  onAmoledModeChange: (Boolean) -> Unit,
  onDynamicColorChange: (Boolean) -> Unit,
  onPaletteStyleChange: (RhythmPaletteStyle) -> Unit,
  onStartSleepTimer: (Int) -> Unit,
  onStartSleepAfterCurrentTrack: () -> Unit,
  onCancelSleepTimer: () -> Unit,
  onSleepTimerFadeOutChange: (Boolean) -> Unit,
  onPlaybackSpeedChange: (Float) -> Unit,
  onRotateArtworkChange: (Boolean) -> Unit,
  onUseWavySeekbarChange: (Boolean) -> Unit,
  onShowMiniPlayerProgressChange: (Boolean) -> Unit,
  onKeepScreenOnPlayerChange: (Boolean) -> Unit,
  onFontOptionChange: (AppFontOption) -> Unit,
  onFontScaleChange: (FontScaleOption) -> Unit,
  onFloatingNavBarEnabledChange: (Boolean) -> Unit,
  onNavBarLabelBehaviorChange: (NavBarLabelBehavior) -> Unit,
  onShowDetachedSearchFabChange: (Boolean) -> Unit,
  onFestiveThemeModeChange: (FestiveThemeMode) -> Unit,
  onFestiveParticlesEnabledChange: (Boolean) -> Unit,
  onSwipeDownToDismissPlayerChange: (Boolean) -> Unit,
  onSwipeArtworkToSkipChange: (Boolean) -> Unit,
  onTapArtworkForLyricsChange: (Boolean) -> Unit,
  onMiniPlayerGesturesEnabledChange: (Boolean) -> Unit,
  onHapticFeedbackEnabledChange: (Boolean) -> Unit,
  onEqualizerEnabledChange: (Boolean) -> Unit,
  onSelectEqualizerPreset: (EqualizerPreset) -> Unit,
  onSetEqualizerBand: (Int, Float) -> Unit,
  onBassBoostLevelChange: (Int) -> Unit,
  onVirtualizerLevelChange: (Int) -> Unit,
  onLyricsAutoScrollChange: (Boolean) -> Unit,
  onLyricsAlignmentChange: (LyricsAlignment) -> Unit,
  onLyricsFontSizeChange: (LyricsFontSize) -> Unit,
  onLyricsDimInactiveChange: (Boolean) -> Unit,
  onLyricsTapToSeekChange: (Boolean) -> Unit,
  onSkipSilenceEnabledChange: (Boolean) -> Unit = {},
  onShowSeek10sButtonsChange: (Boolean) -> Unit = {},
  onAlbumArtShapeChange: (String) -> Unit = {},
  onSongArtShapeChange: (String) -> Unit = {},
  onPlaylistArtShapeChange: (String) -> Unit = {},
  onMiniPlayerShapeChange: (String) -> Unit = {},
  onResetShapes: () -> Unit = {},
) {
  BackHandler(onBack = onBack)

  RhythmCollapsibleHeaderScreen(
    title = section.title,
    showBackButton = true,
    onBackClick = onBack,
  ) { scaffoldModifier ->
    LazyColumn(
      modifier = scaffoldModifier
        .fillMaxSize()
        .testTag("personalization_detail_list"),
      contentPadding = PaddingValues(
        start = 16.dp,
        end = 16.dp,
        top = 8.dp,
        bottom = bottomOverlayPadding.calculateBottomPadding() + 28.dp,
      ),
      verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
      when (section) {
        PersonalizationSection.SLEEP_TIMER -> {
          item(key = "sleep_timer_detail") {
            SleepTimerPersonalizationContent(
              sleepTimerState = sleepTimerState,
              fadeOutEnabled = personalization.sleepTimerFadeOut,
              onStartSleepTimer = onStartSleepTimer,
              onStartSleepAfterCurrentTrack = onStartSleepAfterCurrentTrack,
              onCancelSleepTimer = onCancelSleepTimer,
              onFadeOutChange = onSleepTimerFadeOutChange,
            )
          }
        }

        PersonalizationSection.PLAYER_CONTROLS -> {
          item(key = "player_controls_detail") {
            PlayerControlsPersonalizationContent(
              personalization = personalization,
              onPlaybackSpeedChange = onPlaybackSpeedChange,
              onRotateArtworkChange = onRotateArtworkChange,
              onUseWavySeekbarChange = onUseWavySeekbarChange,
              onShowMiniPlayerProgressChange = onShowMiniPlayerProgressChange,
              onKeepScreenOnPlayerChange = onKeepScreenOnPlayerChange,
              onSkipSilenceEnabledChange = onSkipSilenceEnabledChange,
              onShowSeek10sButtonsChange = onShowSeek10sButtonsChange,
            )
          }
        }

        PersonalizationSection.COLOR_CUSTOMIZATION -> {
          item(key = "color_customization_detail") {
            ColorCustomizationPersonalizationContent(
              appearanceSettings = appearanceSettings,
              paletteStyle = personalization.paletteStyle,
              onThemeModeChange = onThemeModeChange,
              onColorPresetChange = onColorPresetChange,
              onAmoledModeChange = onAmoledModeChange,
              onDynamicColorChange = onDynamicColorChange,
              onPaletteStyleChange = onPaletteStyleChange,
            )
          }
        }

        PersonalizationSection.SHAPE_CUSTOMIZATION -> {
          item(key = "shape_customization_detail") {
            ShapeCustomizationPersonalizationContent(
              personalization = personalization,
              onAlbumArtShapeChange = onAlbumArtShapeChange,
              onSongArtShapeChange = onSongArtShapeChange,
              onPlaylistArtShapeChange = onPlaylistArtShapeChange,
              onMiniPlayerShapeChange = onMiniPlayerShapeChange,
              onResetShapes = onResetShapes,
            )
          }
        }

        PersonalizationSection.FONT_CUSTOMIZATION -> {
          item(key = "font_customization_detail") {
            FontCustomizationPersonalizationContent(
              fontOption = personalization.fontOption,
              fontScale = personalization.fontScale,
              onFontOptionChange = onFontOptionChange,
              onFontScaleChange = onFontScaleChange,
            )
          }
        }

        PersonalizationSection.FLOATING_NAV_BAR -> {
          item(key = "floating_nav_bar_detail") {
            FloatingNavBarPersonalizationContent(
              personalization = personalization,
              onFloatingNavBarEnabledChange = onFloatingNavBarEnabledChange,
              onNavBarLabelBehaviorChange = onNavBarLabelBehaviorChange,
              onShowDetachedSearchFabChange = onShowDetachedSearchFabChange,
            )
          }
        }

        PersonalizationSection.FESTIVE_THEME -> {
          item(key = "festive_theme_detail") {
            FestiveThemePersonalizationContent(
              festiveThemeMode = personalization.festiveThemeMode,
              festiveParticlesEnabled = personalization.festiveParticlesEnabled,
              onFestiveThemeModeChange = onFestiveThemeModeChange,
              onFestiveParticlesEnabledChange = onFestiveParticlesEnabledChange,
            )
          }
        }

        PersonalizationSection.GESTURES -> {
          item(key = "gestures_detail") {
            GesturesPersonalizationContent(
              personalization = personalization,
              onSwipeDownToDismissPlayerChange = onSwipeDownToDismissPlayerChange,
              onSwipeArtworkToSkipChange = onSwipeArtworkToSkipChange,
              onTapArtworkForLyricsChange = onTapArtworkForLyricsChange,
              onMiniPlayerGesturesEnabledChange = onMiniPlayerGesturesEnabledChange,
              onHapticFeedbackEnabledChange = onHapticFeedbackEnabledChange,
            )
          }
        }

        PersonalizationSection.EQUALIZER -> {
          item(key = "equalizer_detail") {
            EqualizerPersonalizationContent(
              personalization = personalization,
              onEqualizerEnabledChange = onEqualizerEnabledChange,
              onSelectEqualizerPreset = onSelectEqualizerPreset,
              onSetEqualizerBand = onSetEqualizerBand,
              onBassBoostLevelChange = onBassBoostLevelChange,
              onVirtualizerLevelChange = onVirtualizerLevelChange,
            )
          }
        }

        PersonalizationSection.LYRICS -> {
          item(key = "lyrics_detail") {
            LyricsPersonalizationContent(
              personalization = personalization,
              onLyricsAutoScrollChange = onLyricsAutoScrollChange,
              onLyricsAlignmentChange = onLyricsAlignmentChange,
              onLyricsFontSizeChange = onLyricsFontSizeChange,
              onLyricsDimInactiveChange = onLyricsDimInactiveChange,
              onLyricsTapToSeekChange = onLyricsTapToSeekChange,
            )
          }
        }
      }
    }
  }
}

@Composable
fun SleepTimerPersonalizationContent(
  sleepTimerState: SleepTimerUiState,
  fadeOutEnabled: Boolean,
  onStartSleepTimer: (Int) -> Unit,
  onStartSleepAfterCurrentTrack: () -> Unit,
  onCancelSleepTimer: () -> Unit,
  onFadeOutChange: (Boolean) -> Unit,
) {
  var customMinutes by remember { mutableFloatStateOf(30f) }
  val statusLabel = when {
    !sleepTimerState.isActive -> "Đang tắt"
    sleepTimerState.stopAfterCurrentSong -> "Sẽ dừng khi hết bài hiện tại"
    else -> "Còn ${FormatUtils.formatDurationMs(sleepTimerState.remainingSeconds * 1000L)}"
  }

  Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
    Material3SettingsGroup(
      title = "Trạng thái & thiết lập nhanh",
      items = listOf(
        Material3SettingsItem(
          icon = RhythmIcons.SleepTimer,
          title = "Hẹn giờ ngủ",
          subtitle = statusLabel,
          palette = SettingsPalettes.Orange,
          trailingText = if (sleepTimerState.isActive) "ĐANG BẬT" else "TẮT",
          customContent = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
              ) {
                listOf(15, 30, 45, 60).forEach { mins ->
                  FilterChip(
                    selected = false,
                    onClick = { onStartSleepTimer(mins) },
                    label = { Text("${mins}p", style = MonoNumericStyle) },
                    shape = CircleShape,
                    modifier = Modifier
                      .weight(1f)
                      .testTag("sleep_timer_$mins"),
                  )
                }
              }

              Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Row(
                  modifier = Modifier.fillMaxWidth(),
                  horizontalArrangement = Arrangement.SpaceBetween,
                  verticalAlignment = Alignment.CenterVertically,
                ) {
                  Text(
                    text = "Tùy chỉnh thời gian",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                  )
                  Text(
                    text = "${customMinutes.roundToInt()} phút",
                    style = MonoNumericStyle.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.primary,
                  )
                }
                Slider(
                  value = customMinutes,
                  onValueChange = { customMinutes = it },
                  valueRange = 5f..120f,
                  modifier = Modifier.fillMaxWidth(),
                )
              }

              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
              ) {
                Button(
                  onClick = { onStartSleepTimer(customMinutes.roundToInt()) },
                  shape = CircleShape,
                  modifier = Modifier.weight(1f),
                ) {
                  Text("Bắt đầu ${customMinutes.roundToInt()}p", maxLines = 1)
                }
                FilledTonalButton(
                  onClick = onStartSleepAfterCurrentTrack,
                  shape = CircleShape,
                  modifier = Modifier
                    .weight(1f)
                    .testTag("sleep_timer_end_of_track"),
                ) {
                  Text("Hết bài này", maxLines = 1)
                }
              }

              if (sleepTimerState.isActive) {
                OutlinedButton(
                  onClick = onCancelSleepTimer,
                  shape = CircleShape,
                  modifier = Modifier
                    .fillMaxWidth()
                    .testTag("sleep_timer_cancel"),
                ) {
                  Text("Hủy hẹn giờ đang chạy")
                }
              }
            }
          },
        ),
        Material3SettingsItem(
          icon = RhythmIcons.VolumeUp,
          title = "Giảm dần âm lượng khi tắt",
          subtitle = "Âm lượng sẽ dịu dần trong 3 giây cuối trước khi tạm dừng",
          palette = SettingsPalettes.Amber,
          switchChecked = fadeOutEnabled,
          onSwitchChange = onFadeOutChange,
        ),
      ),
    )
  }
}

@Composable
private fun PlayerControlsPersonalizationContent(
  personalization: PersonalizationSettings,
  onPlaybackSpeedChange: (Float) -> Unit,
  onRotateArtworkChange: (Boolean) -> Unit,
  onUseWavySeekbarChange: (Boolean) -> Unit,
  onShowMiniPlayerProgressChange: (Boolean) -> Unit,
  onKeepScreenOnPlayerChange: (Boolean) -> Unit,
  onSkipSilenceEnabledChange: (Boolean) -> Unit,
  @Suppress("UNUSED_PARAMETER") onShowSeek10sButtonsChange: (Boolean) -> Unit,
) {
  val speedText = String.format(Locale.US, "%.2fx", personalization.playbackSpeed)
    .replace(".00x", ".0x")

  Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
    Material3SettingsGroup(
      title = "Tốc độ phát nhạc",
      items = listOf(
        Material3SettingsItem(
          icon = RhythmIcons.Speed,
          title = "Tốc độ phát",
          subtitle = "Điều chỉnh nhịp phát từ 0.5x đến 2.0x",
          palette = SettingsPalettes.SkyBlue,
          trailingText = speedText,
          customContent = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
              Slider(
                value = personalization.playbackSpeed,
                onValueChange = { raw ->
                  val snapped = (raw * 20f).roundToInt() / 20f
                  onPlaybackSpeedChange(snapped)
                },
                valueRange = 0.5f..2.0f,
                modifier = Modifier.fillMaxWidth(),
              )
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
              ) {
                listOf(0.75f, 1.0f, 1.25f, 1.5f, 2.0f).forEach { speed ->
                  val selected = kotlin.math.abs(personalization.playbackSpeed - speed) < 0.03f
                  val label = if (speed == 1.0f || speed == 2.0f) "${speed.toInt()}x" else "${speed}x"
                  FilterChip(
                    selected = selected,
                    onClick = { onPlaybackSpeedChange(speed) },
                    label = { Text(label, style = MonoNumericStyle, maxLines = 1) },
                    shape = CircleShape,
                    modifier = Modifier.weight(1f),
                  )
                }
              }
            }
          },
        ),
      ),
    )

    Material3SettingsGroup(
      title = "Trình phát & hiển thị",
      items = listOf(
        Material3SettingsItem(
          icon = RhythmIcons.AlbumFilled,
          title = "Xoay tròn ảnh bìa đĩa nhạc",
          subtitle = "Hiệu ứng đĩa than xoay tròn khi nhạc đang phát",
          palette = SettingsPalettes.Purple,
          switchChecked = personalization.rotateArtwork,
          onSwitchChange = onRotateArtworkChange,
        ),
        Material3SettingsItem(
          icon = RhythmIcons.GraphicEq,
          title = "Thanh tua dạng sóng Rhythm",
          subtitle = "Sử dụng thanh tua gợn sóng Expressive thay cho thanh thẳng",
          palette = SettingsPalettes.Indigo,
          switchChecked = personalization.useWavySeekbar,
          onSwitchChange = onUseWavySeekbarChange,
        ),
        Material3SettingsItem(
          icon = RhythmIcons.Player.Stop,
          title = "Bỏ qua khoảng lặng (Skip Silence)",
          subtitle = "Tự động rút ngắn các đoạn im lặng kéo dài trong bản thu",
          palette = SettingsPalettes.Coral,
          switchChecked = personalization.skipSilenceEnabled,
          onSwitchChange = onSkipSilenceEnabledChange,
          testTag = "switch_skip_silence",
        ),
        Material3SettingsItem(
          icon = RhythmIcons.Tune,
          title = "Thanh tiến trình trên Mini Player",
          subtitle = "Hiển thị nền tiến độ chạy theo bài hát ở thanh phát thu gọn",
          palette = SettingsPalettes.Emerald,
          switchChecked = personalization.showMiniPlayerProgress,
          onSwitchChange = onShowMiniPlayerProgressChange,
        ),
        Material3SettingsItem(
          icon = RhythmIcons.LightMode,
          title = "Giữ màn hình luôn sáng",
          subtitle = "Ngăn tắt màn hình khi đang mở giao diện phát nhạc",
          palette = SettingsPalettes.Orange,
          switchChecked = personalization.keepScreenOnPlayer,
          onSwitchChange = onKeepScreenOnPlayerChange,
        ),
      ),
    )
  }
}

@Composable
private fun ShapeCustomizationPersonalizationContent(
  personalization: PersonalizationSettings,
  onAlbumArtShapeChange: (String) -> Unit,
  onSongArtShapeChange: (String) -> Unit,
  onPlaylistArtShapeChange: (String) -> Unit,
  onMiniPlayerShapeChange: (String) -> Unit,
  onResetShapes: () -> Unit,
) {
  val expressiveOptions = remember {
    listOf(
      ExpressiveMaterialShape.CIRCLE,
      ExpressiveMaterialShape.SQUARE,
      ExpressiveMaterialShape.PILL,
      ExpressiveMaterialShape.GHOSTISH,
      ExpressiveMaterialShape.COOKIE_4,
      ExpressiveMaterialShape.COOKIE_7,
      ExpressiveMaterialShape.COOKIE_9,
      ExpressiveMaterialShape.COOKIE_12,
      ExpressiveMaterialShape.CLOVER_4_LEAF,
      ExpressiveMaterialShape.CLOVER_8_LEAF,
      ExpressiveMaterialShape.FLOWER,
      ExpressiveMaterialShape.SUNNY,
      ExpressiveMaterialShape.HEART,
      ExpressiveMaterialShape.PUFFY,
      ExpressiveMaterialShape.ARCH,
      ExpressiveMaterialShape.GEM,
      ExpressiveMaterialShape.PIXEL_CIRCLE,
    )
  }

  @Composable
  fun ShapeSelectorRow(
    selectedShapeId: String,
    fallback: ExpressiveMaterialShape,
    testTagPrefix: String,
    onSelect: (String) -> Unit,
  ) {
    val rowState = rememberLazyListState()
    val current = resolveExpressiveShapeEnum(selectedShapeId, fallback)
    LazyRow(
      state = rowState,
      modifier = Modifier.horizontalEdgeBlend(rowState),
      horizontalArrangement = Arrangement.spacedBy(10.dp),
    ) {
      items(expressiveOptions, key = { "${testTagPrefix}_${it.name}" }) { shapeEnum ->
        val isSelected = current == shapeEnum
        val composeShape = rememberExpressiveShape(shapeEnum)
        Column(
          horizontalAlignment = Alignment.CenterHorizontally,
          verticalArrangement = Arrangement.spacedBy(4.dp),
          modifier = Modifier
            .width(68.dp)
            .clip(RoundedCornerShape(14.dp))
            .clickable { onSelect(shapeEnum.name) }
            .padding(vertical = 4.dp)
            .testTag("${testTagPrefix}_${shapeEnum.name.lowercase()}"),
        ) {
          Surface(
            shape = composeShape,
            color = if (isSelected) {
              MaterialTheme.colorScheme.primaryContainer
            } else {
              MaterialTheme.colorScheme.surfaceContainerHighest
            },
            modifier = Modifier
              .size(46.dp)
              .then(
                if (isSelected) {
                  Modifier.border(2.dp, MaterialTheme.colorScheme.primary, composeShape)
                } else {
                  Modifier
                },
              ),
          ) {
            Box(contentAlignment = Alignment.Center) {
              if (isSelected) {
                RhythmSymbolIcon(
                  icon = RhythmIcons.Check,
                  contentDescription = shapeEnum.displayName,
                  tint = MaterialTheme.colorScheme.onPrimaryContainer,
                  size = 18.dp,
                  modifier = Modifier.size(18.dp),
                )
              }
            }
          }
          Text(
            text = shapeEnum.displayName,
            style = MaterialTheme.typography.labelSmall,
            color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            textAlign = TextAlign.Center,
          )
        }
      }
    }
  }

  Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
    Material3SettingsGroup(
      title = "Hình dáng biểu cảm Material 3 Expressive",
      items = listOf(
        Material3SettingsItem(
          icon = RhythmIcons.AlbumFilled,
          title = "Hình dáng ảnh Album",
          subtitle = resolveExpressiveShapeEnum(personalization.albumArtShapeId, ExpressiveMaterialShape.GHOSTISH).displayName,
          palette = SettingsPalettes.Purple,
          customContent = {
            ShapeSelectorRow(
              selectedShapeId = personalization.albumArtShapeId,
              fallback = ExpressiveMaterialShape.GHOSTISH,
              testTagPrefix = "shape_album",
              onSelect = onAlbumArtShapeChange,
            )
          },
        ),
        Material3SettingsItem(
          icon = RhythmIcons.MusicNote,
          title = "Hình dáng ảnh Bài hát",
          subtitle = resolveExpressiveShapeEnum(personalization.songArtShapeId, ExpressiveMaterialShape.CLOVER_8_LEAF).displayName,
          palette = SettingsPalettes.Indigo,
          customContent = {
            ShapeSelectorRow(
              selectedShapeId = personalization.songArtShapeId,
              fallback = ExpressiveMaterialShape.CLOVER_8_LEAF,
              testTagPrefix = "shape_song",
              onSelect = onSongArtShapeChange,
            )
          },
        ),
        Material3SettingsItem(
          icon = RhythmIcons.Playlist,
          title = "Hình dáng ảnh Playlist",
          subtitle = resolveExpressiveShapeEnum(personalization.playlistArtShapeId, ExpressiveMaterialShape.CLOVER_4_LEAF).displayName,
          palette = SettingsPalettes.Teal,
          customContent = {
            ShapeSelectorRow(
              selectedShapeId = personalization.playlistArtShapeId,
              fallback = ExpressiveMaterialShape.CLOVER_4_LEAF,
              testTagPrefix = "shape_playlist",
              onSelect = onPlaylistArtShapeChange,
            )
          },
        ),
        Material3SettingsItem(
          icon = RhythmIcons.PlayCircle,
          title = "Hình dáng ảnh Mini Player",
          subtitle = resolveExpressiveShapeEnum(personalization.miniPlayerShapeId, ExpressiveMaterialShape.COOKIE_4).displayName,
          palette = SettingsPalettes.SkyBlue,
          customContent = {
            ShapeSelectorRow(
              selectedShapeId = personalization.miniPlayerShapeId,
              fallback = ExpressiveMaterialShape.COOKIE_4,
              testTagPrefix = "shape_mini",
              onSelect = onMiniPlayerShapeChange,
            )
          },
        ),
      ),
    )

    OutlinedButton(
      onClick = onResetShapes,
      shape = CircleShape,
      modifier = Modifier
        .fillMaxWidth()
        .testTag("reset_shapes_button"),
    ) {
      RhythmSymbolIcon(
        icon = RhythmIcons.Actions.Restore,
        contentDescription = null,
        size = 18.dp,
        modifier = Modifier.size(18.dp),
      )
      Spacer(Modifier.width(8.dp))
      Text("Khôi phục hình dáng mặc định Rhythm")
    }
  }
}

@Composable
private fun ColorCustomizationPersonalizationContent(
  appearanceSettings: AppearanceSettings,
  paletteStyle: RhythmPaletteStyle,
  onThemeModeChange: (ThemeMode) -> Unit,
  onColorPresetChange: (RhythmColorPreset) -> Unit,
  onAmoledModeChange: (Boolean) -> Unit,
  onDynamicColorChange: (Boolean) -> Unit,
  onPaletteStyleChange: (RhythmPaletteStyle) -> Unit,
) {
  val itemsList = buildList {
    add(
      Material3SettingsItem(
        icon = RhythmIcons.DarkMode,
        title = "Chế độ chủ đề",
        subtitle = "Hệ thống - Ánh sáng - Bóng tối",
        palette = SettingsPalettes.Purple,
        trailingText = appearanceSettings.themeMode.label,
        customContent = {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
          ) {
            ThemeMode.entries.forEach { mode ->
              FilterChip(
                selected = appearanceSettings.themeMode == mode,
                onClick = { onThemeModeChange(mode) },
                label = { Text(mode.label, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                shape = CircleShape,
                colors = FilterChipDefaults.filterChipColors(
                  selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                  selectedLabelColor = MaterialTheme.colorScheme.onPrimaryContainer,
                ),
                modifier = Modifier.weight(1f),
              )
            }
          }
        },
      ),
    )

    add(
      Material3SettingsItem(
        icon = RhythmIcons.Palette,
        title = "Bảng màu chủ đạo",
        subtitle = appearanceSettings.colorPreset.label,
        palette = SettingsPalettes.Rose,
        customContent = {
          val presetRowState = rememberLazyListState()
          LazyRow(
            state = presetRowState,
            modifier = Modifier.horizontalEdgeBlend(presetRowState),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
          ) {
            items(RhythmColorPreset.entries) { preset ->
              val selected = appearanceSettings.colorPreset == preset
              val swatchColor = Color(preset.seedHex)
              Box(
                modifier = Modifier
                  .size(42.dp)
                  .clip(CircleShape)
                  .background(swatchColor)
                  .border(
                    width = if (selected) 3.dp else 1.dp,
                    color = if (selected) MaterialTheme.colorScheme.onSurface else Color.White.copy(alpha = 0.2f),
                    shape = CircleShape,
                  )
                  .clickable { onColorPresetChange(preset) }
                  .testTag("preset_${preset.name.lowercase()}"),
                contentAlignment = Alignment.Center,
              ) {
                if (selected) {
                  RhythmSymbolIcon(
                    icon = RhythmIcons.Check,
                    contentDescription = preset.label,
                    tint = Color.White,
                    size = 18.dp,
                    modifier = Modifier.size(18.dp),
                  )
                }
              }
            }
          }
        },
      ),
    )

    add(
      Material3SettingsItem(
        icon = RhythmIcons.AutoAwesome,
        title = "Phong cách phối màu Material 3",
        subtitle = paletteStyle.label,
        palette = SettingsPalettes.Indigo,
        customContent = {
          val styleRowState = rememberLazyListState()
          LazyRow(
            state = styleRowState,
            modifier = Modifier.horizontalEdgeBlend(styleRowState),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
          ) {
            items(RhythmPaletteStyle.entries) { style ->
              FilterChip(
                selected = paletteStyle == style,
                onClick = { onPaletteStyleChange(style) },
                label = { Text(style.label, maxLines = 1) },
                shape = CircleShape,
                modifier = Modifier.testTag("palette_style_${style.name.lowercase()}"),
              )
            }
          }
        },
      ),
    )

    add(
      Material3SettingsItem(
        icon = RhythmIcons.Contrast,
        title = "Chế độ AMOLED đen thuần",
        subtitle = "Nền đen tuyệt đối cho màn hình OLED khi bật Bóng tối",
        palette = SettingsPalettes.Amber,
        switchChecked = appearanceSettings.amoledMode,
        onSwitchChange = onAmoledModeChange,
      ),
    )

    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
      add(
        Material3SettingsItem(
          icon = RhythmIcons.ColorLens,
          title = "Màu động Material You",
          subtitle = "Lấy màu nhấn từ hình nền thiết bị (Android 12+)",
          palette = SettingsPalettes.SkyBlue,
          switchChecked = appearanceSettings.useDynamicColor,
          onSwitchChange = onDynamicColorChange,
        ),
      )
    }
  }

  Material3SettingsGroup(
    title = "Màu sắc & phong cách Material You",
    items = itemsList,
  )
}

@Composable
private fun FontCustomizationPersonalizationContent(
  fontOption: AppFontOption,
  fontScale: FontScaleOption,
  onFontOptionChange: (AppFontOption) -> Unit,
  onFontScaleChange: (FontScaleOption) -> Unit,
) {
  val previewFamily = remember(fontOption) { fontFamilyForOption(fontOption) }

  Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
    Card(
      shape = RoundedCornerShape(24.dp),
      colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.55f)),
      elevation = CardDefaults.cardElevation(defaultElevation = 0.dp),
      modifier = Modifier
        .fillMaxWidth()
        .testTag("font_preview_card"),
    ) {
      Column(
        modifier = Modifier.padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp),
      ) {
        Text(
          text = "Xem trước: ${fontOption.label} (${fontScale.label})",
          style = MaterialTheme.typography.labelLarge.copy(
            fontFamily = previewFamily,
            fontWeight = FontWeight.Bold,
          ),
          color = MaterialTheme.colorScheme.primary,
        )
        Text(
          text = "Âm nhạc chạm tới từng cung bậc cảm xúc — XuanKen Music",
          style = MaterialTheme.typography.titleLarge.copy(
            fontFamily = previewFamily,
            fontSize = (20f * fontScale.scale).sp,
            lineHeight = (26f * fontScale.scale).sp,
          ),
          color = MaterialTheme.colorScheme.onSurface,
        )
        Text(
          text = "Tiếng Việt có dấu, nhịp điệu 03:45 & danh sách phát cá nhân.",
          style = MaterialTheme.typography.bodyMedium.copy(
            fontFamily = previewFamily,
            fontSize = (14f * fontScale.scale).sp,
          ),
          color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
      }
    }

    Material3SettingsGroup(
      title = "Cỡ chữ toàn ứng dụng",
      items = listOf(
        Material3SettingsItem(
          icon = RhythmIcons.TextFields,
          title = "Tỷ lệ kích thước chữ",
          subtitle = "Áp dụng đồng bộ cho tiêu đề, danh sách và lời bài hát",
          palette = SettingsPalettes.SkyBlue,
          trailingText = fontScale.label,
          customContent = {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.spacedBy(6.dp),
            ) {
              FontScaleOption.entries.forEach { scaleOption ->
                FilterChip(
                  selected = fontScale == scaleOption,
                  onClick = { onFontScaleChange(scaleOption) },
                  label = { Text(scaleOption.label, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                  shape = CircleShape,
                  modifier = Modifier
                    .weight(1f)
                    .testTag("font_scale_${scaleOption.name.lowercase()}"),
                )
              }
            }
          },
        ),
      ),
    )

    Material3SettingsGroup(
      title = "Chọn họ font chữ",
      items = AppFontOption.entries.map { option ->
        val selected = fontOption == option
        Material3SettingsItem(
          icon = RhythmIcons.TextFields,
          title = option.label,
          subtitle = option.sampleSubtitle,
          palette = if (selected) SettingsPalettes.Indigo else SettingsPalettes.Slate,
          trailingText = if (selected) "Đang dùng" else null,
          onClick = { onFontOptionChange(option) },
          testTag = "font_option_${option.name.lowercase()}",
          customContent = {
            Text(
              text = "Khúc nhạc đêm mưa • Rhythm Expressive",
              style = MaterialTheme.typography.bodyMedium.copy(
                fontFamily = fontFamilyForOption(option),
                fontWeight = FontWeight.Medium,
              ),
              color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
          },
        )
      },
    )
  }
}

@Composable
private fun FloatingNavBarPersonalizationContent(
  personalization: PersonalizationSettings,
  onFloatingNavBarEnabledChange: (Boolean) -> Unit,
  onNavBarLabelBehaviorChange: (NavBarLabelBehavior) -> Unit,
  onShowDetachedSearchFabChange: (Boolean) -> Unit,
) {
  Material3SettingsGroup(
    title = "Thanh điều hướng dưới cùng",
    items = listOf(
      Material3SettingsItem(
        icon = RhythmIcons.Smartphone,
        title = "Bật Floating Navigation Bar",
        subtitle = "Hiển thị thanh viên thuốc nổi kiểu Rhythm Expressive thay cho thanh gắn đáy chuẩn",
        palette = SettingsPalettes.Cyan,
        switchChecked = personalization.floatingNavBarEnabled,
        onSwitchChange = onFloatingNavBarEnabledChange,
        testTag = "switch_floating_nav_bar",
      ),
      Material3SettingsItem(
        icon = RhythmIcons.TextFields,
        title = "Hiển thị nhãn tab điều hướng",
        subtitle = personalization.navBarLabelBehavior.label,
        palette = SettingsPalettes.Indigo,
        customContent = {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
          ) {
            NavBarLabelBehavior.entries.forEach { behavior ->
              FilterChip(
                selected = personalization.navBarLabelBehavior == behavior,
                onClick = { onNavBarLabelBehaviorChange(behavior) },
                label = { Text(behavior.label, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                shape = CircleShape,
                modifier = Modifier.weight(1f),
              )
            }
          }
        },
      ),
      Material3SettingsItem(
        icon = RhythmIcons.SearchFilled,
        title = "Nút Tìm kiếm tròn tách rời",
        subtitle = "Đặt nút Tìm kiếm dạng FAB bên phải thanh Floating Nav Bar",
        palette = SettingsPalettes.Emerald,
        switchChecked = personalization.showDetachedSearchFab,
        onSwitchChange = onShowDetachedSearchFabChange,
      ),
    ),
  )
}

@Composable
private fun FestiveThemePersonalizationContent(
  festiveThemeMode: FestiveThemeMode,
  festiveParticlesEnabled: Boolean,
  onFestiveThemeModeChange: (FestiveThemeMode) -> Unit,
  onFestiveParticlesEnabledChange: (Boolean) -> Unit,
) {
  Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
    Material3SettingsGroup(
      title = "Hiệu ứng không khí lễ hội",
      items = listOf(
        Material3SettingsItem(
          icon = RhythmIcons.Celebration,
          title = "Hạt ánh sáng & tuyết rơi nhẹ",
          subtitle = "Hiệu ứng hạt chuyển động dịu mắt phía trên giao diện khi bật chủ đề lễ hội",
          palette = SettingsPalettes.Amber,
          switchChecked = festiveParticlesEnabled,
          onSwitchChange = onFestiveParticlesEnabledChange,
        ),
      ),
    )

    Material3SettingsGroup(
      title = "Chọn chủ đề lễ hội",
      items = FestiveThemeMode.entries.map { mode ->
        val selected = festiveThemeMode == mode
        Material3SettingsItem(
          icon = if (mode == FestiveThemeMode.NONE) RhythmIcons.Contrast else RhythmIcons.Celebration,
          title = mode.label,
          subtitle = mode.description,
          palette = if (selected) SettingsPalettes.Coral else SettingsPalettes.Slate,
          trailingText = if (selected) "Đang chọn" else null,
          onClick = { onFestiveThemeModeChange(mode) },
          testTag = "festive_${mode.name.lowercase()}",
        )
      },
    )
  }
}

@Composable
private fun GesturesPersonalizationContent(
  personalization: PersonalizationSettings,
  onSwipeDownToDismissPlayerChange: (Boolean) -> Unit,
  onSwipeArtworkToSkipChange: (Boolean) -> Unit,
  onTapArtworkForLyricsChange: (Boolean) -> Unit,
  onMiniPlayerGesturesEnabledChange: (Boolean) -> Unit,
  onHapticFeedbackEnabledChange: (Boolean) -> Unit,
) {
  Material3SettingsGroup(
    title = "Thao tác chạm & vuốt",
    items = listOf(
      Material3SettingsItem(
        icon = RhythmIcons.KeyboardArrowDown,
        title = "Vuốt xuống để thu gọn trình phát",
        subtitle = "Kéo xuống trên màn hình phát nhạc để quay về trang trước",
        palette = SettingsPalettes.Purple,
        switchChecked = personalization.swipeDownToDismissPlayer,
        onSwitchChange = onSwipeDownToDismissPlayerChange,
      ),
      Material3SettingsItem(
        icon = RhythmIcons.TouchApp,
        title = "Vuốt ảnh bìa để chuyển bài",
        subtitle = "Vuốt trái để qua bài kế tiếp, vuốt phải để lùi về bài trước",
        palette = SettingsPalettes.SkyBlue,
        switchChecked = personalization.swipeArtworkToSkip,
        onSwitchChange = onSwipeArtworkToSkipChange,
      ),
      Material3SettingsItem(
        icon = RhythmIcons.Lyrics,
        title = "Chạm ảnh bìa để mở lời bài hát",
        subtitle = "Chuyển nhanh giữa đĩa nhạc tròn và bảng lời đồng bộ",
        palette = SettingsPalettes.Indigo,
        switchChecked = personalization.tapArtworkForLyrics,
        onSwitchChange = onTapArtworkForLyricsChange,
      ),
      Material3SettingsItem(
        icon = RhythmIcons.PlayCircle,
        title = "Cử chỉ trên Mini Player",
        subtitle = "Vuốt ngang chuyển bài, vuốt lên mở toàn màn hình, vuốt xuống tắt phát",
        palette = SettingsPalettes.Teal,
        switchChecked = personalization.miniPlayerGesturesEnabled,
        onSwitchChange = onMiniPlayerGesturesEnabledChange,
      ),
      Material3SettingsItem(
        icon = RhythmIcons.Tune,
        title = "Phản hồi rung (Haptic Feedback)",
        subtitle = "Rung nhẹ khi chạm điều khiển, chuyển tab hoặc thao tác vuốt",
        palette = SettingsPalettes.Amber,
        switchChecked = personalization.hapticFeedbackEnabled,
        onSwitchChange = onHapticFeedbackEnabledChange,
      ),
    ),
  )
}

@Composable
private fun EqualizerPersonalizationContent(
  personalization: PersonalizationSettings,
  onEqualizerEnabledChange: (Boolean) -> Unit,
  onSelectEqualizerPreset: (EqualizerPreset) -> Unit,
  onSetEqualizerBand: (Int, Float) -> Unit,
  onBassBoostLevelChange: (Int) -> Unit,
  onVirtualizerLevelChange: (Int) -> Unit,
) {
  val bandLabels = listOf("60 Hz", "230 Hz", "910 Hz", "3.6 kHz", "14 kHz")
  val bands = remember(personalization.equalizerBandsDb) {
    List(5) { idx -> personalization.equalizerBandsDb.getOrElse(idx) { 0f } }
  }

  Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
    Material3SettingsGroup(
      title = "Bộ xử lý âm thanh hệ thống",
      items = listOf(
        Material3SettingsItem(
          icon = RhythmIcons.Equalizer,
          title = "Bật Bộ chỉnh âm (Equalizer)",
          subtitle = if (personalization.equalizerEnabled) {
            "Đang áp dụng: ${personalization.equalizerPreset.label}"
          } else {
            "Đang tắt — sử dụng âm thanh nguyên bản"
          },
          palette = SettingsPalettes.Indigo,
          switchChecked = personalization.equalizerEnabled,
          onSwitchChange = onEqualizerEnabledChange,
          testTag = "switch_equalizer_enabled",
          customContent = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
              val presetListState = rememberLazyListState()
              LazyRow(
                state = presetListState,
                modifier = Modifier.horizontalEdgeBlend(presetListState),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
              ) {
                items(EqualizerPreset.entries) { preset ->
                  FilterChip(
                    selected = personalization.equalizerPreset == preset,
                    onClick = { onSelectEqualizerPreset(preset) },
                    label = { Text(preset.label, maxLines = 1) },
                    shape = CircleShape,
                    modifier = Modifier.testTag("eq_preset_${preset.name.lowercase()}"),
                  )
                }
              }

              bandLabels.forEachIndexed { index, freqLabel ->
                val gainDb = bands[index]
                Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                  Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                  ) {
                    Text(
                      text = freqLabel,
                      style = MonoNumericStyle.copy(fontWeight = FontWeight.SemiBold),
                      color = MaterialTheme.colorScheme.onSurface,
                    )
                    Text(
                      text = String.format(Locale.US, "%+.1f dB", gainDb),
                      style = MonoNumericStyle,
                      color = MaterialTheme.colorScheme.primary,
                    )
                  }
                  Slider(
                    value = gainDb,
                    onValueChange = { onSetEqualizerBand(index, (it * 2f).roundToInt() / 2f) },
                    valueRange = -12f..12f,
                    enabled = personalization.equalizerEnabled,
                    colors = SliderDefaults.colors(
                      thumbColor = MaterialTheme.colorScheme.primary,
                      activeTrackColor = MaterialTheme.colorScheme.primary,
                    ),
                    modifier = Modifier.fillMaxWidth(),
                  )
                }
              }

              OutlinedButton(
                onClick = {
                  onSelectEqualizerPreset(EqualizerPreset.FLAT)
                  onBassBoostLevelChange(0)
                  onVirtualizerLevelChange(0)
                },
                shape = CircleShape,
                modifier = Modifier.fillMaxWidth(),
              ) {
                Text("Đặt lại mặc định (Flat)")
              }
            }
          },
        ),
        Material3SettingsItem(
          icon = RhythmIcons.VolumeUp,
          title = "Tăng âm trầm (Bass Boost)",
          subtitle = "Tăng độ sâu dải trầm cho loa & tai nghe",
          palette = SettingsPalettes.Orange,
          trailingText = "${(personalization.bassBoostLevel / 10)}%",
          customContent = {
            Slider(
              value = personalization.bassBoostLevel.toFloat(),
              onValueChange = { onBassBoostLevelChange(it.roundToInt()) },
              valueRange = 0f..1000f,
              enabled = personalization.equalizerEnabled,
              modifier = Modifier.fillMaxWidth(),
            )
          },
        ),
        Material3SettingsItem(
          icon = RhythmIcons.GraphicEq,
          title = "Hiệu ứng không gian (Virtualizer)",
          subtitle = "Mở rộng âm trường vòm 3D nhẹ nhàng",
          palette = SettingsPalettes.Teal,
          trailingText = "${(personalization.virtualizerLevel / 10)}%",
          customContent = {
            Slider(
              value = personalization.virtualizerLevel.toFloat(),
              onValueChange = { onVirtualizerLevelChange(it.roundToInt()) },
              valueRange = 0f..1000f,
              enabled = personalization.equalizerEnabled,
              modifier = Modifier.fillMaxWidth(),
            )
          },
        ),
      ),
    )
  }
}

@Composable
private fun LyricsPersonalizationContent(
  personalization: PersonalizationSettings,
  onLyricsAutoScrollChange: (Boolean) -> Unit,
  onLyricsAlignmentChange: (LyricsAlignment) -> Unit,
  onLyricsFontSizeChange: (LyricsFontSize) -> Unit,
  onLyricsDimInactiveChange: (Boolean) -> Unit,
  onLyricsTapToSeekChange: (Boolean) -> Unit,
) {
  val textAlign = when (personalization.lyricsAlignment) {
    LyricsAlignment.START -> TextAlign.Start
    LyricsAlignment.CENTER -> TextAlign.Center
    LyricsAlignment.END -> TextAlign.End
  }

  Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
    Card(
      shape = RoundedCornerShape(24.dp),
      colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerHigh),
      elevation = CardDefaults.cardElevation(defaultElevation = 0.dp),
      modifier = Modifier
        .fillMaxWidth()
        .testTag("lyrics_preview_card"),
    ) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
      ) {
        Text(
          text = "Dòng lời trước đã qua",
          style = MaterialTheme.typography.titleMedium.copy(
            fontSize = (18f * personalization.lyricsFontSize.scale).sp,
          ),
          color = MaterialTheme.colorScheme.onSurface.copy(
            alpha = if (personalization.lyricsDimInactive) 0.36f else 0.78f,
          ),
          textAlign = textAlign,
          modifier = Modifier.fillMaxWidth(),
        )
        Text(
          text = "Câu hát đang phát nổi bật rõ nét",
          style = MaterialTheme.typography.titleLarge.copy(
            fontWeight = FontWeight.Bold,
            fontSize = (21f * personalization.lyricsFontSize.scale).sp,
          ),
          color = MaterialTheme.colorScheme.primary,
          textAlign = textAlign,
          modifier = Modifier.fillMaxWidth(),
        )
        Text(
          text = "Và nhịp tiếp theo đang chờ cất lên",
          style = MaterialTheme.typography.titleMedium.copy(
            fontSize = (18f * personalization.lyricsFontSize.scale).sp,
          ),
          color = MaterialTheme.colorScheme.onSurface.copy(
            alpha = if (personalization.lyricsDimInactive) 0.36f else 0.78f,
          ),
          textAlign = textAlign,
          modifier = Modifier.fillMaxWidth(),
        )
      }
    }

    Material3SettingsGroup(
      title = "Hiển thị lời bài hát đồng bộ",
      items = listOf(
        Material3SettingsItem(
          icon = RhythmIcons.Lyrics,
          title = "Căn lề lời bài hát",
          subtitle = personalization.lyricsAlignment.label,
          palette = SettingsPalettes.Purple,
          customContent = {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
              LyricsAlignment.entries.forEach { align ->
                FilterChip(
                  selected = personalization.lyricsAlignment == align,
                  onClick = { onLyricsAlignmentChange(align) },
                  label = { Text(align.label, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                  shape = CircleShape,
                  modifier = Modifier.weight(1f),
                )
              }
            }
          },
        ),
        Material3SettingsItem(
          icon = RhythmIcons.TextFields,
          title = "Kích thước chữ lời bài hát",
          subtitle = personalization.lyricsFontSize.label,
          palette = SettingsPalettes.SkyBlue,
          customContent = {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.spacedBy(6.dp),
            ) {
              LyricsFontSize.entries.forEach { size ->
                FilterChip(
                  selected = personalization.lyricsFontSize == size,
                  onClick = { onLyricsFontSizeChange(size) },
                  label = { Text(size.label, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                  shape = CircleShape,
                  modifier = Modifier.weight(1f),
                )
              }
            }
          },
        ),
        Material3SettingsItem(
          icon = RhythmIcons.Play,
          title = "Tự động cuộn theo tiến trình",
          subtitle = "Luôn giữ câu hát hiện tại ở vị trí dễ nhìn nhất",
          palette = SettingsPalettes.Emerald,
          switchChecked = personalization.lyricsAutoScroll,
          onSwitchChange = onLyricsAutoScrollChange,
        ),
        Material3SettingsItem(
          icon = RhythmIcons.TouchApp,
          title = "Chạm câu hát để tua nhanh",
          subtitle = "Nhấn vào bất kỳ dòng có mốc thời gian để phát tại đoạn đó",
          palette = SettingsPalettes.Indigo,
          switchChecked = personalization.lyricsTapToSeek,
          onSwitchChange = onLyricsTapToSeekChange,
        ),
        Material3SettingsItem(
          icon = RhythmIcons.Contrast,
          title = "Làm mờ các dòng chưa tới",
          subtitle = "Tăng độ tương phản cho câu hát đang phát",
          palette = SettingsPalettes.Slate,
          switchChecked = personalization.lyricsDimInactive,
          onSwitchChange = onLyricsDimInactiveChange,
        ),
      ),
    )
  }
}
