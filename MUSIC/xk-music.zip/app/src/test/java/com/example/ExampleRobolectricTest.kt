package com.example

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color as AndroidColor
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.LibraryMusic
import androidx.compose.material.icons.rounded.DarkMode
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.LibraryMusic
import androidx.compose.material.icons.rounded.Lyrics
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.toArgb
import androidx.activity.OnBackPressedDispatcher
import androidx.activity.compose.LocalOnBackPressedDispatcherOwner
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.getUnclippedBoundsInRoot
import androidx.compose.ui.test.hasTestTag
import androidx.compose.ui.test.hasText
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performScrollTo
import androidx.compose.ui.test.performScrollToNode
import androidx.compose.ui.unit.dp
import androidx.test.core.app.ApplicationProvider
import com.example.data.network.XkJsonParser
import com.example.model.Album
import com.example.model.Artist
import com.example.model.AuthSession
import com.example.model.ChartSection
import com.example.model.ListeningStats
import com.example.model.Playlist
import com.example.model.PurchaseRecord
import com.example.model.SleepTimerUiState
import com.example.model.Song
import com.example.model.UserProfile
import com.example.player.PlaybackUiState
import com.example.ui.ActiveTrackMeta
import com.example.ui.AppearanceSettings
import com.example.ui.AuthUiState
import com.example.ui.DetailLoadState
import com.example.ui.DiscoverUiState
import com.example.ui.EqualizerPreset
import com.example.ui.ExploreUiState
import com.example.ui.PersonalizationSection
import com.example.ui.PersonalizationSettings
import com.example.ui.RhythmColorPreset
import com.example.ui.ThemeMode
import com.example.ui.components.Material3SettingsGroup
import com.example.ui.components.Material3SettingsItem
import com.example.ui.components.MiniPlayerBar
import com.example.ui.components.NowPlayingSheet
import com.example.ui.components.RhythmExpressiveCapsulePlayButton
import com.example.ui.components.RhythmFloatingNavBarWithSearch
import com.example.ui.components.RhythmMorphingPlayPauseButton
import com.example.ui.components.RhythmNavItem
import com.example.ui.components.RhythmPlayButton
import com.example.ui.components.RhythmScallopedPolygonButton
import com.example.ui.components.RhythmSegmentedDockButton
import com.example.ui.components.RhythmSegmentedDockRow
import com.example.ui.components.RhythmWavySlider
import com.example.ui.components.SettingsPalettes
import com.example.ui.components.SongRowItem
import com.example.ui.screens.AlbumDetailScreen
import com.example.ui.screens.AllArtistsScreen
import com.example.ui.screens.ChartsScreen
import com.example.ui.screens.DiscoverScreen
import com.example.ui.screens.ExploreScreen
import com.example.ui.screens.LibraryScreen
import com.example.ui.screens.PersonalizationDetailScreen
import com.example.ui.screens.ProfileScreen
import androidx.compose.ui.test.onAllNodesWithText
import androidx.compose.ui.test.onNodeWithContentDescription
import com.example.ui.theme.RhythmColorExtractor
import com.example.ui.theme.XkMusicTheme
import androidx.core.graphics.ColorUtils
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @get:Rule
  val composeTestRule = createComposeRule()

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    assertEquals("XK Music", context.getString(R.string.app_name))
    assertEquals("Cá nhân", context.getString(R.string.nav_profile))
  }

  @Test
  fun `parseAuthSession parses api and firebase responses`() {
    val apiJson = """
      {
        "idToken": "tok_123",
        "refreshToken": "ref_456",
        "expiresIn": 3600,
        "user": {
          "uid": "u_01",
          "email": "fan@xuanken.name.vn",
          "displayName": "Xuan Ken Fan",
          "balance": 250000
        }
      }
    """.trimIndent()
    val session = XkJsonParser.parseAuthSession(apiJson)
    assertNotNull(session)
    assertEquals("tok_123", session?.idToken)
    assertEquals("ref_456", session?.refreshToken)
    assertEquals("u_01", session?.user?.uid)
    assertEquals("Xuan Ken Fan", session?.user?.displayName)
    assertEquals(250000L, session?.user?.balance)
  }

  @Test
  fun `parseUserProfile handles array and RTDB object map for purchasedSongIds`() {
    val memberJson = """
      {
        "uid": "u_01",
        "email": "fan@xuanken.name.vn",
        "displayName": "Fan",
        "purchasedSongIds": { "song_a": true, "song_b": true, "song_removed": false },
        "likedSongIds": ["song_a"]
      }
    """.trimIndent()
    val profile = XkJsonParser.parseUserProfile(memberJson)
    assertNotNull(profile)
    assertEquals(listOf("song_a", "song_b"), profile?.purchasedSongIds)
    assertEquals(listOf("song_a"), profile?.likedSongIds)
  }

  @Test
  fun `parsePlaylistsList hydrates private playlists with userId and songIds`() {
    val song1 = Song(id = "s1", title = "Khúc Nhạc Riêng", artistName = "XuanKen")
    val playlistsJson = """
      {
        "pl_priv": {
          "title": "Playlist Riêng Tư",
          "userId": "u_01",
          "curator": "Fan",
          "songIds": ["s1"]
        }
      }
    """.trimIndent()
    val parsed = XkJsonParser.parsePlaylistsList(playlistsJson, mapOf("s1" to song1))
    assertEquals(1, parsed.size)
    assertEquals("pl_priv", parsed.first().id)
    assertEquals("u_01", parsed.first().curatorId)
    assertEquals(1, parsed.first().songs.size)
    assertEquals("Khúc Nhạc Riêng", parsed.first().songs.first().title)
  }

  @Test
  fun `validateVoucherFromRtdb computes discount accurately`() {
    val vouchersJson = """
      {
        "v1": { "code": "XUANKEN50", "discountType": "percent", "discountValue": 50, "isActive": true, "description": "Giảm 50%" },
        "v2": { "code": "EXPIRED", "discountType": "percent", "discountValue": 20, "isActive": false }
      }
    """.trimIndent()

    val valid = XkJsonParser.validateVoucherFromRtdb(vouchersJson, "xuanken50", 100_000L)
    assertTrue(valid.valid)
    assertEquals(50_000L, valid.finalPrice)

    val inactive = XkJsonParser.validateVoucherFromRtdb(vouchersJson, "EXPIRED", 100_000L)
    assertFalse(inactive.valid)
    assertEquals(100_000L, inactive.finalPrice)
  }

  @Test
  fun `parsePurchasesList and parseStreamUrl parse valid payloads`() {
    val song = Song(id = "s1", title = "Bài Hát Độc Quyền", artistName = "XuanKen")
    val purchasesJson = """
      {
        "s1": { "purchaseId": "pur_1", "songId": "s1", "price": 29000, "purchasedAt": "2026-01-01T00:00:00Z" }
      }
    """.trimIndent()
    val purchases = XkJsonParser.parsePurchasesList(purchasesJson, mapOf("s1" to song))
    assertEquals(1, purchases.size)
    assertEquals("Bài Hát Độc Quyền", purchases.first().songTitle)
    assertEquals(29000L, purchases.first().price)

    val streamUrl = XkJsonParser.parseStreamUrl("""{"streamUrl":"https://cdn.example.com/track.mp3"}""")
    assertEquals("https://cdn.example.com/track.mp3", streamUrl)
  }

  @Test
  fun `songRowItem hides paid price badge when song is purchased`() {
    val paidSong = Song(
      id = "paid_1",
      title = "Bản Độc Quyền",
      artistName = "XuanKen",
      isPaid = true,
      priceText = "20.000đ",
    )

    composeTestRule.setContent {
      XkMusicTheme {
        SongRowItem(
          song = paidSong,
          isCurrentSong = false,
          isPlaying = false,
          isFavorite = false,
          isPurchased = true,
          onClick = {},
          onToggleFavorite = {},
        )
      }
    }

    composeTestRule.onNodeWithText("Bản Độc Quyền").assertIsDisplayed()
    composeTestRule.onNodeWithText("20.000đ").assertDoesNotExist()
  }

  @Test
  fun `songRowItem shows paid price badge when song is not purchased`() {
    val paidSong = Song(
      id = "paid_2",
      title = "Bản Trả Phí",
      artistName = "XuanKen",
      isPaid = true,
      priceText = "20.000đ",
    )

    composeTestRule.setContent {
      XkMusicTheme {
        SongRowItem(
          song = paidSong,
          isCurrentSong = false,
          isPlaying = false,
          isFavorite = false,
          isPurchased = false,
          onClick = {},
          onToggleFavorite = {},
        )
      }
    }

    composeTestRule.onNodeWithText("Bản Trả Phí").assertIsDisplayed()
    composeTestRule.onNodeWithText("20.000đ").assertIsDisplayed()
  }

  @Test
  fun `rhythm floating nav bar with detached search button and settings group render`() {
    val defaults = AppearanceSettings()
    assertEquals(ThemeMode.DARK, defaults.themeMode)
    assertEquals(RhythmColorPreset.DEFAULT, defaults.colorPreset)
    assertFalse(defaults.amoledMode)

    val items = listOf(
      RhythmNavItem("discover", "Khám phá", Icons.Rounded.Home, Icons.Outlined.Home, "nav_discover"),
      RhythmNavItem("library", "Thư viện", Icons.Rounded.LibraryMusic, Icons.Outlined.LibraryMusic, "nav_library"),
    )

    composeTestRule.setContent {
      XkMusicTheme(
        themeMode = ThemeMode.LIGHT,
        colorPreset = RhythmColorPreset.LAVENDER,
      ) {
        Column {
          Material3SettingsGroup(
            title = "Giao diện Rhythm",
            items = listOf(
              Material3SettingsItem(
                icon = Icons.Rounded.DarkMode,
                title = "Chế độ nền",
                subtitle = "Tùy chỉnh sáng/tối",
                palette = SettingsPalettes.Purple,
              ),
            ),
          )
          RhythmFloatingNavBarWithSearch(
            items = items,
            selectedPredicate = { it.route == "discover" },
            onSelect = {},
            isSearchSelected = false,
            onSearchClick = {},
            searchTestTag = "nav_explore",
          )
        }
      }
    }

    composeTestRule.onNodeWithTag("nav_discover").assertIsDisplayed()
    composeTestRule.onNodeWithTag("nav_library").assertIsDisplayed()
    composeTestRule.onNodeWithTag("nav_explore").assertIsDisplayed()
    composeTestRule.onNodeWithText("Khám phá").assertIsDisplayed()
    composeTestRule.onNodeWithText("Giao diện Rhythm").assertIsDisplayed()
  }

  @Test
  fun `mini player bar wavy slider play button and morphing button render`() {
    val activeSong = Song(
      id = "mini_1",
      title = "Nhạc Rhythm Expressive",
      artistName = "Xuân Kiên",
      durationSeconds = 215,
    )
    val state = PlaybackUiState(
      currentSong = activeSong,
      isPlaying = true,
      positionMs = 64_000L,
      durationMs = 215_000L,
    )

    composeTestRule.setContent {
      XkMusicTheme(themeMode = ThemeMode.DARK, amoledMode = true) {
        Column {
          MiniPlayerBar(
            playbackState = state,
            isFavorite = true,
            onExpandClick = {},
            onTogglePlayPause = {},
            onSkipNext = {},
            onToggleFavorite = {},
          )
          RhythmPlayButton(isPlaying = true, onClick = {})
          RhythmWavySlider(
            valueMs = 64_000L,
            durationMs = 215_000L,
            isPlaying = true,
            onSeekTo = {},
          )
          RhythmMorphingPlayPauseButton(isPlaying = true, onClick = {})
        }
      }
    }

    composeTestRule.onNodeWithTag("mini_player_bar").assertIsDisplayed()
    composeTestRule.onNodeWithTag("mini_player_play_pause").assertIsDisplayed()
    composeTestRule.onNodeWithText("Nhạc Rhythm Expressive").assertIsDisplayed()
    composeTestRule.onNodeWithText("Đang phát").assertIsDisplayed()
  }

  @Test
  fun `discover screen renders updated inline header greeting artists recommendations trending newly added and listening stats`() {
    val trendingSongs = (1..14).map { i ->
      Song(id = "s$i", title = "Bài Thịnh Hành $i", artistName = "Xuân Kiên", createdAtMs = i * 1000L)
    }
    val latestSongs = (1..7).map { i ->
      Song(id = "n$i", title = "Bài Mới Thêm $i", artistName = "XK New", createdAtMs = (20 - i) * 1000L)
    }
    val artists = (1..12).map { i ->
      Artist(id = "art_$i", name = "Nghệ Sĩ $i")
    }
    val album1 = Album(id = "a1", title = "Album Đêm Tím", artistName = "Xuân Kiên")
    val uiState = DiscoverUiState(
      isLoading = false,
      artists = artists,
      popularSongs = trendingSongs,
      latestSongs = latestSongs,
      chartSections = listOf(ChartSection(title = "Top Tuần", songs = trendingSongs)),
      albums = listOf(album1),
    )

    composeTestRule.setContent {
      XkMusicTheme(themeMode = ThemeMode.DARK, useDynamicColor = false) {
        DiscoverScreen(
          uiState = uiState,
          activeTrack = ActiveTrackMeta(songId = "s1", isPlaying = true),
          favoriteIds = setOf("s1"),
          purchasedIds = emptySet(),
          bottomOverlayPadding = PaddingValues(bottom = 120.dp),
          onRefresh = {},
          onOpenSearch = {},
          onPlaySong = { _, _ -> },
          onToggleFavorite = {},
          onPurchaseSong = {},
          onOpenAlbum = {},
          onOpenArtist = {},
          userName = "Xuân Kiên",
          listeningStats = ListeningStats(totalListeningTimeMs = 3_900_000L, songsPlayedCount = 14),
          onOpenAllArtists = {},
        )
      }
    }

    composeTestRule.waitForIdle()
    composeTestRule.onNodeWithText("XuanKen Music").assertIsDisplayed()
    composeTestRule.onNodeWithTag("discover_search_button").assertDoesNotExist()
    composeTestRule.onNodeWithTag("discover_refresh_button").assertDoesNotExist()
    composeTestRule.onNodeWithTag("discover_greeting_row").assertIsDisplayed()
    val greetingPrefix = com.example.ui.components.vietnameseGreetingText()
    assertTrue(
      "Unexpected greeting: $greetingPrefix",
      greetingPrefix in listOf("Chào buổi sáng", "Chào buổi trưa", "Chào buổi chiều", "Chào buổi tối", "Chào buổi đêm"),
    )
    composeTestRule.onNodeWithText("$greetingPrefix, Xuân Kiên").assertIsDisplayed()
    composeTestRule.onNodeWithText("Nghe nhanh").assertDoesNotExist()
    composeTestRule.onNodeWithText("Bảng xếp hạng").assertDoesNotExist()
    composeTestRule.onNodeWithTag("hero_spotlight_card").assertDoesNotExist()

    composeTestRule.onNodeWithText("Nghệ sĩ nổi bật").assertIsDisplayed()
    composeTestRule.onNodeWithText("Xem thêm").assertIsDisplayed()

    composeTestRule.onNodeWithTag("discover_list").performScrollToNode(hasText("Bài Thịnh Hành 10"))
    composeTestRule.onNodeWithText("Bài Thịnh Hành 10").assertIsDisplayed()
    composeTestRule.onNodeWithText("Bài Thịnh Hành 11").assertDoesNotExist()

    composeTestRule.onNodeWithTag("discover_list").performScrollToNode(hasText("Những bài hát mới thêm"))
    composeTestRule.onNodeWithText("Những bài hát mới thêm").assertIsDisplayed()
    composeTestRule.onNodeWithTag("discover_list").performScrollToNode(hasText("Bài Mới Thêm 5"))
    composeTestRule.onNodeWithText("Bài Mới Thêm 5").assertIsDisplayed()
    composeTestRule.onNodeWithText("Bài Mới Thêm 6").assertDoesNotExist()

    composeTestRule.onNodeWithTag("discover_list").performScrollToNode(hasText("Tổng thời gian đã nghe"))
    composeTestRule.onNodeWithText("Tổng thời gian đã nghe").assertIsDisplayed()
    composeTestRule.onNodeWithTag("discover_list").performScrollToNode(hasText("1 giờ 5 phút"))
    composeTestRule.onNodeWithText("1 giờ 5 phút").assertIsDisplayed()
  }

  @Test
  fun `parseHomeBundle search settings blocks vouchers and download parsers work`() {
    val homeJson = """
      {
        "data": {
          "site": { "siteName": "XK Music", "genres": ["Lofi", "Ballad"] },
          "songs": [{ "id": "s1", "title": "Đêm Mưa", "artistName": "Xuân Kiên", "streamUrl": "/api/v1/stream/s1?sig=abc" }],
          "albums": [{ "id": "a1", "title": "Album 1", "artistName": "XK" }],
          "playlists": [{ "id": "p1", "title": "Tuyển chọn", "songIds": ["s1"] }]
        }
      }
    """.trimIndent()
    val home = XkJsonParser.parseHomeBundle(homeJson)
    assertNotNull(home)
    assertEquals(1, home?.popularSongs?.size)
    assertEquals("https://xkmu.xuanken.name.vn/api/v1/stream/s1?sig=abc", home?.popularSongs?.first()?.audioUrl)

    val searchJson = """{"songs":[{"id":"s2","title":"Tìm Kiếm","artistName":"XK"}],"albums":[{"id":"a2","title":"Alb","artistName":"XK"}]}"""
    val search = XkJsonParser.parseSearchBundle(searchJson)
    assertEquals(1, search?.songs?.size)
    assertEquals(1, search?.albums?.size)

    val settingsJson = """{"settings":{"themeMode":"LIGHT","amoledMode":false,"likedAlbumIds":["a1"],"blockedSongIds":["s9"]}}"""
    val settings = XkJsonParser.parseUserSettings(settingsJson)
    assertEquals("LIGHT", settings?.themeMode)
    assertEquals(listOf("a1"), settings?.likedAlbumIds)
    assertEquals(listOf("s9"), settings?.blockedSongIds)

    val blocks = XkJsonParser.parseBlockedSongIds("""{"blocks":[{"songId":"b1"},{"songId":"b2"}]}""")
    assertEquals(listOf("b1", "b2"), blocks)

    val vouchers = XkJsonParser.parseVouchersList("""{"vouchers":[{"code":"VIP20","discountType":"percent","discountValue":20,"isActive":true}]}""")
    assertEquals(1, vouchers.size)
    assertEquals("VIP20", vouchers.first().code)

    val dlUrl = XkJsonParser.parseDownloadUrl("""{"downloadUrl":"/api/v1/stream/s1?dl=1"}""")
    assertEquals("https://xkmu.xuanken.name.vn/api/v1/stream/s1?dl=1", dlUrl)
  }

  @Test
  fun `expressive now playing sheet renders peanut art capsule play scalloped skips and 5-pill dock`() {
    val activeSong = Song(
      id = "np_1",
      title = "Giữ Lại Được Chi",
      artistName = "Reddy (XuanKen)",
      durationSeconds = 300,
    )
    val state = PlaybackUiState(
      currentSong = activeSong,
      queue = listOf(activeSong),
      isPlaying = true,
      positionMs = 230_000L,
      durationMs = 300_000L,
    )

    composeTestRule.setContent {
      XkMusicTheme(themeMode = ThemeMode.LIGHT, colorPreset = RhythmColorPreset.LAVENDER) {
        NowPlayingSheet(
          playbackState = state,
          favoriteIds = emptySet(),
          purchasedIds = emptySet(),
          sleepTimerState = SleepTimerUiState(),
          onDismiss = {},
          onTogglePlayPause = {},
          onSkipNext = {},
          onSkipPrevious = {},
          onSeekTo = {},
          onToggleShuffle = {},
          onCycleRepeat = {},
          onToggleFavorite = {},
          onPlayQueueItem = { _, _ -> },
          onOpenArtist = {},
          onPurchaseSong = {},
          onStartSleepTimer = {},
          onStartSleepAfterCurrentTrack = {},
          onCancelSleepTimer = {},
        )
      }
    }

    composeTestRule.onNodeWithTag("player_peanut_artwork").assertIsDisplayed()
    composeTestRule.onNodeWithTag("player_play_pause_button").assertIsDisplayed()
    composeTestRule.onNodeWithText("Tạm dừng").assertIsDisplayed()
    composeTestRule.onNodeWithTag("player_next_button").assertIsDisplayed()
    composeTestRule.onNodeWithTag("player_prev_button").assertIsDisplayed()
    composeTestRule.onNodeWithTag("player_lyrics_toggle").assertIsDisplayed()
    composeTestRule.onNodeWithTag("player_favorite_toggle").assertIsDisplayed()
    composeTestRule.onNodeWithTag("player_sleep_timer_button").assertIsDisplayed()
    composeTestRule.onNodeWithTag("player_queue_button").assertIsDisplayed()
    composeTestRule.onNodeWithTag("player_more_button").assertIsDisplayed()
  }

  @Test
  fun `parseStreamInfo distinguishes demo previews from full master audio URLs`() {
    val demoOnly = XkJsonParser.parseStreamInfo("""{"demoUrl":"https://cdn.example.com/demo/song1.mp3","isDemo":true}""")
    assertNotNull(demoOnly)
    assertTrue(demoOnly!!.isDemo)

    val taggedDemoStream = XkJsonParser.parseStreamInfo("""{"streamUrl":"https://xkmu.xuanken.name.vn/api/v1/stream/s1","isFull":false}""")
    assertNotNull(taggedDemoStream)
    assertTrue(taggedDemoStream!!.isDemo)

    val masterPriority = XkJsonParser.parseStreamInfo(
      """{"demoUrl":"https://cdn.example.com/demo_s1.mp3","masterUrl":"https://cdn.example.com/master/full_s1.mp3","isDemo":false}""",
    )
    assertNotNull(masterPriority)
    assertFalse(masterPriority!!.isDemo)
    assertEquals("https://cdn.example.com/master/full_s1.mp3", masterPriority.url)

    assertTrue(XkJsonParser.looksLikeDemoUrl("https://xkmu.xuanken.name.vn/audio/demo_123.mp3"))
    assertFalse(XkJsonParser.looksLikeDemoUrl("https://xkmu.xuanken.name.vn/api/v1/stream/s1?sig=abc"))
  }

  @Test
  fun `now playing sheet adapts cleanly on compact 360x560 screen with bottom system bar margin`() {
    val activeSong = Song(
      id = "compact_1",
      title = "Hết Tình Cạn Nghĩa (Cover)",
      artistName = "XuanKen",
      durationSeconds = 276,
      isPaid = true,
      priceText = "20.000đ",
    )
    val state = PlaybackUiState(
      currentSong = activeSong,
      queue = listOf(activeSong),
      isPlaying = true,
      positionMs = 175_000L,
      durationMs = 276_000L,
    )

    composeTestRule.setContent {
      XkMusicTheme(themeMode = ThemeMode.DARK, useDynamicColor = false) {
        // Simulate a compact 360x560dp phone screen minus 36dp status bar & 48dp 3-button nav bar
        Box(
          modifier = Modifier
            .size(width = 360.dp, height = 560.dp)
            .padding(top = 36.dp, bottom = 48.dp),
        ) {
          NowPlayingSheet(
            playbackState = state,
            favoriteIds = emptySet(),
            purchasedIds = setOf("compact_1"),
            sleepTimerState = SleepTimerUiState(),
            onDismiss = {},
            onTogglePlayPause = {},
            onSkipNext = {},
            onSkipPrevious = {},
            onSeekTo = {},
            onToggleShuffle = {},
            onCycleRepeat = {},
            onToggleFavorite = {},
            onPlayQueueItem = { _, _ -> },
            onOpenArtist = {},
            onPurchaseSong = {},
            onStartSleepTimer = {},
            onStartSleepAfterCurrentTrack = {},
            onCancelSleepTimer = {},
          )
        }
      }
    }

    composeTestRule.waitForIdle()
    composeTestRule.onNodeWithTag("player_collapse_button").assertIsDisplayed()
    composeTestRule.onNodeWithTag("player_peanut_artwork").assertIsDisplayed()
    composeTestRule.onNodeWithTag("player_play_pause_button").assertIsDisplayed()
    composeTestRule.onNodeWithTag("player_next_button").assertIsDisplayed()
    composeTestRule.onNodeWithTag("player_prev_button").assertIsDisplayed()
    composeTestRule.onNodeWithTag("player_lyrics_toggle").assertIsDisplayed()
    composeTestRule.onNodeWithTag("player_favorite_toggle").assertIsDisplayed()
    composeTestRule.onNodeWithTag("player_sleep_timer_button").assertIsDisplayed()
    composeTestRule.onNodeWithTag("player_queue_button").assertIsDisplayed()
    composeTestRule.onNodeWithTag("player_more_button").assertIsDisplayed()

    // Ensure dock does not overflow past the available safe box height (560 - 36 - 48 = 476dp)
    val moreDockBounds = composeTestRule.onNodeWithTag("player_more_button").getUnclippedBoundsInRoot()
    assertTrue("Dock bottom (${moreDockBounds.bottom}) must stay above bottom nav bar", moreDockBounds.bottom <= 520.dp)
  }

  @Test
  fun `rhythmColorExtractor extracts vibrant pastel dark palette with WCAG contrast`() {
    val bmp = Bitmap.createBitmap(16, 16, Bitmap.Config.ARGB_8888)
    bmp.eraseColor(AndroidColor.rgb(98, 72, 232))

    val (seedArgb, isMono) = RhythmColorExtractor.extractDominantSeed(bmp)
    assertFalse(isMono)

    val darkPalette = RhythmColorExtractor.derivePlayerPalette(
      seedArgb = seedArgb,
      isDarkTheme = true,
      isMonochrome = isMono,
    )
    assertTrue("Dark theme Rhythm canvas should be bright pastel", darkPalette.isLightCanvas)
    assertTrue(darkPalette.accentBg.luminance() > 0.5f)
    val contrast = ColorUtils.calculateContrast(darkPalette.accentFg.toArgb(), darkPalette.accentBg.toArgb())
    assertTrue("Contrast $contrast should be >= 7.0", contrast >= 7.0)

    val grayBmp = Bitmap.createBitmap(16, 16, Bitmap.Config.ARGB_8888)
    grayBmp.eraseColor(AndroidColor.rgb(120, 120, 120))
    val (_, monoDetected) = RhythmColorExtractor.extractDominantSeed(grayBmp)
    assertTrue(monoDetected)
  }

  @Test
  fun `rhythm segmented dock row and standard 411x891 player render cleanly`() {
    val song = Song(
      id = "std_1",
      title = "Giữ Lại Được Chi",
      artistName = "XuanKen",
      durationSeconds = 300,
    )
    val state = PlaybackUiState(
      currentSong = song,
      queue = listOf(song),
      isPlaying = false,
      positionMs = 45_000L,
      durationMs = 300_000L,
    )

    composeTestRule.setContent {
      XkMusicTheme(themeMode = ThemeMode.DARK, useDynamicColor = false) {
        Box(
          modifier = Modifier
            .size(width = 411.dp, height = 891.dp)
            .padding(top = 36.dp, bottom = 48.dp),
        ) {
          NowPlayingSheet(
            playbackState = state,
            favoriteIds = setOf("std_1"),
            purchasedIds = setOf("std_1"),
            sleepTimerState = SleepTimerUiState(isActive = true, remainingSeconds = 900),
            onDismiss = {},
            onTogglePlayPause = {},
            onSkipNext = {},
            onSkipPrevious = {},
            onSeekTo = {},
            onToggleShuffle = {},
            onCycleRepeat = {},
            onToggleFavorite = {},
            onPlayQueueItem = { _, _ -> },
            onOpenArtist = {},
            onPurchaseSong = {},
            onStartSleepTimer = {},
            onStartSleepAfterCurrentTrack = {},
            onCancelSleepTimer = {},
          )
        }
      }
    }

    composeTestRule.waitForIdle()
    composeTestRule.onNodeWithText("Phát").assertIsDisplayed()
    composeTestRule.onNodeWithTag("player_collapse_button").assertIsDisplayed()
    composeTestRule.onNodeWithTag("player_lyrics_toggle").assertIsDisplayed()
    composeTestRule.onNodeWithTag("player_more_button").assertIsDisplayed()
    composeTestRule.onNodeWithTag("player_replay_10").assertDoesNotExist()
    composeTestRule.onNodeWithTag("player_forward_10").assertDoesNotExist()
    composeTestRule.onNodeWithText("Hẹn giờ 15:00").assertDoesNotExist()
    composeTestRule.onNodeWithText("15:00").assertIsDisplayed()

    composeTestRule.onNodeWithTag("player_sleep_timer_button").performClick()
    composeTestRule.waitForIdle()
    composeTestRule.onNodeWithText("Hẹn giờ ngủ").assertIsDisplayed()
    composeTestRule.onNodeWithText("ĐANG BẬT").assertIsDisplayed()
    composeTestRule.onNodeWithText("Còn 15:00").assertIsDisplayed()
    composeTestRule.onNodeWithText("Giảm dần âm lượng khi tắt").assertIsDisplayed()
  }

  @Test
  fun `album detail screen renders rhythm full bleed hero split actions and purchased tracks`() {
    val songFree = Song(id = "s_free", title = "Khúc Dạo Đầu", artistName = "XuanKen", durationSeconds = 180)
    val songPaid = Song(
      id = "s_paid",
      title = "Bản Độc Quyền Full",
      artistName = "XuanKen",
      durationSeconds = 240,
      isPaid = true,
      priceText = "20.000đ",
    )
    val album = Album(
      id = "alb_1",
      title = "Tuyển Tập Đêm Tím",
      artistName = "XuanKen",
      artistId = "art_1",
      releaseYear = "2026",
      genre = "Ballad",
      songs = listOf(songFree, songPaid),
    )

    composeTestRule.setContent {
      XkMusicTheme(themeMode = ThemeMode.DARK, useDynamicColor = false) {
        Box(modifier = Modifier.size(width = 411.dp, height = 891.dp)) {
          AlbumDetailScreen(
            state = DetailLoadState.Success(album),
            activeTrack = ActiveTrackMeta(songId = "s_paid", isPlaying = true),
            favoriteIds = setOf("s_paid"),
            purchasedIds = setOf("s_paid"),
            bottomOverlayPadding = PaddingValues(bottom = 96.dp),
            isAlbumFavorite = true,
            onToggleAlbumFavorite = {},
            onBack = {},
            onRetry = {},
            onPlaySong = { _, _ -> },
            onPlayAll = { _, _ -> },
            onToggleFavorite = {},
            onPurchaseSong = {},
            onOpenArtist = {},
          )
        }
      }
    }

    composeTestRule.waitForIdle()
    composeTestRule.onNodeWithTag("detail_back_button").assertIsDisplayed()
    composeTestRule.onNodeWithTag("album_favorite_button").assertIsDisplayed()
    composeTestRule.onNodeWithText("Tuyển Tập Đêm Tím").assertIsDisplayed()
    composeTestRule.onNodeWithText("2026").assertIsDisplayed()
    composeTestRule.onNodeWithText("Phát tất cả").assertIsDisplayed()
    composeTestRule.onNodeWithText("Trộn bài").assertIsDisplayed()
    composeTestRule.onNodeWithText("Bản Độc Quyền Full").assertIsDisplayed()
    composeTestRule.onNodeWithText("20.000đ").assertDoesNotExist()
  }

  @Test
  fun `explore screen renders rhythm empty state when no results match`() {
    val uiState = ExploreUiState(
      isLoading = false,
      query = "khong_ton_tai_xyz",
      songs = emptyList(),
      availableGenres = listOf("Ballad", "Lofi"),
    )

    composeTestRule.setContent {
      XkMusicTheme(themeMode = ThemeMode.DARK, useDynamicColor = false) {
        Box(modifier = Modifier.size(width = 411.dp, height = 891.dp)) {
          ExploreScreen(
            uiState = uiState,
            activeTrack = ActiveTrackMeta(),
            favoriteIds = emptySet(),
            purchasedIds = emptySet(),
            bottomOverlayPadding = PaddingValues(bottom = 96.dp),
            onQueryChange = {},
            onSelectGenre = {},
            onSelectPaidFilter = {},
            onSelectSort = {},
            onRetry = {},
            onPlaySong = { _, _ -> },
            onPlayAll = { _, _ -> },
            onToggleFavorite = {},
            onPurchaseSong = {},
          )
        }
      }
    }

    composeTestRule.mainClock.advanceTimeBy(600)
    composeTestRule.waitForIdle()
    composeTestRule.onNodeWithTag("explore_search_input").assertIsDisplayed()
    composeTestRule.onNodeWithText("Không tìm thấy bài hát").assertIsDisplayed()
  }

  @Test
  fun `now playing sheet back press closes lyrics before dismissing player`() {
    val song = Song(
      id = "back_1",
      title = "Khúc Giao Mùa",
      artistName = "XuanKen",
      durationSeconds = 210,
      lyrics = "[00:01.00] Dòng lời một\n[00:05.00] Dòng lời hai",
    )
    val state = PlaybackUiState(
      currentSong = song,
      queue = listOf(song),
      isPlaying = true,
      positionMs = 2_000L,
      durationMs = 210_000L,
    )
    var dismissCount = 0
    var dispatcher: OnBackPressedDispatcher? = null

    composeTestRule.setContent {
      XkMusicTheme(themeMode = ThemeMode.DARK, useDynamicColor = false) {
        dispatcher = LocalOnBackPressedDispatcherOwner.current?.onBackPressedDispatcher
        Box(modifier = Modifier.size(width = 411.dp, height = 891.dp)) {
          NowPlayingSheet(
            playbackState = state,
            favoriteIds = emptySet(),
            purchasedIds = setOf("back_1"),
            sleepTimerState = SleepTimerUiState(),
            onDismiss = { dismissCount++ },
            onTogglePlayPause = {},
            onSkipNext = {},
            onSkipPrevious = {},
            onSeekTo = {},
            onToggleShuffle = {},
            onCycleRepeat = {},
            onToggleFavorite = {},
            onPlayQueueItem = { _, _ -> },
            onOpenArtist = {},
            onPurchaseSong = {},
            onStartSleepTimer = {},
            onStartSleepAfterCurrentTrack = {},
            onCancelSleepTimer = {},
          )
        }
      }
    }

    composeTestRule.waitForIdle()
    composeTestRule.onNodeWithTag("player_peanut_artwork").assertIsDisplayed()

    composeTestRule.onNodeWithTag("player_lyrics_toggle").performClick()
    composeTestRule.waitForIdle()
    composeTestRule.onNodeWithText("Dòng lời một").assertIsDisplayed()

    composeTestRule.runOnUiThread {
      dispatcher?.onBackPressed()
    }
    composeTestRule.waitForIdle()
    assertEquals(0, dismissCount)
    composeTestRule.onNodeWithTag("player_peanut_artwork").assertIsDisplayed()

    composeTestRule.runOnUiThread {
      dispatcher?.onBackPressed()
    }
    composeTestRule.waitForIdle()
    assertEquals(1, dismissCount)
  }

  @Test
  fun `now playing sheet renders starry sky background alongside circular cover`() {
    val song = Song(
      id = "star_1",
      title = "Bầu Trời Đầy Sao",
      artistName = "XuanKen",
      durationSeconds = 200,
    )
    val state = PlaybackUiState(
      currentSong = song,
      queue = listOf(song),
      isPlaying = true,
      positionMs = 10_000L,
      durationMs = 200_000L,
    )

    composeTestRule.setContent {
      XkMusicTheme(themeMode = ThemeMode.DARK, useDynamicColor = false) {
        Box(modifier = Modifier.size(width = 411.dp, height = 891.dp)) {
          NowPlayingSheet(
            playbackState = state,
            favoriteIds = emptySet(),
            purchasedIds = setOf("star_1"),
            sleepTimerState = SleepTimerUiState(),
            onDismiss = {},
            onTogglePlayPause = {},
            onSkipNext = {},
            onSkipPrevious = {},
            onSeekTo = {},
            onToggleShuffle = {},
            onCycleRepeat = {},
            onToggleFavorite = {},
            onPlayQueueItem = { _, _ -> },
            onOpenArtist = {},
            onPurchaseSong = {},
            onStartSleepTimer = {},
            onStartSleepAfterCurrentTrack = {},
            onCancelSleepTimer = {},
          )
        }
      }
    }

    composeTestRule.waitForIdle()
    composeTestRule.onNodeWithTag("player_starry_sky").assertIsDisplayed()
    composeTestRule.onNodeWithTag("player_peanut_artwork").assertIsDisplayed()
  }

  @Test
  fun `charts screen displays top 10 songs only`() {
    val songs = (1..15).map { i ->
      Song(id = "c$i", title = "Ca Khúc BXH $i", artistName = "XuanKen")
    }
    val discoverState = DiscoverUiState(
      isLoading = false,
      chartSections = listOf(ChartSection(title = "Top BXH", songs = songs)),
    )

    composeTestRule.setContent {
      XkMusicTheme(themeMode = ThemeMode.DARK, useDynamicColor = false) {
        Box(modifier = Modifier.size(width = 411.dp, height = 891.dp)) {
          ChartsScreen(
            discoverState = discoverState,
            activeTrack = ActiveTrackMeta(),
            favoriteIds = emptySet(),
            purchasedIds = emptySet(),
            bottomOverlayPadding = PaddingValues(bottom = 80.dp),
            onRetry = {},
            onPlaySong = { _, _ -> },
            onPlayAll = { _, _ -> },
            onToggleFavorite = {},
            onPurchaseSong = {},
          )
        }
      }
    }

    composeTestRule.waitForIdle()
    composeTestRule.onNodeWithText("Top 10 ca khúc dẫn đầu tuần này").assertIsDisplayed()
    composeTestRule.onNodeWithTag("charts_list").performScrollToNode(hasText("Ca Khúc BXH 10"))
    composeTestRule.onNodeWithText("Ca Khúc BXH 10").assertIsDisplayed()
    composeTestRule.onNodeWithText("Ca Khúc BXH 11").assertDoesNotExist()
  }

  @Test
  fun `library screen shows only current user personal playlists sorted alphabetically`() {
    val playlists = listOf(
      Playlist(id = "p_other", title = "A Public Của Người Khác", curatorId = "u_other"),
      Playlist(id = "p_z", title = "Zeta Chill", curatorId = "u_me"),
      Playlist(id = "p_b", title = "Bình Minh", curatorId = "u_me"),
      Playlist(id = "p_a", title = "Ánh Trăng", curatorId = "u_me"),
    )

    composeTestRule.setContent {
      XkMusicTheme(themeMode = ThemeMode.DARK, useDynamicColor = false) {
        Box(modifier = Modifier.size(width = 411.dp, height = 891.dp)) {
          LibraryScreen(
            favorites = emptyList(),
            recentSongs = emptyList(),
            playlists = playlists,
            activeTrack = ActiveTrackMeta(),
            favoriteIds = emptySet(),
            purchasedIds = emptySet(),
            currentUserId = "u_me",
            bottomOverlayPadding = PaddingValues(bottom = 80.dp),
            onPlaySong = { _, _ -> },
            onPlayAll = { _, _ -> },
            onToggleFavorite = {},
            onPurchaseSong = {},
            onOpenPlaylist = {},
            onCreatePlaylist = { _, _ -> },
          )
        }
      }
    }

    composeTestRule.waitForIdle()
    composeTestRule.onNodeWithText("Playlist").performClick()
    composeTestRule.waitForIdle()

    composeTestRule.onNodeWithText("A Public Của Người Khác").assertDoesNotExist()
    val aTop = composeTestRule.onNodeWithText("Ánh Trăng").getUnclippedBoundsInRoot().top
    val bTop = composeTestRule.onNodeWithText("Bình Minh").getUnclippedBoundsInRoot().top
    val zTop = composeTestRule.onNodeWithText("Zeta Chill").getUnclippedBoundsInRoot().top
    assertTrue("Expected Ánh Trăng ($aTop) before Bình Minh ($bTop)", aTop < bTop)
    assertTrue("Expected Bình Minh ($bTop) before Zeta Chill ($zTop)", bTop < zTop)
  }

  @Test
  fun `profile screen shows login only without web sync subtitle or register chip`() {
    composeTestRule.setContent {
      XkMusicTheme(themeMode = ThemeMode.DARK, useDynamicColor = false) {
        Box(modifier = Modifier.size(width = 411.dp, height = 891.dp)) {
          ProfileScreen(
            authState = AuthUiState(session = null),
            sleepTimerState = SleepTimerUiState(),
            bottomOverlayPadding = PaddingValues(bottom = 80.dp),
            onLogin = { _, _ -> },
            onRegister = { _, _, _ -> },
            onRefreshProfile = {},
            onLogout = {},
            onClearAuthError = {},
            onPlayPurchasedSong = {},
            onStartSleepTimer = {},
            onStartSleepAfterCurrentTrack = {},
            onCancelSleepTimer = {},
          )
        }
      }
    }

    composeTestRule.waitForIdle()
    assertEquals(2, composeTestRule.onAllNodesWithText("Đăng nhập").fetchSemanticsNodes().size)
    composeTestRule.onNodeWithText("Đăng nhập đồng bộ Web").assertDoesNotExist()
    composeTestRule.onNodeWithText("Đăng ký").assertDoesNotExist()
    composeTestRule.onNodeWithTag("auth_display_name_input").assertDoesNotExist()
    composeTestRule.onNodeWithText("Cá nhân hóa").assertDoesNotExist()
    composeTestRule.onNodeWithText("Kho nhạc đã mở khóa").assertDoesNotExist()
  }

  @Test
  fun `all artists screen lays out artists in 3-column grid`() {
    val artists = (1..6).map { i -> Artist(id = "a$i", name = "Ca Sĩ $i") }

    composeTestRule.setContent {
      XkMusicTheme(themeMode = ThemeMode.DARK, useDynamicColor = false) {
        Box(modifier = Modifier.size(width = 411.dp, height = 891.dp)) {
          AllArtistsScreen(
            artists = artists,
            bottomOverlayPadding = PaddingValues(bottom = 80.dp),
            onBack = {},
            onOpenArtist = {},
          )
        }
      }
    }

    composeTestRule.waitForIdle()
    val a1 = composeTestRule.onNodeWithTag("all_artist_a1").getUnclippedBoundsInRoot()
    val a2 = composeTestRule.onNodeWithTag("all_artist_a2").getUnclippedBoundsInRoot()
    val a3 = composeTestRule.onNodeWithTag("all_artist_a3").getUnclippedBoundsInRoot()
    val a4 = composeTestRule.onNodeWithTag("all_artist_a4").getUnclippedBoundsInRoot()

    assertEquals(a1.top.value, a2.top.value, 2f)
    assertEquals(a2.top.value, a3.top.value, 2f)
    assertTrue("4th artist should wrap to second row", a4.top > a1.bottom)
  }

  @Test
  fun `profile screen replaces old sleep timer and appearance groups with ca nhan hoa hub`() {
    val clickedSections = mutableListOf<PersonalizationSection>()
    val catalogSongs = listOf(
      Song(id = "s1", title = "Khúc Nhạc 1", artistName = "XuanKen"),
      Song(id = "s2", title = "Khúc Nhạc 2", artistName = "XuanKen"),
    )
    val signedInAuth = AuthUiState(
      session = AuthSession(
        idToken = "tok",
        user = UserProfile(uid = "u1", email = "a@b.vn", displayName = "Xuân Kiên"),
      ),
      purchases = listOf(
        PurchaseRecord(id = "p1", songId = "s1", songTitle = "Khúc Nhạc 1", price = 15000L),
        PurchaseRecord(id = "p2", songId = "s2", songTitle = "Khúc Nhạc 2", price = 20000L),
        PurchaseRecord(id = "p_deleted", songId = "deleted_51", songTitle = "Bài hát #deleted_51", price = 10000L),
      ),
    )

    composeTestRule.setContent {
      XkMusicTheme(themeMode = ThemeMode.DARK, useDynamicColor = false) {
        Box(modifier = Modifier.size(width = 411.dp, height = 891.dp)) {
          ProfileScreen(
            authState = signedInAuth,
            sleepTimerState = SleepTimerUiState(),
            bottomOverlayPadding = PaddingValues(bottom = 80.dp),
            onLogin = { _, _ -> },
            onRefreshProfile = {},
            onLogout = {},
            onPlayPurchasedSong = {},
            onOpenPersonalization = { clickedSections.add(it) },
            allKnownSongs = catalogSongs,
          )
        }
      }
    }

    composeTestRule.waitForIdle()
    // Old sections must be gone
    composeTestRule.onNodeWithText("Hẹn giờ tắt nhạc").assertDoesNotExist()
    composeTestRule.onNodeWithText("Giao diện Rhythm").assertDoesNotExist()
    composeTestRule.onNodeWithText("Bảng màu Rhythm").assertDoesNotExist()

    // New Cá nhân hóa hub + Theme mode 3 choices
    composeTestRule.onNodeWithTag("profile_list").performScrollToNode(hasText("Cá nhân hóa"))
    composeTestRule.onNodeWithText("Cá nhân hóa").assertIsDisplayed()
    composeTestRule.onNodeWithTag("profile_list").performScrollToNode(hasText("Chọn chế độ chủ đề"))
    composeTestRule.onNodeWithTag("theme_mode_system").assertIsDisplayed()
    composeTestRule.onNodeWithTag("theme_mode_light").assertIsDisplayed()
    composeTestRule.onNodeWithTag("theme_mode_dark").assertIsDisplayed()
    composeTestRule.onNodeWithText("Hệ thống").assertIsDisplayed()
    composeTestRule.onNodeWithText("Ánh sáng").assertIsDisplayed()
    composeTestRule.onNodeWithText("Bóng tối").assertIsDisplayed()

    // Verify personalization rows exist & are clickable
    PersonalizationSection.entries.forEach { section ->
      composeTestRule.onNodeWithTag("personalization_${section.name.lowercase()}")
        .performScrollTo()
        .assertIsDisplayed()
    }

    composeTestRule.onNodeWithTag("personalization_equalizer")
      .performScrollTo()
      .performClick()
    assertEquals(listOf(PersonalizationSection.EQUALIZER), clickedSections)

    // Verify deleted purchase ID is filtered out (2 valid instead of 3) and grouped into modal sheet
    composeTestRule.onNodeWithTag("profile_list").performScrollToNode(hasTestTag("open_purchased_songs_button"))
    composeTestRule.onNodeWithText("2 bài").assertIsDisplayed()
    composeTestRule.onNodeWithTag("open_purchased_songs_button").performClick()
    composeTestRule.waitForIdle()
    composeTestRule.onNodeWithText("Kho nhạc đã mở khóa (2)").assertIsDisplayed()
    composeTestRule.onNodeWithText("Khúc Nhạc 1").assertIsDisplayed()
    composeTestRule.onNodeWithText("Bài hát #deleted_51").assertDoesNotExist()
  }

  @Test
  fun `now playing sheet renders clear blue sky background in light mode`() {
    val song = Song(
      id = "sky_1",
      title = "Bầu Trời Trong Xanh",
      artistName = "XuanKen",
      durationSeconds = 210,
    )
    val state = PlaybackUiState(
      currentSong = song,
      queue = listOf(song),
      isPlaying = true,
      positionMs = 15_000L,
      durationMs = 210_000L,
    )

    composeTestRule.setContent {
      XkMusicTheme(themeMode = ThemeMode.LIGHT, useDynamicColor = false) {
        Box(modifier = Modifier.size(width = 411.dp, height = 891.dp)) {
          NowPlayingSheet(
            playbackState = state,
            favoriteIds = emptySet(),
            purchasedIds = setOf("sky_1"),
            sleepTimerState = SleepTimerUiState(),
            onDismiss = {},
            onTogglePlayPause = {},
            onSkipNext = {},
            onSkipPrevious = {},
            onSeekTo = {},
            onToggleShuffle = {},
            onCycleRepeat = {},
            onToggleFavorite = {},
            onPlayQueueItem = { _, _ -> },
            onOpenArtist = {},
            onPurchaseSong = {},
            onStartSleepTimer = {},
            onStartSleepAfterCurrentTrack = {},
            onCancelSleepTimer = {},
          )
        }
      }
    }

    composeTestRule.waitForIdle()
    composeTestRule.onNodeWithTag("player_clear_sky").assertIsDisplayed()
    composeTestRule.onNodeWithTag("player_starry_sky").assertDoesNotExist()
  }

  @Test
  fun `personalization detail screens render equalizer and font customization controls`() {
    var selectedPreset: EqualizerPreset? = null
    composeTestRule.setContent {
      XkMusicTheme(themeMode = ThemeMode.DARK, useDynamicColor = false) {
        Box(modifier = Modifier.size(width = 411.dp, height = 891.dp)) {
          PersonalizationDetailScreen(
            section = PersonalizationSection.EQUALIZER,
            appearanceSettings = AppearanceSettings(),
            personalization = PersonalizationSettings(equalizerEnabled = true),
            sleepTimerState = SleepTimerUiState(),
            bottomOverlayPadding = PaddingValues(bottom = 80.dp),
            onBack = {},
            onThemeModeChange = {},
            onColorPresetChange = {},
            onAmoledModeChange = {},
            onDynamicColorChange = {},
            onPaletteStyleChange = {},
            onStartSleepTimer = {},
            onStartSleepAfterCurrentTrack = {},
            onCancelSleepTimer = {},
            onSleepTimerFadeOutChange = {},
            onPlaybackSpeedChange = {},
            onRotateArtworkChange = {},
            onUseWavySeekbarChange = {},
            onShowMiniPlayerProgressChange = {},
            onKeepScreenOnPlayerChange = {},
            onFontOptionChange = {},
            onFontScaleChange = {},
            onFloatingNavBarEnabledChange = {},
            onNavBarLabelBehaviorChange = {},
            onShowDetachedSearchFabChange = {},
            onFestiveThemeModeChange = {},
            onFestiveParticlesEnabledChange = {},
            onSwipeDownToDismissPlayerChange = {},
            onSwipeArtworkToSkipChange = {},
            onTapArtworkForLyricsChange = {},
            onMiniPlayerGesturesEnabledChange = {},
            onHapticFeedbackEnabledChange = {},
            onEqualizerEnabledChange = {},
            onSelectEqualizerPreset = { selectedPreset = it },
            onSetEqualizerBand = { _, _ -> },
            onBassBoostLevelChange = {},
            onVirtualizerLevelChange = {},
            onLyricsAutoScrollChange = {},
            onLyricsAlignmentChange = {},
            onLyricsFontSizeChange = {},
            onLyricsDimInactiveChange = {},
            onLyricsTapToSeekChange = {},
          )
        }
      }
    }

    composeTestRule.waitForIdle()
    composeTestRule.onNodeWithText("Bộ chỉnh âm").assertIsDisplayed()
    composeTestRule.onNodeWithText("Tăng Bass").performClick()
    assertEquals(EqualizerPreset.BASS_BOOST, selectedPreset)
    composeTestRule.onNodeWithText("60 Hz").assertIsDisplayed()
    composeTestRule.onNodeWithTag("personalization_detail_list")
      .performScrollToNode(hasText("Tăng âm trầm (Bass Boost)"))
    composeTestRule.onNodeWithText("Tăng âm trầm (Bass Boost)").assertIsDisplayed()
  }

  @Test
  fun `shape customization screen renders expressive shapes and triggers callbacks`() {
    var selectedAlbumShape: String? = null
    var resetCount = 0

    composeTestRule.setContent {
      XkMusicTheme(themeMode = ThemeMode.DARK, useDynamicColor = false) {
        Box(modifier = Modifier.size(width = 411.dp, height = 891.dp)) {
          PersonalizationDetailScreen(
            section = PersonalizationSection.SHAPE_CUSTOMIZATION,
            appearanceSettings = AppearanceSettings(),
            personalization = PersonalizationSettings(),
            sleepTimerState = SleepTimerUiState(),
            bottomOverlayPadding = PaddingValues(bottom = 80.dp),
            onBack = {},
            onThemeModeChange = {},
            onColorPresetChange = {},
            onAmoledModeChange = {},
            onDynamicColorChange = {},
            onPaletteStyleChange = {},
            onStartSleepTimer = {},
            onStartSleepAfterCurrentTrack = {},
            onCancelSleepTimer = {},
            onSleepTimerFadeOutChange = {},
            onPlaybackSpeedChange = {},
            onRotateArtworkChange = {},
            onUseWavySeekbarChange = {},
            onShowMiniPlayerProgressChange = {},
            onKeepScreenOnPlayerChange = {},
            onFontOptionChange = {},
            onFontScaleChange = {},
            onFloatingNavBarEnabledChange = {},
            onNavBarLabelBehaviorChange = {},
            onShowDetachedSearchFabChange = {},
            onFestiveThemeModeChange = {},
            onFestiveParticlesEnabledChange = {},
            onSwipeDownToDismissPlayerChange = {},
            onSwipeArtworkToSkipChange = {},
            onTapArtworkForLyricsChange = {},
            onMiniPlayerGesturesEnabledChange = {},
            onHapticFeedbackEnabledChange = {},
            onEqualizerEnabledChange = {},
            onSelectEqualizerPreset = {},
            onSetEqualizerBand = { _, _ -> },
            onBassBoostLevelChange = {},
            onVirtualizerLevelChange = {},
            onLyricsAutoScrollChange = {},
            onLyricsAlignmentChange = {},
            onLyricsFontSizeChange = {},
            onLyricsDimInactiveChange = {},
            onLyricsTapToSeekChange = {},
            onAlbumArtShapeChange = { selectedAlbumShape = it },
            onResetShapes = { resetCount++ },
          )
        }
      }
    }

    composeTestRule.waitForIdle()
    composeTestRule.onNodeWithText("Tùy chỉnh hình dáng").assertIsDisplayed()
    composeTestRule.onNodeWithTag("shape_album_circle").performClick()
    assertEquals("CIRCLE", selectedAlbumShape)

    composeTestRule.onNodeWithTag("personalization_detail_list")
      .performScrollToNode(hasText("Khôi phục hình dáng mặc định Rhythm"))
    composeTestRule.onNodeWithTag("reset_shapes_button").performClick()
    assertEquals(1, resetCount)
  }

  @Test
  fun `now playing queue controls and song info dialog work reliably`() {
    val s1 = Song(id = "q1", title = "Bài Một", artistName = "XuanKen", durationSeconds = 180)
    val s2 = Song(id = "q2", title = "Bài Hai", artistName = "XuanKen", durationSeconds = 190)
    val s3 = Song(id = "q3", title = "Bài Ba", artistName = "XuanKen", durationSeconds = 200)
    val playbackState = PlaybackUiState(
      currentSong = s1,
      queue = listOf(s1, s2, s3),
      currentIndex = 0,
      isPlaying = true,
      positionMs = 15_000L,
      durationMs = 180_000L,
    )
    var removedIdx = -1
    var shuffleCalls = 0
    var clearCalls = 0

    composeTestRule.setContent {
      XkMusicTheme(themeMode = ThemeMode.DARK, useDynamicColor = false) {
        Box(modifier = Modifier.size(width = 411.dp, height = 891.dp)) {
          NowPlayingSheet(
            playbackState = playbackState,
            favoriteIds = emptySet(),
            purchasedIds = setOf("q1", "q2", "q3"),
            sleepTimerState = SleepTimerUiState(),
            playCountOnDevice = 12,
            onDismiss = {},
            onTogglePlayPause = {},
            onSkipNext = {},
            onSkipPrevious = {},
            onSeekTo = {},
            onToggleShuffle = {},
            onCycleRepeat = {},
            onToggleFavorite = {},
            onPlayQueueItem = { _, _ -> },
            onRemoveQueueItem = { removedIdx = it },
            onShuffleUpcomingQueue = { shuffleCalls++ },
            onClearUpcomingQueue = { clearCalls++ },
            onOpenArtist = {},
            onPurchaseSong = {},
            onStartSleepTimer = {},
            onStartSleepAfterCurrentTrack = {},
            onCancelSleepTimer = {},
          )
        }
      }
    }

    composeTestRule.waitForIdle()
    composeTestRule.onNodeWithTag("player_queue_button").performClick()
    composeTestRule.waitForIdle()

    composeTestRule.onNodeWithTag("queue_shuffle_upcoming_button").performClick()
    assertEquals(1, shuffleCalls)

    composeTestRule.onNodeWithTag("queue_remove_1").performClick()
    assertEquals(1, removedIdx)

    composeTestRule.onNodeWithTag("queue_clear_upcoming_button").performClick()
    assertEquals(1, clearCalls)
  }

  @Test
  fun `now playing more sheet opens song info dialog`() {
    val s1 = Song(id = "q1", title = "Bài Một", artistName = "XuanKen", durationSeconds = 180)
    val playbackState = PlaybackUiState(
      currentSong = s1,
      queue = listOf(s1),
      currentIndex = 0,
      isPlaying = true,
      positionMs = 15_000L,
      durationMs = 180_000L,
    )

    composeTestRule.setContent {
      XkMusicTheme(themeMode = ThemeMode.DARK, useDynamicColor = false) {
        Box(modifier = Modifier.size(width = 411.dp, height = 891.dp)) {
          NowPlayingSheet(
            playbackState = playbackState,
            favoriteIds = emptySet(),
            purchasedIds = setOf("q1"),
            sleepTimerState = SleepTimerUiState(),
            playCountOnDevice = 12,
            onDismiss = {},
            onTogglePlayPause = {},
            onSkipNext = {},
            onSkipPrevious = {},
            onSeekTo = {},
            onToggleShuffle = {},
            onCycleRepeat = {},
            onToggleFavorite = {},
            onPlayQueueItem = { _, _ -> },
            onOpenArtist = {},
            onPurchaseSong = {},
            onStartSleepTimer = {},
            onStartSleepAfterCurrentTrack = {},
            onCancelSleepTimer = {},
          )
        }
      }
    }

    composeTestRule.waitForIdle()
    composeTestRule.onNodeWithTag("player_more_button").performClick()
    composeTestRule.waitForIdle()
    composeTestRule.onNodeWithTag("player_song_info_button").performScrollTo().performClick()
    composeTestRule.waitForIdle()
    composeTestRule.onNodeWithTag("song_info_dialog").assertIsDisplayed()
    composeTestRule.onNodeWithText("12 lượt").assertIsDisplayed()
  }

  @Test
  fun `discover listening stats card opens detailed listening insights sheet`() {
    val song = Song(id = "top_1", title = "Ca Khúc Nghe Nhiều", artistName = "XuanKen", durationSeconds = 210)
    val discoverState = DiscoverUiState(
      isLoading = false,
      popularSongs = listOf(song),
    )
    val stats = ListeningStats(
      totalListeningTimeMs = 3_720_000L,
      songsPlayedCount = 15,
      songPlayCounts = mapOf("top_1" to 9),
    )

    composeTestRule.setContent {
      XkMusicTheme(themeMode = ThemeMode.DARK, useDynamicColor = false) {
        Box(modifier = Modifier.size(width = 411.dp, height = 891.dp)) {
          DiscoverScreen(
            uiState = discoverState,
            activeTrack = ActiveTrackMeta(),
            favoriteIds = emptySet(),
            purchasedIds = setOf("top_1"),
            bottomOverlayPadding = PaddingValues(bottom = 80.dp),
            onRefresh = {},
            onOpenSearch = {},
            onPlaySong = { _, _ -> },
            onToggleFavorite = {},
            onPurchaseSong = {},
            onOpenAlbum = {},
            onOpenArtist = {},
            listeningStats = stats,
          )
        }
      }
    }

    composeTestRule.waitForIdle()
    composeTestRule.onNodeWithTag("discover_list")
      .performScrollToNode(hasTestTag("discover_listening_stats"))
    composeTestRule.onNodeWithTag("discover_listening_stats").performClick()
    composeTestRule.waitForIdle()

    composeTestRule.onNodeWithText("Thống kê nghe nhạc Rhythm").assertIsDisplayed()
    composeTestRule.onNodeWithText("Nghe nhiều nhất trên thiết bị").assertIsDisplayed()
    composeTestRule.onNodeWithTag("insights_song_top_1").assertIsDisplayed()
    composeTestRule.onNodeWithText("9 lượt").assertIsDisplayed()
  }
}
