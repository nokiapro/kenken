package com.example

import com.example.ui.FormatUtils
import com.example.ui.components.LyricsUtils
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {
  @Test
  fun formatDuration_works() {
    assertEquals("3:35", FormatUtils.formatDurationSeconds(215))
    assertEquals("--:--", FormatUtils.formatDurationSeconds(0))
    assertEquals("1:05", FormatUtils.formatDurationMs(65_000L))
  }

  @Test
  fun formatCompactCount_works() {
    assertEquals("40", FormatUtils.formatCompactCount(40L))
    assertEquals("1.5K", FormatUtils.formatCompactCount(1_500L))
    assertEquals("2.3M", FormatUtils.formatCompactCount(2_300_000L))
  }

  @Test
  fun lyricsUtils_parsesSyncedLrcAndFindsActiveLine() {
    val lrc = """
      [ti:Bài hát thử]
      [ar:XuanKen]
      [00:05.00]Câu mở đầu
      [00:12.50][00:45.00]Điệp khúc vang lên
      [00:25.125]Lời kết thúc
    """.trimIndent()

    val parsed = LyricsUtils.parse(lrc)
    assertTrue(parsed.isSynced)
    assertEquals(4, parsed.syncedLines.size)
    assertEquals(5_000L, parsed.syncedLines[0].timeMs)
    assertEquals("Câu mở đầu", parsed.syncedLines[0].text)
    assertEquals(45_000L, parsed.syncedLines[3].timeMs)

    assertEquals(-1, LyricsUtils.findActiveIndex(parsed.syncedLines, 2_000L))
    assertEquals(0, LyricsUtils.findActiveIndex(parsed.syncedLines, 6_000L))
    assertEquals(1, LyricsUtils.findActiveIndex(parsed.syncedLines, 15_000L))
    assertEquals(2, LyricsUtils.findActiveIndex(parsed.syncedLines, 26_000L))
  }

  @Test
  fun lyricsUtils_fallsBackToPlainLines() {
    val plain = "Dòng một\n\nDòng hai"
    val parsed = LyricsUtils.parse(plain)
    assertFalse(parsed.isSynced)
    assertEquals(listOf("Dòng một", "Dòng hai"), parsed.plainLines)
  }
}
